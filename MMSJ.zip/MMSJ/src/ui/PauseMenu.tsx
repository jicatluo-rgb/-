import { MWButton, Panel, Section, Slider, Toggle, Chip } from './kit';
import type { Mode } from '../game/engine';

export interface Settings {
  renderDistance: number;
  sensitivity: number;
  volume: number;
  dayNight: boolean;
  timeOfDay: number;
  bloom: boolean;
  ssr: boolean;
  ssao: boolean;
  godray: boolean;
  dof: boolean;
  motionBlur: boolean;
  hdPBR: boolean;
}

export default function PauseMenu({
  settings,
  mode,
  onChange,
  onResume,
  onSetMode,
  onTeleport,
  onQuit,
  onSave,
  onExportHTML,
  onClose,
}: {
  settings: Settings;
  mode: Mode;
  onChange: (s: Partial<Settings>) => void;
  onResume: () => void;
  onSetMode: (m: Mode) => void;
  onTeleport: () => void;
  onQuit: () => void;
  onSave: () => void;
  onExportHTML: () => void;
  onClose: () => void;
}) {
  return (
    <div className="pointer-events-auto absolute inset-0 z-20 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm">
      <Panel title="游戏菜单" onClose={onClose} className="w-full max-w-md">
        <div className="space-y-3 pt-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-sm font-black text-[#7a4b17]">模式</span>
            <Chip active={mode === 'creative'} onClick={() => onSetMode('creative')}>
              🎨 创造
            </Chip>
            <Chip active={mode === 'survival'} onClick={() => onSetMode('survival')}>
              ⚔️ 生存
            </Chip>
          </div>

          <Section title="基础设置" icon="⚙️" defaultOpen>
            <Slider
              label="🔭 视野距离（区块）"
              value={settings.renderDistance}
              min={3}
              max={10}
              onChange={(v) => onChange({ renderDistance: v })}
            />
            <Slider
              label="🖱️ 鼠标灵敏度"
              value={settings.sensitivity}
              min={0.5}
              max={3}
              step={0.1}
              onChange={(v) => onChange({ sensitivity: v })}
            />
            <Slider
              label="🔊 音量"
              value={settings.volume}
              min={0}
              max={1}
              step={0.05}
              onChange={(v) => onChange({ volume: v })}
            />
            <Toggle
              label="🌗 昼夜循环"
              checked={settings.dayNight}
              onChange={(v) => onChange({ dayNight: v })}
            />
            {!settings.dayNight && (
              <Slider
                label="🕐 一天中的时间"
                value={settings.timeOfDay}
                min={0}
                max={0.99}
                step={0.01}
                onChange={(v) => onChange({ timeOfDay: v })}
              />
            )}
          </Section>

          <Section title="画面效果（实验性，较吃性能）" icon="✨">
            <Toggle
              label="✨ 泛光光影（发光方块更亮更柔和）"
              checked={settings.bloom}
              onChange={(v) => onChange({ bloom: v })}
            />
            <Toggle
              label="🪞 反射 SSR（水面/冰面反射周围场景）"
              checked={settings.ssr}
              onChange={(v) => onChange({ ssr: v })}
            />
            <Toggle
              label="🌑 环境光遮蔽 SSAO（缝隙墙角暗部层次）"
              checked={settings.ssao}
              onChange={(v) => onChange({ ssao: v })}
            />
            <Toggle
              label="🌫️ 体积光/丁达尔（树冠/缝隙间的光柱）"
              checked={settings.godray}
              onChange={(v) => onChange({ godray: v })}
            />
            <Toggle
              label="🎯 景深（准星瞄准处清楚，远近虚化）"
              checked={settings.dof}
              onChange={(v) => onChange({ dof: v })}
            />
            <Toggle
              label="💨 动态模糊（快速转视角时的轻微拖影）"
              checked={settings.motionBlur}
              onChange={(v) => onChange({ motionBlur: v })}
            />
            <Toggle
              label="🧱 HD PBR 材质包（泥土/石头/矿石/羊毛/玻璃等 69 种方块，真实贴图，首次开启需要加载）"
              checked={settings.hdPBR}
              onChange={(v) => onChange({ hdPBR: v })}
            />
          </Section>

          <div className="grid grid-cols-2 gap-2 pt-1">
            <MWButton onClick={() => onChange({ timeOfDay: 0.28, dayNight: settings.dayNight })} variant="orange">
              ☀️ 白天
            </MWButton>
            <MWButton onClick={() => onChange({ timeOfDay: 0.8, dayNight: settings.dayNight })} variant="blue">
              🌙 夜晚
            </MWButton>
            <MWButton onClick={onTeleport} variant="pink">
              🚀 回到地面
            </MWButton>
            <MWButton onClick={onSave} variant="green">
              💾 保存进度
            </MWButton>
            <MWButton onClick={onExportHTML} variant="pink">
              📦 复制/导出单HTML
            </MWButton>
            <MWButton onClick={onQuit} variant="gray" className="col-span-2">
              🏠 保存并返回主菜单
            </MWButton>
          </div>

          <MWButton className="w-full py-3 text-lg" onClick={onResume}>
            ▶ 继续游戏
          </MWButton>
        </div>
      </Panel>
    </div>
  );
}
