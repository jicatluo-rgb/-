import { useMemo, useState } from 'react';
import { Panel, Chip } from './kit';
import { BLOCKS, CATEGORIES } from '../game/blocks';
import { RECIPES, recipePatternSize } from '../game/crafting';
import { blockIcon, itemIcon, toolIcon } from '../game/textures';
import { getItemName, INV_SIZE, isToolId, type ItemStack } from '../game/items';
import SlotGrid, { type HeldStack } from './SlotGrid';
import { cn } from '../utils/cn';

export default function Inventory({
  inv,
  selected,
  mode,
  craft2,
  craft2Result,
  onAssign,
  onMove,
  onQuickMove,
  onTakeResult,
  onLoadRecipe,
  onClose,
}: {
  inv: (ItemStack | null)[];
  selected: number;
  mode: 'creative' | 'survival';
  craft2: (ItemStack | null)[];
  craft2Result: ItemStack | null;
  onAssign: (blockId: number) => void;
  onMove: (fromZone: string, fromIdx: number, toZone: string, toIdx: number) => void;
  onQuickMove: (zone: string, idx: number) => void;
  onTakeResult: () => void;
  onLoadRecipe: (recipeId: string) => void;
  onClose: () => void;
}) {
  const [tab, setTab] = useState<'blocks' | 'craft'>('blocks');
  const [cat, setCat] = useState<string>(CATEGORIES[0]);
  const [q, setQ] = useState('');
  const [held, setHeld] = useState<HeldStack | null>(null);

  const ownedIds = useMemo(() => {
    const set = new Set<number>();
    inv.forEach((s) => s && set.add(s.id));
    return set;
  }, [inv]);

  const palette = useMemo(
    () =>
      BLOCKS.filter(
        (block) =>
          block.id !== 0 &&
          block.id !== 11 &&
          block.id !== 16 &&
          block.id !== 17 &&
          (mode === 'creative' || ownedIds.has(block.id)) &&
          (q ? block.name.includes(q) : block.category === cat),
      ).map((block) => ({ ...block, icon: blockIcon(block.id, 84) })),
    [cat, mode, ownedIds, q],
  );

  const getStack = (zone: string, idx: number): ItemStack | null =>
    zone === 'inv' ? inv[idx] ?? null : zone === 'craft2' ? craft2[idx] ?? null : null;

  const handlePick = (zone: string, idx: number) => {
    if (held) {
      if (held.zone === zone && held.idx === idx) {
        setHeld(null);
        return;
      }
      onMove(held.zone, held.idx, zone, idx);
      setHeld(null);
      return;
    }
    const stack = getStack(zone, idx);
    if (stack) setHeld({ zone, idx, stack });
  };

  const resultIcon = craft2Result
    ? isToolId(craft2Result.id)
      ? toolIcon(craft2Result.id, 72)
      : craft2Result.id >= 200
        ? itemIcon(craft2Result.id, 72)
        : blockIcon(craft2Result.id, 72)
    : '';

  return (
    <div className="pointer-events-auto absolute inset-0 z-20 flex items-center justify-center bg-black/45 p-4 backdrop-blur-sm">
      <Panel title="背包与合成" onClose={onClose} className="w-full max-w-3xl">
        <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
          <Chip active={tab === 'blocks'} onClick={() => setTab('blocks')}>
            🎒 背包
          </Chip>
          <Chip active={tab === 'craft'} onClick={() => setTab('craft')}>
            📖 配方手册
          </Chip>
          <span className="text-xs font-black text-[#a5713f]">
            {mode === 'creative' ? '创造模式' : '生存模式'}
          </span>
        </div>

        {/* 2x2 个人合成（MC 背包自带） */}
        <div className="mt-3 flex items-center justify-center gap-3 rounded-2xl border-[3px] border-[#e9c48d] bg-[#fffaf0]/80 p-2">
          <div className="text-center">
            <div className="mb-1 text-[10px] font-black text-[#a5713f]">2×2 合成</div>
            <SlotGrid
              slots={craft2}
              zone="craft2"
              held={held}
              onPick={handlePick}
              onMove={onMove}
              onQuickMove={onQuickMove}
              infinite={mode === 'creative'}
            />
          </div>
          <div className="text-2xl text-[#ff9f1c]">➜</div>
          <div className="text-center">
            <div className="mb-1 text-[10px] font-black text-[#a5713f]">成品</div>
            <button
              onClick={onTakeResult}
              disabled={!craft2Result}
              className={cn(
                'flex h-12 w-12 items-center justify-center rounded-xl border-[3px]',
                craft2Result
                  ? 'border-[#ffd166] bg-white/90 hover:scale-105'
                  : 'border-white/40 bg-white/20',
              )}
            >
              {resultIcon ? (
                <img src={resultIcon} alt="" className="h-10 w-10" draggable={false} />
              ) : (
                <span className="text-xs text-white/40">?</span>
              )}
            </button>
          </div>
        </div>

        {tab === 'blocks' ? (
          <>
            <div className="mt-2 flex flex-wrap items-center gap-2">
              {CATEGORIES.map((category) => (
                <Chip
                  key={category}
                  active={!q && cat === category}
                  onClick={() => {
                    setCat(category);
                    setQ('');
                  }}
                >
                  {category}
                </Chip>
              ))}
              <input
                value={q}
                onChange={(event) => setQ(event.target.value)}
                placeholder="搜索方块..."
                className="ml-auto w-36 rounded-xl border-[3px] border-[#e9c48d] bg-white/90 px-3 py-1.5 text-sm font-bold text-[#7a4b17] outline-none placeholder:text-[#c8a375] focus:border-[#ff9f1c]"
              />
            </div>

            <div className="mt-2 grid max-h-[26vh] grid-cols-6 gap-2 overflow-y-auto rounded-2xl border-[3px] border-[#e9c48d] bg-[#fffaf0]/80 p-3 sm:grid-cols-9">
              {palette.map((block) => (
                <button
                  key={block.id}
                  onClick={() => onAssign(block.id)}
                  className={cn(
                    'flex flex-col items-center gap-0.5 rounded-xl border-[3px] p-1 transition',
                    inv.some((s) => s?.id === block.id)
                      ? 'border-[#4fae3a] bg-[#eaffdf]'
                      : 'border-white bg-white/80 hover:-translate-y-0.5 hover:border-[#ffd166]',
                  )}
                >
                  <img src={block.icon} alt={block.name} className="h-9 w-9" draggable={false} />
                  <span className="text-[9px] font-black leading-none text-[#7a4b17]">{block.name}</span>
                </button>
              ))}
              {palette.length === 0 && (
                <div className="col-span-full py-4 text-center text-sm font-bold text-[#a5713f]">
                  挖掘方块、探索遗迹或打开宝箱来收集材料吧
                </div>
              )}
            </div>
          </>
        ) : (
          <div className="mt-2 grid max-h-[30vh] grid-cols-1 gap-2 overflow-y-auto pr-1 sm:grid-cols-2">
            {RECIPES.map((recipe) => {
              const { w, h } = recipePatternSize(recipe);
              const fits2x2 = w <= 2 && h <= 2;
              return (
                <div
                  key={recipe.id}
                  className="flex items-center gap-3 rounded-2xl border-[3px] border-[#e9c48d] bg-white/75 p-2"
                >
                  {/* mini pattern */}
                  <div className="grid shrink-0 grid-cols-3 gap-0.5 rounded-lg bg-[#5b3d22] p-1">
                    {Array.from({ length: 9 }, (_, i) => {
                      const y = Math.floor(i / 3);
                      const x = i % 3;
                      const cell = y < recipe.pattern.length ? recipe.pattern[y][x] : 0;
                      return (
                        <div
                          key={i}
                          className="flex h-6 w-6 items-center justify-center rounded-sm bg-black/35"
                        >
                          {cell ? (
                            <img
                              src={
                                isToolId(cell)
                                  ? toolIcon(cell, 32)
                                  : cell >= 200
                                    ? itemIcon(cell, 32)
                                    : blockIcon(cell, 32)
                              }
                              alt=""
                              className="h-5 w-5"
                            />
                          ) : null}
                        </div>
                      );
                    })}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-black text-[#7a4b17]">
                      {recipe.name}{' '}
                      <span className="text-[#ff9f1c]">
                        → {getItemName(recipe.output.id)} x{recipe.output.count}
                      </span>
                    </div>
                    <div className="text-[9px] font-bold text-[#a5713f]">{recipe.desc}</div>
                  </div>
                  <button
                    onClick={() => onLoadRecipe(recipe.id)}
                    disabled={!fits2x2}
                    title={fits2x2 ? '放入 2x2 合成' : '需要工作台（3x3）'}
                    className={cn(
                      'shrink-0 rounded-xl border-2 px-2 py-1 text-[10px] font-black',
                      fits2x2
                        ? 'border-white bg-gradient-to-b from-[#8ede63] to-[#4fae3a] text-white shadow-[0_3px_0_#2f7f2a]'
                        : 'border-[#e9c48d] bg-white/60 text-[#c8a375]',
                    )}
                  >
                    {fits2x2 ? '摆料' : '需工作台'}
                  </button>
                </div>
              );
            })}
          </div>
        )}

        {/* 36-slot inventory */}
        <div className="mt-3">
          <div className="mb-1 text-xs font-black text-[#7a4b17]">
            我的背包（{INV_SIZE} 格）· 拖拽移动 / 点击拾取 / Shift 快速转移
          </div>
          <div className="rounded-2xl border-[3px] border-[#b98a53] bg-gradient-to-b from-[#5b3d22] to-[#3b2716] p-2">
            <SlotGrid
              slots={inv}
              zone="inv"
              selected={selected}
              held={held}
              onPick={handlePick}
              onMove={onMove}
              onQuickMove={onQuickMove}
              infinite={mode === 'creative'}
            />
          </div>
        </div>
      </Panel>
    </div>
  );
}
