import { useEffect, useMemo, useRef, useState } from 'react';
import { MWButton, Panel } from './kit';
import { cn } from '../utils/cn';

/** 迷你家园：养一株植物（浇水/施肥/光照 → 成长 → 收获金币与道具） */

export interface PlantState {
  stage: number; // 0 种子 … 5 成熟
  growth: number; // 0-100 当前阶段进度
  water: number; // 0-100
  light: number; // 0-100
  fert: number; // 0-100
  lastTick: number;
  harvests: number;
  name: string;
  log: string[];
}

const STAGE_NAMES = ['种子', '嫩芽', '幼苗', '抽枝', '开花', '结果'];
const DEFAULT: PlantState = {
  stage: 0,
  growth: 0,
  water: 60,
  light: 50,
  fert: 30,
  lastTick: Date.now(),
  harvests: 0,
  name: '小绿',
  log: ['🌱 你把一颗神秘的种子埋进了花盆'],
};

function load(): PlantState {
  try {
    const raw = localStorage.getItem('msw-plant');
    if (!raw) return DEFAULT;
    return { ...DEFAULT, ...(JSON.parse(raw) as PlantState) };
  } catch {
    return DEFAULT;
  }
}

export default function HomePlant({
  coins,
  onReward,
  onClose,
  embedded,
}: {
  coins: number;
  onReward: (amount: number) => void;
  onClose: () => void;
  /** 嵌在主界面内容区时隐藏关闭按钮 */
  embedded?: boolean;
}) {
  const [p, setP] = useState<PlantState>(load);
  const [msg, setMsg] = useState<string | null>(null);
  const [watering, setWatering] = useState(false);
  const timer = useRef<number | null>(null);

  // 真实时间推进成长（离线也会长）
  useEffect(() => {
    const apply = (state: PlantState): PlantState => {
      const now = Date.now();
      const hours = Math.min(48, (now - state.lastTick) / 3600000);
      if (hours <= 0) return state;
      let { stage, growth, water, light, fert } = state;
      water = Math.max(0, water - hours * 6);
      light = Math.max(0, light - hours * 4);
      fert = Math.max(0, fert - hours * 3);
      const health = (water > 15 ? 1 : 0) + (light > 15 ? 1 : 0) + (fert > 10 ? 0.6 : 0);
      growth += hours * 22 * Math.max(0.15, health / 2.6);
      while (growth >= 100 && stage < 5) {
        growth -= 100;
        stage += 1;
      }
      if (stage >= 5) growth = Math.min(100, growth);
      return { ...state, stage, growth, water, light, fert, lastTick: now };
    };
    setP((s) => {
      const next = apply(s);
      localStorage.setItem('msw-plant', JSON.stringify(next));
      return next;
    });
    timer.current = window.setInterval(() => {
      setP((s) => {
        const next = apply(s);
        localStorage.setItem('msw-plant', JSON.stringify(next));
        return next;
      });
    }, 3000);
    return () => {
      if (timer.current) window.clearInterval(timer.current);
    };
  }, []);

  const push = (text: string) => {
    setMsg(text);
    setTimeout(() => setMsg(null), 2200);
    setP((s) => {
      const next = { ...s, log: [text, ...s.log].slice(0, 12) };
      localStorage.setItem('msw-plant', JSON.stringify(next));
      return next;
    });
  };

  const act = (kind: 'water' | 'fert' | 'light') => {
    const cost = kind === 'fert' ? 10 : 0;
    if (cost > coins) {
      push('🪙 金币不足，无法施肥');
      return;
    }
    if (cost) onReward(-cost);
    if (kind === 'water') setWatering(true);
    setP((s) => {
      const next = {
        ...s,
        water: kind === 'water' ? Math.min(100, s.water + 34) : s.water,
        fert: kind === 'fert' ? Math.min(100, s.fert + 45) : s.fert,
        light: kind === 'light' ? Math.min(100, s.light + 40) : s.light,
      };
      localStorage.setItem('msw-plant', JSON.stringify(next));
      return next;
    });
    push(
      kind === 'water' ? '💧 浇水完成，土壤湿润了' : kind === 'fert' ? '🧪 施肥完成，营养满满' : '☀️ 搬到阳光下晒了晒',
    );
    if (kind === 'water') setTimeout(() => setWatering(false), 900);
  };

  const canHarvest = p.stage >= 5 && p.growth >= 100;
  const harvest = () => {
    if (!canHarvest) return;
    const reward = 60 + p.harvests * 10;
    onReward(reward);
    push(`🎉 收获了成熟的果实！获得 ${reward} 金币`);
    setP((s) => {
      const next: PlantState = {
        ...s,
        stage: 1,
        growth: 0,
        water: 70,
        light: 60,
        fert: 40,
        harvests: s.harvests + 1,
      };
      localStorage.setItem('msw-plant', JSON.stringify(next));
      return next;
    });
  };

  const overall = useMemo(
    () => Math.min(100, ((p.stage + p.growth / 100) / 5) * 100),
    [p.stage, p.growth],
  );

  return (
    <Panel title="迷你家园 · 我的植物" onClose={embedded ? undefined : onClose} className="w-full">
      <div className="grid gap-4 md:grid-cols-[1.05fr_1fr]">
        {/* 花盆场景 */}
        <div className="relative overflow-hidden rounded-3xl border-[4px] border-white/80 bg-gradient-to-b from-[#bfe6ff] via-[#dff3ff] to-[#c9e8b0] p-4">
          {/* 阳光/天气 */}
          <div
            className={cn(
              'absolute right-4 top-4 h-16 w-16 rounded-full transition-all duration-700',
              p.light > 50 ? 'bg-[#ffd166] shadow-[0_0_40px_rgba(255,209,102,0.9)]' : 'bg-[#f5f0e0] opacity-60',
            )}
          />
          {p.light <= 50 && (
            <>
              <div className="absolute right-2 top-6 h-8 w-14 rounded-full bg-white/85" />
              <div className="absolute right-10 top-3 h-7 w-12 rounded-full bg-white/70" />
            </>
          )}
          {watering && (
            <div className="pointer-events-none absolute inset-x-0 top-0 h-40">
              {Array.from({ length: 26 }, (_, i) => (
                <span
                  key={i}
                  className="absolute h-4 w-1 rounded-full bg-[#7cd4ff]/80"
                  style={{
                    left: `${4 + i * 3.6}%`,
                    animation: `rainfall 0.9s linear ${i * 0.03}s infinite`,
                  }}
                />
              ))}
            </div>
          )}

          {/* 植物 */}
          <div className="relative mt-16 flex h-44 items-end justify-center">
            <PlantArt stage={p.stage} growth={p.growth} healthy={p.water > 15 && p.light > 15} />
          </div>

          {/* 花盆 */}
          <div className="relative mx-auto h-16 w-44">
            <div className="absolute inset-x-0 top-0 h-5 rounded-t-xl bg-gradient-to-b from-[#e07a4a] to-[#c25e33]" />
            <div className="absolute inset-x-3 top-4 h-12 rounded-b-[22px] bg-gradient-to-b from-[#c25e33] to-[#9c4526]" />
            <div className="absolute inset-x-6 top-3 h-3 rounded-full bg-[#5b3a22]" />
          </div>
          <div className="mt-2 text-center text-xs font-black text-[#3b4a2f]">
            「{p.name}」· {STAGE_NAMES[p.stage]} · 已收获 {p.harvests} 次
          </div>
        </div>

        {/* 状态与操作 */}
        <div className="space-y-3">
          <Bar label="🌱 总成长" value={overall} color="from-[#8ede63] to-[#3f9a2e]" />
          <Bar label="💧 水分" value={p.water} color="from-[#7cd4ff] to-[#2f9fe0]" warn={p.water <= 15} />
          <Bar label="☀️ 光照" value={p.light} color="from-[#ffd166] to-[#ff9f1c]" warn={p.light <= 15} />
          <Bar label="🧪 养分" value={p.fert} color="from-[#ffa6cd] to-[#ff5fa2]" warn={p.fert <= 10} />

          <div className="grid grid-cols-3 gap-2 pt-1">
            <MWButton className="px-2 py-2 text-xs" onClick={() => act('water')}>💧 浇水</MWButton>
            <MWButton className="px-2 py-2 text-xs" variant="pink" onClick={() => act('fert')}>🧪 施肥 10🪙</MWButton>
            <MWButton className="px-2 py-2 text-xs" variant="orange" onClick={() => act('light')}>☀️ 晒太阳</MWButton>
          </div>

          <MWButton className="w-full py-3 text-base" variant={canHarvest ? 'green' : 'gray'} onClick={harvest}>
            {canHarvest ? `🎉 收获果实（+${60 + p.harvests * 10} 🪙）` : '⏳ 还没成熟，再等等'}
          </MWButton>

          {msg && (
            <div className="animate-[pop_0.25s_ease-out] rounded-2xl border-[3px] border-white bg-gradient-to-b from-[#e7ffd9] to-[#c6f0a8] px-3 py-2 text-center text-xs font-black text-[#3f6b28]">
              {msg}
            </div>
          )}

          <div className="max-h-28 overflow-y-auto rounded-2xl border-[3px] border-[#e9c48d] bg-white/70 p-2">
            <div className="mb-1 text-[10px] font-black text-[#a5713f]">📖 家园日志</div>
            {p.log.map((line, i) => (
              <div key={i} className="text-[10px] font-bold text-[#7a4b17]">{line}</div>
            ))}
          </div>

          <p className="text-[10px] font-bold leading-relaxed text-[#a5713f]">
            💡 保持水分、光照与养分充足，植物会随真实时间成长（关掉游戏也在长）。成熟后收获可得金币，收获次数越多奖励越高。
          </p>
        </div>
      </div>
    </Panel>
  );
}

function Bar({ label, value, color, warn }: { label: string; value: number; color: string; warn?: boolean }) {
  return (
    <div>
      <div className="mb-0.5 flex justify-between text-[11px] font-black text-[#7a4b17]">
        <span>{label}</span>
        <span className={warn ? 'text-[#e63946]' : 'text-[#a5713f]'}>{Math.round(value)}%</span>
      </div>
      <div className="h-3 overflow-hidden rounded-full border-2 border-white bg-[#e9c48d]/60">
        <div
          className={cn('h-full rounded-full bg-gradient-to-r transition-[width] duration-500', color)}
          style={{ width: `${Math.max(0, Math.min(100, value))}%` }}
        />
      </div>
    </div>
  );
}

/** 随成长阶段变化的植物造型（纯 CSS/SVG，带摆动动画） */
function PlantArt({ stage, growth, healthy }: { stage: number; growth: number; healthy: boolean }) {
  const sway = healthy ? 'plant-sway' : 'plant-sad';
  const h = 24 + stage * 26 + (growth / 100) * 18;
  return (
    <div className="relative flex flex-col items-center" style={{ animation: `${sway} 3.4s ease-in-out infinite` }}>
      {stage >= 4 && (
        <div className="absolute -top-2 flex gap-1">
          {['#ff6b6b', '#ffd166', '#ff8fb3'].map((c, i) => (
            <span key={i} className="block h-5 w-5 rounded-full border-2 border-white/80" style={{ background: c }} />
          ))}
        </div>
      )}
      {stage >= 5 && (
        <div className="absolute -top-8 flex gap-2">
          {['#ff5d6c', '#ff9f1c'].map((c, i) => (
            <span
              key={i}
              className="block h-7 w-7 rounded-full border-2 border-white shadow-lg"
              style={{ background: `radial-gradient(circle at 35% 30%, #fff, ${c})` }}
            />
          ))}
        </div>
      )}
      {stage >= 2 && (
        <>
          <Leaf side="left" top={h * 0.42} size={16 + stage * 3} />
          <Leaf side="right" top={h * 0.6} size={14 + stage * 3} />
        </>
      )}
      {stage >= 3 && <Leaf side="left" top={h * 0.76} size={12 + stage * 2} />}
      <div
        className={cn('w-2 rounded-t-full', healthy ? 'bg-[#4fae3a]' : 'bg-[#8a9a6a]')}
        style={{ height: h }}
      />
      {stage === 0 && (
        <div className="absolute bottom-0 h-4 w-6 rounded-full bg-[#6b4326]" />
      )}
      {stage === 1 && (
        <div className="absolute -top-1 flex gap-0.5">
          <span className="block h-3 w-2 rounded-full bg-[#6ec949]" />
          <span className="block h-3 w-2 rounded-full bg-[#8ede63]" />
        </div>
      )}
    </div>
  );
}

function Leaf({ side, top, size }: { side: 'left' | 'right'; top: number; size: number }) {
  return (
    <span
      className="absolute block rounded-[60%_40%_60%_40%] bg-gradient-to-br from-[#8ede63] to-[#3f9a2e]"
      style={{
        width: size,
        height: size * 0.62,
        bottom: top,
        [side]: size * 0.4,
        transform: side === 'left' ? 'rotate(-22deg)' : 'rotate(22deg)',
      }}
    />
  );
}
