import { useEffect, useRef, useState } from 'react';
import type { ItemStack } from '../game/items';
import { MAX_STACK, getItemName, getTool, isToolId } from '../game/items';
import { blockIcon, toolIcon } from '../game/textures';
import { cn } from '../utils/cn';

export interface HeldStack {
  zone: string;
  idx: number;
  stack: ItemStack;
}

/**
 * Minecraft-style slot grid.
 * - Drag a stack onto another slot to move / merge / swap.
 * - Click a slot to pick it up, click again to put it down.
 * - Shift + click quickly moves a whole stack.
 */
export default function SlotGrid({
  slots,
  zone,
  offset = 0,
  selected,
  held,
  onPick,
  onMove,
  onQuickMove,
  infinite,
  disabled,
}: {
  slots: (ItemStack | null)[];
  zone: string;
  offset?: number;
  selected?: number;
  held?: HeldStack | null;
  onPick: (zone: string, idx: number) => void;
  onMove: (fromZone: string, fromIdx: number, toZone: string, toIdx: number) => void;
  onQuickMove: (zone: string, idx: number) => void;
  infinite?: boolean;
  disabled?: boolean;
}) {
  return <SlotGridInner slots={slots} zone={zone} offset={offset} selected={selected} held={held} onPick={onPick} onMove={onMove} onQuickMove={onQuickMove} infinite={infinite} disabled={disabled} />;
}

function SlotGridInner({
  slots,
  zone,
  offset = 0,
  selected,
  held,
  onPick: onPickProp,
  onMove: onMoveProp,
  onQuickMove: onQuickMoveProp,
  infinite,
  disabled,
}: {
  slots: (ItemStack | null)[];
  zone: string;
  offset?: number;
  selected?: number;
  held?: HeldStack | null;
  onPick: (zone: string, idx: number) => void;
  onMove: (fromZone: string, fromIdx: number, toZone: string, toIdx: number) => void;
  onQuickMove: (zone: string, idx: number) => void;
  infinite?: boolean;
  disabled?: boolean;
}) {
  const [drag, setDrag] = useState<{ zone: string; idx: number; stack: ItemStack; x: number; y: number } | null>(null);
  const [cursor, setCursor] = useState<{ x: number; y: number } | null>(null);
  const startRef = useRef<{
    zone: string;
    idx: number;
    stack: ItemStack | null;
    x: number;
    y: number;
    moved: boolean;
  } | null>(null);

  useEffect(() => {
    const handlePointerMove = (e: PointerEvent) => {
      setCursor({ x: e.clientX, y: e.clientY });
      const st = startRef.current;
      if (!st) return;
      if (!st.moved && Math.hypot(e.clientX - st.x, e.clientY - st.y) > 7) {
        st.moved = true;
        if (st.stack) setDrag({ zone: st.zone, idx: st.idx, stack: st.stack, x: e.clientX, y: e.clientY });
      } else if (st.moved && st.stack) {
        setDrag((d) => (d ? { ...d, x: e.clientX, y: e.clientY } : d));
      }
    };
    const handlePointerUp = (e: PointerEvent) => {
      const st = startRef.current;
      startRef.current = null;
      setDrag(null);
      if (!st) return;
      if (st.moved && st.stack) {
        const el = document.elementFromPoint(e.clientX, e.clientY);
        const target = el?.closest?.('[data-slot]') as HTMLElement | null;
        if (target) {
          onMoveProp(st.zone, st.idx, target.dataset.zone ?? zone, Number(target.dataset.idx));
        }
      } else {
        if (e.shiftKey) onQuickMoveProp(st.zone, st.idx);
        else onPickProp(st.zone, st.idx);
      }
    };
    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerup', handlePointerUp);
    return () => {
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
    };
  }, [onMoveProp, onPickProp, onQuickMoveProp]);

  const ghostStack = drag?.stack ?? held?.stack ?? null;

  return (
    <div className="relative">
      <div className="grid grid-cols-9 gap-1.5">
        {slots.map((stack, i) => {
          const globalIdx = offset + i;
          const isHeld = held?.zone === zone && held.idx === globalIdx;
          const isSelected = zone === 'inv' && selected === globalIdx && globalIdx < 9;
          return (
            <div
              key={i}
              data-slot=""
              data-zone={zone}
              data-idx={globalIdx}
              onPointerDown={(e) => {
                if (disabled || e.button !== 0) return;
                startRef.current = {
                  zone,
                  idx: globalIdx,
                  stack: slots[i] ? { ...slots[i]! } : null,
                  x: e.clientX,
                  y: e.clientY,
                  moved: false,
                };
                e.preventDefault();
              }}
              className={cn(
                'relative flex h-12 w-12 items-center justify-center rounded-xl border-[3px] select-none',
                isHeld
                  ? 'border-dashed border-[#ffd166]/80 bg-white/10'
                  : 'border-white/50 bg-black/30 hover:bg-black/45',
                isSelected && 'border-[#ffd166] bg-[#5b3d22]/90 shadow-[0_0_12px_rgba(255,209,102,0.7)]',
              )}
            >
              {!isHeld && stack ? (
                <>
                  <img
                    src={isToolId(stack.id) ? toolIcon(stack.id, 64) : blockIcon(stack.id, 64)}
                    alt={getItemName(stack.id)}
                    className="pointer-events-none h-9 w-9"
                    draggable={false}
                  />
                  {isToolId(stack.id) ? (
                    <div className="absolute -bottom-0.5 left-1 right-1 h-1 overflow-hidden rounded-full bg-black/70">
                      <div
                        className={cn(
                          'h-full',
                          stack.count > (getTool(stack.id)?.durability ?? 1) * 0.4
                            ? 'bg-[#8ede63]'
                            : stack.count > (getTool(stack.id)?.durability ?? 1) * 0.15
                              ? 'bg-[#ffd166]'
                              : 'bg-[#ff5d6c]',
                        )}
                        style={{
                          width: `${Math.max(0, Math.min(1, stack.count / (getTool(stack.id)?.durability ?? 1))) * 100}%`,
                        }}
                      />
                    </div>
                  ) : (
                    <span className="absolute bottom-0 right-0.5 text-[10px] font-black text-white drop-shadow-[0_1px_1px_rgba(0,0,0,0.9)]">
                      {infinite ? '∞' : stack.count}
                    </span>
                  )}
                </>
              ) : (
                !isHeld && <span className="text-xs text-white/15">·</span>
              )}
            </div>
          );
        })}
      </div>

      {(drag || held) && cursor && ghostStack && (
        <div
          className="pointer-events-none fixed z-50 -translate-x-1/2 -translate-y-1/2"
          style={{ left: cursor.x, top: cursor.y }}
        >
          <img
            src={blockIcon(ghostStack.id, 64)}
            alt=""
            className="h-11 w-11 rounded-lg border-2 border-white/80 bg-black/50 shadow-xl"
            draggable={false}
          />
        </div>
      )}
    </div>
  );
}

export function stackCount(inv: (ItemStack | null)[], blockId: number) {
  return inv.reduce((sum, s) => sum + (s && s.id === blockId ? s.count : 0), 0);
}

export { MAX_STACK };
