import { useRef, useState } from 'react';
import { cn } from '../utils/cn';

interface Props {
  onMove: (x: number, z: number) => void;
  onLook: (dx: number, dy: number) => void;
  onJump: () => void;
  onPlace: () => void;
  onBreak: (down: boolean) => void;
  onToggleFly: () => void;
  flying: boolean;
  creative: boolean;
}

export default function TouchControls({
  onMove,
  onLook,
  onJump,
  onPlace,
  onBreak,
  onToggleFly,
  flying,
  creative,
}: Props) {
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const joyRef = useRef<HTMLDivElement>(null);
  const joyId = useRef<number | null>(null);
  const lookId = useRef<number | null>(null);
  const lookLast = useRef({ x: 0, y: 0, t: 0, moved: 0 });
  const holdTimer = useRef<number | null>(null);

  const handleJoyMove = (clientX: number, clientY: number) => {
    const el = joyRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const cx = r.left + r.width / 2;
    const cy = r.top + r.height / 2;
    let dx = clientX - cx;
    let dy = clientY - cy;
    const max = r.width / 2;
    const d = Math.hypot(dx, dy);
    if (d > max) {
      dx = (dx / d) * max;
      dy = (dy / d) * max;
    }
    setKnob({ x: dx, y: dy });
    onMove(dx / max, dy / max);
  };

  return (
    <>
      {/* look / tap layer */}
      <div
        className="pointer-events-auto absolute inset-0 z-0"
        onPointerDown={(e) => {
          if (lookId.current !== null) return;
          lookId.current = e.pointerId;
          lookLast.current = { x: e.clientX, y: e.clientY, t: performance.now(), moved: 0 };
          holdTimer.current = window.setTimeout(() => onBreak(true), 260);
        }}
        onPointerMove={(e) => {
          if (lookId.current !== e.pointerId) return;
          const dx = e.clientX - lookLast.current.x;
          const dy = e.clientY - lookLast.current.y;
          lookLast.current.x = e.clientX;
          lookLast.current.y = e.clientY;
          lookLast.current.moved += Math.hypot(dx, dy);
          if (lookLast.current.moved > 10 && holdTimer.current) {
            clearTimeout(holdTimer.current);
            holdTimer.current = null;
            onBreak(false);
          }
          onLook(dx, dy);
        }}
        onPointerUp={(e) => {
          if (lookId.current !== e.pointerId) return;
          lookId.current = null;
          if (holdTimer.current) {
            clearTimeout(holdTimer.current);
            holdTimer.current = null;
            const quick = performance.now() - lookLast.current.t < 260 && lookLast.current.moved < 10;
            if (quick) {
              onBreak(true);
              window.setTimeout(() => onBreak(false), 220);
              return;
            }
          }
          onBreak(false);
        }}
        onPointerCancel={() => {
          lookId.current = null;
          onBreak(false);
        }}
      />

      {/* joystick */}
      <div
        ref={joyRef}
        className="pointer-events-auto absolute bottom-24 left-6 z-10 h-36 w-36 rounded-full border-[5px] border-white/80 bg-white/25 backdrop-blur-sm"
        onPointerDown={(e) => {
          joyId.current = e.pointerId;
          (e.target as HTMLElement).setPointerCapture(e.pointerId);
          handleJoyMove(e.clientX, e.clientY);
        }}
        onPointerMove={(e) => {
          if (joyId.current !== e.pointerId) return;
          handleJoyMove(e.clientX, e.clientY);
        }}
        onPointerUp={() => {
          joyId.current = null;
          setKnob({ x: 0, y: 0 });
          onMove(0, 0);
        }}
        onPointerCancel={() => {
          joyId.current = null;
          setKnob({ x: 0, y: 0 });
          onMove(0, 0);
        }}
      >
        <div
          className="pointer-events-none absolute left-1/2 top-1/2 h-16 w-16 rounded-full border-[4px] border-white bg-gradient-to-b from-[#ffd166] to-[#ff9f1c] shadow-lg"
          style={{ transform: `translate(-50%, -50%) translate(${knob.x}px, ${knob.y}px)` }}
        />
      </div>

      {/* action buttons */}
      <div className="pointer-events-auto absolute bottom-24 right-5 z-10 flex flex-col items-end gap-3">
        <div className="flex gap-3">
          {creative && (
            <TouchBtn onClick={onToggleFly} active={flying} className="h-14 w-14 text-xl">
              ✈️
            </TouchBtn>
          )}
          <TouchBtn onClick={onJump} className="h-16 w-16 text-2xl">
            ⬆️
          </TouchBtn>
        </div>
        <div className="flex gap-3">
          <TouchBtn
            onPointerDown={() => onBreak(true)}
            onPointerUp={() => onBreak(false)}
            className="h-16 w-16 bg-gradient-to-b from-[#ffa6cd] to-[#ff5fa2] text-2xl"
          >
            ⛏️
          </TouchBtn>
          <TouchBtn onClick={onPlace} className="h-16 w-16 bg-gradient-to-b from-[#8ede63] to-[#4fae3a] text-2xl">
            🧱
          </TouchBtn>
        </div>
      </div>
    </>
  );
}

function TouchBtn({
  children,
  onClick,
  onPointerDown,
  onPointerUp,
  className,
  active,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  onPointerDown?: () => void;
  onPointerUp?: () => void;
  className?: string;
  active?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      onPointerDown={onPointerDown}
      onPointerUp={onPointerUp}
      onPointerLeave={onPointerUp}
      className={cn(
        'flex items-center justify-center rounded-full border-[4px] border-white text-white shadow-[0_5px_0_rgba(0,0,0,0.3)] transition active:translate-y-1 active:shadow-none',
        active ? 'bg-gradient-to-b from-[#8ede63] to-[#4fae3a]' : 'bg-gradient-to-b from-[#7cd4ff] to-[#2f9fe0]',
        className,
      )}
    >
      {children}
    </button>
  );
}
