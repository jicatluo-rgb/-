import type { ReactNode } from 'react';
import { cn } from '../utils/cn';

/** Chunky wooden / candy panel used across the mini-world UI. */
export function Panel({
  children,
  className,
  bodyClassName,
  title,
  onClose,
}: {
  children: ReactNode;
  className?: string;
  bodyClassName?: string;
  title?: string;
  onClose?: () => void;
}) {
  return (
    <div
      className={cn(
        'relative flex max-h-[85vh] flex-col rounded-[28px] border-[5px] border-white/95 bg-gradient-to-b from-[#fff7e6] to-[#ffe6bd] shadow-[0_14px_0_rgba(120,74,32,0.35),0_24px_50px_rgba(0,0,0,0.35)]',
        className,
      )}
    >
      <div className="pointer-events-none absolute inset-[3px] rounded-[22px] border-2 border-[#e9c48d]/70" />
      {title && (
        <div className="relative -mt-7 flex shrink-0 justify-center">
          <div className="rounded-full border-4 border-white bg-gradient-to-b from-[#ffd166] to-[#ff9f1c] px-7 py-1.5 text-lg font-black tracking-wide text-white shadow-[0_5px_0_rgba(178,89,0,0.6)]">
            {title}
          </div>
        </div>
      )}
      {onClose && (
        <button
          onClick={onClose}
          className="absolute -right-3 -top-3 z-10 h-10 w-10 rounded-full border-4 border-white bg-gradient-to-b from-[#ff8080] to-[#e63a3a] text-lg font-black text-white shadow-[0_4px_0_rgba(150,20,20,0.7)] transition active:translate-y-0.5"
        >
          ✕
        </button>
      )}
      {/* 之前这里没有任何高度限制/滚动设置——菜单项一多，内容会直接超出屏幕，
          底下的开关和按钮压根够不着，鼠标滚轮也没地方可滚。overflow-y-auto +
          限定最大高度，菜单才能在内容变长的时候正常滚动。 */}
      <div className={cn('relative min-h-0 flex-1 overflow-y-auto overscroll-contain p-5', bodyClassName)}>
        {children}
      </div>
    </div>
  );
}

const VARIANTS = {
  green: 'from-[#8ede63] to-[#4fae3a] shadow-[0_6px_0_#2f7f2a] hover:from-[#9bea70]',
  blue: 'from-[#7cd4ff] to-[#2f9fe0] shadow-[0_6px_0_#1c6ea0] hover:from-[#8fdcff]',
  orange: 'from-[#ffd166] to-[#ff9f1c] shadow-[0_6px_0_#c96f00] hover:from-[#ffdc85]',
  pink: 'from-[#ffa6cd] to-[#ff5fa2] shadow-[0_6px_0_#c0396f] hover:from-[#ffb8d8]',
  gray: 'from-[#e6e6ef] to-[#b9b9c8] shadow-[0_6px_0_#8a8a9a] hover:from-[#f0f0f8]',
} as const;

export function MWButton({
  children,
  onClick,
  variant = 'green',
  className,
  disabled,
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: keyof typeof VARIANTS;
  className?: string;
  disabled?: boolean;
}) {
  return (
    <button
      disabled={disabled}
      onClick={onClick}
      className={cn(
        'rounded-2xl border-[3px] border-white bg-gradient-to-b px-6 py-2.5 text-base font-black text-white transition-all duration-100 active:translate-y-1 active:shadow-none disabled:opacity-50',
        'drop-shadow-[0_1px_0_rgba(0,0,0,0.25)]',
        VARIANTS[variant],
        className,
      )}
      style={{ textShadow: '0 2px 2px rgba(0,0,0,0.25)' }}
    >
      {children}
    </button>
  );
}

export function Slider({
  label,
  value,
  min,
  max,
  step = 1,
  onChange,
  suffix,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (v: number) => void;
  suffix?: string;
}) {
  return (
    <label className="block select-none">
      <div className="mb-1 flex items-center justify-between text-sm font-bold text-[#7a4b17]">
        <span>{label}</span>
        <span className="rounded-lg bg-white/80 px-2 py-0.5 text-xs text-[#b06a12]">
          {Math.round(value * 100) / 100}
          {suffix}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="h-3 w-full cursor-pointer appearance-none rounded-full bg-[#e9c48d] accent-[#ff9f1c] outline-none [&::-webkit-slider-thumb]:h-5 [&::-webkit-slider-thumb]:w-5 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-white [&::-webkit-slider-thumb]:bg-[#ff9f1c] [&::-webkit-slider-thumb]:shadow-md"
      />
    </label>
  );
}

export function Toggle({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className="flex w-full items-center justify-between rounded-2xl border-2 border-[#e9c48d] bg-white/70 px-4 py-2 text-sm font-bold text-[#7a4b17]"
    >
      <span>{label}</span>
      <span
        className={cn(
          'relative h-6 w-12 rounded-full border-2 border-white transition',
          checked ? 'bg-[#4fae3a]' : 'bg-[#c9c9d4]',
        )}
      >
        <span
          className={cn(
            'absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-all',
            checked ? 'left-6' : 'left-0.5',
          )}
        />
      </span>
    </button>
  );
}

/** 可折叠的"收纳抽屉"——设置项一多，摊平列一整屏很难找，也容易把菜单撑得
 *  比屏幕还高。用原生 <details>/<summary> 实现（不用额外管开关状态，
 *  键盘/无障碍也是免费的），样式跟整体糖果风保持一致。 */
export function Section({
  title,
  icon,
  defaultOpen = false,
  children,
}: {
  title: string;
  icon?: string;
  defaultOpen?: boolean;
  children: ReactNode;
}) {
  return (
    <details
      open={defaultOpen}
      className="group overflow-hidden rounded-2xl border-2 border-[#e9c48d] bg-white/60"
    >
      <summary className="flex cursor-pointer list-none items-center justify-between px-4 py-2.5 text-sm font-black text-[#7a4b17] select-none [&::-webkit-details-marker]:hidden">
        <span>
          {icon && <span className="mr-1.5">{icon}</span>}
          {title}
        </span>
        <span className="text-[#b06a12] transition-transform duration-150 group-open:rotate-90">▶</span>
      </summary>
      <div className="space-y-3 border-t-2 border-[#e9c48d]/70 p-3">{children}</div>
    </details>
  );
}

export function Chip({
  active,
  children,
  onClick,
}: {
  active?: boolean;
  children: ReactNode;
  onClick?: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'rounded-full border-[3px] px-4 py-1.5 text-sm font-black transition',
        active
          ? 'border-white bg-gradient-to-b from-[#ffd166] to-[#ff9f1c] text-white shadow-[0_4px_0_#c96f00]'
          : 'border-[#e9c48d] bg-white/70 text-[#a5713f] hover:bg-white',
      )}
    >
      {children}
    </button>
  );
}
