import { useMemo } from 'react';
import type { HudState } from '../game/engine';
import { getItemName, isToolId, getTool, type ItemStack } from '../game/items';
import { blockIcon, toolIcon } from '../game/textures';
import { cn } from '../utils/cn';

const MOD_EMOJI: Record<string, string> = {
  guns: '🔫',
  horror: '👻',
  bossrush: '💀',
  petdragon: '🐉',
  tame: '🦴',
  swordmaster: '🗡️',
  nightvision: '👁️',
  radar: '📡',
  magnet: '🧲',
  doublejump: '🦘',
  speed: '💨',
  doubleloot: '🎁',
  regen: '❤️‍🩹',
  nohunger: '🍗',
  fastmine: '⛏️',
  wallbuild: '🧱',
  bigexplosion: '💥',
  flight: '🪽',
  rain: '🌧️',
  timecontrol: '🕰️',
  physics: '🌍',
};

/** 生存指标细条 */
function MiniBar({
  label,
  value,
  max,
  color,
  warn,
  showPct = true,
  hint,
}: {
  label: string;
  value: number;
  max: number;
  color: string;
  warn?: boolean;
  showPct?: boolean;
  hint?: string;
}) {
  const pct = Math.max(0, Math.min(1, value / max)) * 100;
  return (
    <div className="flex items-center gap-1.5">
      <span
        className={cn(
          'w-8 shrink-0 text-right text-[9px] font-black drop-shadow-[0_1px_1px_rgba(0,0,0,0.9)]',
          warn ? 'animate-pulse text-[#ff6b6b]' : 'text-white/85',
        )}
      >
        {label}
      </span>
      <div className="h-2 flex-1 overflow-hidden rounded-full border border-white/60 bg-black/45">
        <div className={cn('h-full rounded-full transition-[width] duration-300', color)} style={{ width: `${pct}%` }} />
      </div>
      {showPct && (
        <span className="w-7 shrink-0 text-[9px] font-black text-white/70 tabular-nums">{Math.round(value * 10) / 10}</span>
      )}
      {hint ? <span className="w-24 shrink-0 truncate text-[9px] font-black text-[#ff9f9f]">{hint}</span> : <span className="w-24 shrink-0" />}
    </div>
  );
}

function Heart({ fill }: { fill: number }) {
  return (
    <svg viewBox="0 0 20 20" className="h-6 w-6 drop-shadow-[0_2px_0_rgba(0,0,0,0.35)]">
      <path
        d="M10 17.5 2.8 10.6C.6 8.5.9 5 3.4 3.4c1.9-1.2 4.3-.7 5.6 1l1 1.2 1-1.2c1.3-1.7 3.7-2.2 5.6-1 2.5 1.6 2.8 5.1.6 7.2L10 17.5Z"
        fill="rgba(0,0,0,0.35)"
      />
      <clipPath id={`hc${fill}`}>
        <rect x="0" y="0" width={20 * fill} height="20" />
      </clipPath>
      <path
        d="M10 17.5 2.8 10.6C.6 8.5.9 5 3.4 3.4c1.9-1.2 4.3-.7 5.6 1l1 1.2 1-1.2c1.3-1.7 3.7-2.2 5.6-1 2.5 1.6 2.8 5.1.6 7.2L10 17.5Z"
        fill="#ff5468"
        clipPath={`url(#hc${fill})`}
      />
      <circle cx="6.5" cy="6.5" r="1.6" fill="rgba(255,255,255,0.85)" clipPath={`url(#hc${fill})`} />
    </svg>
  );
}

function Drumstick({ fill }: { fill: number }) {
  return (
    <svg viewBox="0 0 20 20" className="h-6 w-6 drop-shadow-[0_2px_0_rgba(0,0,0,0.35)]">
      <path d="M15 3c2.2 1.5 2.4 4.8.4 6.8l-5 5-3.2-3.2 5-5C14.2 4.6 13 3.9 15 3Z" fill="rgba(0,0,0,0.35)" />
      <clipPath id={`dc${fill}`}>
        <rect x="0" y="0" width={20 * fill} height="20" />
      </clipPath>
      <g clipPath={`url(#dc${fill})`}>
        <path d="M15.2 3.2c2.1 1.5 2.3 4.7.3 6.7l-4.9 4.9-3.2-3.2 4.9-4.9c1.6-1.6 1-2.9 2.9-3.5Z" fill="#f0a651" />
        <circle cx="5.6" cy="14.4" r="3.1" fill="#fff0d8" />
        <circle cx="7.4" cy="16" r="2.4" fill="#fff8ec" />
      </g>
    </svg>
  );
}

export default function Hud({
  state,
  hotbar,
  selected,
  onSelect,
  onOpenInventory,
  onOpenMenu,
  onToggleFly,
  onCycleCamera,
  toast,
  locked,
  isTouch,
  showQuests,
  onToggleQuests,
}: {
  state: HudState;
  hotbar: (ItemStack | null)[];
  selected: number;
  onSelect: (i: number) => void;
  onOpenInventory: () => void;
  onOpenMenu: () => void;
  onToggleFly: () => void;
  onCycleCamera: () => void;
  toast: string | null;
  locked: boolean;
  isTouch: boolean;
  showQuests: boolean;
  onToggleQuests: () => void;
}) {
  const icons = useMemo(
    () =>
      hotbar.map((stack) =>
        stack ? (isToolId(stack.id) ? toolIcon(stack.id, 72) : blockIcon(stack.id, 72)) : '',
      ),
    [hotbar],
  );
  const hearts = Array.from({ length: 10 }, (_, i) => Math.max(0, Math.min(1, state.health / 2 - i)));
  const food = Array.from({ length: 10 }, (_, i) => Math.max(0, Math.min(1, state.hunger / 2 - i)));
  const timeLabel = timeToClock(state.timeOfDay);
  const selectedStack = hotbar[selected];
  const selectedName = selectedStack ? getItemName(selectedStack.id) : '空';
  const daytime = state.timeOfDay >= 0.25 && state.timeOfDay < 0.75;

  return (
    <div className="pointer-events-none absolute inset-0 z-10 select-none">
      {/* 恐怖 / 画质 模组全屏滤镜 */}
      {state.activeMods.includes('rainhorror') && state.raining && (
        <div className="pointer-events-none absolute inset-0 bg-[#0d1b2a]/45 mix-blend-multiply" />
      )}
      {state.activeMods.includes('knocker') && state.fear > 4 && (
        <div
          className="pointer-events-none absolute inset-0 transition-all duration-700"
          style={{ boxShadow: `inset 0 0 ${70 + state.fear * 14}px rgba(12,0,22,${0.3 + state.fear * 0.055})` }}
        />
      )}
      {state.activeMods.includes('brokenscript') && state.glitch > 0.05 && (
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div
            className="absolute inset-x-0 h-6 bg-[#00ffc8]/25 mix-blend-screen"
            style={{ top: `${(1 - state.glitch) * 70}%`, transform: `translateX(${(state.glitch - 0.5) * 44}px)` }}
          />
          <div className="absolute inset-x-0 h-3 bg-[#ff0055]/25 mix-blend-screen" style={{ top: `${state.glitch * 55}%` }} />
          <div className="absolute left-5 top-1/3 font-mono text-xs font-black text-[#00ffc8]/85">
            ERR_SCRIPT_CORRUPT @0x{(state.glitch * 9999).toFixed(0)}
          </div>
        </div>
      )}
      {state.activeMods.includes('hdshader') && (
        <div className="pointer-events-none absolute inset-0" style={{ boxShadow: 'inset 0 0 190px rgba(24,12,0,0.34)' }} />
      )}

      {/* crosshair */}
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
        <div className="relative h-8 w-8">
          <div className="absolute left-1/2 top-0 h-2.5 w-1 -translate-x-1/2 rounded-full bg-white/90 shadow" />
          <div className="absolute bottom-0 left-1/2 h-2.5 w-1 -translate-x-1/2 rounded-full bg-white/90 shadow" />
          <div className="absolute left-0 top-1/2 h-1 w-2.5 -translate-y-1/2 rounded-full bg-white/90 shadow" />
          <div className="absolute right-0 top-1/2 h-1 w-2.5 -translate-y-1/2 rounded-full bg-white/90 shadow" />
          <div className="absolute left-1/2 top-1/2 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#ffd166]" />
          {state.breakProgress > 0 && (
            <svg viewBox="0 0 40 40" className="absolute -inset-2 h-12 w-12 -rotate-90">
              <circle cx="20" cy="20" r="16" fill="none" stroke="rgba(0,0,0,0.25)" strokeWidth="4" />
              <circle
                cx="20"
                cy="20"
                r="16"
                fill="none"
                stroke="#ffd166"
                strokeWidth="4"
                strokeLinecap="round"
                strokeDasharray={`${state.breakProgress * 100} 100`}
                pathLength={100}
              />
            </svg>
          )}
        </div>
        {state.targetName && (
          <div className="absolute left-1/2 top-10 -translate-x-1/2 whitespace-nowrap rounded-full bg-black/45 px-3 py-0.5 text-xs font-bold text-white backdrop-blur-sm">
            {state.targetName}
          </div>
        )}
      </div>

      {/* top-left info */}
      <div className="pointer-events-auto absolute left-3 top-3 flex flex-col gap-2">
        <div className="rounded-2xl border-[3px] border-white/90 bg-gradient-to-b from-[#fff7e6]/95 to-[#ffe6bd]/95 px-3 py-2 text-xs font-black text-[#7a4b17] shadow-[0_5px_0_rgba(120,74,32,0.3)]">
          <div className="flex items-center gap-2">
            <span className="rounded-full bg-[#4fae3a] px-2 py-0.5 text-[10px] text-white">
              {state.mode === 'creative' ? '创造' : '生存'}
            </span>
            <span>🕐 {timeLabel}</span>
            <span>⚡ {state.fps} FPS</span>
          </div>
          <div className="mt-1 flex items-center gap-2 text-[11px] text-[#a5713f]">
            <span>
              X {state.x.toFixed(1)} · Y {state.y.toFixed(1)} · Z {state.z.toFixed(1)}
            </span>
          </div>
          <div className="mt-0.5 flex items-center gap-2 text-[11px] text-[#a5713f]">
            <span>🌍 {biomeName(state.biome)}</span>
            <span>🧱 {state.chunks} 区块</span>
            <span>生物 {state.mobCount}</span>
            {state.flying && <span className="text-[#2f9fe0]">✈️ 飞行中</span>}
          </div>
          <div className="mt-0.5 text-[10px] font-black text-[#4f8a35]">
            {daytime ? '白昼安全期：不会刷新敌对生物' : `夜幕降临：附近敌对生物 ${state.hostileCount}`}
            {state.raining && ' · 🌧️ 下雨'}
          </div>
          {state.activeMods.length > 0 && (
            <div className="mt-1 flex max-w-[220px] flex-wrap gap-1">
              {state.activeMods.slice(0, 6).map((id) => (
                <span key={id} className="rounded-md bg-[#9c6bff]/25 px-1 text-[9px] font-black text-[#5b3a8a]">
                  {MOD_EMOJI[id] ?? '🧩'}
                </span>
              ))}
              {state.activeMods.length > 6 && (
                <span className="rounded-md bg-[#9c6bff]/25 px-1 text-[9px] font-black text-[#5b3a8a]">
                  +{state.activeMods.length - 6}
                </span>
              )}
            </div>
          )}
          {state.ammo > 0 && (
            <div className="mt-0.5 text-[10px] font-black text-[#8a5a00]">🔫 弹药 {state.ammo}</div>
          )}
        </div>
      </div>

      {state.waveMode && state.wave > 0 && (
        <div className="absolute left-1/2 top-16 -translate-x-1/2 animate-[pop_0.25s_ease-out]">
          <div className="rounded-full border-[3px] border-white bg-gradient-to-b from-[#ff6b6b] to-[#e63946] px-6 py-1.5 text-sm font-black text-white shadow-[0_5px_0_rgba(150,20,20,0.6)]">
            🌊 野人来了 · 第 {state.wave} 波 · 守住营地！
          </div>
        </div>
      )}

      {state.bossName && (
        <div className="absolute left-1/2 top-4 w-[min(56vw,520px)] -translate-x-1/2">
          <div className="text-center text-sm font-black text-white drop-shadow-[0_2px_2px_rgba(0,0,0,0.8)]">
            Mini-Boss · {state.bossName}
          </div>
          <div className="mt-1 h-4 overflow-hidden rounded-full border-[3px] border-white bg-black/45 shadow-lg">
            <div
              className="h-full bg-gradient-to-r from-[#6a1b9a] via-[#e040fb] to-[#7b1fa2] transition-[width] duration-200"
              style={{ width: `${Math.max(0, (state.bossHealth / Math.max(1, state.bossMaxHealth)) * 100)}%` }}
            />
          </div>
        </div>
      )}

      {/* top-right buttons */}
      <div className="pointer-events-auto absolute right-3 top-3 flex gap-2">
        <RoundBtn onClick={onOpenInventory} label="背包" emoji="🎒" />
        <RoundBtn onClick={onToggleQuests} label="目标" emoji="📋" active={showQuests} />
        <RoundBtn onClick={onCycleCamera} label="视角" emoji="🎥" />
        {state.mode === 'creative' && <RoundBtn onClick={onToggleFly} label="飞行" emoji="✈️" active={state.flying} />}
        <RoundBtn onClick={onOpenMenu} label="菜单" emoji="⚙️" />
      </div>

      {/* quests panel */}
      {showQuests && (
        <div className="pointer-events-auto absolute left-3 top-3 z-10 mt-24 w-64">
          <div className="rounded-3xl border-[3px] border-white/90 bg-gradient-to-b from-[#fff7e6]/95 to-[#ffe6bd]/95 p-3 shadow-[0_6px_0_rgba(120,74,32,0.3)]">
            <div className="mb-2 flex items-center justify-between">
              <span className="text-sm font-black text-[#7a4b17]">📋 冒险目标</span>
              <span className="text-[10px] font-black text-[#a5713f]">
                {state.quests.filter((quest) => quest.done).length}/{state.quests.length}
              </span>
            </div>
            <div className="space-y-1.5">
              {state.quests.map((quest) => (
                <div key={quest.id} className={cn('rounded-xl border-2 px-2 py-1', quest.done ? 'border-[#8ede63] bg-[#eaffdf]' : 'border-[#e9c48d] bg-white/70')}>
                  <div className="flex items-center justify-between text-[11px] font-black text-[#7a4b17]">
                    <span>
                      {quest.emoji} {quest.name}
                      {quest.done && ' ✅'}
                    </span>
                    <span className="text-[#a5713f]">
                      {quest.progress}/{quest.target}
                    </span>
                  </div>
                  <div className="mt-0.5 h-1.5 overflow-hidden rounded-full bg-[#e9c48d]/60">
                    <div
                      className={cn('h-full rounded-full', quest.done ? 'bg-[#4fae3a]' : 'bg-[#ff9f1c]')}
                      style={{ width: `${Math.min(100, (quest.progress / Math.max(1, quest.target)) * 100)}%` }}
                    />
                  </div>
                  {!quest.done && <div className="mt-0.5 text-[9px] font-bold text-[#a5713f]">{quest.desc}</div>}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* toast */}
      {toast && (
        <div className="absolute left-1/2 top-24 -translate-x-1/2 animate-[pop_0.25s_ease-out]">
          <div className="rounded-full border-[3px] border-white bg-gradient-to-b from-[#ffd166] to-[#ff9f1c] px-5 py-1.5 text-sm font-black text-white shadow-[0_5px_0_rgba(178,89,0,0.6)]">
            {toast}
          </div>
        </div>
      )}

      {/* survival stats */}
      {state.mode === 'survival' && (
        <div className="absolute bottom-28 left-1/2 flex w-[min(92vw,760px)] -translate-x-1/2 items-end justify-between px-2">
          <div className="flex gap-0.5">
            {hearts.map((f, i) => (
              <Heart key={i} fill={f} />
            ))}
          </div>
          <div className="flex flex-row-reverse gap-0.5">
            {food.map((f, i) => (
              <Drumstick key={i} fill={f} />
            ))}
          </div>
        </div>
      )}

      {/* 生存指标：体力 / 口渴 / 体温 */}
      {state.mode === 'survival' && (
        <div className="absolute bottom-[8.5rem] left-1/2 w-[min(92vw,420px)] -translate-x-1/2 space-y-1">
          <MiniBar label="体力" value={state.stamina} max={10} color="bg-[#ffd166]" warn={state.stamina <= 2} />
          <MiniBar label="水分" value={state.thirst} max={10} color="bg-[#7cd4ff]" warn={state.thirst <= 2} />
          <MiniBar
            label="体温"
            value={state.temp}
            max={10}
            color={state.temp <= 2 ? 'bg-[#7cd4ff]' : state.temp >= 8 ? 'bg-[#ff6b4a]' : 'bg-[#8ede63]'}
            warn={state.temp <= 1.5 || state.temp >= 8.5}
            showPct={false}
            hint={state.temp <= 2 ? '太冷了！靠近火源' : state.temp >= 8.5 ? '太热了！' : ''}
          />
        </div>
      )}

      {/* 惊变 100 天：天数计数 */}
      {state.activeMods.includes('hundredDays') && (
        <div className="absolute right-3 top-20 rounded-2xl border-[3px] border-white/90 bg-black/55 px-3 py-1.5 text-center backdrop-blur-sm">
          <div className="font-display text-2xl leading-none text-white tabular-nums">{state.day}</div>
          <div className="text-[9px] font-black tracking-widest text-white/70">/ 100 天</div>
        </div>
      )}

      {/* 敲门人：恐惧值 */}
      {state.activeMods.includes('knocker') && state.fear > 0.5 && (
        <div className="absolute left-3 top-1/2 w-3 -translate-y-1/2">
          <div className="h-40 w-3 overflow-hidden rounded-full border-2 border-white/70 bg-black/50">
            <div
              className="absolute bottom-0 w-full bg-gradient-to-t from-[#4a0d6b] to-[#ff1744] transition-[height] duration-500"
              style={{ height: `${state.fear * 10}%` }}
            />
          </div>
          <div className="mt-1 text-center text-[9px] font-black text-white/80">恐惧</div>
        </div>
      )}

      {state.air < 1 && (
        <div className="absolute bottom-40 left-1/2 flex -translate-x-1/2 gap-1">
          {Array.from({ length: 10 }, (_, i) => (
            <div
              key={i}
              className={cn(
                'h-3.5 w-3.5 rounded-full border-2 border-white/70',
                state.air * 10 > i ? 'bg-[#7cd4ff]' : 'bg-transparent opacity-30',
              )}
            />
          ))}
        </div>
      )}

      {/* hotbar */}
      <div className="pointer-events-auto absolute bottom-3 left-1/2 -translate-x-1/2">
        <div className="mb-1 text-center text-sm font-black text-white drop-shadow-[0_2px_2px_rgba(0,0,0,0.6)]">
          {selectedName}
        </div>
        <div className="flex items-end gap-1.5 rounded-3xl border-[4px] border-white/90 bg-gradient-to-b from-[#5b3d22]/85 to-[#3b2716]/85 p-2 shadow-[0_8px_0_rgba(0,0,0,0.35)] backdrop-blur-sm">
          {hotbar.map((id, i) => (
            <button
              key={i}
              onClick={() => onSelect(i)}
              className={cn(
                'relative flex h-12 w-12 items-center justify-center rounded-2xl border-[3px] transition-all sm:h-14 sm:w-14',
                selected === i
                  ? '-translate-y-1.5 scale-110 border-[#ffd166] bg-gradient-to-b from-[#fff3d6] to-[#ffdc9a] shadow-[0_0_18px_rgba(255,209,102,0.9)]'
                  : 'border-white/70 bg-white/15 hover:bg-white/25',
              )}
            >
              {icons[i] ? (
                <img src={icons[i]} alt="" className="h-9 w-9 sm:h-11 sm:w-11" draggable={false} />
              ) : (
                <span className="text-white/40">·</span>
              )}
              <span className="absolute -left-0.5 -top-1 rounded-md bg-black/55 px-1 text-[9px] font-black text-white/90">
                {i + 1}
              </span>
              {state.mode === 'survival' && id && !isToolId(id.id) && (
                <span className="absolute -bottom-1 -right-1 rounded-md bg-[#ff9f1c] px-1 text-[9px] font-black text-white">
                  {id.count}
                </span>
              )}
              {id && isToolId(id.id) && (
                <div className="absolute -bottom-1 left-1 right-1 h-1.5 overflow-hidden rounded-full bg-black/60">
                  <div
                    className={cn(
                      'h-full',
                      id.count > (getTool(id.id)?.durability ?? 1) * 0.4
                        ? 'bg-[#8ede63]'
                        : id.count > (getTool(id.id)?.durability ?? 1) * 0.15
                          ? 'bg-[#ffd166]'
                          : 'bg-[#ff5d6c]',
                    )}
                    style={{ width: `${Math.max(0, Math.min(1, id.count / (getTool(id.id)?.durability ?? 1))) * 100}%` }}
                  />
                </div>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* click to play prompt */}
      {!locked && !isTouch && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/35 backdrop-blur-[2px]">
          <div className="animate-[pop_0.3s_ease-out] rounded-3xl border-[5px] border-white bg-gradient-to-b from-[#fff7e6] to-[#ffe6bd] px-10 py-6 text-center shadow-[0_12px_0_rgba(120,74,32,0.35)]">
            <div className="text-3xl">🖱️</div>
            <div className="mt-2 text-xl font-black text-[#7a4b17]">点击屏幕继续游戏</div>
            <div className="mt-1 text-xs font-bold text-[#a5713f]">锁定鼠标后即可自由探索方块世界</div>
          </div>
        </div>
      )}
    </div>
  );
}

function RoundBtn({
  onClick,
  label,
  emoji,
  active,
}: {
  onClick: () => void;
  label: string;
  emoji: string;
  active?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'flex h-12 w-12 flex-col items-center justify-center rounded-2xl border-[3px] border-white text-white shadow-[0_5px_0_rgba(0,0,0,0.3)] transition active:translate-y-1 active:shadow-none',
        active
          ? 'bg-gradient-to-b from-[#8ede63] to-[#4fae3a]'
          : 'bg-gradient-to-b from-[#ffd166] to-[#ff9f1c]',
      )}
    >
      <span className="text-lg leading-none">{emoji}</span>
      <span className="text-[9px] font-black leading-tight">{label}</span>
    </button>
  );
}

function timeToClock(t: number) {
  const total = ((t + 0.0) % 1) * 24;
  const h = Math.floor(total);
  const m = Math.floor((total - h) * 60);
  const icon = h >= 6 && h < 18 ? '☀️' : '🌙';
  return `${icon} ${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

function biomeName(b: string) {
  return b === 'desert' ? '沙漠' : b === 'snow' ? '雪原' : '草原';
}
