import { useMemo, useRef, useState } from 'react';
import {
  Blocks,
  Users,
  ShoppingBag,
  Sprout,
  Coins,
  CalendarCheck,
  CalendarCheck2,
  Download,
  ChevronRight,
  Dices,
  Swords,
  Palette,
  Play,
  Trash2,
  Puzzle,
  Radio,
  Flame,
  Lock,
  Check,
  ArrowRight,
  Mountain,
  Square,
  Cloud,
} from 'lucide-react';
import { MODS, MOD_CATEGORIES, type ModCategory } from '../game/mods';
import HomePlant from './HomePlant';
import type { Mode, SaveData } from '../game/engine';
import type { WorldType } from '../game/world';
import { cn } from '../utils/cn';

export interface StartConfig {
  mode: Mode;
  worldType: WorldType;
  seed: number;
  renderDistance: number;
  waveGame?: boolean;
  mods?: string[];
}

const ISLAND_UNLOCK_CLICKS = 10;

interface CoinData {
  coins: number;
  last: string;
  streak: number;
}

function loadCoins(): CoinData {
  try {
    const raw = localStorage.getItem('msw-coins');
    if (!raw) return { coins: 9999, last: '', streak: 0 };
    return JSON.parse(raw) as CoinData;
  } catch {
    return { coins: 9999, last: '', streak: 0 };
  }
}

const todayStr = () => new Date().toISOString().slice(0, 10);

const ROOMS = [
  { name: '野人来了 · 草原营地', emoji: '🌊', worldType: 'normal' as WorldType, players: 3, cap: 4, host: '小美', seed: 20240214, ping: 24 },
  { name: '野人来了 · 雪山求生', emoji: '🏔️', worldType: 'normal' as WorldType, players: 2, cap: 4, host: '大壮', seed: 777, ping: 38 },
  { name: '野人来了 · 天空之城', emoji: '☁️', worldType: 'islands' as WorldType, players: 1, cap: 4, host: '糖糖', seed: 520, ping: 51 },
  { name: '恐怖夜 · 血月遗迹', emoji: '👻', worldType: 'normal' as WorldType, players: 2, cap: 4, host: '阿凯', seed: 6666, ping: 33, mods: ['horror'] },
];

const AI_CHATS = [
  { who: '小美', text: '大家守住营地，野人要来了！' },
  { who: '大壮', text: '我有石剑，前排交给我！' },
  { who: '糖糖', text: '记得放火把，晚上太黑了~' },
  { who: '阿凯', text: '我在挖陷阱，嘿嘿~' },
  { who: '小美', text: '谁有多余的水晶弹？' },
  { who: '大壮', text: '这波打完我去挖水晶。' },
];

const TERRAINS: { id: WorldType; name: string; icon: typeof Mountain; desc: string }[] = [
  { id: 'normal', name: '随机大陆', icon: Mountain, desc: '草原 / 沙漠 / 雪原' },
  { id: 'flat', name: '超平坦', icon: Square, desc: '一马平川好建造' },
  { id: 'islands', name: '天空之城', icon: Cloud, desc: '隐藏浮空岛世界' },
];

type View = 'single' | 'lobby' | 'shop' | 'home2';

export default function StartScreen({
  onStart,
  saved,
  onContinue,
  onDeleteSave,
  onExportHTML,
}: {
  onStart: (c: StartConfig) => void;
  saved?: SaveData | null;
  onContinue?: () => void;
  onDeleteSave?: () => void;
  onExportHTML?: () => void;
}) {
  const [view, setView] = useState<View>('single');
  const [mode, setMode] = useState<Mode>('creative');
  const [worldType, setWorldType] = useState<WorldType>('normal');
  const [seedText, setSeedText] = useState(() => String(Math.floor(Math.random() * 999999)));
  const [distance, setDistance] = useState(6);
  const flatClicks = useRef(0);
  const [islandsUnlocked, setIslandsUnlocked] = useState(false);
  const [secretMsg, setSecretMsg] = useState<string | null>(null);
  const [coins, setCoins] = useState<CoinData>(loadCoins);
  const [justChecked, setJustChecked] = useState(false);
  const [ownedMods, setOwnedMods] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('msw-mods') ?? '[]') as string[];
    } catch {
      return [];
    }
  });
  const [activeMods, setActiveMods] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('msw-mods-on') ?? '[]') as string[];
    } catch {
      return [];
    }
  });
  const [shopCat, setShopCat] = useState<ModCategory | 'all'>('all');
  const [chatTick, setChatTick] = useState(0);

  const checkedToday = coins.last === todayStr();
  const visibleChats = useMemo(() => AI_CHATS.slice(0, 3 + (chatTick % 3)), [chatTick]);

  const saveCoins = (next: CoinData) => {
    setCoins(next);
    localStorage.setItem('msw-coins', JSON.stringify(next));
  };

  const doCheckin = () => {
    if (checkedToday) return;
    const streak = coins.last ? coins.streak + 1 : 1;
    saveCoins({ coins: coins.coins + 50 + streak * 10, last: todayStr(), streak });
    setJustChecked(true);
    setTimeout(() => setJustChecked(false), 1200);
  };

  const buyMod = (id: string, price: number) => {
    if (ownedMods.includes(id) || coins.coins < price) return;
    saveCoins({ ...coins, coins: coins.coins - price });
    const nextOwned = [...ownedMods, id];
    setOwnedMods(nextOwned);
    localStorage.setItem('msw-mods', JSON.stringify(nextOwned));
    const nextOn = [...activeMods, id];
    setActiveMods(nextOn);
    localStorage.setItem('msw-mods-on', JSON.stringify(nextOn));
  };

  const toggleMod = (id: string) => {
    const next = activeMods.includes(id) ? activeMods.filter((m) => m !== id) : [...activeMods, id];
    setActiveMods(next);
    localStorage.setItem('msw-mods-on', JSON.stringify(next));
  };

  const clickFlat = () => {
    flatClicks.current += 1;
    if (flatClicks.current >= ISLAND_UNLOCK_CLICKS && !islandsUnlocked) {
      setIslandsUnlocked(true);
      setWorldType('islands');
      setSecretMsg('隐藏世界「天空之城」已解锁');
      setTimeout(() => setSecretMsg(null), 3600);
    } else {
      setWorldType('flat');
    }
  };

  const startSingle = () =>
    onStart({ mode, worldType, seed: hashSeed(seedText), renderDistance: distance, mods: activeMods });

  const NAV: { id: View; label: string; sub: string; icon: typeof Blocks; tint: string }[] = [
    { id: 'single', label: '单人游戏', sub: '生存冒险', icon: Blocks, tint: 'from-[#8ede63] to-[#3f9a2e]' },
    { id: 'lobby', label: '联机大厅', sub: 'AI 队友', icon: Users, tint: 'from-[#7cd4ff] to-[#2f9fe0]' },
    { id: 'shop', label: '模组商城', sub: `${MODS.length} 个玩法`, icon: ShoppingBag, tint: 'from-[#ffd166] to-[#ff9f1c]' },
    { id: 'home2', label: '迷你家园', sub: '养一株植物', icon: Sprout, tint: 'from-[#ffa6cd] to-[#ff5fa2]' },
  ];

  return (
    <div className="relative flex h-full w-full flex-col overflow-hidden">
      <Ambience />

      {/* ---------- 顶栏 ---------- */}
      <header className="relative z-20 flex shrink-0 items-center gap-3 px-3 py-2 sm:px-5 sm:py-3">
        <div className="flex items-center gap-2.5">
          <span className="relative grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-[#8ede63] to-[#2f7f2a] shadow-[0_4px_0_rgba(30,80,20,0.5)] sm:h-12 sm:w-12">
            <Blocks className="h-6 w-6 text-white sm:h-7 sm:w-7" strokeWidth={2.4} />
          </span>
          <div className="leading-none">
            <h1 className="font-display text-xl text-white drop-shadow-[0_3px_0_rgba(47,127,42,1)] sm:text-3xl">
              我的秘密世界
            </h1>
            <p className="mt-1 hidden text-[10px] font-bold tracking-[0.18em] text-white/85 sm:block">
              MY SECRET WORLD · 好玩才是硬道理
            </p>
          </div>
        </div>

        <div className="ml-auto flex items-center gap-2">
          <div className="flex items-center gap-1.5 rounded-full border-2 border-white/90 bg-white/85 py-1 pl-2.5 pr-3 shadow-[0_3px_0_rgba(120,80,0,0.28)]">
            <Coins className="h-4 w-4 text-[#e6a700]" strokeWidth={2.6} />
            <span className="font-display text-base leading-none text-[#8a5a00] tabular-nums sm:text-lg">
              {coins.coins}
            </span>
          </div>

          <button
            onClick={doCheckin}
            disabled={checkedToday}
            className={cn(
              'group flex items-center gap-1.5 rounded-full border-2 border-white py-1.5 pl-2.5 pr-3 text-xs font-black shadow-[0_4px_0_rgba(0,0,0,0.22)] transition-all active:translate-y-1 active:shadow-none sm:text-sm',
              checkedToday
                ? 'bg-white/70 text-[#8a8f98]'
                : 'bg-gradient-to-b from-[#ff8fb3] to-[#ff5fa2] text-white hover:brightness-105',
              justChecked && 'animate-[glow-pulse_0.6s_ease-out_2]',
            )}
          >
            {checkedToday ? (
              <CalendarCheck2 className="h-4 w-4" strokeWidth={2.6} />
            ) : (
              <CalendarCheck className="h-4 w-4" strokeWidth={2.6} />
            )}
            <span className="hidden sm:inline">{checkedToday ? `已签到 ${coins.streak} 天` : '每日签到'}</span>
            <span className="sm:hidden">{checkedToday ? coins.streak : '签到'}</span>
          </button>

          {onExportHTML && (
            <button
              onClick={onExportHTML}
              title="复制 / 导出单文件 HTML"
              className="grid h-9 w-9 place-items-center rounded-full border-2 border-white bg-white/85 text-[#2f9fe0] shadow-[0_3px_0_rgba(0,0,0,0.2)] transition-all hover:bg-white active:translate-y-1 active:shadow-none sm:h-10 sm:w-10"
            >
              <Download className="h-4 w-4 sm:h-5 sm:w-5" strokeWidth={2.6} />
            </button>
          )}
        </div>
      </header>

      {/* ---------- 主体：左侧导航轨 + 右侧内容 ---------- */}
      <div className="relative z-10 flex min-h-0 flex-1 flex-col gap-2.5 px-3 pb-3 sm:flex-row sm:gap-3 sm:px-5 sm:pb-5">
        <nav className="flex shrink-0 gap-2 overflow-x-auto pb-1 sm:w-[188px] sm:flex-col sm:overflow-visible sm:pb-0">
          {NAV.map((item, i) => {
            const Icon = item.icon;
            const active = view === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setView(item.id)}
                style={{ animationDelay: `${i * 70}ms` }}
                className={cn(
                  'group relative flex min-w-[132px] flex-1 items-center gap-2.5 overflow-hidden rounded-2xl border-[3px] px-3 py-2.5 text-left transition-all duration-200 sm:min-w-0 sm:flex-none sm:py-3',
                  'animate-[slide-rail_0.4s_ease-out_both]',
                  active
                    ? 'border-white bg-white/95 shadow-[0_6px_0_rgba(0,0,0,0.22)]'
                    : 'border-white/50 bg-white/25 hover:-translate-y-0.5 hover:bg-white/45',
                )}
              >
                {active && (
                  <span className={cn('absolute inset-y-0 left-0 w-1.5 bg-gradient-to-b', item.tint)} />
                )}
                <span
                  className={cn(
                    'grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br text-white shadow-[0_3px_0_rgba(0,0,0,0.22)] transition-transform duration-200 group-hover:scale-110 group-hover:-rotate-6',
                    item.tint,
                  )}
                >
                  <Icon className="h-5 w-5" strokeWidth={2.5} />
                </span>
                <span className="min-w-0 flex-1 leading-tight">
                  <span
                    className={cn(
                      'block truncate font-display text-[15px]',
                      active ? 'text-[#3b2a17]' : 'text-white drop-shadow-[0_2px_0_rgba(0,0,0,0.25)]',
                    )}
                  >
                    {item.label}
                  </span>
                  <span className={cn('block truncate text-[10px] font-bold', active ? 'text-[#a07a4a]' : 'text-white/80')}>
                    {item.id === 'shop' ? `已启用 ${activeMods.length}/${ownedMods.length}` : item.sub}
                  </span>
                </span>
                <ChevronRight
                  className={cn(
                    'hidden h-4 w-4 shrink-0 transition-transform duration-200 sm:block',
                    active ? 'translate-x-0.5 text-[#c9a06a]' : 'text-white/60 group-hover:translate-x-1',
                  )}
                  strokeWidth={3}
                />
              </button>
            );
          })}

          {/* 存档状态 */}
          <div className="hidden rounded-2xl border-[3px] border-white/50 bg-white/20 p-2.5 sm:block">
            <div className="text-[10px] font-black tracking-wide text-white/80">当前存档</div>
            {saved ? (
              <>
                <div className="mt-1 truncate font-display text-sm text-white drop-shadow">
                  种子 {saved.seed}
                </div>
                <div className="text-[10px] font-bold text-white/75">
                  {saved.mode === 'creative' ? '创造' : '生存'} · {saved.edits?.length ?? 0} 处改动
                </div>
              </>
            ) : (
              <div className="mt-1 text-[11px] font-bold text-white/70">还没有存档</div>
            )}
          </div>
        </nav>

        {/* ---------- 右侧内容区 ---------- */}
        <main className="min-h-0 min-w-0 flex-1 overflow-y-auto pr-1">
          {view === 'single' && (
            <div key="single" className="grid h-full grid-cols-1 gap-3 lg:grid-cols-[1.35fr_1fr]">
              {/* 创建世界 */}
              <section className="animate-[rise_0.35s_ease-out_both] rounded-3xl border-[4px] border-white/90 bg-gradient-to-b from-[#fffaf0] to-[#ffeccd] p-4 shadow-[0_8px_0_rgba(120,74,32,0.28)]">
                <SectionTitle icon={Blocks} tint="from-[#8ede63] to-[#3f9a2e]" title="创建新世界" hint="选择模式与地形，立刻出发" />

                <div className="mt-3 grid grid-cols-2 gap-2.5">
                  <ModeTile
                    active={mode === 'survival'}
                    icon={Swords}
                    title="生存模式"
                    desc="挖矿 · 合成 · 打怪掉落"
                    tint="from-[#ff8a8a] to-[#d94848]"
                    onClick={() => setMode('survival')}
                  />
                  <ModeTile
                    active={mode === 'creative'}
                    icon={Palette}
                    title="创造模式"
                    desc="无限方块 · 自由飞行"
                    tint="from-[#7cd4ff] to-[#2f9fe0]"
                    onClick={() => setMode('creative')}
                  />
                </div>

                <div className="mt-3">
                  <Label>地形</Label>
                  <div className="mt-1.5 grid grid-cols-3 gap-2">
                    {TERRAINS.map((t) => {
                      const locked = t.id === 'islands' && !islandsUnlocked;
                      const Icon = t.icon;
                      const selected = worldType === t.id;
                      return (
                        <button
                          key={t.id}
                          onClick={() => (t.id === 'flat' ? clickFlat() : setWorldType(t.id))}
                          disabled={locked}
                          className={cn(
                            'group relative overflow-hidden rounded-2xl border-[3px] px-2 py-2 text-left transition-all duration-200',
                            selected
                              ? 'border-[#ff9f1c] bg-white shadow-[0_4px_0_rgba(201,111,0,0.45)]'
                              : 'border-white/70 bg-white/50 hover:-translate-y-0.5 hover:bg-white/80',
                            locked && 'cursor-not-allowed opacity-60',
                          )}
                        >
                          <Icon
                            className={cn('h-5 w-5 transition-transform group-hover:scale-110', selected ? 'text-[#ff9f1c]' : 'text-[#8a7355]')}
                            strokeWidth={2.4}
                          />
                          <div className="mt-1 font-display text-[13px] text-[#5b3d22]">{t.name}</div>
                          <div className="text-[9px] font-bold text-[#a08a6a]">{locked ? '连点解锁' : t.desc}</div>
                          {t.id === 'flat' && !islandsUnlocked && (
                            <span className="absolute right-1.5 top-1.5 rounded-md bg-[#5b3d22]/10 px-1 text-[9px] font-black text-[#a08a6a]">
                              {Math.min(flatClicks.current, ISLAND_UNLOCK_CLICKS)}/{ISLAND_UNLOCK_CLICKS}
                            </span>
                          )}
                          {locked && <Lock className="absolute right-1.5 top-1.5 h-3.5 w-3.5 text-[#a08a6a]" />}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {secretMsg && (
                  <div className="mt-2.5 animate-[tick-up_0.3s_ease-out] rounded-xl border-2 border-white bg-gradient-to-r from-[#c3a6ff] to-[#9c6bff] px-3 py-1.5 text-center text-xs font-black text-white">
                    ✨ {secretMsg}
                  </div>
                )}

                <div className="mt-3 grid grid-cols-[1fr_auto] items-end gap-2">
                  <div>
                    <Label>世界种子</Label>
                    <div className="mt-1.5 flex items-center gap-2">
                      <input
                        value={seedText}
                        onChange={(e) => setSeedText(e.target.value)}
                        className="min-w-0 flex-1 rounded-xl border-[3px] border-[#e9c48d] bg-white px-2.5 py-1.5 font-display text-sm text-[#5b3d22] outline-none transition focus:border-[#ff9f1c]"
                      />
                      <button
                        onClick={() => setSeedText(String(Math.floor(Math.random() * 999999)))}
                        className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border-2 border-white bg-gradient-to-b from-[#7cd4ff] to-[#2f9fe0] text-white shadow-[0_3px_0_#1c6ea0] transition-all hover:brightness-105 active:translate-y-0.5 active:shadow-none"
                        title="随机种子"
                      >
                        <Dices className="h-4 w-4" strokeWidth={2.6} />
                      </button>
                    </div>
                  </div>
                  <div>
                    <Label>视距</Label>
                    <div className="mt-1.5 flex gap-1.5">
                      {[
                        { d: 4, n: '流畅' },
                        { d: 6, n: '标准' },
                        { d: 8, n: '高清' },
                      ].map((o) => (
                        <button
                          key={o.d}
                          onClick={() => setDistance(o.d)}
                          className={cn(
                            'rounded-xl border-2 px-2.5 py-1.5 text-[11px] font-black transition-all',
                            distance === o.d
                              ? 'border-white bg-gradient-to-b from-[#ffd166] to-[#ff9f1c] text-white shadow-[0_3px_0_#c96f00]'
                              : 'border-[#e9c48d] bg-white/70 text-[#a08a6a] hover:bg-white',
                          )}
                        >
                          {o.n}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <button
                  onClick={startSingle}
                  className="group mt-3.5 flex w-full items-center justify-center gap-2 rounded-2xl border-[3px] border-white bg-gradient-to-b from-[#8ede63] to-[#3f9a2e] py-3 font-display text-lg text-white shadow-[0_6px_0_#2f7f2a] transition-all hover:brightness-105 active:translate-y-1.5 active:shadow-none"
                >
                  <Play className="h-5 w-5 fill-current" strokeWidth={2.4} />
                  开始冒险
                  <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" strokeWidth={2.8} />
                </button>
              </section>

              {/* 右栏：继续冒险 / 已启用模组 / 操作 */}
              <div className="flex flex-col gap-3">
                {saved && onContinue && (
                  <section
                    className="animate-[rise_0.35s_ease-out_0.08s_both] rounded-3xl border-[4px] border-white/90 bg-gradient-to-b from-[#eaffdf] to-[#c6f0a8] p-3.5 shadow-[0_8px_0_rgba(70,120,40,0.28)]"
                  >
                    <div className="flex items-center gap-3">
                      <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-white/80 text-xl shadow-inner">💾</span>
                      <div className="min-w-0 flex-1">
                        <div className="font-display text-[15px] text-[#3f6b28]">继续上次的冒险</div>
                        <div className="truncate text-[10px] font-bold text-[#5d8a44]">
                          种子 {saved.seed} · {saved.mode === 'creative' ? '创造' : '生存'} ·{' '}
                          {saved.worldType === 'flat' ? '超平坦' : saved.worldType === 'islands' ? '天空之城' : '随机大陆'}
                        </div>
                      </div>
                      <button
                        onClick={onContinue}
                        className="shrink-0 rounded-xl border-2 border-white bg-gradient-to-b from-[#8ede63] to-[#4fae3a] px-3 py-1.5 text-xs font-black text-white shadow-[0_3px_0_#2f7f2a] transition-all active:translate-y-0.5 active:shadow-none"
                      >
                        继续
                      </button>
                      {onDeleteSave && (
                        <button
                          onClick={onDeleteSave}
                          title="删除存档"
                          className="grid h-8 w-8 shrink-0 place-items-center rounded-xl border-2 border-white bg-white/70 text-[#c64242] transition-all hover:bg-white active:translate-y-0.5"
                        >
                          <Trash2 className="h-4 w-4" strokeWidth={2.6} />
                        </button>
                      )}
                    </div>
                  </section>
                )}

                <section className="animate-[rise_0.35s_ease-out_0.14s_both] rounded-3xl border-[4px] border-white/90 bg-white/90 p-3.5 shadow-[0_8px_0_rgba(120,74,32,0.2)]">
                  <SectionTitle icon={Puzzle} tint="from-[#c3a6ff] to-[#9c6bff]" title="已启用模组" hint={`${activeMods.length} 个生效中`} compact />
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {activeMods.length === 0 && (
                      <p className="text-[11px] font-bold text-[#a08a6a]">还没启用模组，去「模组商城」挑几个玩法吧</p>
                    )}
                    {activeMods.map((id) => {
                      const m = MODS.find((x) => x.id === id);
                      if (!m) return null;
                      return (
                        <span
                          key={id}
                          className="group flex items-center gap-1 rounded-full border-2 border-[#c3a6ff] bg-[#f4edff] py-0.5 pl-2 pr-1 text-[10px] font-black text-[#5b3a8a]"
                        >
                          {m.emoji} {m.name}
                          <button
                            onClick={() => toggleMod(id)}
                            className="grid h-4 w-4 place-items-center rounded-full bg-white/80 text-[#c64242] transition hover:bg-white"
                          >
                            ✕
                          </button>
                        </span>
                      );
                    })}
                  </div>
                </section>

                <section className="animate-[rise_0.35s_ease-out_0.2s_both] rounded-3xl border-[4px] border-white/90 bg-white/90 p-3.5 shadow-[0_8px_0_rgba(120,74,32,0.2)]">
                  <SectionTitle icon={Radio} tint="from-[#7cd4ff] to-[#2f9fe0]" title="操作提示" compact />
                  <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-[10px] font-bold text-[#7a5c3a]">
                    {[
                      ['WASD', '移动'],
                      ['空格', '跳跃 / 双击飞行'],
                      ['左键', '挖掘 / 射击'],
                      ['右键', '放置 / 开箱'],
                      ['E', '背包与合成'],
                      ['Q', '冒险目标'],
                      ['Shift / Ctrl', '疾跑 / 潜行'],
                      ['T', '切换昼夜（模组）'],
                      ['中键', '拾取方块'],
                      ['V', '切换视角'],
                    ].map(([k, v]) => (
                      <div key={k} className="flex items-center gap-1.5">
                        <kbd className="rounded-md border border-[#e9c48d] bg-[#fffaf0] px-1.5 py-0.5 font-display text-[9px] text-[#5b3d22]">
                          {k}
                        </kbd>
                        <span className="truncate">{v}</span>
                      </div>
                    ))}
                  </div>
                </section>
              </div>
            </div>
          )}

          {view === 'lobby' && (
            <div key="lobby" className="grid h-full grid-cols-1 gap-3 lg:grid-cols-[1.4fr_1fr]">
              <section className="animate-[rise_0.35s_ease-out_both] rounded-3xl border-[4px] border-white/90 bg-gradient-to-b from-[#eaf7ff] to-[#cfeaff] p-4 shadow-[0_8px_0_rgba(30,110,160,0.25)]">
                <SectionTitle icon={Users} tint="from-[#7cd4ff] to-[#2f9fe0]" title="联机大厅" hint="AI 队友实时在线，随时开一局" />
                <div className="mt-3 space-y-2">
                  {ROOMS.map((room, i) => (
                    <div
                      key={room.name}
                      style={{ animationDelay: `${i * 60}ms` }}
                      className="group animate-[rise_0.3s_ease-out_both] flex items-center gap-3 rounded-2xl border-[3px] border-white bg-white/85 p-2.5 transition-all duration-200 hover:-translate-y-0.5 hover:border-[#7cd4ff] hover:bg-white"
                    >
                      <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-[#dff3ff] to-[#bfe6ff] text-xl shadow-inner">
                        {room.emoji}
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="truncate font-display text-[14px] text-[#1f4f6b]">{room.name}</div>
                        <div className="mt-0.5 flex items-center gap-2 text-[10px] font-bold text-[#5d8aa5]">
                          <span>房主 {room.host}</span>
                          <span className="h-2.5 w-px bg-[#b9d9ea]" />
                          <span className="flex items-center gap-1">
                            <span className="relative flex h-1.5 w-1.5">
                              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#4fae3a] opacity-70" />
                              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-[#4fae3a]" />
                            </span>
                            {room.players}/{room.cap} 在线
                          </span>
                          <span className="h-2.5 w-px bg-[#b9d9ea]" />
                          <span>{room.ping}ms</span>
                          {room.mods?.length ? (
                            <>
                              <span className="h-2.5 w-px bg-[#b9d9ea]" />
                              <span className="text-[#9c6bff]">{room.mods.length} 个模组</span>
                            </>
                          ) : null}
                        </div>
                        <div className="mt-1 flex gap-0.5">
                          {Array.from({ length: room.cap }, (_, k) => (
                            <span
                              key={k}
                              className={cn('h-1.5 flex-1 rounded-full', k < room.players ? 'bg-[#4fae3a]' : 'bg-[#d9e9f2]')}
                            />
                          ))}
                        </div>
                      </div>
                      <button
                        onClick={() =>
                          onStart({
                            mode: 'survival',
                            worldType: room.worldType,
                            seed: room.seed,
                            renderDistance: 6,
                            waveGame: true,
                            mods: [...activeMods, ...(room.mods ?? [])],
                          })
                        }
                        className="flex shrink-0 items-center gap-1 rounded-xl border-2 border-white bg-gradient-to-b from-[#7cd4ff] to-[#2f9fe0] px-3 py-2 text-xs font-black text-white shadow-[0_4px_0_#1c6ea0] transition-all hover:brightness-105 active:translate-y-1 active:shadow-none"
                      >
                        <Play className="h-3.5 w-3.5 fill-current" strokeWidth={2.6} />
                        加入
                      </button>
                    </div>
                  ))}
                </div>
                <p className="mt-2.5 flex items-start gap-1.5 rounded-2xl border-2 border-white/70 bg-white/60 px-3 py-2 text-[10px] font-bold leading-relaxed text-[#3d6d88]">
                  <Flame className="mt-px h-3.5 w-3.5 shrink-0 text-[#ff6b4a]" strokeWidth={2.6} />
                  「野人来了」：与 AI 队友一起守住营地，抵挡一波波野人进攻，波次越高越凶！
                </p>
              </section>

              <div className="flex flex-col gap-3">
                <section className="animate-[rise_0.35s_ease-out_0.1s_both] rounded-3xl border-[4px] border-white/90 bg-[#1f2b3a] p-3.5 shadow-[0_8px_0_rgba(0,0,0,0.3)]">
                  <div className="flex items-center justify-between">
                    <div className="font-display text-[15px] text-white">大厅频道</div>
                    <button
                      onClick={() => setChatTick((t) => t + 1)}
                      className="rounded-lg border border-white/25 bg-white/10 px-2 py-0.5 text-[10px] font-black text-white/80 transition hover:bg-white/20"
                    >
                      刷新
                    </button>
                  </div>
                  <div className="mt-2 space-y-1.5">
                    {visibleChats.map((line, i) => (
                      <div
                        key={`${line.who}-${i}`}
                        style={{ animationDelay: `${i * 50}ms` }}
                        className="animate-[tick-up_0.3s_ease-out_both] text-[11px] font-bold leading-snug"
                      >
                        <span className="text-[#7cd4ff]">{line.who}：</span>
                        <span className="text-[#dff3ff]">{line.text}</span>
                      </div>
                    ))}
                  </div>
                </section>

                <section className="grid animate-[rise_0.35s_ease-out_0.16s_both] grid-cols-2 gap-2.5">
                  {[
                    { label: '在线 AI 玩家', value: 12, emoji: '🤖' },
                    { label: '进行中房间', value: ROOMS.length, emoji: '🎮' },
                  ].map((s) => (
                    <div key={s.label} className="rounded-2xl border-[3px] border-white/90 bg-white/90 p-3 shadow-[0_5px_0_rgba(30,110,160,0.2)]">
                      <div className="text-2xl">{s.emoji}</div>
                      <div className="font-display text-2xl leading-none text-[#1f4f6b] tabular-nums">{s.value}</div>
                      <div className="mt-0.5 text-[10px] font-bold text-[#5d8aa5]">{s.label}</div>
                    </div>
                  ))}
                </section>
              </div>
            </div>
          )}

          {view === 'shop' && (
            <section
              key="shop"
              className="animate-[rise_0.35s_ease-out_both] rounded-3xl border-[4px] border-white/90 bg-gradient-to-b from-[#fffaf0] to-[#ffeccd] p-4 shadow-[0_8px_0_rgba(120,74,32,0.28)]"
            >
              <div className="flex flex-wrap items-center gap-2">
                <SectionTitle
                  icon={ShoppingBag}
                  tint="from-[#ffd166] to-[#ff9f1c]"
                  title="模组商城"
                  hint={`${MODS.length} 个玩法模组 · 拥有 ${ownedMods.length} · 启用 ${activeMods.length}`}
                />
                <div className="ml-auto flex items-center gap-1.5 rounded-full border-2 border-white bg-white/85 py-1 pl-2.5 pr-3">
                  <Coins className="h-4 w-4 text-[#e6a700]" strokeWidth={2.6} />
                  <span className="font-display text-base leading-none text-[#8a5a00] tabular-nums">{coins.coins}</span>
                </div>
              </div>

              <div className="mt-3 flex flex-wrap gap-1.5">
                <CatChip active={shopCat === 'all'} onClick={() => setShopCat('all')}>
                  全部
                </CatChip>
                {MOD_CATEGORIES.map((c) => (
                  <CatChip key={c.id} active={shopCat === c.id} onClick={() => setShopCat(c.id)}>
                    {c.name}
                  </CatChip>
                ))}
              </div>

              <div className="mt-3 grid max-h-[52vh] grid-cols-1 gap-2 overflow-y-auto pr-1 sm:grid-cols-2 xl:grid-cols-3">
                {MODS.filter((m) => shopCat === 'all' || m.category === shopCat).map((m, i) => {
                  const owned = ownedMods.includes(m.id);
                  const active = activeMods.includes(m.id);
                  const affordable = coins.coins >= m.price;
                  return (
                    <div
                      key={m.id}
                      style={{ animationDelay: `${Math.min(i * 30, 300)}ms` }}
                      className={cn(
                        'group animate-[rise_0.3s_ease-out_both] flex flex-col rounded-2xl border-[3px] bg-white/90 p-2.5 transition-all duration-200 hover:-translate-y-0.5',
                        active ? 'border-[#4fae3a] bg-[#f2ffe9]' : 'border-[#e9c48d] hover:border-[#ffd166]',
                      )}
                    >
                      <div className="flex items-start gap-2">
                        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-[#fffaf0] text-lg shadow-inner transition-transform group-hover:scale-110">
                          {m.emoji}
                        </span>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5">
                            <span className="truncate font-display text-[13px] text-[#5b3d22]">{m.name}</span>
                            {active && <Check className="h-3.5 w-3.5 shrink-0 text-[#4fae3a]" strokeWidth={3.4} />}
                          </div>
                          <span className="text-[9px] font-black text-[#c9a06a]">
                            {MOD_CATEGORIES.find((c) => c.id === m.category)?.name}
                          </span>
                        </div>
                      </div>
                      <p className="mt-1.5 flex-1 text-[10px] font-bold leading-snug text-[#a08a6a]">{m.desc}</p>
                      {!owned ? (
                        <button
                          onClick={() => buyMod(m.id, m.price)}
                          disabled={!affordable}
                          className={cn(
                            'mt-2 flex items-center justify-center gap-1 rounded-xl border-2 border-white py-1.5 text-[11px] font-black text-white shadow-[0_3px_0_rgba(0,0,0,0.2)] transition-all active:translate-y-0.5 active:shadow-none',
                            affordable
                              ? 'bg-gradient-to-b from-[#ffd166] to-[#ff9f1c] hover:brightness-105'
                              : 'cursor-not-allowed bg-[#c9c9d4]',
                          )}
                        >
                          <Coins className="h-3.5 w-3.5" strokeWidth={2.8} />
                          {m.price} 购买
                        </button>
                      ) : (
                        <button
                          onClick={() => toggleMod(m.id)}
                          className={cn(
                            'mt-2 rounded-xl border-2 border-white py-1.5 text-[11px] font-black text-white shadow-[0_3px_0_rgba(0,0,0,0.2)] transition-all active:translate-y-0.5 active:shadow-none',
                            active ? 'bg-gradient-to-b from-[#8ede63] to-[#4fae3a]' : 'bg-gradient-to-b from-[#c9c9d4] to-[#a3a3b0]',
                          )}
                        >
                          {active ? '✅ 已启用' : '启用模组'}
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </section>
          )}

          {view === 'home2' && (
            <div key="home2" className="animate-[rise_0.35s_ease-out_both] pt-8">
              <HomePlant
                coins={coins.coins}
                embedded
                onReward={(amount) => saveCoins({ ...coins, coins: Math.max(0, coins.coins + amount) })}
                onClose={() => setView('single')}
              />
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

function SectionTitle({
  icon: Icon,
  tint,
  title,
  hint,
  compact,
}: {
  icon: typeof Blocks;
  tint: string;
  title: string;
  hint?: string;
  compact?: boolean;
}) {
  return (
    <div className="flex items-center gap-2.5">
      <span className={cn('grid shrink-0 place-items-center rounded-xl bg-gradient-to-br text-white shadow-[0_3px_0_rgba(0,0,0,0.2)]', tint, compact ? 'h-8 w-8' : 'h-10 w-10')}>
        <Icon className={compact ? 'h-4 w-4' : 'h-5 w-5'} strokeWidth={2.5} />
      </span>
      <div className="min-w-0">
        <h2 className={cn('font-display text-[#5b3d22]', compact ? 'text-[15px]' : 'text-lg sm:text-xl')}>{title}</h2>
        {hint && !compact && <p className="truncate text-[10px] font-bold text-[#a08a6a]">{hint}</p>}
      </div>
    </div>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return <div className="text-[10px] font-black tracking-wide text-[#a08a6a]">{children}</div>;
}

function CatChip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'rounded-full border-2 px-3 py-1 text-[11px] font-black transition-all',
        active
          ? 'border-white bg-gradient-to-b from-[#ffd166] to-[#ff9f1c] text-white shadow-[0_3px_0_#c96f00]'
          : 'border-[#e9c48d] bg-white/70 text-[#a08a6a] hover:bg-white',
      )}
    >
      {children}
    </button>
  );
}

function ModeTile({
  active,
  icon: Icon,
  title,
  desc,
  tint,
  onClick,
}: {
  active: boolean;
  icon: typeof Swords;
  title: string;
  desc: string;
  tint: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'group flex items-center gap-2.5 rounded-2xl border-[3px] p-2.5 text-left transition-all duration-200',
        active
          ? 'border-[#ff9f1c] bg-white shadow-[0_4px_0_rgba(201,111,0,0.45)]'
          : 'border-white/70 bg-white/50 hover:-translate-y-0.5 hover:bg-white/80',
      )}
    >
      <span className={cn('grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-gradient-to-br text-white shadow-[0_3px_0_rgba(0,0,0,0.2)] transition-transform group-hover:scale-110 group-hover:-rotate-6', tint)}>
        <Icon className="h-5 w-5" strokeWidth={2.5} />
      </span>
      <span className="min-w-0">
        <span className="block font-display text-[14px] text-[#5b3d22]">{title}</span>
        <span className="block truncate text-[10px] font-bold text-[#a08a6a]">{desc}</span>
      </span>
    </button>
  );
}

/** 分层氛围背景：天空渐变 + 视差云 + 漂浮方块 + 远山 */
function Ambience() {
  const blocks = useMemo(
    () => [
      { l: 6, t: 16, s: 46, d: 0, dur: 9 },
      { l: 22, t: 62, s: 34, d: 1.4, dur: 11 },
      { l: 41, t: 10, s: 28, d: 2.6, dur: 8 },
      { l: 63, t: 70, s: 40, d: 0.8, dur: 12 },
      { l: 80, t: 20, s: 32, d: 3.2, dur: 10 },
      { l: 91, t: 58, s: 26, d: 2.1, dur: 13 },
    ],
    [],
  );
  const colors = ['#8ede63', '#ffd166', '#7cd4ff', '#ffa6cd', '#c3a6ff', '#ff9f1c'];

  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-[#4fb0ff] via-[#9ad9ff] to-[#d9f2c4]" />
      {/* 阳光 */}
      <div className="absolute -right-24 -top-24 h-96 w-96 rounded-full bg-[radial-gradient(circle,rgba(255,246,201,0.95),rgba(255,209,102,0.35)_45%,transparent_70%)]" />
      {/* 视差云层 */}
      <div className="absolute inset-x-0 top-[8%] h-24 opacity-80">
        <div className="absolute h-10 w-40 rounded-full bg-white/80 blur-[2px]" style={{ animation: 'drift 46s linear infinite' }} />
        <div className="absolute h-8 w-28 rounded-full bg-white/60 blur-[2px]" style={{ animation: 'drift 62s linear infinite', animationDelay: '-18s', top: 34 }} />
      </div>
      <div className="absolute inset-x-0 top-[34%] h-24 opacity-60">
        <div className="absolute h-12 w-52 rounded-full bg-white/70 blur-[3px]" style={{ animation: 'drift 78s linear infinite', animationDelay: '-30s' }} />
      </div>
      {/* 漂浮方块 */}
      {blocks.map((b, i) => (
        <span
          key={i}
          className="absolute rounded-lg border-2 border-white/70 shadow-lg"
          style={{
            left: `${b.l}%`,
            top: `${b.t}%`,
            width: b.s,
            height: b.s,
            background: colors[i % colors.length],
            opacity: 0.55,
            animation: `floaty ${b.dur}s ease-in-out ${b.d}s infinite`,
          }}
        />
      ))}
      {/* 远山 */}
      <div className="absolute bottom-0 left-0 h-56 w-full">
        <div className="absolute bottom-0 left-[-14%] h-52 w-[64%] rounded-t-[50%] bg-[#7ed957]/90" />
        <div className="absolute bottom-0 right-[-14%] h-64 w-[68%] rounded-t-[50%] bg-[#5fbf45]/90" />
        <div className="absolute bottom-0 h-24 w-full bg-[#4fae3a]" />
        <div className="absolute bottom-0 h-24 w-full bg-gradient-to-t from-[#2f7f2a]/45 to-transparent" />
      </div>
    </div>
  );
}

function hashSeed(text: string): number {
  const n = Number(text);
  if (!Number.isNaN(n) && text.trim() !== '') return Math.floor(Math.abs(n)) || 1;
  let h = 0;
  for (let i = 0; i < text.length; i++) h = (h * 31 + text.charCodeAt(i)) >>> 0;
  return h || 1;
}
