import { useState } from 'react';
import { Panel } from './kit';
import { RECIPES } from '../game/crafting';
import { blockIcon, itemIcon, toolIcon } from '../game/textures';
import { getItemName, isToolId, type ItemStack } from '../game/items';
import SlotGrid, { type HeldStack } from './SlotGrid';
import { cn } from '../utils/cn';

/** 工作台：我的世界式 3x3 形状合成 */
export default function CraftTable({
  craft3,
  craft3Result,
  inv,
  selected,
  mode,
  onMove,
  onQuickMove,
  onTakeResult,
  onLoadRecipe,
  onClose,
}: {
  craft3: (ItemStack | null)[];
  craft3Result: ItemStack | null;
  inv: (ItemStack | null)[];
  selected: number;
  mode: 'creative' | 'survival';
  onMove: (fromZone: string, fromIdx: number, toZone: string, toIdx: number) => void;
  onQuickMove: (zone: string, idx: number) => void;
  onTakeResult: () => void;
  onLoadRecipe: (recipeId: string) => void;
  onClose: () => void;
}) {
  const [showRecipes, setShowRecipes] = useState(false);
  const [held, setHeld] = useState<HeldStack | null>(null);

  const getStack = (zone: string, idx: number): ItemStack | null =>
    zone === 'craft' ? craft3[idx] ?? null : zone === 'inv' ? inv[idx] ?? null : null;

  const handlePick = (zone: string, idx: number) => {
    if (held) {
      if (held.zone === zone && held.idx === idx) {
        setHeld(null);
        return;
      }
      onMove(held.zone, held.idx, zone, idx);
      setHeld(null);
      return;
    }
    const stack = getStack(zone, idx);
    if (stack) setHeld({ zone, idx, stack });
  };

  const resultIcon = craft3Result
    ? isToolId(craft3Result.id)
      ? toolIcon(craft3Result.id, 96)
      : craft3Result.id >= 200
        ? itemIcon(craft3Result.id, 96)
        : blockIcon(craft3Result.id, 96)
    : '';

  return (
    <div className="pointer-events-auto absolute inset-0 z-30 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm">
      <Panel title="工作台 · 3x3 合成" onClose={onClose} className="w-full max-w-2xl">
        <div className="flex flex-col items-center gap-3 pt-1 sm:flex-row sm:justify-center">
          {/* 3x3 grid */}
          <div className="text-center">
            <div className="mb-1 text-xs font-black text-[#7a4b17]">3×3 合成网格</div>
            <SlotGrid
              slots={craft3}
              zone="craft"
              held={held}
              onPick={handlePick}
              onMove={onMove}
              onQuickMove={onQuickMove}
              infinite={mode === 'creative'}
            />
          </div>
          <div className="text-3xl text-[#ff9f1c]">➜</div>
          {/* result slot */}
          <div className="text-center">
            <div className="mb-1 text-xs font-black text-[#7a4b17]">成品</div>
            <button
              onClick={onTakeResult}
              disabled={!craft3Result}
              className={cn(
                'flex h-16 w-16 items-center justify-center rounded-2xl border-4',
                craft3Result
                  ? 'border-[#ffd166] bg-white/90 shadow-[0_0_16px_rgba(255,209,102,0.9)] hover:scale-105'
                  : 'border-white/40 bg-white/20',
              )}
            >
              {resultIcon ? (
                <img src={resultIcon} alt="" className="h-13 w-13" draggable={false} />
              ) : (
                <span className="text-sm text-white/40">?</span>
              )}
            </button>
            <button
              onClick={() => setShowRecipes((v) => !v)}
              className="mt-2 rounded-xl border-2 border-white bg-gradient-to-b from-[#7cd4ff] to-[#2f9fe0] px-2 py-1 text-[10px] font-black text-white shadow-[0_3px_0_#1c6ea0]"
            >
              📖 配方 {showRecipes ? '▲' : '▼'}
            </button>
          </div>
        </div>

        {/* recipe book */}
        {showRecipes && (
          <div className="mt-3 grid max-h-[26vh] grid-cols-1 gap-1.5 overflow-y-auto rounded-2xl border-[3px] border-[#e9c48d] bg-[#fffaf0]/90 p-2 sm:grid-cols-2">
            {RECIPES.map((recipe) => (
              <button
                key={recipe.id}
                onClick={() => onLoadRecipe(recipe.id)}
                className="flex items-center gap-2 rounded-xl border-2 border-[#e9c48d] bg-white/80 px-2 py-1 text-left hover:border-[#ffd166]"
              >
                <span className="shrink-0 text-lg">{recipe.name.slice(0, 1)}</span>
                <span className="min-w-0 flex-1 truncate text-[11px] font-black text-[#7a4b17]">
                  {recipe.name} <span className="text-[#ff9f1c]">→ {getItemName(recipe.output.id)}</span>
                </span>
                <span className="shrink-0 rounded-lg bg-[#4fae3a] px-1.5 py-0.5 text-[9px] font-black text-white">
                  摆料
                </span>
              </button>
            ))}
          </div>
        )}

        {/* player inventory */}
        <div className="mt-3 rounded-2xl border-[3px] border-[#b98a53] bg-gradient-to-b from-[#5b3d22] to-[#3b2716] p-2">
          <div className="mb-1 px-1 text-xs font-black text-[#ffd9a0]">🎒 我的背包</div>
          <SlotGrid
            slots={inv.slice(9, 36)}
            zone="inv"
            offset={9}
            held={held}
            onPick={handlePick}
            onMove={onMove}
            onQuickMove={onQuickMove}
            infinite={mode === 'creative'}
          />
          <div className="mt-1.5">
            <SlotGrid
              slots={inv.slice(0, 9)}
              zone="inv"
              offset={0}
              selected={selected}
              held={held}
              onPick={handlePick}
              onMove={onMove}
              onQuickMove={onQuickMove}
              infinite={mode === 'creative'}
            />
          </div>
        </div>

        <div className="mt-2 text-center text-[10px] font-bold text-[#a5713f]">
          💡 把材料摆成配方形状就能合成 · 关闭时材料自动退回背包
        </div>
      </Panel>
    </div>
  );
}
