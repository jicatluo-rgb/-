import { useState } from 'react';
import { Panel, MWButton } from './kit';
import type { ItemStack } from '../game/items';
import SlotGrid, { type HeldStack } from './SlotGrid';
import type { Mode } from '../game/engine';

/**
 * Minecraft-style chest screen: 27 chest slots + 36 player slots,
 * drag & drop / click-pick / shift-click quick move between them.
 */
export default function ChestUI({
  chestSlots,
  inv,
  selected,
  mode,
  onMove,
  onQuickMove,
  onTakeAll,
  onClose,
}: {
  chestSlots: (ItemStack | null)[];
  inv: (ItemStack | null)[];
  selected: number;
  mode: Mode;
  onMove: (fromZone: string, fromIdx: number, toZone: string, toIdx: number) => void;
  onQuickMove: (zone: string, idx: number) => void;
  onTakeAll: () => void;
  onClose: () => void;
}) {
  const [held, setHeld] = useState<HeldStack | null>(null);

  const getStack = (zone: string, idx: number): ItemStack | null =>
    zone === 'chest' ? chestSlots[idx] ?? null : inv[idx] ?? null;

  const handlePick = (zone: string, idx: number) => {
    if (held) {
      if (held.zone === zone && held.idx === idx) {
        setHeld(null);
        return;
      }
      onMove(held.zone, held.idx, zone, idx);
      setHeld(null);
      return;
    }
    const stack = getStack(zone, idx);
    if (stack) setHeld({ zone, idx, stack });
  };

  return (
    <div className="pointer-events-auto absolute inset-0 z-30 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm">
      <Panel title="惊喜宝箱" onClose={onClose} className="w-full max-w-2xl">
        <div className="space-y-3 pt-1">
          <div className="text-center text-xs font-black text-[#a5713f]">
            ✨ 拖拽或点击移动物品 · Shift 点击整组快速转移
          </div>

          {/* chest area */}
          <div className="rounded-2xl border-[4px] border-[#ff8fb3] bg-gradient-to-b from-[#ffd6e6]/70 to-[#ffb3cd]/70 p-2">
            <div className="mb-1 px-1 text-xs font-black text-[#c23a76]">🎀 宝箱（27 格）</div>
            <SlotGrid
              slots={chestSlots}
              zone="chest"
              held={held}
              onPick={handlePick}
              onMove={onMove}
              onQuickMove={onQuickMove}
              infinite={mode === 'creative'}
            />
          </div>

          {/* player inventory */}
          <div className="rounded-2xl border-[3px] border-[#b98a53] bg-gradient-to-b from-[#5b3d22] to-[#3b2716] p-2">
            <div className="mb-1 px-1 text-xs font-black text-[#ffd9a0]">🎒 我的背包</div>
            <SlotGrid
              slots={inv.slice(9, 36)}
              zone="inv"
              offset={9}
              held={held}
              onPick={handlePick}
              onMove={onMove}
              onQuickMove={onQuickMove}
              infinite={mode === 'creative'}
            />
            <div className="mt-1.5">
              <SlotGrid
                slots={inv.slice(0, 9)}
                zone="inv"
                offset={0}
                selected={selected}
                held={held}
                onPick={handlePick}
                onMove={onMove}
                onQuickMove={onQuickMove}
                infinite={mode === 'creative'}
              />
            </div>
          </div>

          <div className="flex gap-2">
            <MWButton className="flex-1" onClick={onTakeAll}>
              📥 全部取走
            </MWButton>
            <MWButton className="flex-1" variant="gray" onClick={onClose}>
              ✖ 关闭
            </MWButton>
          </div>
        </div>
      </Panel>
    </div>
  );
}
