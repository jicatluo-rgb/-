/** 修复的TNT物理系统 - 更真实的爆炸效果 */

import * as THREE from 'three';

export interface TNTEntity {
  mesh: THREE.Mesh;
  position: THREE.Vector3;
  velocity: THREE.Vector3;
  fuseTime: number;
  maxFuseTime: number;
  isPrimed: boolean;
  isExploding: boolean;
}

export class TNTSystem {
  private scene: THREE.Scene;
  private tntEntities: TNTEntity[] = [];
  private gravity: number = -20;
  private fuseDuration: number = 4.0; // 4秒引信时间
  private explosionRadius: number = 5;
  private explosionForce: number = 20;

  constructor(scene: THREE.Scene) {
    this.scene = scene;
  }

  /** 创建TNT实体 */
  createTNT(position: THREE.Vector3, velocity: THREE.Vector3 = new THREE.Vector3()): TNTEntity {
    const tntGroup = new THREE.Group();
    
    // TNT方块（红色带TNT字样）
    const tntMesh = new THREE.Mesh(
      new THREE.BoxGeometry(0.8, 0.8, 0.8),
      new THREE.MeshLambertMaterial({ color: 0xcc0000 })
    );
    tntGroup.add(tntMesh);
    
    // TNT标签（白色）
    const labelMesh = new THREE.Mesh(
      new THREE.BoxGeometry(0.7, 0.3, 0.81),
      new THREE.MeshBasicMaterial({ color: 0xffffff })
    );
    labelMesh.position.y = 0;
    tntGroup.add(labelMesh);
    
    // "TNT"文字（黑色）
    const textMesh1 = new THREE.Mesh(
      new THREE.BoxGeometry(0.15, 0.2, 0.82),
      new THREE.MeshBasicMaterial({ color: 0x000000 })
    );
    textMesh1.position.set(-0.2, 0, 0);
    tntGroup.add(textMesh1);
    
    const textMesh2 = new THREE.Mesh(
      new THREE.BoxGeometry(0.15, 0.2, 0.82),
      new THREE.MeshBasicMaterial({ color: 0x000000 })
    );
    textMesh2.position.set(0.2, 0, 0);
    tntGroup.add(textMesh2);
    
    const textMesh3 = new THREE.Mesh(
      new THREE.BoxGeometry(0.15, 0.2, 0.82),
      new THREE.MeshBasicMaterial({ color: 0x000000 })
    );
    textMesh3.position.set(0, 0, 0);
    tntGroup.add(textMesh3);
    
    tntGroup.position.copy(position);
    this.scene.add(tntGroup);

    const tnt: TNTEntity = {
      mesh: tntMesh,
      position: position.clone(),
      velocity: velocity.clone(),
      fuseTime: this.fuseDuration,
      maxFuseTime: this.fuseDuration,
      isPrimed: true,
      isExploding: false,
    };

    this.tntEntities.push(tnt);
    return tnt;
  }

  /** 点燃TNT */
  primeTNT(tnt: TNTEntity) {
    tnt.isPrimed = true;
    tnt.fuseTime = this.fuseDuration;
    
    // 闪烁效果
    const material = tnt.mesh.material as THREE.MeshLambertMaterial;
    const originalColor = material.color.clone();
    
    const flashInterval = setInterval(() => {
      if (!tnt.isPrimed) {
        clearInterval(flashInterval);
        return;
      }
      
      const flash = Math.random() > 0.5;
      material.color.set(flash ? 0xffffff : originalColor);
      
      setTimeout(() => {
        material.color.copy(originalColor);
      }, 100);
    }, 200);
  }

  /** 更新所有TNT实体 */
  update(deltaTime: number) {
    for (let i = this.tntEntities.length - 1; i >= 0; i--) {
      const tnt = this.tntEntities[i];
      
      if (tnt.isPrimed) {
        // 应用重力
        tnt.velocity.y += this.gravity * deltaTime;
        
        // 更新位置
        tnt.position.add(tnt.velocity.clone().multiplyScalar(deltaTime));
        tnt.mesh.position.copy(tnt.position);
        
        // 旋转
        tnt.mesh.rotation.x += deltaTime * 2;
        tnt.mesh.rotation.y += deltaTime * 3;
        
        // 地面碰撞
        if (tnt.position.y < 0.4) {
          tnt.position.y = 0.4;
          tnt.velocity.y = -tnt.velocity.y * 0.3;
          tnt.velocity.x *= 0.7;
          tnt.velocity.z *= 0.7;
        }
        
        // 更新引信时间
        tnt.fuseTime -= deltaTime;
        
        // 爆炸
        if (tnt.fuseTime <= 0) {
          this.explodeTNT(tnt);
          this.tntEntities.splice(i, 1);
        }
      }
    }
  }

  /** 引爆TNT */
  private explodeTNT(tnt: TNTEntity) {
    tnt.isExploding = true;
    
    // 移除TNT模型
    this.scene.remove(tnt.mesh.parent || tnt.mesh);
    tnt.mesh.geometry.dispose();
    (tnt.mesh.material as THREE.Material).dispose();
    
    // 创建爆炸效果
    this.createExplosionEffect(tnt.position);
    
    // TODO: 对方块和生物造成爆炸伤害
    // 这里需要调用世界的explode方法
  }

  /** 创建爆炸视觉效果 */
  private createExplosionEffect(position: THREE.Vector3) {
    // 爆炸闪光
    const flash = new THREE.Mesh(
      new THREE.SphereGeometry(this.explosionRadius * 0.5, 16, 16),
      new THREE.MeshBasicMaterial({
        color: 0xffff00,
        transparent: true,
        opacity: 0.8,
      })
    );
    flash.position.copy(position);
    this.scene.add(flash);
    
    // 逐渐消失
    let opacity = 0.8;
    const flashInterval = setInterval(() => {
      opacity -= 0.05;
      (flash.material as THREE.MeshBasicMaterial).opacity = opacity;
      flash.scale.multiplyScalar(1.1);
      
      if (opacity <= 0) {
        clearInterval(flashInterval);
        this.scene.remove(flash);
        flash.geometry.dispose();
        (flash.material as THREE.Material).dispose();
      }
    }, 50);
    
    // 烟雾效果
    for (let i = 0; i < 10; i++) {
      const smoke = new THREE.Mesh(
        new THREE.SphereGeometry(0.5 + Math.random() * 0.5, 8, 8),
        new THREE.MeshBasicMaterial({
          color: 0x555555,
          transparent: true,
          opacity: 0.6,
        })
      );
      
      smoke.position.set(
        position.x + (Math.random() - 0.5) * this.explosionRadius,
        position.y + (Math.random() - 0.5) * this.explosionRadius,
        position.z + (Math.random() - 0.5) * this.explosionRadius
      );
      
      this.scene.add(smoke);
      
      // 烟雾上升并消失
      let smokeOpacity = 0.6;
      const smokeInterval = setInterval(() => {
        smoke.position.y += 0.1;
        smokeOpacity -= 0.02;
        (smoke.material as THREE.MeshBasicMaterial).opacity = smokeOpacity;
        smoke.scale.multiplyScalar(1.05);
        
        if (smokeOpacity <= 0) {
          clearInterval(smokeInterval);
          this.scene.remove(smoke);
          smoke.geometry.dispose();
          (smoke.material as THREE.Material).dispose();
        }
      }, 50);
    }
    
    // 爆炸粒子
    for (let i = 0; i < 30; i++) {
      const particle = new THREE.Mesh(
        new THREE.BoxGeometry(0.15, 0.15, 0.15),
        new THREE.MeshBasicMaterial({
          color: Math.random() > 0.5 ? 0xff6600 : 0xff9900,
        })
      );
      
      particle.position.copy(position);
      this.scene.add(particle);
      
      const velocity = new THREE.Vector3(
        (Math.random() - 0.5) * this.explosionForce,
        Math.random() * this.explosionForce,
        (Math.random() - 0.5) * this.explosionForce
      );
      
      let life = 1.0;
      const particleInterval = setInterval(() => {
        life -= 0.05;
        velocity.y -= 0.2;
        particle.position.add(velocity.clone().multiplyScalar(0.05));
        particle.rotation.x += 0.2;
        particle.rotation.y += 0.2;
        
        if (life <= 0) {
          clearInterval(particleInterval);
          this.scene.remove(particle);
          particle.geometry.dispose();
          (particle.material as THREE.Material).dispose();
        }
      }, 50);
    }
  }

  /** 清理所有TNT实体 */
  dispose() {
    for (const tnt of this.tntEntities) {
      this.scene.remove(tnt.mesh.parent || tnt.mesh);
      tnt.mesh.geometry.dispose();
      (tnt.mesh.material as THREE.Material).dispose();
    }
    this.tntEntities = [];
  }

  /** 获取TNT数量 */
  getTNTCount(): number {
    return this.tntEntities.length;
  }
}
