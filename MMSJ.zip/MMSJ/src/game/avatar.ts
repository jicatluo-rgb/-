import * as THREE from 'three';

/** 玩家角色：Q 版比例 + 双段关节（肘/膝）+ 头发/围巾/鞋子细节 */
export interface Avatar {
  group: THREE.Group;
  head: THREE.Group;
  torso: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  leftElbow: THREE.Group;
  rightElbow: THREE.Group;
  leftKnee: THREE.Group;
  rightKnee: THREE.Group;
  scarf: THREE.Mesh;
}

function canvasTexture(draw: (ctx: CanvasRenderingContext2D, size: number) => void, size = 64) {
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const ctx = c.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;
  draw(ctx, size);
  const tex = new THREE.CanvasTexture(c);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.LinearFilter;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/** 脸部：大眼睛 + 高光 + 腮红 + 微笑 + 刘海 */
function faceTexture() {
  return canvasTexture((ctx, s) => {
    const u = s / 64;
    ctx.fillStyle = '#ffe0c0';
    ctx.fillRect(0, 0, s, s);
    // 刘海
    ctx.fillStyle = '#5d3a1e';
    ctx.fillRect(0, 0, s, 15 * u);
    ctx.fillRect(0, 0, 9 * u, 26 * u);
    ctx.fillRect(s - 9 * u, 0, 9 * u, 26 * u);
    ctx.fillRect(14 * u, 13 * u, 8 * u, 6 * u);
    ctx.fillRect(40 * u, 13 * u, 8 * u, 6 * u);
    // 眼白
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(14 * u, 27 * u, 12 * u, 14 * u);
    ctx.fillRect(38 * u, 27 * u, 12 * u, 14 * u);
    // 瞳孔
    ctx.fillStyle = '#2b2b35';
    ctx.fillRect(17 * u, 29 * u, 7 * u, 11 * u);
    ctx.fillRect(41 * u, 29 * u, 7 * u, 11 * u);
    // 高光
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(18 * u, 30 * u, 3 * u, 4 * u);
    ctx.fillRect(42 * u, 30 * u, 3 * u, 4 * u);
    // 腮红
    ctx.fillStyle = 'rgba(255,138,160,0.6)';
    ctx.fillRect(8 * u, 43 * u, 9 * u, 5 * u);
    ctx.fillRect(47 * u, 43 * u, 9 * u, 5 * u);
    // 嘴
    ctx.fillStyle = '#c4614f';
    ctx.fillRect(28 * u, 47 * u, 8 * u, 3 * u);
    ctx.fillRect(26 * u, 45 * u, 2 * u, 2 * u);
    ctx.fillRect(36 * u, 45 * u, 2 * u, 2 * u);
  });
}

/** 头发顶部 + 后脑 */
function hairTexture() {
  return canvasTexture((ctx, s) => {
    const u = s / 64;
    ctx.fillStyle = '#5d3a1e';
    ctx.fillRect(0, 0, s, s);
    ctx.fillStyle = '#6f4826';
    for (let i = 0; i < 26; i++) {
      ctx.fillRect(((i * 11) % 60) * u, ((i * 17) % 58) * u, 4 * u, 3 * u);
    }
    ctx.fillStyle = '#7d5530';
    ctx.fillRect(0, 0, s, 4 * u);
  });
}

/** 上衣：领口 + 纽扣 + 口袋 */
function shirtTexture() {
  return canvasTexture((ctx, s) => {
    const u = s / 64;
    ctx.fillStyle = '#4fc3f7';
    ctx.fillRect(0, 0, s, s);
    ctx.fillStyle = '#3ba7dd';
    for (let i = 0; i < 14; i++) ctx.fillRect(((i * 13) % 58) * u, ((i * 23) % 56) * u, 5 * u, 4 * u);
    // 领口
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(22 * u, 0, 20 * u, 5 * u);
    // 纽扣
    ctx.fillStyle = '#ffd166';
    ctx.fillRect(30 * u, 14 * u, 4 * u, 4 * u);
    ctx.fillRect(30 * u, 28 * u, 4 * u, 4 * u);
    ctx.fillRect(30 * u, 42 * u, 4 * u, 4 * u);
    // 口袋
    ctx.fillStyle = '#3ba7dd';
    ctx.fillRect(8 * u, 34 * u, 14 * u, 12 * u);
    ctx.fillStyle = '#2f8fc4';
    ctx.fillRect(8 * u, 34 * u, 14 * u, 2 * u);
  });
}

/** 裤子 + 鞋 */
function pantsTexture() {
  return canvasTexture((ctx, s) => {
    const u = s / 64;
    ctx.fillStyle = '#3f51b5';
    ctx.fillRect(0, 0, s, s);
    ctx.fillStyle = '#35449a';
    for (let i = 0; i < 12; i++) ctx.fillRect(((i * 17) % 56) * u, ((i * 29) % 54) * u, 5 * u, 4 * u);
    // 膝盖补丁
    ctx.fillStyle = '#5c6bc0';
    ctx.fillRect(20 * u, 26 * u, 16 * u, 12 * u);
    // 鞋
    ctx.fillStyle = '#6b4326';
    ctx.fillRect(0, 52 * u, s, 12 * u);
    ctx.fillStyle = '#8e5b2e';
    ctx.fillRect(0, 52 * u, s, 3 * u);
  });
}

export function createAvatar(): Avatar {
  const group = new THREE.Group();
  const mats: THREE.Material[] = [];
  const geos: THREE.BufferGeometry[] = [];

  const skinMat = new THREE.MeshLambertMaterial({ color: 0xffe0c0 });
  const faceMat = new THREE.MeshLambertMaterial({ map: faceTexture() });
  const hairMat = new THREE.MeshLambertMaterial({ map: hairTexture() });
  const shirtMat = new THREE.MeshLambertMaterial({ map: shirtTexture() });
  const pantsMat = new THREE.MeshLambertMaterial({ map: pantsTexture() });
  const shoeMat = new THREE.MeshLambertMaterial({ color: 0x6b4326 });
  const scarfMat = new THREE.MeshLambertMaterial({ color: 0xff6b6b });
  mats.push(skinMat, faceMat, hairMat, shirtMat, pantsMat, shoeMat, scarfMat);

  const box = (w: number, h: number, d: number, mat: THREE.Material | THREE.Material[]) => {
    const g = new THREE.BoxGeometry(w, h, d);
    geos.push(g);
    const m = new THREE.Mesh(g, mat);
    m.castShadow = true;
    m.receiveShadow = true;
    return m;
  };
  const ball = (r: number, mat: THREE.Material) => {
    const g = new THREE.SphereGeometry(r, 12, 9);
    geos.push(g);
    const m = new THREE.Mesh(g, mat);
    m.castShadow = true;
    return m;
  };

  /* ---------- 躯干 ---------- */
  const torso = new THREE.Group();
  torso.position.y = 0.78;
  group.add(torso);
  const chest = box(0.5, 0.52, 0.28, shirtMat);
  chest.position.y = 0.26;
  torso.add(chest);
  // 腰带
  const belt = box(0.52, 0.09, 0.3, new THREE.MeshLambertMaterial({ color: 0x8e5b2e }));
  mats.push(belt.material as THREE.Material);
  belt.position.y = 0.02;
  torso.add(belt);
  const buckle = box(0.1, 0.07, 0.04, new THREE.MeshLambertMaterial({ color: 0xffd166 }));
  mats.push(buckle.material as THREE.Material);
  buckle.position.set(0, 0.02, -0.16);
  torso.add(buckle);
  // 围巾（会随动作摆动）
  const scarf = box(0.42, 0.12, 0.32, scarfMat);
  scarf.position.y = 0.54;
  torso.add(scarf);
  const scarfTail = box(0.14, 0.3, 0.06, scarfMat);
  scarfTail.position.set(0.1, 0.4, 0.16);
  torso.add(scarfTail);

  /* ---------- 头 ---------- */
  const head = new THREE.Group();
  head.position.y = 0.86;
  torso.add(head);
  const skull = box(0.56, 0.54, 0.54, [skinMat, skinMat, hairMat, skinMat, faceMat, hairMat]);
  skull.position.y = 0.28;
  head.add(skull);
  // 头发层次
  const fringe = box(0.58, 0.14, 0.2, hairMat);
  fringe.position.set(0, 0.5, -0.2);
  head.add(fringe);
  const hairBack = box(0.58, 0.4, 0.14, hairMat);
  hairBack.position.set(0, 0.3, 0.24);
  head.add(hairBack);
  for (const s of [-1, 1]) {
    const tuft = box(0.1, 0.16, 0.1, hairMat);
    tuft.position.set(s * 0.2, 0.6, 0);
    tuft.rotation.z = s * 0.4;
    head.add(tuft);
  }

  /* ---------- 手臂（肩 → 肘 → 手） ---------- */
  const makeArm = (side: number) => {
    const shoulder = new THREE.Group();
    shoulder.position.set(side * 0.32, 0.46, 0);
    torso.add(shoulder);
    const upper = box(0.16, 0.3, 0.16, shirtMat);
    upper.position.y = -0.15;
    shoulder.add(upper);
    const elbow = new THREE.Group();
    elbow.position.y = -0.3;
    shoulder.add(elbow);
    const fore = box(0.14, 0.26, 0.14, skinMat);
    fore.position.y = -0.13;
    elbow.add(fore);
    const hand = ball(0.085, skinMat);
    hand.position.y = -0.28;
    elbow.add(hand);
    return { shoulder, elbow };
  };
  const la = makeArm(-1);
  const ra = makeArm(1);

  /* ---------- 腿（髋 → 膝 → 鞋） ---------- */
  const makeLeg = (side: number) => {
    const hip = new THREE.Group();
    hip.position.set(side * 0.14, 0, 0);
    torso.add(hip);
    const thigh = box(0.19, 0.34, 0.19, pantsMat);
    thigh.position.y = -0.17;
    hip.add(thigh);
    const knee = new THREE.Group();
    knee.position.y = -0.34;
    hip.add(knee);
    const shin = box(0.17, 0.3, 0.17, pantsMat);
    shin.position.y = -0.15;
    knee.add(shin);
    const shoe = box(0.2, 0.12, 0.28, shoeMat);
    shoe.position.set(0, -0.34, -0.04);
    knee.add(shoe);
    return { hip, knee };
  };
  const ll = makeLeg(-1);
  const rl = makeLeg(1);

  // 整体比例：Q 版（头大身小）
  group.scale.setScalar(1.0);
  torso.position.y = 0.74;

  return {
    group,
    head,
    torso,
    leftArm: la.shoulder,
    rightArm: ra.shoulder,
    leftLeg: ll.hip,
    rightLeg: rl.hip,
    leftElbow: la.elbow,
    rightElbow: ra.elbow,
    leftKnee: ll.knee,
    rightKnee: rl.knee,
    scarf: scarfTail,
  };
}
