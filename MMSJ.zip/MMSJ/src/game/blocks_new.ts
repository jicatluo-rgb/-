/** 扩展方块系统 - 20+群系特定方块 */

export interface BlockDefNew {
  id: number;
  name: string;
  type: 'solid' | 'transparent' | 'fluid' | 'plant' | 'light' | 'special';
  biome: string;
  hardness: number; // 挖掘难度
  light: number; // 发光等级 0-15
  drops: number[]; // 掉落物品ID
  description?: string;
}

export const NEW_BLOCKS: BlockDefNew[] = [
  // 平原方块
  { id: 400, name: '草方块', type: 'solid', biome: 'plains', hardness: 0.6, light: 0, drops: [2], description: '平原表面方块' },
  { id: 401, name: '泥土', type: 'solid', biome: 'plains', hardness: 0.5, light: 0, drops: [2], description: '基础方块' },
  { id: 402, name: '石头', type: 'solid', biome: 'plains', hardness: 1.5, light: 0, drops: [4], description: '基础石材' },
  { id: 403, name: '圆石', type: 'solid', biome: 'plains', hardness: 2.0, light: 0, drops: [4], description: '建筑材料' },
  { id: 404, name: '铁矿', type: 'solid', biome: 'plains', hardness: 3.0, light: 0, drops: [230], description: '铁锭来源' },
  { id: 405, name: '金矿', type: 'solid', biome: 'desert', hardness: 3.0, light: 0, drops: [231], description: '金锭来源' },
  { id: 406, name: '钻石矿', type: 'solid', biome: 'plains', hardness: 5.0, light: 0, drops: [232], description: '钻石来源' },
  { id: 407, name: '红石矿', type: 'solid', biome: 'plains', hardness: 3.0, light: 0, drops: [233], description: '红石来源' },
  { id: 408, name: '煤矿', type: 'solid', biome: 'plains', hardness: 2.0, light: 0, drops: [239], description: '煤炭来源' },
  
  // 森林方块
  { id: 410, name: '橡木原木', type: 'solid', biome: 'forest', hardness: 2.0, light: 0, drops: [6], description: '橡木来源' },
  { id: 411, name: '橡木木板', type: 'solid', biome: 'forest', hardness: 2.0, light: 0, drops: [8], description: '建筑材料' },
  { id: 412, name: '橡木树叶', type: 'transparent', biome: 'forest', hardness: 0.2, light: 0, drops: [220], description: '树叶' },
  { id: 413, name: '白桦原木', type: 'solid', biome: 'forest', hardness: 2.0, light: 0, drops: [6], description: '白桦木来源' },
  { id: 414, name: '白桦木板', type: 'solid', biome: 'forest', hardness: 2.0, light: 0, drops: [8], description: '建筑材料' },
  { id: 415, name: '丛林原木', type: 'solid', biome: 'forest', hardness: 2.0, light: 0, drops: [6], description: '丛林木来源' },
  
  // 沙漠方块
  { id: 420, name: '沙子', type: 'solid', biome: 'desert', hardness: 0.5, light: 0, drops: [5], description: '玻璃原料' },
  { id: 421, name: '沙石', type: 'solid', biome: 'desert', hardness: 1.0, light: 0, drops: [4], description: '建筑材料' },
  { id: 422, name: '红沙', type: 'solid', biome: 'desert', hardness: 0.5, light: 0, drops: [5], description: '红色沙子' },
  { id: 423, name: '仙人掌', type: 'plant', biome: 'desert', hardness: 0.4, light: 0, drops: [], description: '会伤害接触者' },
  
  // 海洋方块
  { id: 430, name: '水', type: 'fluid', biome: 'ocean', hardness: 0, light: 0, drops: [], description: '流体' },
  { id: 431, name: '海晶石', type: 'solid', biome: 'ocean', hardness: 1.5, light: 0, drops: [4], description: '海底方块' },
  { id: 432, name: '海晶灯', type: 'light', biome: 'ocean', hardness: 1.0, light: 15, drops: [], description: '发光方块' },
  { id: 433, name: '珊瑚', type: 'plant', biome: 'ocean', hardness: 0.1, light: 0, drops: [], description: '海底植物' },
  
  // 沼泽方块
  { id: 440, name: '睡莲', type: 'plant', biome: 'swamp', hardness: 0, light: 0, drops: [], description: '水面植物' },
  { id: 441, name: '粘液块', type: 'solid', biome: 'swamp', hardness: 0.5, light: 0, drops: [235], description: '弹性方块' },
  { id: 442, name: '蘑菇', type: 'plant', biome: 'swamp', hardness: 0, light: 0, drops: [227], description: '可食用' },
  
  // 雪原方块
  { id: 450, name: '雪块', type: 'solid', biome: 'snow', hardness: 0.5, light: 0, drops: [], description: '雪原方块' },
  { id: 451, name: '冰', type: 'transparent', biome: 'snow', hardness: 0.5, light: 0, drops: [], description: '滑溜' },
  { id: 452, name: '浮冰', type: 'solid', biome: 'snow', hardness: 1.0, light: 0, drops: [], description: '不融化' },
  { id: 453, name: '雪', type: 'plant', biome: 'snow', hardness: 0.1, light: 0, drops: [], description: '雪层' },
  
  // 下界方块
  { id: 460, name: '地狱岩', type: 'solid', biome: 'nether', hardness: 0.4, light: 0, drops: [4], description: '下界基础方块' },
  { id: 461, name: '灵魂沙', type: 'solid', biome: 'nether', hardness: 0.5, light: 0, drops: [], description: '减速' },
  { id: 462, name: '下界石英矿', type: 'solid', biome: 'nether', hardness: 3.0, light: 0, drops: [], description: '石英来源' },
  { id: 463, name: '岩浆', type: 'fluid', biome: 'nether', hardness: 0, light: 15, drops: [], description: '会燃烧' },
  { id: 464, name: '荧石', type: 'light', biome: 'nether', hardness: 0.3, light: 15, drops: [234], description: '发光' },
  
  // 末地方块
  { id: 470, name: '末地石', type: 'solid', biome: 'end', hardness: 3.0, light: 0, drops: [4], description: '末地基础方块' },
  { id: 471, name: '紫颂植物', type: 'plant', biome: 'end', hardness: 0.4, light: 0, drops: [254], description: '可食用' },
  { id: 472, name: '末地烛', type: 'light', biome: 'end', hardness: 0.3, light: 14, drops: [], description: '发光' },
  
  // 特殊方块
  { id: 480, name: 'TNT', type: 'special', biome: 'plains', hardness: 0, light: 0, drops: [234], description: '爆炸' },
  { id: 481, name: '工作台', type: 'solid', biome: 'plains', hardness: 2.5, light: 0, drops: [8], description: '合成工具' },
  { id: 482, name: '熔炉', type: 'solid', biome: 'plains', hardness: 3.5, light: 13, drops: [4], description: '熔炼物品' },
  { id: 483, name: '箱子', type: 'solid', biome: 'plains', hardness: 2.5, light: 0, drops: [8], description: '存储物品' },
  { id: 484, name: '书架', type: 'solid', biome: 'plains', hardness: 1.5, light: 0, drops: [8], description: '附魔台加成' },
  { id: 485, name: '附魔台', type: 'solid', biome: 'plains', hardness: 5.0, light: 0, drops: [232, 4], description: '附魔物品' },
  { id: 486, name: '末地传送门', type: 'special', biome: 'plains', hardness: -1, light: 0, drops: [], description: '传送到末地' },
];

// 群系方块映射
export const BIOME_BLOCKS: Record<string, number[]> = {
  plains: [400, 401, 402, 403, 404, 406, 407, 408, 480, 481, 482, 483, 484, 485, 486],
  forest: [410, 411, 412, 413, 414, 415],
  desert: [420, 421, 422, 423, 405],
  ocean: [430, 431, 432, 433],
  swamp: [440, 441, 442],
  snow: [450, 451, 452, 453],
  nether: [460, 461, 462, 463, 464],
  end: [470, 471, 472],
};
