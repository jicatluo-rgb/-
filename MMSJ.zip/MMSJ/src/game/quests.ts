/** 目标/成就系统：给生存冒险一个清晰的推进路线 */

export interface QuestDef {
  id: string;
  name: string;
  desc: string;
  target: number;
  emoji: string;
}

export interface QuestView {
  id: string;
  name: string;
  desc: string;
  emoji: string;
  progress: number;
  target: number;
  done: boolean;
}

export const QUESTS: QuestDef[] = [
  { id: 'wood', name: '砍树入门', desc: '采集原木（撸树是生存第一步）', target: 10, emoji: '🪓' },
  { id: 'tool', name: '打造工具', desc: '合成任意一件工具', target: 1, emoji: '🔧' },
  { id: 'torch', name: '点亮黑夜', desc: '合成火把', target: 1, emoji: '🔥' },
  { id: 'shelter', name: '建造庇护所', desc: '放置 25 个方块', target: 25, emoji: '🏠' },
  { id: 'tame', name: '驯服伙伴', desc: '用食物驯服一只生物', target: 1, emoji: '💖' },
  { id: 'chest', name: '搜刮宝箱', desc: '打开一个战利品宝箱', target: 1, emoji: '🎁' },
  { id: 'rainbow', name: '彩虹核心', desc: '合成稀有彩虹核心', target: 1, emoji: '🌈' },
  { id: 'boss', name: '讨伐蛊真兴', desc: '击败祭坛的 Mini-Boss', target: 1, emoji: '⚔️' },
];

/** 完成目标时的奖励（blockId, count 或 toolId, 耐久） */
export const QUEST_REWARDS: Record<string, [number, number][]> = {
  wood: [[13, 5]], // 荧光石
  tool: [[30, 8]], // 火把
  torch: [[14, 6]], // 糖果
  shelter: [[19, 4]], // 云朵块
  tame: [[15, 3]], // 水晶
  chest: [[10, 8]], // 红砖
  rainbow: [[20, 2]], // 炸药
  boss: [[18, 4], [15, 6]], // 彩虹核心 + 水晶
};

export const DEFAULT_QUEST_PROGRESS: Record<string, number> = {};
