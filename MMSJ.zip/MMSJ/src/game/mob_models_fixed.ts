/** 修复的生物模型 - 僵尸、骷髅、蜘蛛等 */

import * as THREE from 'three';

/** 僵尸模型 - 更真实的腐烂僵尸 */
export function createZombieModel(): THREE.Group {
  const group = new THREE.Group();
  const skinColor = 0x4caf50; // 绿色皮肤
  const clothColor = 0x455a64; // 破烂衣服

  // 身体
  const body = new THREE.Group();
  body.position.y = 0.78;
  group.add(body);

  // 躯干
  const torso = new THREE.Mesh(
    new THREE.BoxGeometry(0.42, 0.54, 0.26),
    new THREE.MeshLambertMaterial({ color: skinColor })
  );
  torso.position.y = 0.26;
  body.add(torso);

  // 破烂衣服
  const cloth = new THREE.Mesh(
    new THREE.BoxGeometry(0.44, 0.16, 0.28),
    new THREE.MeshLambertMaterial({ color: clothColor })
  );
  cloth.position.y = 0.04;
  body.add(cloth);

  // 头部
  const head = new THREE.Group();
  head.position.y = 0.78;
  group.add(head);

  const headMesh = new THREE.Mesh(
    new THREE.BoxGeometry(0.42, 0.42, 0.4),
    new THREE.MeshLambertMaterial({ color: skinColor })
  );
  head.add(headMesh);

  // 眼睛（黑色空洞）
  const eyeMat = new THREE.MeshBasicMaterial({ color: 0x1a1a1a });
  const leftEye = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.08, 0.05), eyeMat);
  leftEye.position.set(-0.1, 0.01, -0.2);
  head.add(leftEye);

  const rightEye = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.08, 0.05), eyeMat);
  rightEye.position.set(0.1, 0.01, -0.2);
  head.add(rightEye);

  // 嘴巴
  const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.05, 0.05), eyeMat);
  mouth.position.set(0, -0.13, -0.2);
  head.add(mouth);

  // 手臂（前伸姿势）
  const armMat = new THREE.MeshLambertMaterial({ color: skinColor });
  const leftArm = new THREE.Group();
  leftArm.position.set(-0.29, 0.5, 0);
  leftArm.rotation.x = -1.35; // 前伸
  body.add(leftArm);

  const leftUpperArm = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.26, 0.13), armMat);
  leftUpperArm.position.y = -0.13;
  leftArm.add(leftUpperArm);

  const leftForearm = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.24, 0.12), armMat);
  leftForearm.position.y = -0.38;
  leftArm.add(leftForearm);

  const rightArm = new THREE.Group();
  rightArm.position.set(0.29, 0.5, 0);
  rightArm.rotation.x = -1.35;
  body.add(rightArm);

  const rightUpperArm = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.26, 0.13), armMat);
  rightUpperArm.position.y = -0.13;
  rightArm.add(rightUpperArm);

  const rightForearm = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.24, 0.12), armMat);
  rightForearm.position.y = -0.38;
  rightArm.add(rightForearm);

  // 腿
  const legMat = new THREE.MeshLambertMaterial({ color: clothColor });
  const leftLeg = new THREE.Group();
  leftLeg.position.set(-0.13, 0, 0);
  body.add(leftLeg);

  const leftThigh = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.34, 0.15), legMat);
  leftThigh.position.y = -0.17;
  leftLeg.add(leftThigh);

  const leftShin = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.3, 0.14), legMat);
  leftShin.position.y = -0.52;
  leftLeg.add(leftShin);

  const rightLeg = new THREE.Group();
  rightLeg.position.set(0.13, 0, 0);
  body.add(rightLeg);

  const rightThigh = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.34, 0.15), legMat);
  rightThigh.position.y = -0.17;
  rightLeg.add(rightThigh);

  const rightShin = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.3, 0.14), legMat);
  rightShin.position.y = -0.52;
  rightLeg.add(rightShin);

  group.traverse((obj) => {
    if ((obj as THREE.Mesh).isMesh) {
      obj.castShadow = true;
      obj.receiveShadow = true;
    }
  });

  return group;
}

/** 骷髅模型 - 更真实的骨架 */
export function createSkeletonModel(): THREE.Group {
  const group = new THREE.Group();
  const boneColor = 0xe8e4d8; // 骨头颜色
  const darkColor = 0x1c1c22;

  // 身体
  const body = new THREE.Group();
  body.position.y = 0.72;
  group.add(body);

  // 脊柱
  const spine = new THREE.Mesh(
    new THREE.BoxGeometry(0.09, 0.46, 0.09),
    new THREE.MeshLambertMaterial({ color: boneColor })
  );
  spine.position.y = 0.26;
  body.add(spine);

  // 肋骨
  for (let i = 0; i < 3; i++) {
    const y = 0.42 - i * 0.15;
    const rib = new THREE.Mesh(
      new THREE.BoxGeometry(0.4, 0.045, 0.05),
      new THREE.MeshLambertMaterial({ color: boneColor })
    );
    rib.position.set(0, y, -0.02);
    body.add(rib);

    // 肋骨两侧
    const leftRib = new THREE.Mesh(
      new THREE.BoxGeometry(0.05, 0.045, 0.18),
      new THREE.MeshLambertMaterial({ color: boneColor })
    );
    leftRib.position.set(-0.19, y - 0.03, 0.02);
    body.add(leftRib);

    const rightRib = new THREE.Mesh(
      new THREE.BoxGeometry(0.05, 0.045, 0.18),
      new THREE.MeshLambertMaterial({ color: boneColor })
    );
    rightRib.position.set(0.19, y - 0.03, 0.02);
    body.add(rightRib);
  }

  // 骨盆
  const pelvis = new THREE.Mesh(
    new THREE.BoxGeometry(0.28, 0.09, 0.16),
    new THREE.MeshLambertMaterial({ color: boneColor })
  );
  pelvis.position.y = 0.02;
  body.add(pelvis);

  // 锁骨
  const collarbone = new THREE.Mesh(
    new THREE.BoxGeometry(0.42, 0.05, 0.06),
    new THREE.MeshLambertMaterial({ color: boneColor })
  );
  collarbone.position.y = 0.5;
  body.add(collarbone);

  // 头部
  const head = new THREE.Group();
  head.position.y = 0.8;
  group.add(head);

  const skull = new THREE.Mesh(
    new THREE.BoxGeometry(0.4, 0.32, 0.38),
    new THREE.MeshLambertMaterial({ color: boneColor })
  );
  skull.position.y = 0.04;
  head.add(skull);

  // 眼窝
  const eyeSocketMat = new THREE.MeshBasicMaterial({ color: darkColor });
  const leftEyeSocket = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.13, 0.09), eyeSocketMat);
  leftEyeSocket.position.set(-0.1, 0.06, -0.18);
  head.add(leftEyeSocket);

  const rightEyeSocket = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.13, 0.09), eyeSocketMat);
  rightEyeSocket.position.set(0.1, 0.06, -0.18);
  head.add(rightEyeSocket);

  // 眼睛（发光）
  const eyeMat = new THREE.MeshBasicMaterial({ color: 0xff3b30 });
  const leftEye = new THREE.Mesh(new THREE.SphereGeometry(0.032, 8, 8), eyeMat);
  leftEye.position.set(-0.1, 0.06, -0.22);
  head.add(leftEye);

  const rightEye = new THREE.Mesh(new THREE.SphereGeometry(0.032, 8, 8), eyeMat);
  rightEye.position.set(0.1, 0.06, -0.22);
  head.add(rightEye);

  // 鼻腔
  const nose = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.07, 0.07), eyeSocketMat);
  nose.position.set(0, -0.04, -0.19);
  head.add(nose);

  // 下颌
  const jaw = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.09, 0.26), new THREE.MeshLambertMaterial({ color: boneColor }));
  jaw.position.set(0, -0.15, -0.02);
  head.add(jaw);

  // 牙齿
  for (let i = 0; i < 4; i++) {
    const tooth = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.055, 0.035), eyeSocketMat);
    tooth.position.set(-0.1 + i * 0.07, -0.1, -0.16);
    head.add(tooth);
  }

  // 手臂（持弓姿势）
  const armMat = new THREE.MeshLambertMaterial({ color: boneColor });
  const leftArm = new THREE.Group();
  leftArm.position.set(-0.26, 0.48, 0);
  leftArm.rotation.x = -1.05;
  body.add(leftArm);

  const leftUpperArm = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.24, 0.07), armMat);
  leftUpperArm.position.y = -0.12;
  leftArm.add(leftUpperArm);

  const leftForearm = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.22, 0.06), armMat);
  leftForearm.position.y = -0.35;
  leftArm.add(leftForearm);

  const rightArm = new THREE.Group();
  rightArm.position.set(0.26, 0.48, 0);
  rightArm.rotation.x = -1.05;
  body.add(rightArm);

  const rightUpperArm = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.24, 0.07), armMat);
  rightUpperArm.position.y = -0.12;
  rightArm.add(rightUpperArm);

  const rightForearm = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.22, 0.06), armMat);
  rightForearm.position.y = -0.35;
  rightArm.add(rightForearm);

  // 弓
  const bow = new THREE.Mesh(
    new THREE.TorusGeometry(0.28, 0.022, 4, 14, Math.PI),
    new THREE.MeshLambertMaterial({ color: 0x6b4326 })
  );
  bow.position.set(-0.4, 0.92, -0.22);
  bow.rotation.y = Math.PI / 2;
  group.add(bow);

  // 腿
  const leftLeg = new THREE.Group();
  leftLeg.position.set(-0.11, 0, 0);
  body.add(leftLeg);

  const leftThigh = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.3, 0.08), armMat);
  leftThigh.position.y = -0.15;
  leftLeg.add(leftThigh);

  const leftShin = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.28, 0.07), armMat);
  leftShin.position.y = -0.45;
  leftLeg.add(leftShin);

  const rightLeg = new THREE.Group();
  rightLeg.position.set(0.11, 0, 0);
  body.add(rightLeg);

  const rightThigh = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.3, 0.08), armMat);
  rightThigh.position.y = -0.15;
  rightLeg.add(rightThigh);

  const rightShin = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.28, 0.07), armMat);
  rightShin.position.y = -0.45;
  rightLeg.add(rightShin);

  group.traverse((obj) => {
    if ((obj as THREE.Mesh).isMesh) {
      obj.castShadow = true;
      obj.receiveShadow = true;
    }
  });

  return group;
}

/** 蜘蛛模型 - 更真实的8腿蜘蛛 */
export function createSpiderModel(): THREE.Group {
  const group = new THREE.Group();
  const bodyColor = 0x3e2723; // 深棕色
  const accentColor = 0xd50000; // 红色斑点

  // 身体
  const body = new THREE.Group();
  body.position.y = 0.5;
  group.add(body);

  // 头胸部
  const cephalothorax = new THREE.Mesh(
    new THREE.BoxGeometry(0.58, 0.3, 0.46),
    new THREE.MeshLambertMaterial({ color: bodyColor })
  );
  cephalothorax.position.set(0, 0, -0.14);
  body.add(cephalothorax);

  // 腹部（球体）
  const abdomen = new THREE.Mesh(
    new THREE.SphereGeometry(0.32, 12, 10),
    new THREE.MeshLambertMaterial({ color: bodyColor })
  );
  abdomen.position.set(0, 0.02, 0.34);
  body.add(abdomen);

  // 腹部斑点
  const spotMat = new THREE.MeshBasicMaterial({ color: accentColor });
  const spots = [
    [-0.13, 0.24, 0.28],
    [0.13, 0.24, 0.28],
    [0, 0.28, 0.42],
  ];
  spots.forEach(([x, y, z]) => {
    const spot = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 8), spotMat);
    spot.position.set(x, y, z);
    body.add(spot);
  });

  // 头部
  const head = new THREE.Group();
  head.position.set(0, -0.02, -0.42);
  body.add(head);

  const headMesh = new THREE.Mesh(
    new THREE.BoxGeometry(0.42, 0.28, 0.28),
    new THREE.MeshLambertMaterial({ color: bodyColor })
  );
  head.add(headMesh);

  // 眼睛（8只）
  const eyeMat = new THREE.MeshBasicMaterial({ color: accentColor });
  const mainEyes = [
    [-0.1, 0.06, -0.15],
    [0.1, 0.06, -0.15],
  ];
  mainEyes.forEach(([x, y, z]) => {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.07, 8, 8), eyeMat);
    eye.position.set(x, y, z);
    head.add(eye);
  });

  // 小眼睛
  const smallEyes = [
    [-0.16, 0.1, -0.11],
    [0.16, 0.1, -0.11],
    [-0.05, 0.13, -0.14],
    [0.05, 0.13, -0.14],
    [-0.12, -0.02, -0.14],
    [0.12, -0.02, -0.14],
  ];
  smallEyes.forEach(([x, y, z]) => {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.03, 6, 6), eyeMat);
    eye.position.set(x, y, z);
    head.add(eye);
  });

  // 毒牙
  const fangMat = new THREE.MeshLambertMaterial({ color: 0xf5f5f5 });
  for (const s of [-1, 1]) {
    const fang = new THREE.Mesh(new THREE.BoxGeometry(0.055, 0.13, 0.055), fangMat);
    fang.position.set(s * 0.09, -0.15, -0.1);
    fang.rotation.x = 0.3;
    head.add(fang);
  }

  // 8条腿（两节）
  const legMat = new THREE.MeshLambertMaterial({ color: accentColor });
  for (const s of [-1, 1]) {
    for (let i = 0; i < 4; i++) {
      const zPos = -0.3 + i * 0.24;
      const legGroup = new THREE.Group();
      legGroup.position.set(s * 0.26, 0.06, zPos);
      body.add(legGroup);

      // 上节
      const upperLeg = new THREE.Mesh(new THREE.BoxGeometry(0.075, 0.34, 0.075), legMat);
      upperLeg.position.y = -0.17;
      legGroup.add(upperLeg);

      // 关节
      const knee = new THREE.Mesh(new THREE.SphereGeometry(0.05, 6, 6), legMat);
      knee.position.y = -0.34;
      legGroup.add(knee);

      // 下节
      const lowerLeg = new THREE.Mesh(new THREE.BoxGeometry(0.065, 0.4, 0.065), legMat);
      lowerLeg.position.y = -0.54;
      legGroup.add(lowerLeg);

      // 设置角度
      legGroup.rotation.z = s * 0.9;
      legGroup.rotation.y = s * (0.3 + i * 0.08);
    }
  }

  group.traverse((obj) => {
    if ((obj as THREE.Mesh).isMesh) {
      obj.castShadow = true;
      obj.receiveShadow = true;
    }
  });

  return group;
}

/** 苦力怕模型 - 更经典的Creeper */
export function createCreeperModel(): THREE.Group {
  const group = new THREE.Group();
  const bodyColor = 0x81c784; // 浅绿色
  const darkColor = 0x2e7d32; // 深绿色

  // 身体
  const body = new THREE.Group();
  body.position.y = 0.6;
  group.add(body);

  const bodyMesh = new THREE.Mesh(
    new THREE.BoxGeometry(0.4, 0.62, 0.28),
    new THREE.MeshLambertMaterial({ color: bodyColor })
  );
  bodyMesh.position.y = 0.24;
  body.add(bodyMesh);

  // 斑点
  const spotMat = new THREE.MeshLambertMaterial({ color: darkColor });
  const spots = [
    [-0.14, 0.38, -0.15],
    [0.12, 0.14, 0.15],
    [0, 0.46, 0.15],
  ];
  spots.forEach(([x, y, z]) => {
    const spot = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.11, 0.03), spotMat);
    spot.position.set(x, y, z);
    body.add(spot);
  });

  // 头部
  const head = new THREE.Group();
  head.position.y = 0.86;
  group.add(head);

  const headMesh = new THREE.Mesh(
    new THREE.BoxGeometry(0.44, 0.42, 0.42),
    new THREE.MeshLambertMaterial({ color: bodyColor })
  );
  head.add(headMesh);

  // 眼睛（黑色方块）
  const eyeMat = new THREE.MeshBasicMaterial({ color: 0x1a1a1a });
  const leftEye = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.13, 0.05), eyeMat);
  leftEye.position.set(-0.11, 0.07, -0.22);
  head.add(leftEye);

  const rightEye = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.13, 0.05), eyeMat);
  rightEye.position.set(0.11, 0.07, -0.22);
  head.add(rightEye);

  // 鼻子
  const nose = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.15, 0.05), eyeMat);
  nose.position.set(0, -0.07, -0.22);
  head.add(nose);

  // 嘴巴
  const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.17, 0.07, 0.05), eyeMat);
  mouth.position.set(0, -0.17, -0.22);
  head.add(mouth);

  // 4条短腿
  const legMat = new THREE.MeshLambertMaterial({ color: darkColor });
  const legPositions = [
    [-0.14, -0.14],
    [0.14, -0.14],
    [-0.14, 0.14],
    [0.14, 0.14],
  ];
  legPositions.forEach(([x, z]) => {
    const leg = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.16, 0.16), legMat);
    leg.position.set(x, 0.6, z);
    group.add(leg);
  });

  group.traverse((obj) => {
    if ((obj as THREE.Mesh).isMesh) {
      obj.castShadow = true;
      obj.receiveShadow = true;
    }
  });

  return group;
}
