/** 画质选项系统 - 实验性光影开关 */

export interface GraphicsSettings {
  // 基础画质
  renderDistance: number; // 渲染距离（区块）
  pixelRatio: number; // 像素比
  antialias: boolean; // 抗锯齿
  
  // 光影效果
  shadows: boolean; // 阴影
  shadowQuality: 'low' | 'medium' | 'high'; // 阴影质量
  
  // 实验性功能（默认关闭）
  experimentalSSAO: boolean; // 屏幕空间环境光遮蔽
  experimentalBloom: boolean; // 泛光效果
  experimentalRaytracing: boolean; // 光线追踪
  experimentalVolumetricLight: boolean; // 体积光
  
  // 后处理
  toneMapping: 'none' | 'aces' | 'filmic' | 'reinhard'; // 色调映射
  toneMappingExposure: number; // 曝光度
  
  // 性能
  maxFPS: number; // 最大帧率
  vsync: boolean; // 垂直同步
}

export const DEFAULT_GRAPHICS_SETTINGS: GraphicsSettings = {
  renderDistance: 6,
  pixelRatio: 1.0,
  antialias: true,
  shadows: true,
  shadowQuality: 'medium',
  experimentalSSAO: false,
  experimentalBloom: false,
  experimentalRaytracing: false,
  experimentalVolumetricLight: false,
  toneMapping: 'aces',
  toneMappingExposure: 1.0,
  maxFPS: 60,
  vsync: true,
};

export const LOW_GRAPHICS_SETTINGS: GraphicsSettings = {
  renderDistance: 4,
  pixelRatio: 1.0,
  antialias: false,
  shadows: false,
  shadowQuality: 'low',
  experimentalSSAO: false,
  experimentalBloom: false,
  experimentalRaytracing: false,
  experimentalVolumetricLight: false,
  toneMapping: 'none',
  toneMappingExposure: 1.0,
  maxFPS: 30,
  vsync: false,
};

export const HIGH_GRAPHICS_SETTINGS: GraphicsSettings = {
  renderDistance: 8,
  pixelRatio: Math.min(window.devicePixelRatio, 2.0),
  antialias: true,
  shadows: true,
  shadowQuality: 'high',
  experimentalSSAO: true,
  experimentalBloom: true,
  experimentalRaytracing: true,
  experimentalVolumetricLight: true,
  toneMapping: 'aces',
  toneMappingExposure: 1.1,
  maxFPS: 120,
  vsync: true,
};

export class GraphicsManager {
  private settings: GraphicsSettings;
  private canvas: HTMLCanvasElement | null = null;
  private renderer: any = null;

  constructor(settings: GraphicsSettings = DEFAULT_GRAPHICS_SETTINGS) {
    this.settings = { ...settings };
  }

  setRenderer(renderer: any, canvas: HTMLCanvasElement) {
    this.renderer = renderer;
    this.canvas = canvas;
    this.applySettings();
  }

  setSettings(settings: Partial<GraphicsSettings>) {
    this.settings = { ...this.settings, ...settings };
    this.applySettings();
  }

  getSettings(): GraphicsSettings {
    return { ...this.settings };
  }

  private applySettings() {
    if (!this.renderer || !this.canvas) return;

    // 像素比
    this.renderer.setPixelRatio(this.settings.pixelRatio);
    
    // 抗锯齿
    if (this.settings.antialias) {
      this.renderer.setPixelRatio(Math.min(this.settings.pixelRatio, 2.0));
    }
    
    // 色调映射
    switch (this.settings.toneMapping) {
      case 'aces':
        this.renderer.toneMapping = 4; // THREE.ACESFilmicToneMapping
        break;
      case 'filmic':
        this.renderer.toneMapping = 3; // THREE.FilmicToneMapping
        break;
      case 'reinhard':
        this.renderer.toneMapping = 2; // THREE.ReinhardToneMapping
        break;
      default:
        this.renderer.toneMapping = 0; // THREE.NoToneMapping
    }
    
    this.renderer.toneMappingExposure = this.settings.toneMappingExposure;
    
    // 阴影
    this.renderer.shadowMap.enabled = this.settings.shadows;
    
    // 阴影质量
    switch (this.settings.shadowQuality) {
      case 'low':
        this.renderer.shadowMap.type = 1; // THREE.BasicShadowMap
        break;
      case 'medium':
        this.renderer.shadowMap.type = 2; // THREE.PCFShadowMap
        break;
      case 'high':
        this.renderer.shadowMap.type = 3; // THREE.PCFSoftShadowMap
        break;
    }
  }

  isExperimentalEnabled(): boolean {
    return this.settings.experimentalSSAO || 
           this.settings.experimentalBloom || 
           this.settings.experimentalRaytracing || 
           this.settings.experimentalVolumetricLight;
  }

  getShadowMapSize(): number {
    switch (this.settings.shadowQuality) {
      case 'low': return 512;
      case 'medium': return 1024;
      case 'high': return 2048;
      default: return 1024;
    }
  }
}

// 画质预设
export const GRAPHICS_PRESETS = {
  low: LOW_GRAPHICS_SETTINGS,
  medium: DEFAULT_GRAPHICS_SETTINGS,
  high: HIGH_GRAPHICS_SETTINGS,
};

// 检测是否为低性能设备
export function isLowPowerDevice(): boolean {
  if (typeof window === 'undefined') return false;
  
  // 检测设备性能
  const canvas = document.createElement('canvas');
  const gl = canvas.getContext('webgl');
  
  if (!gl) return true;
  
  const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
  if (debugInfo) {
    const renderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
    // 检测集成显卡或移动设备
    if (renderer.toLowerCase().includes('intel') || 
        renderer.toLowerCase().includes('mali') ||
        renderer.toLowerCase().includes('adreno')) {
      return true;
    }
  }
  
  // 检测移动设备
  if (window.matchMedia('(pointer: coarse)').matches) {
    return true;
  }
  
  // 检测低分辨率屏幕
  if (window.innerWidth < 768) {
    return true;
  }
  
  return false;
}

// 自动选择画质预设
export function autoSelectGraphicsPreset(): GraphicsSettings {
  if (isLowPowerDevice()) {
    return LOW_GRAPHICS_SETTINGS;
  }
  
  // 检测高性能设备
  const canvas = document.createElement('canvas');
  const gl = canvas.getContext('webgl');
  
  if (gl) {
    const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
    if (debugInfo) {
      const renderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
      if (renderer.toLowerCase().includes('nvidia') || 
          renderer.toLowerCase().includes('radeon') ||
          renderer.toLowerCase().includes('geforce')) {
        return HIGH_GRAPHICS_SETTINGS;
      }
    }
  }
  
  return DEFAULT_GRAPHICS_SETTINGS;
}
