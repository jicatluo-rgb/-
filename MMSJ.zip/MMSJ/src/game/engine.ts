import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { SSRPass } from 'three/addons/postprocessing/SSRPass.js';
import { SSAOPass } from 'three/addons/postprocessing/SSAOPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { BokehPass } from 'three/addons/postprocessing/BokehPass.js';
import { World, CHUNK_SIZE, SEA_LEVEL, WORLD_HEIGHT, type WorldType } from './world';
import { AIR, BLOCKS, getBlock, type Pass } from './blocks';
import {
  CHEST_SIZE,
  INV_SIZE,
  MAX_STACK,
  getItem,
  getItemName,
  getTool,
  isAmmo,
  isToolId,
  type ItemStack,
  type ToolType,
} from './items';
import { QUESTS, QUEST_REWARDS, type QuestView } from './quests';
import {
  createAtlasTexture,
  createCrackTextures,
  getTileCanvases,
  setHDTextures,
  setHDGlassTextures,
  getGlassNormalAtlasTexture,
  getGlassOrmAtlasTexture,
  getProceduralNormalAtlasTexture,
  tileUV,
  TILE_PX,
} from './textures';
import { createAvatar, type Avatar } from './avatar';
import { MOB_DEFS, MobEntity } from './mobs';
import { RECIPES, matchRecipe, recipePatternSize } from './crafting';
import { createDropMesh, type ItemDrop } from './drop';
import { sfx } from './audio';
import { createPistolModel, createRifleModel, createSniperModel } from './gun_models';

export type Mode = 'creative' | 'survival';

export interface HudState {
  fps: number;
  x: number;
  y: number;
  z: number;
  mode: Mode;
  health: number;
  hunger: number;
  air: number;
  timeOfDay: number;
  biome: string;
  chunks: number;
  flying: boolean;
  inWater: boolean;
  breakProgress: number;
  targetName: string | null;
  loading: number;
  dead: boolean;
  mobCount: number;
  hostileCount: number;
  bossName: string | null;
  bossHealth: number;
  bossMaxHealth: number;
  quests: QuestView[];
  wave: number;
  waveMode: boolean;
  activeMods: string[];
  raining: boolean;
  ammo: number;
  stamina: number;
  thirst: number;
  temp: number;
  day: number;
  fear: number;
  glitch: number;
}

export interface SaveData {
  seed: number;
  worldType: WorldType;
  mode: Mode;
  pos: [number, number, number];
  yaw: number;
  pitch: number;
  hotbar?: number[];
  itemCounts?: Record<number, number>;
  inventory?: ([number, number] | null)[];
  selected?: number;
  chests?: Record<string, ([number, number] | null)[]>;
  quests?: Record<string, number>;
  version?: number;
  edits: [string, number][];
  timeOfDay: number;
  openedChests?: string[];
  savedAt: number;
  /** 下界维度：存的时候如果玩家在下界就记一下，读档时会自动切回去 */
  dimension?: 'overworld' | 'nether';
  netherEdits?: [string, number][];
}

export type SlotZone = 'inv' | 'chest' | 'craft' | 'craft2';

export interface GameOptions {
  seed: number;
  worldType: WorldType;
  mode: Mode;
  renderDistance: number;
  save?: SaveData | null;
  waveGame?: boolean;
  /** 已启用的玩法模组 id 列表 */
  mods?: string[];
  /** 模组商城购买的道具，生存开局赠送 */
  bonus?: [number, number][];
  onState: (s: HudState) => void;
  onInventory: (slots: (ItemStack | null)[], selected: number) => void;
  onChest: (slots: (ItemStack | null)[]) => void;
  onGrid2?: (grid: (ItemStack | null)[], result: ItemStack | null) => void;
  onCraftTable?: (grid: (ItemStack | null)[], result: ItemStack | null) => void;
  onLockChange: (locked: boolean) => void;
  onToast: (msg: string) => void;
}

const PLAYER_HALF = 0.3;
const PLAYER_HEIGHT = 1.8;
const EYE = 1.62;
const GRAVITY = 30;
const JUMP_V = 9.2;
const REACH = 6;
const MOB_DT = 0.05; // fixed physics step for mobs (20 Hz)

/** 方块 → 对应工具类型（无此项 = 徒手） */
const BLOCK_TOOL: Record<number, ToolType> = {
  3: 'pickaxe', 4: 'pickaxe', 13: 'pickaxe', 15: 'pickaxe', 21: 'pickaxe',
  6: 'axe', 7: 'axe', 8: 'axe', 22: 'axe', 28: 'axe', 29: 'axe',
  1: 'shovel', 2: 'shovel', 5: 'shovel', 12: 'shovel', 19: 'shovel', 23: 'shovel',
};

interface RagdollPart {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  angVel: THREE.Vector3;
  halfH: number;
}

interface Ragdoll {
  parts: RagdollPart[];
  life: number;
}

interface Particle {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  life: number;
  /** 该粒子独占材质（尘土），销毁时需要一并释放 */
  ownMaterial?: boolean;
  /** 初始尺寸，淡出时按此缩放而不是写死 */
  size?: number;
}

function radialTexture(inner: string, outer: string, coreStop = 0.4): THREE.Texture {
  const c = document.createElement('canvas');
  c.width = c.height = 128;
  const ctx = c.getContext('2d')!;
  const g = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
  g.addColorStop(0, inner);
  g.addColorStop(coreStop, inner);
  g.addColorStop(1, outer);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 128, 128);
  return new THREE.CanvasTexture(c);
}

export class Game {
  canvas: HTMLCanvasElement;
  opts: GameOptions;
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera: THREE.PerspectiveCamera;
  world: World;
  /** 下界维度：overworld/nether 各自一份独立的 World 实例，`this.world` 永远指向"当前所在"的那个。
   *  nether 是懒创建的（第一次进传送门才 new），避免每局游戏都白白多生成一份下界地形。 */
  private overworld!: World;
  private nether: World | null = null;
  private dimension: 'overworld' | 'nether' = 'overworld';
  private lastOverworldPos = new THREE.Vector3(8.5, 40, 8.5);
  private lastNetherPos = new THREE.Vector3(0.5, 34.1, 0.5);
  /** 传送门冷却：刚落地那一小段时间内脚下即使还站在传送门里也不会立刻被吸回去 */
  private portalCooldown = 0;
  private atlasTex!: THREE.Texture;
  private hdPBREnabled = false;
  clock = new THREE.Clock();

  // player
  pos = new THREE.Vector3(8, 40, 8);
  vel = new THREE.Vector3();
  yaw = 0;
  pitch = 0;
  onGround = false;
  flying = false;
  mode: Mode;
  health = 20;
  hunger = 20;
  air = 1;
  dead = false;
  inWater = false;

  // input
  keys = new Set<string>();
  breaking = false;
  placing = false;
  locked = false;
  paused = false;
  touchMove = { x: 0, z: 0 };
  touchJump = false;
  sensitivity = 0.0022;

  // interaction — real 36-slot inventory like Minecraft
  inventory: (ItemStack | null)[] = Array.from({ length: INV_SIZE }, () => null);
  selected = 0;
  private openChestPos: { x: number; y: number; z: number } | null = null;
  breakProgress = 0;
  target: { x: number; y: number; z: number; id: number } | null = null;
  placeCooldown = 0;
  lastSpaceTap = 0;

  // world streaming
  renderDistance: number;
  private chunkQueue: { cx: number; cz: number }[] = [];
  private chunkQueueTotal = 0;
  private lastChunkKey = '';
  loading = 0;

  // visuals
  highlight!: THREE.LineSegments;
  handGroup = new THREE.Group();
  handArm: THREE.Group | null = null;
  handMesh: THREE.Object3D | null = null;
  swing = 0;
  bob = 0;
  sun!: THREE.DirectionalLight;
  hemi!: THREE.HemisphereLight;
  private fillLight!: THREE.DirectionalLight;
  skyDome!: THREE.Mesh;
  crackMesh!: THREE.Mesh;
  crackTextures!: THREE.Texture[];
  private crackStage = -1;
  private avatarPhase = 0;
  private avatarBreath = 0;
  sunSprite!: THREE.Sprite;
  moonSprite!: THREE.Sprite;
  clouds!: THREE.InstancedMesh;
  private cloudDriftX = 0;
  avatar!: Avatar;
  cameraMode = 0; // 0 first person, 1 third back, 2 third front
  timeOfDay = 0.28; // 0..1  (0.25 = morning, 0.5 = noon)
  dayNight = true;
  daySpeed = 1 / 420; // full cycle in 7 minutes

  mobs: MobEntity[] = [];
  private tntEntities: { mesh: THREE.Mesh; pos: THREE.Vector3; timer: number }[] = [];
  private particles: Particle[] = [];
  private particleMats = new Map<number, THREE.MeshLambertMaterial>();
  private particleGeo = new THREE.BoxGeometry(1, 1, 1);
  private dustMat: THREE.MeshLambertMaterial | null = null;
  private dustGeo: THREE.BoxGeometry | null = null;
  private wasOnGround = false;
  private raf = 0;
  private fpsAcc = 0;
  private fpsCount = 0;
  private fps = 60;
  private stateTimer = 0;
  private stepTimer = 0;
  private digSoundTimer = 0;
  private sprinting = false;
  private mobSpawnTimer = 0.8;
  private mobTickAccumulator = 0;
  private spawnedAltars = new Set<string>();
  private maxMobs: number;
  private ragdolls: Ragdoll[] = [];
  private eatTimer = 0;
  private FOODS: Record<number, { hunger: number; health: number; label: string }> = {
    14: { hunger: 2, health: 0, label: '糖果' },
    22: { hunger: 3, health: 1, label: '南瓜' },
    27: { hunger: 2, health: 0, label: '蘑菇' },
    24: { hunger: 1, health: 0, label: '红花' },
    25: { hunger: 1, health: 0, label: '蓝花' },
  };
  private torchLight!: THREE.PointLight;
  /** finalComposer：真正输出到屏幕的合成链（SSAO -> SSR -> 泛光叠加 -> 输出） */
  private composer: EffectComposer | null = null;
  /** bloomComposer：只用来单独渲染"应该发光的物体"，产出一张泛光贴图，
   *  再由 mixPass 叠加回正常画面。太阳/月亮、地形这些不在 BLOOM_LAYER 里的东西
   *  渲染这张图时会被临时刷成纯黑，这样泛光就不会包住整个太阳变成一片光污染。 */
  private bloomComposer: EffectComposer | null = null;
  private bloomPass: UnrealBloomPass | null = null;
  private mixPass: ShaderPass | null = null;
  private bloomEnabled = false;
  private static readonly BLOOM_LAYER = 1;
  private bloomLayers = new THREE.Layers();  private bloomDarkMaterial = new THREE.MeshBasicMaterial({ color: 0x000000 });
  private bloomMaterialCache = new Map<string, THREE.Material | THREE.Material[]>();
  private ssrPass: SSRPass | null = null;
  private ssrEnabled = false;
  private ssaoPass: SSAOPass | null = null;
  private ssaoEnabled = false;
  private ssaoRawTarget: THREE.WebGLRenderTarget | null = null;
  private ssaoDummyTarget: THREE.WebGLRenderTarget | null = null;
  private aoApplyPass: ShaderPass | null = null;
  /** 体积光 / 丁达尔效应（screen-space sun shaft）：
   *  1) godrayMaskComposer 把地形涂黑、只留太阳精灵（靠深度测试被树冠/方块正确遮挡），
   *     渲染出一张"太阳可见度遮罩"；
   *  2) godrayBlurComposer 对这张遮罩做一次以太阳屏幕坐标为中心的径向衰减采样
   *     （GPU Gems 3 的经典 sun-shaft 做法），产出光柱纹理；
   *  3) godrayMixPass 把光柱纹理加回主画面，跟泛光的叠加方式（mixPass）是同一个套路。 */
  private static readonly SUN_LAYER = 2;
  private sunLayers = new THREE.Layers();
  private godrayMaskTarget: THREE.WebGLRenderTarget | null = null;
  private godrayBlurTarget: THREE.WebGLRenderTarget | null = null;
  private godrayBlurPass: ShaderPass | null = null;
  private godrayMixPass: ShaderPass | null = null;
  private godrayEnabled = false;
  private godraySunUV = new THREE.Vector2(0.5, 0.5);
  private godrayIntensity = 0;
  private colorGradePass: ShaderPass | null = null;
  private dofPass: BokehPass | null = null;
  private dofEnabled = false;
  private dofFocusSmoothed = 22;
  private motionBlurPass: ShaderPass | null = null;
  private motionBlurEnabled = false;
  private prevYawForBlur = 0;
  private prevPitchForBlur = 0;
  /** SSR 只反射水/冰/玻璃/水晶这些真正光滑/半透明的表面，
   *  不是全场景（地面、树、玩家都反光）——这个数组的引用要保持不变，
   *  每帧只更新内容，避免重复触发 SSRPass 内部的 shader 重编译。 */
  private ssrReflectiveMeshes: THREE.Mesh[] = [];
  private baseFogFar = 40;
  private questProgress: Record<string, number> = {};
  private placedBlocks = 0;
  private drops: ItemDrop[] = [];
  mods = new Set<string>();
  raining = false;
  private tracers: { line: THREE.Line; life: number }[] = [];
  private rainParticles: THREE.Points | null = null;
  private airJumps = 0;
  private jumpHeld = false;
  private shootCooldown = 0;
  private bossRushTimer = 30;
  stamina = 10;
  thirst = 10;
  temp = 5;
  day = 1;
  fear = 0;
  glitch = 0;
  private lastDayPhase = true;
  private knockTimer = 0;
  private glitchTimer = 0;
  waveMode = false;
  wave = 0;
  private waveTimer = 0;
  private spawnedBosses = new Set<string>();
  private bossKeys = new Map<number, string>();
  private disposed = false;

  constructor(canvas: HTMLCanvasElement, opts: GameOptions) {
    this.canvas = canvas;
    this.opts = opts;
    this.mode = opts.mode;
    this.renderDistance = opts.renderDistance;
    const lowPowerDevice = window.matchMedia('(pointer: coarse)').matches;
    this.lowPower = lowPowerDevice;
    this.maxMobs = lowPowerDevice ? 8 : 12;
    this.flying = false;

    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: !lowPowerDevice,
      powerPreference: 'high-performance',
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, lowPowerDevice ? 1.15 : 2));
    this.renderer.setSize(window.innerWidth, window.innerHeight, false);
    this.renderer.setClearColor(0x8fd3ff);
    // 电影级色调映射：高光不溢出、暗部有层次
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    // 柔和实时阴影
    this.renderer.shadowMap.enabled = !lowPowerDevice;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.camera = new THREE.PerspectiveCamera(72, window.innerWidth / window.innerHeight, 0.08, 1200);
    this.scene.add(this.camera);

    // 高清材质包：材质分辨率翻倍并重绘细节
    if (opts.mods?.includes('hdtexture')) setHDTextures(true);
    const atlas = createAtlasTexture();
    this.atlasTex = atlas;
    this.world = new World(opts.seed, opts.worldType, atlas);
    this.overworld = this.world;
    // 光线追踪：网格化时逐顶点射线求天空遮蔽
    this.world.raytraced = !!opts.mods?.includes('raytracing');
    this.scene.add(this.world.group);
    // 让驯服宠物能索敌（共享同一数组引用）
    this.world.mobList = this.mobs as unknown as import('./world').MobLike[];

    if (opts.save) {
      this.world.importEdits(opts.save.edits ?? []);
      this.world.importOpenedChests(opts.save.openedChests ?? []);
      this.world.importChests(opts.save.chests ?? {});
      this.loadInventoryFromSave(opts.save);
      this.questProgress = { ...(opts.save.quests ?? {}) };
      this.timeOfDay = opts.save.timeOfDay ?? this.timeOfDay;
    } else if (this.mode === 'creative') {
      // Creative starts with a full hotbar of goodies.
      [1, 4, 8, 9, 13, 14, 18, 20, 6].forEach((id, i) => {
        this.inventory[i] = { id, count: MAX_STACK };
      });
    }
    // Survival starts with an empty inventory — you punch trees to earn everything.

    this.setupScene();
    this.spawnPlayer();

    // 读档如果存的时候人在下界，这里把维度切过去（在下面恢复坐标之前，
    // 这样下面 forceGenerate 用的是正确的那个 World 实例）
    if (opts.save?.dimension === 'nether') {
      this.nether = new World(this.overworld.seed + 74177, 'nether', this.atlasTex);
      this.nether.importEdits(opts.save.netherEdits ?? []);
      this.nether.mobList = this.mobs as unknown as import('./world').MobLike[];
      this.scene.remove(this.overworld.group);
      this.world = this.nether;
      this.dimension = 'nether';
      this.scene.add(this.nether.group);
    }

    if (opts.save?.pos) {
      this.pos.set(opts.save.pos[0], opts.save.pos[1], opts.save.pos[2]);
      this.yaw = opts.save.yaw ?? this.yaw;
      this.pitch = opts.save.pitch ?? 0;
      // make sure there is ground under the restored position
      const scx = Math.floor(this.pos.x / CHUNK_SIZE);
      const scz = Math.floor(this.pos.z / CHUNK_SIZE);
      for (let dx = -1; dx <= 1; dx++) {
        for (let dz = -1; dz <= 1; dz++) this.world.forceGenerate(scx + dx, scz + dz);
      }
    }
    this.bindEvents();
    this.updateHandBlock();
    this.notifyInventory();

    if (this.mode === 'survival') {
      setTimeout(
        () => this.opts.onToast('⚔️ 生存目标：白天采集资源、合成装备，夜晚警惕怪物，击败 Boss！'),
        1600,
      );
    }
    if (opts.waveGame) {
      this.waveMode = true;
      this.waveTimer = 5;
      this.opts.onToast('🌊 联机小游戏「野人来了」开始！和 AI 队友一起守住营地！');
    }
    this.mods = new Set(opts.mods ?? []);
    if (this.mods.has('guns') && this.mode === 'survival') {
      // 枪械模组：赠送一套零件方便上手
      this.addItem(202, 2, false);
      this.addItem(203, 1, false);
      this.addItem(204, 16, false);
    }
    if (opts.bonus && this.mode === 'survival') {
      opts.bonus.forEach(([id, count]) => this.addItem(id, count, false));
    }
    if (this.mods.has('petdragon')) {
      const dragonDef = MOB_DEFS.find((d) => d.id === 21);
      if (dragonDef) {
        const mob = new MobEntity(dragonDef, this.pos.x + 1.5, this.pos.y + 2, this.pos.z);
        mob.tamed = true;
        this.scene.add(mob.group);
        this.mobs.push(mob);
        this.opts.onToast('🐉 飞龙伙伴已加入队伍！');
      }
    }
    if (this.mods.has('rain') || this.mods.has('rainhorror')) this.raining = Math.random() < 0.45;
    if (this.mods.size) this.notifyInventory();

    this.clock.start();
    this.loop();
  }

  /* ------------------------------------------------ scene ------------ */

  /** 线性雾（之前用的 THREE.Fog）在近处到 near 之前完全没有雾、过了 far 直接全白，
   *  是一条生硬的直线；真实大气的雾/霾其实是指数衰减的——离得越远消光越快，
   *  但近处也不是"完全没有"，只是很淡，这种连续的衰减曲线才是"大气感"的来源。
   *  换成 THREE.FogExp2（只有一个 density 参数，没有 near/far）之后，原来所有
   *  给 near/far 赋值的地方都要跟着换算成等效的 density，统一走这个换算函数，
   *  免得到处散落着不一致的换算公式。
   *
   *  ⚠️ 这个系数上次给错了：three.js 的 FogExp2 用的是 exp(-(density*d)^2)
   *  （注意是平方），不是普通指数衰减 exp(-density*d)。之前 K=3.0 是按普通指数
   *  衰减估的，套到平方公式上意味着走到 far 距离 1/3 处雾就已经浓到看不清了——
   *  这就是"可见范围突然变得很小、雾好重"的真正原因，不是你的错觉。重新解：
   *  希望走到 far 距离时雾浓度到 95%（exp(-K^2)=0.05），解出 K≈1.73。 */
  private static readonly FOG_DENSITY_K = 1.7;
  private fogDensityFor(effectiveFar: number): number {
    return Game.FOG_DENSITY_K / Math.max(1, effectiveFar);
  }

  private setupScene() {
    this.baseFogFar = this.renderDistance * CHUNK_SIZE * 0.95;
    this.scene.fog = new THREE.FogExp2(0x8fd3ff, this.fogDensityFor(this.baseFogFar));
    this.hemi = new THREE.HemisphereLight(0xbfe6ff, 0x6a5a44, 1.0);
    this.scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight(0xfff2d0, 1.0);
    this.sun.position.set(60, 120, 40);
    this.scene.add(this.sun);
    this.scene.add(this.sun.target);

    // 阴影相机：跟随玩家的方形范围
    const shadowRange = 34;
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(3072, 3072);
    this.sun.shadow.camera.left = -shadowRange;
    this.sun.shadow.camera.right = shadowRange;
    this.sun.shadow.camera.top = shadowRange;
    this.sun.shadow.camera.bottom = -shadowRange;
    this.sun.shadow.camera.near = 1;
    this.sun.shadow.camera.far = 260;
    this.sun.shadow.bias = -0.0015;
    // 之前把 normalBias 调到 0.065 是为了压树叶阴影的摩尔纹瑕疵，但这个值在这个
    // 1 格=1 单位的体素世界里太大了——normalBias 是沿着表面法线方向把阴影采样点
    // 往外推，推 0.065 个单位、在低角度阳光下投影到地面能形成肉眼可见的一整段
    // 空隙，看起来就是"阴影跟方块本体脱节、飘在一段距离外"，这是所有实心方块的
    // 阴影现在都在犯的问题，比树叶偶尔的一点摩尔纹严重得多，必须优先保证阴影贴着
    // 方块本体。调回一个温和很多的值，树叶阴影可能会重新出现一点点噪点，但不会
    // 再有大面积的"阴影漂移"。
    this.sun.shadow.normalBias = 0.02;
    this.sun.shadow.camera.updateProjectionMatrix();
    // 补光：之前是固定挂在世界坐标 (-40,30,-50) 朝向原点的一盏灯——离生成点一远，
    // 这个方向跟太阳、跟玩家的相对关系基本就是瞎的了。现在改成经典三点布光里的
    // "fill light"：始终待在太阳的正反方向、强度跟随昼夜动态变化（在 updateSky 里
    // 更新），阳光背对的那一面不会再死黑一片，边缘也不会那么硬。
    this.fillLight = new THREE.DirectionalLight(0x9fc6ff, 0.14);
    this.fillLight.position.set(-40, 30, -50);
    this.scene.add(this.fillLight);
    this.scene.add(this.fillLight.target);

    // 渐变天穹（替代纯色背景）
    this.skyDome = new THREE.Mesh(
      new THREE.SphereGeometry(900, 32, 20),
      new THREE.ShaderMaterial({
        side: THREE.BackSide,
        depthWrite: false,
        fog: false,
        uniforms: {
          uTop: { value: new THREE.Color(0x2f7fe0) },
          uMid: { value: new THREE.Color(0x8fd3ff) },
          uBottom: { value: new THREE.Color(0xd9f2c4) },
          uSunDir: { value: new THREE.Vector3(0, 1, 0) },
          uSunColor: { value: new THREE.Color(0xfff0c0) },
        },
        vertexShader: `
          varying vec3 vDir;
          void main() {
            vDir = normalize(position);
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
          }
        `,
        fragmentShader: `
          uniform vec3 uTop;
          uniform vec3 uMid;
          uniform vec3 uBottom;
          uniform vec3 uSunDir;
          uniform vec3 uSunColor;
          varying vec3 vDir;
          void main() {
            float h = clamp(vDir.y * 0.5 + 0.5, 0.0, 1.0);
            vec3 col = mix(uBottom, uMid, smoothstep(0.34, 0.56, h));
            col = mix(col, uTop, smoothstep(0.55, 1.0, h));
            // 太阳辉光
            float d = max(dot(normalize(vDir), normalize(uSunDir)), 0.0);
            col += uSunColor * pow(d, 22.0) * 0.9;
            col += uSunColor * pow(d, 4.0) * 0.22;
            // 更宽的一层大气散射光晕：日出日落时天空会被太阳方向的暖色"染"开一大片，
            // 而不是只有太阳周围一小圈亮
            col += uSunColor * pow(d, 1.4) * 0.1;
            // 地平线雾化
            col = mix(col, uBottom, pow(1.0 - abs(vDir.y), 8.0) * 0.35);
            gl_FragColor = vec4(col, 1.0);
          }
        `,
      }),
    );
    this.skyDome.frustumCulled = false;
    this.scene.add(this.skyDome);

    const sunMat = new THREE.SpriteMaterial({
      // 太阳之前是又大又是一整块死白圆盘：缩小核心占比（coreStop 0.4→0.16），
      // 边缘颜色也降一点亮度，配合下面缩小的 scale，看起来是个"小太阳"而不是天空里的巨型光斑
      map: radialTexture('rgba(255,248,214,1)', 'rgba(255,214,120,0)', 0.16),
      transparent: true,
      depthWrite: false,
      fog: false,
    });
    this.sunSprite = new THREE.Sprite(sunMat);
    this.sunSprite.scale.setScalar(22);
    // 体积光遮罩通道只保留这个 layer 的东西不涂黑，见 setupGodrayComposer()
    this.sunSprite.layers.enable(Game.SUN_LAYER);
    this.scene.add(this.sunSprite);

    const moonMat = new THREE.SpriteMaterial({
      map: radialTexture('rgba(238,246,255,1)', 'rgba(180,210,255,0)', 0.16),
      transparent: true,
      depthWrite: false,
      fog: false,
    });
    this.moonSprite = new THREE.Sprite(moonMat);
    this.moonSprite.scale.setScalar(15);
    this.scene.add(this.moonSprite);

    // 方块云：MC 经典的那种扁平色块云，不是照片写实的蓬松云。之前折腾了好几版
    // "真实"云朵纹理，效果一直不理想（发霉/接缝/怎么调都不像）——干脆换成这个
    // 更简单也更符合这个游戏整体像素风格的方案：一片网格，每格要么是一块扁平的
    // 云方块、要么是空的（留出天空），用 InstancedMesh 一次性摆好，之后每帧只需要
    // 挪动整个网格的位置（跟随玩家 + 缓慢飘移），不需要逐格重算。
    const CLOUD_GRID = 28;
    const CLOUD_CELL = 15;
    const CLOUD_H = 4.5;
    const cloudHash = (x: number, z: number) => {
      const v = Math.sin(x * 127.1 + z * 311.7) * 43758.5453;
      return v - Math.floor(v);
    };
    const cloudGeo = new THREE.BoxGeometry(CLOUD_CELL * 0.94, CLOUD_H, CLOUD_CELL * 0.94);
    const cloudMat = new THREE.MeshLambertMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.92,
      fog: false,
    });
    const cloudCells: { x: number; z: number }[] = [];
    for (let gx = 0; gx < CLOUD_GRID; gx++) {
      for (let gz = 0; gz < CLOUD_GRID; gz++) {
        // 45% 左右的格子有云，跟正版那种"一片一片、留有空隙"的疏密感接近
        if (cloudHash(gx, gz) > 0.55) cloudCells.push({ x: gx, z: gz });
      }
    }
    this.clouds = new THREE.InstancedMesh(cloudGeo, cloudMat, cloudCells.length);
    this.clouds.castShadow = false;
    this.clouds.receiveShadow = false;
    const cm = new THREE.Matrix4();
    cloudCells.forEach((p, i) => {
      cm.makeTranslation((p.x - CLOUD_GRID / 2) * CLOUD_CELL, 0, (p.z - CLOUD_GRID / 2) * CLOUD_CELL);
      this.clouds.setMatrixAt(i, cm);
    });
    this.clouds.instanceMatrix.needsUpdate = true;
    this.clouds.position.y = 118;
    this.scene.add(this.clouds);

    const edges = new THREE.EdgesGeometry(new THREE.BoxGeometry(1.004, 1.004, 1.004));
    this.highlight = new THREE.LineSegments(
      edges,
      new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.95, depthTest: true }),
    );
    this.highlight.visible = false;
    this.scene.add(this.highlight);

    // 破坏裂纹覆盖层：随挖掘进度逐级加深
    this.crackTextures = createCrackTextures();
    this.crackMesh = new THREE.Mesh(
      new THREE.BoxGeometry(1.008, 1.008, 1.008),
      new THREE.MeshBasicMaterial({
        map: this.crackTextures[0],
        transparent: true,
        depthWrite: false,
        polygonOffset: true,
        polygonOffsetFactor: -1,
        polygonOffsetUnits: -1,
      }),
    );
    this.crackMesh.visible = false;
    this.crackMesh.renderOrder = 3;
    this.scene.add(this.crackMesh);

    this.camera.add(this.handGroup);
    this.handGroup.position.set(0.5, -0.42, -0.7);

    // 第一人称手臂：袖子 + 手掌，让手持物品不再“凭空漂浮”
    const skinMat = new THREE.MeshLambertMaterial({ color: 0xffe0c0 });
    const sleeveMat = new THREE.MeshLambertMaterial({ color: 0x4fc3f7 });
    this.handArm = new THREE.Group();
    const sleeve = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.4, 0.13), sleeveMat);
    sleeve.position.set(0.06, -0.28, 0.18);
    sleeve.rotation.x = 0.5;
    this.handArm.add(sleeve);
    const cuff = new THREE.Mesh(new THREE.BoxGeometry(0.145, 0.06, 0.145), new THREE.MeshLambertMaterial({ color: 0x3ba7dd }));
    cuff.position.set(0.06, -0.09, 0.08);
    this.handArm.add(cuff);
    const palm = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.13, 0.15), skinMat);
    palm.position.set(0.06, -0.03, 0.0);
    this.handArm.add(palm);
    for (let i = 0; i < 3; i++) {
      const finger = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.05, 0.09), skinMat);
      finger.position.set(0.015 + i * 0.045, 0.0, -0.09);
      this.handArm.add(finger);
    }
    this.handArm.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) (o as THREE.Mesh).renderOrder = 9;
    });
    this.handGroup.add(this.handArm);
    // 手臂一直是设了 renderOrder 但从没关掉深度测试——玩家贴近墙面/方块时，
    // 世界几何体的深度会正常地"挡住"手臂，看起来就是手插进墙里/ 手突然消失了一截。
    // 第一人称手部模型的标准做法是永远画在最上面，不管面前是什么，这里统一关掉
    // depthTest（用下面这个复用的辅助函数，握持方块/工具/枪械那几处也都会调用它）。
    this.disableHandDepthTest(this.handArm);

    this.torchLight = new THREE.PointLight(0xffc46b, 0, 18, 2);
    this.torchLight.position.set(0.1, 0.15, -1.35);
    this.camera.add(this.torchLight);

    this.avatar = createAvatar();
    this.avatar.group.visible = false;
    this.scene.add(this.avatar.group);
  }

  cycleCamera() {
    this.cameraMode = (this.cameraMode + 1) % 3;
    this.opts.onToast(
      this.cameraMode === 0 ? '👀 第一人称' : this.cameraMode === 1 ? '🎥 第三人称（背后）' : '🤳 第三人称（正面）',
    );
  }

  private updateAvatar(dt: number, bobY: number) {
    const a = this.avatar;
    a.group.visible = this.cameraMode !== 0;
    this.handGroup.visible = this.cameraMode === 0;
    if (!a.group.visible) return;
    a.group.position.set(this.pos.x, this.pos.y + bobY * 0.3, this.pos.z);
    // 平滑转身（不再瞬间对齐）
    let dy = this.yaw - a.group.rotation.y;
    while (dy > Math.PI) dy -= Math.PI * 2;
    while (dy < -Math.PI) dy += Math.PI * 2;
    a.group.rotation.y += dy * Math.min(1, dt * 14);

    this.avatarPhase += dt * (2.4 + Math.hypot(this.vel.x, this.vel.z) * 1.5);
    const speed = Math.hypot(this.vel.x, this.vel.z);
    const amt = Math.min(1, speed / 4.5);
    const p = this.avatarPhase;
    const swing = Math.sin(p);
    const swing2 = Math.sin(p * 2);
    const breathing = Math.sin(this.avatarBreath) * 0.02;
    this.avatarBreath += dt * 2.1;

    // 腿：髋部摆动 + 膝盖后弯（抬起时弯曲更大）
    a.leftLeg.rotation.x = swing * 0.82 * amt;
    a.rightLeg.rotation.x = -swing * 0.82 * amt;
    a.leftKnee.rotation.x = -Math.max(0, Math.cos(p)) * 0.9 * amt - 0.04;
    a.rightKnee.rotation.x = -Math.max(0, -Math.cos(p)) * 0.9 * amt - 0.04;

    // 手臂：反向摆动 + 肘部微弯
    a.leftArm.rotation.x = -swing * 0.7 * amt;
    a.rightArm.rotation.x = swing * 0.7 * amt;
    a.leftElbow.rotation.x = -0.16 - Math.max(0, -Math.cos(p)) * 0.35 * amt;
    a.rightElbow.rotation.x = -0.16 - Math.max(0, Math.cos(p)) * 0.35 * amt;
    a.leftArm.rotation.z = 0.08 + breathing;
    a.rightArm.rotation.z = -0.08 - breathing;

    // 躯干：起伏 + 左右微倾 + 呼吸
    a.torso.position.y = 0.74 + swing2 * 0.022 * amt + breathing * 0.5;
    a.torso.rotation.z = swing * 0.05 * amt;
    a.torso.rotation.x = Math.min(0.24, speed * 0.05);
    // 围巾飘动
    a.scarf.rotation.x = -0.2 - amt * 0.5 - swing2 * 0.12 * amt;

    if (!this.onGround) {
      // 空中姿态：手臂上扬、腿前后分开
      a.leftArm.rotation.x = -1.0;
      a.rightArm.rotation.x = -1.0;
      a.leftElbow.rotation.x = -0.5;
      a.rightElbow.rotation.x = -0.5;
      a.leftLeg.rotation.x = 0.42;
      a.rightLeg.rotation.x = -0.24;
      a.leftKnee.rotation.x = -0.5;
      a.rightKnee.rotation.x = -0.14;
      a.torso.rotation.x = 0.1;
    }
    if (this.sprinting && amt > 0.5) {
      // 疾跑：手臂弯得更厉害
      a.leftElbow.rotation.x = -1.15;
      a.rightElbow.rotation.x = -1.15;
    }
    if (this.swing > 0) {
      const s = Math.sin(this.swing * Math.PI);
      a.rightArm.rotation.x = -s * 2.2;
      a.rightElbow.rotation.x = -s * 0.8;
    }

    // 头部：跟随俯仰 + 走路点头 + 眨眼由贴图表现
    a.head.rotation.x = THREE.MathUtils.clamp(this.pitch * 0.55, -0.6, 0.6) + swing2 * 0.03 * amt;
    a.head.rotation.y = THREE.MathUtils.clamp(-dy * 0.25, -0.5, 0.5);
  }

  private spawnPlayer() {
    // preload a few chunks so the ground exists
    for (let dx = -1; dx <= 1; dx++) {
      for (let dz = -1; dz <= 1; dz++) this.world.forceGenerate(dx, dz);
    }
    const y = this.world.surfaceY(8, 8);
    this.pos.set(8.5, Math.max(y, SEA_LEVEL + 1) + 0.2, 8.5);
    this.yaw = Math.PI * 0.25;
  }

  /** 玩家踩进传送门方块时调用：决定往哪个维度传，然后交给 switchDimension 处理落地。 */
  private enterPortal() {
    const target: 'overworld' | 'nether' = this.dimension === 'overworld' ? 'nether' : 'overworld';
    this.switchDimension(target);
  }

  /** 真正的跨维度切换：换 World 实例、换场景挂载、换玩家坐标、换天空氛围。
   *  坐标按经典的 1:8 比例缩放（下界 1 格 = 主世界 8 格），这样传送门之间的相对方位感还在。 */
  private switchDimension(target: 'overworld' | 'nether') {
    if (this.dimension === target || !this.world) return;

    if (this.dimension === 'overworld') this.lastOverworldPos.copy(this.pos);
    else this.lastNetherPos.copy(this.pos);

    if (target === 'nether' && !this.nether) {
      this.nether = new World(this.overworld.seed + 74177, 'nether', this.atlasTex);
    }
    const fromWorld = this.world;
    const toWorld = target === 'nether' ? this.nether! : this.overworld;

    const scale = target === 'nether' ? 1 / 8 : 8;
    const tx = Math.round(this.pos.x * scale);
    const tz = Math.round(this.pos.z * scale);

    this.scene.remove(fromWorld.group);
    this.world = toWorld;
    this.dimension = target;
    this.scene.add(toWorld.group);
    toWorld.mobList = this.mobs as unknown as import('./world').MobLike[];

    const landing = toWorld.ensurePortalNear(tx, tz);
    this.pos.copy(landing);
    this.vel.set(0, 0, 0);
    this.portalCooldown = 1.4;

    // 换维度时清空当前生物列表：下界暂时没有专属怪物生成规则，
    // 与其让主世界的怪物穿模出现在下界洞窟里，不如干脆先清空（下次刷新会按新维度重新生成）。
    for (const m of this.mobs) {
      this.scene.remove(m.group);
      m.dispose();
    }
    this.mobs.length = 0;

    this.opts.onToast(
      target === 'nether' ? '🔥 传送门把你吸进了下界…' : '🌤️ 传送门把你送回了主世界',
    );
  }

  /* ------------------------------------------------ input ------------ */

  private onKeyDown = (e: KeyboardEvent) => {
    if (e.repeat) return;
    const t = e.target as HTMLElement | null;
    if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA')) return;
    const code = e.code;
    this.keys.add(code);
    if (code.startsWith('Digit')) {
      const n = Number(code.slice(5));
      if (n >= 1 && n <= 9) this.setSelected(n - 1);
    }
    if (code === 'Space') {
      const now = performance.now();
      if (now - this.lastSpaceTap < 280 && (this.mode === 'creative' || this.mods.has('flight'))) {
        this.flying = !this.flying;
        this.vel.y = 0;
        this.opts.onToast(this.flying ? '✈️ 飞行模式开启' : '🚶 飞行模式关闭');
      }
      this.lastSpaceTap = now;
    }
    if (code === 'KeyV' || code === 'F5') {
      e.preventDefault();
      this.cycleCamera();
    }
    if (code === 'KeyT' && this.mods.has('timecontrol')) {
      this.timeOfDay = this.isDaytime() ? 0.82 : 0.3;
      this.opts.onToast(this.isDaytime() ? '☀️ 天亮了' : '🌙 天黑了');
    }
    if (code === 'KeyF' && this.mode === 'creative') {
      this.flying = !this.flying;
      this.vel.y = 0;
      this.opts.onToast(this.flying ? '✈️ 飞行模式开启' : '🚶 飞行模式关闭');
    }
    if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(code)) e.preventDefault();
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };

  private onMouseMove = (e: MouseEvent) => {
    if (!this.locked || this.paused) return;
    this.yaw -= e.movementX * this.sensitivity;
    this.pitch -= e.movementY * this.sensitivity;
    const lim = Math.PI / 2 - 0.001;
    this.pitch = Math.max(-lim, Math.min(lim, this.pitch));
  };

  private onMouseDown = (e: MouseEvent) => {
    if (!this.locked || this.paused) return;
    if (e.button === 0) {
      if (this.tryShoot()) return;
      if (this.tryHitMob()) return;
      this.breaking = true;
    } else if (e.button === 2) {
      if (this.tryFeedMob()) return;
      this.placing = true;
      this.tryPlace();
    } else if (e.button === 1) this.pickBlock();
  };

  private onMouseUp = (e: MouseEvent) => {
    if (e.button === 0) {
      this.breaking = false;
      this.breakProgress = 0;
    }
    if (e.button === 2) this.placing = false;
  };

  private onWheel = (e: WheelEvent) => {
    if (!this.locked || this.paused) return;
    const dir = e.deltaY > 0 ? 1 : -1;
    this.setSelected((this.selected + dir + 9) % 9);
  };

  private onPointerLockChange = () => {
    this.locked = document.pointerLockElement === this.canvas;
    if (!this.locked) {
      this.breaking = false;
      this.placing = false;
      this.keys.clear();
    }
    this.opts.onLockChange(this.locked);
  };

  private onResize = () => {
    this.renderer.setSize(window.innerWidth, window.innerHeight, false);
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    this.composer?.setSize(window.innerWidth, window.innerHeight);
    this.ssaoRawTarget?.setSize(window.innerWidth, window.innerHeight);
    const gw = Math.max(2, Math.floor(window.innerWidth / 2));
    const gh = Math.max(2, Math.floor(window.innerHeight / 2));
    this.godrayMaskTarget?.setSize(gw, gh);
    this.godrayBlurTarget?.setSize(gw, gh);
  };

  private bindEvents() {
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    document.addEventListener('mousemove', this.onMouseMove);
    document.addEventListener('pointerlockchange', this.onPointerLockChange);
    this.canvas.addEventListener('mousedown', this.onMouseDown);
    window.addEventListener('mouseup', this.onMouseUp);
    this.canvas.addEventListener('wheel', this.onWheel, { passive: true });
    this.canvas.addEventListener('contextmenu', (e) => e.preventDefault());
    window.addEventListener('resize', this.onResize);
  }

  requestLock() {
    sfx.resume();
    this.canvas.requestPointerLock?.();
  }

  exitLock() {
    document.exitPointerLock?.();
  }

  /* ------------------------------------------------ API -------------- */

  setSelected(i: number) {
    if (i < 0 || i >= INV_SIZE) return;
    this.selected = i;
    this.updateHandBlock();
    this.notifyInventory();
    sfx.click();
  }

  /** 创造模式：把方块放进选中格；生存模式：选中背包里该方块所在格。 */
  selectOrSetBlock(blockId: number) {
    if (this.mode === 'creative') {
      this.inventory[this.selected] = { id: blockId, count: MAX_STACK };
      this.updateHandBlock();
      this.notifyInventory();
      sfx.click();
      return;
    }
    const idx = this.inventory.findIndex((s) => s && s.id === blockId);
    if (idx >= 0) this.setSelected(idx);
    else this.opts.onToast(`背包里没有 ${getBlock(blockId).name}`);
  }

  setMode(mode: Mode) {
    this.mode = mode;
    this.flying = mode === 'creative' ? this.flying : false;
    if (mode === 'survival') {
      this.health = 20;
      this.hunger = 20;
    }
    this.notifyInventory();
    this.opts.onToast(mode === 'creative' ? '🎨 创造模式' : '⚔️ 生存模式');
  }

  setRenderDistance(d: number) {
    this.renderDistance = d;
    this.baseFogFar = d * CHUNK_SIZE * 0.95;
    (this.scene.fog as THREE.FogExp2).density = this.fogDensityFor(this.baseFogFar);
    this.lastChunkKey = '';
  }

  setDayNight(on: boolean) {
    this.dayNight = on;
  }

  /** 开关泛光后处理。首次开启时才会真正创建 composer，失败时安全回退到普通渲染。 */
  setBloom(on: boolean) {
    if (on && !this.composer) this.setupComposer();
    this.bloomEnabled = on && !!this.composer;
    if (this.bloomPass) this.bloomPass.enabled = this.bloomEnabled;
    if (this.mixPass) this.mixPass.enabled = this.bloomEnabled;
  }

  /** 开关屏幕空间反射（实验性）。水面/冰面/湿滑地面会真实反射周围场景。 */
  setSSR(on: boolean) {
    if (on && !this.composer) this.setupComposer();
    this.ssrEnabled = on && !!this.composer;
    if (this.ssrPass) this.ssrPass.enabled = this.ssrEnabled;
  }

  /** 开关体积光/丁达尔效应（实验性）。阳光穿过树冠、方块缝隙时会出现一道道光柱。 */
  setGodray(on: boolean) {
    if (on && !this.composer) this.setupComposer();
    this.godrayEnabled = on && !!this.composer && !!this.godrayMixPass;
    if (this.godrayMixPass) this.godrayMixPass.enabled = this.godrayEnabled;
  }

  /** 开关景深（实验性）。准星瞄准的地方清楚，远处/近处背景会虚化。 */
  setDOF(on: boolean) {
    if (on && !this.composer) this.setupComposer();
    this.dofEnabled = on && !!this.composer && !!this.dofPass;
    if (this.dofPass) this.dofPass.enabled = this.dofEnabled;
  }

  /** 开关动态模糊（实验性）。快速转视角时会有轻微拖影，站定不动完全没影响。 */
  setMotionBlur(on: boolean) {
    if (on && !this.composer) this.setupComposer();
    this.motionBlurEnabled = on && !!this.composer && !!this.motionBlurPass;
    if (this.motionBlurPass) this.motionBlurPass.enabled = this.motionBlurEnabled;
  }

  /** 开关屏幕空间环境光遮蔽（实验性）。方块缝隙、墙角会有更明显的暗部接触阴影。 */
  setSSAO(on: boolean) {
    if (on && !this.composer) this.setupComposer();
    this.ssaoEnabled = on && !!this.composer && !!this.aoApplyPass;
    if (this.ssaoPass) this.ssaoPass.enabled = this.ssaoEnabled;
    if (this.aoApplyPass) this.aoApplyPass.enabled = this.ssaoEnabled;
  }

  /** 开关 HD PBR 材质包（实验性，默认关闭）。接了 69 种常见方块（泥土/石头/
   *  木板/矿石/羊毛/陶土/玻璃……），含真实底色 + 法线 + 粗糙度/金属度贴图，
   *  来自玩家自己上传的材质包；没接进来的方块（比如糖果/彩虹这些游戏自创的
   *  装饰方块）不受影响，一直是程序化贴图。
   *  第一次开启会异步加载贴图文件，加载完之前照常用程序化贴图，不会卡住画面；
   *  加载失败会自动回退，返回 false 并弹提示，不会导致材质整个丢失/报错。 */
  async setHDPBR(on: boolean): Promise<boolean> {
    if (this.hdPBREnabled === on) return on;
    const ok = await setHDGlassTextures(on);
    if (!ok) {
      this.opts.onToast('⚠️ HD 材质包加载失败，已回退到程序化贴图');
      return false;
    }
    this.hdPBREnabled = on;
    const newAtlas = createAtlasTexture();
    // 法线/ORM 图集跟颜色图集用同一套槽位布局，材质包没覆盖到的格子都是中性值，
    // 所以可以直接整体挂给"每一个"共享材质（opaque/cutout/transparent/glow），
    // 不会影响到各自材质里那些没接上材质包的方块。
    // 关掉 HD 材质包的时候要换回默认的"假凹凸"程序化法线图集，而不是直接给 null——
    // 不然关闭 HD 之后所有方块会瞬间变回完全没有凹凸的纯平贴图。
    const normalAtlas = on ? getGlassNormalAtlasTexture() : getProceduralNormalAtlasTexture();
    const ormAtlas = on ? getGlassOrmAtlasTexture() : null;
    // 材质本身的 roughness/metalness 是跟贴图的通道值相乘的（不是二选一）——
    // 共享材质原来的基础值都比较小（比如 opaque 是 0.06 金属度），如果不把
    // 基础值拉回 1.0，贴图里真正的高光/金属区域（比如矿石）会被这个基础值
    // 压得很不明显，等于白接了 PBR 贴图。开的时候拉到 1.0 让贴图完全说了算，
    // 关的时候按 world.ts 里各材质本来的基础值改回去。
    const BASE_RM: Record<Pass, [number, number]> = {
      opaque: [0.62, 0.06],
      cutout: [0.78, 0],
      transparent: [0.08, 0],
      glow: [0.6, 0],
    };
    const worlds = this.nether && this.nether !== this.overworld ? [this.overworld, this.nether] : [this.overworld];
    for (const w of worlds) {
      for (const key of Object.keys(w.materials) as Pass[]) {
        const mat = w.materials[key] as THREE.MeshStandardMaterial;
        mat.map = newAtlas;
        mat.normalMap = normalAtlas;
        mat.roughnessMap = ormAtlas;
        mat.metalnessMap = ormAtlas;
        const [baseRough, baseMetal] = BASE_RM[key];
        mat.roughness = on ? 1.0 : baseRough;
        mat.metalness = on ? 1.0 : baseMetal;
        mat.needsUpdate = true;
      }
    }
    return true;
  }

  private setupComposer() {
    try {
      this.bloomLayers.set(Game.BLOOM_LAYER);
      const w = window.innerWidth;
      const h = window.innerHeight;
      const renderPass = new RenderPass(this.scene, this.camera);

      // SSAO：之前的代码把 minDistance/maxDistance 除以了 (far-near)（0.02/1200、3/1200），
      // 但 three.js SSAOPass 里这两个值本来就是直接拿来跟"接触点之间的线性深度差"比较的
      // 世界单位量级（官方示例默认 minDistance=0.005、maxDistance=0.1），根本不需要再除
      // 一次相机远裁面。除完之后这两个值只剩 1e-5～2.5e-3，range check 的窗口窄到基本失效，
      // 于是该有对比度的墙角/缝隙没有变暗（"没有层次感"），该被过滤掉的噪声又没被滤掉
      // （看起来像到处在"漏光/漏影"）。这里换回真实世界单位，并按方块尺寸(1格)重新标定。
      //
      // 光调完参数后层次感还是不够——查了 three.js SSAOPass 的源码，它压根没有暴露任何
      // "强度/对比度"参数，内部就是把 AO 和原图做一次线性相乘再糊一层模糊，效果天生就偏
      // 柔和寡淡，跟 GTAO/HBAO 那种能调 power 的实现完全不是一个量级，光调 kernelRadius/
      // min/maxDistance 三个参数是弥补不了这个差距的。所以这里换一种接法：让 SSAOPass 只
      // 输出"原始灰度遮蔽图"（output = OUTPUT.SSAO，不再由它自己去跟原图相乘），再单独写一个
      // aoApplyPass，对这张灰度图做 pow(ao, power) 的对比度曲线之后才乘回画面——power 越大，
      // 墙角/缝隙这些真正被遮住的地方就压得越黑，开阔平面基本不受影响，这才是真正意义上的
      // "层次感"，而不是整张图一起被轻微调暗。
      const ssao = new SSAOPass(this.scene, this.camera, w, h);
      ssao.enabled = false;
      // 上次这三个数字让 AO 看起来"离方块本体有一段距离才开始变暗"（跟阴影
      // peter-panning 是同一类毛病）：kernelRadius 太大会让遮蔽范围往外扩散、
      // 跟真实接触边缘脱节；minDistance 卡得太高会把"真正贴在一起"的那部分
      // 深度差异当成噪声过滤掉，导致最贴近的地方反而没有遮蔽、看着像空了一截。
      // 两个都往回收，让遮蔽更贴着真实几何接触面。
      ssao.kernelRadius = 0.4; // 采样半径（世界单位）
      ssao.minDistance = 0.0004; // 卡得更松，真正贴合的接触面才不会被当噪声滤掉
      ssao.maxDistance = 0.11; // 超过这个深度差就不再算"贴着"，遮蔽只发生在真正的接触面附近
      ssao.output = SSAOPass.OUTPUT.SSAO; // 只要灰度遮蔽图，不要它自己跟原图相乘
      // SSAOPass 内部用一个不认 alphaTest/贴图的 MeshNormalMaterial 去渲染法线/深度缓冲，
      // 树叶、花草、火把这类十字面片的"镂空"部分会被当成实心矩形，
      // 结果就是叶子/花朵边缘出现一圈不该有的漏光/黑边。
      // 三个透明通道（cutout/transparent）在 SSAO 这一步临时隐藏，
      // 不参与遮蔽计算，最终画面里它们仍然正常绘制，只是不会污染 AO。
      const originalSSAORender = ssao.render.bind(ssao);
      ssao.render = (
        renderer: THREE.WebGLRenderer,
        writeBuffer: THREE.WebGLRenderTarget,
        readBuffer: THREE.WebGLRenderTarget,
        deltaTime: number,
        maskActive: boolean,
      ) => {
        const hidden: THREE.Mesh[] = [];
        for (const chunk of this.world.chunks.values()) {
          const cutout = chunk.meshes.cutout;
          const transparent = chunk.meshes.transparent;
          // 发光方块（火把/荧光石/岩浆…）用的是同一套"镂空十字面片 + 自发光"
          // 通道，同样会被 SSAO 的法线材质当成实心矩形，一起隐藏掉
          const glow = chunk.meshes.glow;
          if (cutout && cutout.visible) {
            cutout.visible = false;
            hidden.push(cutout);
          }
          if (transparent && transparent.visible) {
            transparent.visible = false;
            hidden.push(transparent);
          }
          if (glow && glow.visible) {
            glow.visible = false;
            hidden.push(glow);
          }
        }
        originalSSAORender(renderer, writeBuffer, readBuffer, deltaTime, maskActive);
        for (const m of hidden) m.visible = true;
      };

      // aoApplyPass：读取上面 ssao 手动渲染出来的灰度遮蔽图 + 当前画面，
      // 做 pow(ao, power) 对比度曲线后再乘回去（见上面 SSAO 注释）。
      // ssao 本身不再放进 composer 的自动 pass 链里，改成每帧手动调用
      // ssaoPass.render() 把结果写进 ssaoRawTarget，这里只负责"应用"。
      this.ssaoRawTarget = new THREE.WebGLRenderTarget(w, h, {
        minFilter: THREE.LinearFilter,
        magFilter: THREE.LinearFilter,
      });
      this.ssaoDummyTarget = new THREE.WebGLRenderTarget(4, 4);
      const aoApply = new ShaderPass(
        new THREE.ShaderMaterial({
          uniforms: {
            baseTexture: { value: null },
            aoTexture: { value: this.ssaoRawTarget.texture },
            uPower: { value: 2.0 }, // 越大墙角/缝隙压得越黑，1.0 = 不加对比度（等价于原来的效果）
            uStrength: { value: 1.0 }, // 留一点底，完全遮蔽的地方也不会死黑成纯黑
          },
          vertexShader: `
            varying vec2 vUv;
            void main() {
              vUv = uv;
              gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
            }
          `,
          fragmentShader: `
            uniform sampler2D baseTexture;
            uniform sampler2D aoTexture;
            uniform float uPower, uStrength;
            varying vec2 vUv;
            void main() {
              float ao = clamp(texture2D(aoTexture, vUv).r, 0.0, 1.0);
              ao = pow(ao, uPower);
              vec3 base = texture2D(baseTexture, vUv).rgb;
              gl_FragColor = vec4(base * mix(1.0, ao, uStrength), 1.0);
            }
          `,
        }),
        'baseTexture',
      );
      aoApply.enabled = false;
      this.aoApplyPass = aoApply;

      const ssr = new SSRPass({
        renderer: this.renderer,
        scene: this.scene,
        camera: this.camera,
        width: w,
        height: h,
        // 只让水/冰/玻璃/水晶这类"transparent"通道的方块参与反射测试。
        // selects:null 会把地面、树木、玩家全部当成反光面，这是之前
        // "所有东西都在反光"的直接原因。
        selects: this.ssrReflectiveMeshes,
        groundReflector: null,
      });
      ssr.enabled = false;
      ssr.thickness = 0.018;
      ssr.infiniteThick = false;
      ssr.maxDistance = 60;
      // 显式给 opacity（反射强度）和 output 兜底，避免用到 SSRPass 内部默认值——
      // ray march 失败（没照到东西）的地方会退回正常画面而不是留空洞。
      ssr.opacity = 0.85;
      ssr.output = SSRPass.OUTPUT.Default;

      // ------ 泛光：只让"标记过的发光物体"发光，而不是全屏找亮像素 ------
      // 之前用的是无差别全屏阈值泛光：太阳贴图本身又大又亮，一旦超过阈值，
      // 泛光会把它糊成一大团光斑，变成"光污染"。这里换成 three.js 官方的
      // selective bloom 写法：单独用一张离屏画面只画"发光层"的物体（其它全部
      // 涂黑），把这张图模糊叠加回正常画面。太阳/月亮精灵不在发光层里，
      // 所以再也不会被泛光越吹越大。
      const bloomComposer = new EffectComposer(this.renderer);
      bloomComposer.renderToScreen = false;
      bloomComposer.addPass(renderPass);
      const bloom = new UnrealBloomPass(new THREE.Vector2(w, h), 0.5, 0.35, 0.82);
      bloom.enabled = false;
      bloomComposer.addPass(bloom);

      const mixPass = new ShaderPass(
        new THREE.ShaderMaterial({
          uniforms: {
            baseTexture: { value: null },
            bloomTexture: { value: bloomComposer.renderTarget2.texture },
          },
          vertexShader: `
            varying vec2 vUv;
            void main() {
              vUv = uv;
              gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
            }
          `,
          fragmentShader: `
            uniform sampler2D baseTexture;
            uniform sampler2D bloomTexture;
            varying vec2 vUv;
            void main() {
              gl_FragColor = texture2D(baseTexture, vUv) + texture2D(bloomTexture, vUv);
            }
          `,
        }),
        'baseTexture',
      );
      mixPass.enabled = false;

      // ------ 体积光 / 丁达尔效应 ------
      // godrayMaskTarget：半分辨率离屏渲染，把地形/生物全部涂黑，只留太阳精灵原样亮度，
      // 靠深度测试自然被树冠/方块正确遮挡（在主循环里手动 render，见 renderGodrayMask()）。
      // godrayBlurPass：对这张遮罩做以太阳屏幕坐标为中心的径向衰减采样，产出光柱纹理。
      // godrayMixPass：把光柱纹理加回主画面，跟上面 mixPass 叠加泛光是同一个套路。
      const gw = Math.max(2, Math.floor(w / 2));
      const gh = Math.max(2, Math.floor(h / 2));
      this.godrayMaskTarget = new THREE.WebGLRenderTarget(gw, gh, {
        minFilter: THREE.LinearFilter,
        magFilter: THREE.LinearFilter,
      });
      this.godrayBlurTarget = new THREE.WebGLRenderTarget(gw, gh, {
        minFilter: THREE.LinearFilter,
        magFilter: THREE.LinearFilter,
      });

      const godrayBlur = new ShaderPass(
        new THREE.ShaderMaterial({
          uniforms: {
            tDiffuse: { value: null },
            uSunUV: { value: this.godraySunUV },
            uExposure: { value: 0.75 },
            uDecay: { value: 0.975 },
            uDensity: { value: 0.9 },
            uWeight: { value: 0.75 },
          },
          vertexShader: `
            varying vec2 vUv;
            void main() {
              vUv = uv;
              gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
            }
          `,
          // 经典的 screen-space sun shaft 径向采样（GPU Gems 3, "Volumetric Light
          // Scattering as a Post-Process"）：沿着"当前像素 -> 太阳屏幕坐标"这条线
          // 往回采样并逐步衰减，被遮住的地方（遮罩是黑的）自然贡献不了光，被树冠/
          // 方块缝隙漏过去的地方就会在下游积累出一道道亮线——这就是丁达尔效应。
          fragmentShader: `
            uniform sampler2D tDiffuse;
            uniform vec2 uSunUV;
            uniform float uExposure, uDecay, uDensity, uWeight;
            varying vec2 vUv;
            const int NUM_SAMPLES = 48;
            void main() {
              vec2 deltaTexCoord = (vUv - uSunUV) * (uDensity / float(NUM_SAMPLES));
              vec2 coord = vUv;
              float illuminationDecay = 1.0;
              vec3 col = vec3(0.0);
              for (int i = 0; i < NUM_SAMPLES; i++) {
                coord -= deltaTexCoord;
                vec3 s = texture2D(tDiffuse, coord).rgb * illuminationDecay * uWeight;
                col += s;
                illuminationDecay *= uDecay;
              }
              gl_FragColor = vec4(col * uExposure, 1.0);
            }
          `,
        }),
      );
      godrayBlur.needsSwap = false;
      this.godrayBlurPass = godrayBlur;

      const godrayMixPass = new ShaderPass(
        new THREE.ShaderMaterial({
          uniforms: {
            baseTexture: { value: null },
            godrayTexture: { value: this.godrayBlurTarget.texture },
            uIntensity: { value: 0 },
          },
          vertexShader: `
            varying vec2 vUv;
            void main() {
              vUv = uv;
              gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
            }
          `,
          fragmentShader: `
            uniform sampler2D baseTexture;
            uniform sampler2D godrayTexture;
            uniform float uIntensity;
            varying vec2 vUv;
            void main() {
              vec3 base = texture2D(baseTexture, vUv).rgb;
              vec3 rays = texture2D(godrayTexture, vUv).rgb;
              // 阳光暖色调，别加成一片死白
              gl_FragColor = vec4(base + rays * vec3(1.0, 0.92, 0.75) * uIntensity, 1.0);
            }
          `,
        }),
        'baseTexture',
      );
      godrayMixPass.enabled = false;
      this.godrayMixPass = godrayMixPass;

      // ------ 简单调色（色调修正） ------
      // 原来只有 ACESFilmicToneMapping + exposure，没有任何对比度/饱和度控制，
      // 灰雾蒙蒙、发闷。这里加一个轻量级 lift/contrast/saturation，让暗部不那么灰、
      // 颜色更有辨识度，同时保留一点暖色（篝火/夕阳）的偏好。
      const colorGrade = new ShaderPass(
        new THREE.ShaderMaterial({
          uniforms: {
            tDiffuse: { value: null },
            uContrast: { value: 1.1 },
            uSaturation: { value: 1.18 },
            uLift: { value: new THREE.Vector3(0.01, 0.006, 0.0) }, // 暗部微微偏暖，去灰
          },
          vertexShader: `
            varying vec2 vUv;
            void main() {
              vUv = uv;
              gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
            }
          `,
          fragmentShader: `
            uniform sampler2D tDiffuse;
            uniform float uContrast, uSaturation;
            uniform vec3 uLift;
            varying vec2 vUv;
            void main() {
              vec3 c = texture2D(tDiffuse, vUv).rgb + uLift;
              c = (c - 0.5) * uContrast + 0.5;
              float luma = dot(c, vec3(0.2126, 0.7152, 0.0722));
              c = mix(vec3(luma), c, uSaturation);
              gl_FragColor = vec4(max(c, 0.0), 1.0);
            }
          `,
        }),
      );
      this.colorGradePass = colorGrade;

      // ------ 景深 (DOF) ------
      // 用官方 BokehPass，自带一套独立的深度渲染（不需要跟 SSAO/SSR 共享深度纹理）。
      // focus 每帧由准星射线的实际命中距离动态更新（见主循环里的 dofPass.uniforms.focus），
      // 看得远的时候远处清楚，看近处方块的时候背景自然虚化——不是固定对焦距离。
      const dof = new BokehPass(this.scene, this.camera, {
        focus: 10,
        aperture: 0.00035, // 光圈系数，不是真实 f 值；调小一点更保守，减少亮光源被虚化后糊成一大片亮斑的风险
        maxblur: 0.006,
      });
      dof.enabled = false;
      this.dofPass = dof;

      // ------ 动态模糊（简化版：方向性多重采样，不需要额外的历史帧缓冲）------
      // 真正的运动模糊需要逐像素速度缓冲（G-buffer），成本和复杂度都高很多。这里用一个
      // 便宜但常见的近似：根据这一帧相机朝向（yaw/pitch）转动的角度，沿屏幕空间对应方向
      // 多次采样当前画面再平均——转视角越快，拖影越明显；站定不动时方向向量是 0，
      // 完全没有额外开销/画面不受影响。
      const motionBlur = new ShaderPass(
        new THREE.ShaderMaterial({
          uniforms: {
            tDiffuse: { value: null },
            uDir: { value: new THREE.Vector2(0, 0) },
          },
          vertexShader: `
            varying vec2 vUv;
            void main() {
              vUv = uv;
              gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
            }
          `,
          fragmentShader: `
            uniform sampler2D tDiffuse;
            uniform vec2 uDir;
            varying vec2 vUv;
            const int N = 9;
            void main() {
              vec3 sum = vec3(0.0);
              for (int i = 0; i < N; i++) {
                float t = (float(i) / float(N - 1)) - 0.5; // -0.5..0.5
                sum += texture2D(tDiffuse, vUv + uDir * t).rgb;
              }
              gl_FragColor = vec4(sum / float(N), 1.0);
            }
          `,
        }),
      );
      motionBlur.enabled = false;
      this.motionBlurPass = motionBlur;

      const composer = new EffectComposer(this.renderer);
      composer.addPass(renderPass);
      composer.addPass(aoApply);
      composer.addPass(ssr);
      composer.addPass(mixPass);
      composer.addPass(godrayMixPass);
      composer.addPass(colorGrade);
      composer.addPass(dof);
      composer.addPass(motionBlur);
      composer.addPass(new OutputPass());
      composer.setSize(w, h);
      bloomComposer.setSize(w, h);

      this.composer = composer;
      this.bloomComposer = bloomComposer;
      this.bloomPass = bloom;
      this.mixPass = mixPass;
      this.ssrPass = ssr;
      this.ssaoPass = ssao;
      this.aoApplyPass = aoApply;
      this.dofPass = dof;
      this.motionBlurPass = motionBlur;
    } catch (err) {
      // 后处理创建失败（比如设备不支持某些扩展）时，静默回退到普通渲染，不影响游戏正常运行
      console.warn('后处理初始化失败，已回退到普通渲染', err);
      this.composer = null;
      this.bloomComposer = null;
      this.bloomPass = null;
      this.mixPass = null;
      this.ssrPass = null;
      this.ssaoPass = null;
      this.ssaoRawTarget = null;
      this.ssaoDummyTarget = null;
      this.aoApplyPass = null;
      this.godrayMaskTarget = null;
      this.godrayBlurTarget = null;
      this.godrayBlurPass = null;
      this.godrayMixPass = null;
      this.colorGradePass = null;
      this.dofPass = null;
      this.motionBlurPass = null;
    }
  }

  /** selective bloom 第一步：把不在发光层的物体材质临时换成纯黑，
   *  这样 bloomComposer 只会画出"应该发光的东西"。
   *  同一套逻辑也复用给体积光遮罩通道（keepLayers 换成 sunLayers 就行）。 */
  private darkenExcept(obj: THREE.Object3D, keepLayers: THREE.Layers) {
    const mesh = obj as THREE.Mesh;
    if (mesh.isMesh && !keepLayers.test(mesh.layers)) {
      this.bloomMaterialCache.set(mesh.uuid, mesh.material);
      mesh.material = this.bloomDarkMaterial;
    }
  }

  /** selective bloom 第二步：换回原来的材质。 */
  private restoreDarkened(obj: THREE.Object3D) {
    const mesh = obj as THREE.Mesh;
    const cached = this.bloomMaterialCache.get(mesh.uuid);
    if (cached) {
      mesh.material = cached;
      this.bloomMaterialCache.delete(mesh.uuid);
    }
  }

  /** 把当前已加载区块里"水/冰/玻璃/水晶"的网格收集进 SSR 的反射列表。
   *  原地更新数组内容（不换引用），这样不会每帧触发 SSRPass 内部重建 shader。 */
  private refreshSSRSelects() {
    const list = this.ssrReflectiveMeshes;
    list.length = 0;
    for (const chunk of this.world.chunks.values()) {
      const mesh = chunk.meshes.transparent;
      if (mesh) list.push(mesh);
    }
  }

  setTimeOfDay(t: number) {
    this.timeOfDay = t;
  }

  setPaused(p: boolean) {
    this.paused = p;
    if (p) {
      this.breaking = false;
      this.placing = false;
      this.keys.clear();
    }
  }

  setTouchMove(x: number, z: number) {
    this.touchMove.x = x;
    this.touchMove.z = z;
  }

  touchLook(dx: number, dy: number) {
    this.yaw -= dx * 0.005;
    this.pitch -= dy * 0.005;
    const lim = Math.PI / 2 - 0.001;
    this.pitch = Math.max(-lim, Math.min(lim, this.pitch));
  }

  setBreaking(b: boolean) {
    if (b && this.tryHitMob()) {
      this.breaking = false;
      return;
    }
    this.breaking = b;
    if (!b) this.breakProgress = 0;
  }

  triggerPlace() {
    if (this.tryFeedMob()) return;
    this.tryPlace();
  }

  /* ================= 我的世界式合成（2x2 背包 / 3x3 工作台） ================= */

  craftGrid3: (ItemStack | null)[] = Array.from({ length: 9 }, () => null);
  craftGrid2: (ItemStack | null)[] = Array.from({ length: 4 }, () => null);
  craftResult3: ItemStack | null = null;
  craftResult2: ItemStack | null = null;

  private gridSize(zone: string) {
    return zone === 'craft' ? 3 : 2;
  }

  private craftGrid(zone: string): (ItemStack | null)[] {
    return zone === 'craft' ? this.craftGrid3 : this.craftGrid2;
  }

  private refreshCraftResult(zone: string) {
    const grid = this.craftGrid(zone);
    const recipe = matchRecipe(grid.map((s) => (s ? s.id : null)), this.gridSize(zone));
    const result = recipe ? { id: recipe.output.id, count: recipe.output.count } : null;
    if (zone === 'craft') {
      this.craftResult3 = result;
      this.opts.onCraftTable?.(grid.map((s) => (s ? { ...s } : null)), result);
    } else {
      this.craftResult2 = result;
      this.opts.onGrid2?.(grid.map((s) => (s ? { ...s } : null)), result);
    }
  }

  private returnCraftGrid(zone: string) {
    const grid = this.craftGrid(zone);
    grid.forEach((stack) => {
      if (stack) this.addItem(stack.id, stack.count, false);
    });
    grid.fill(null);
    this.refreshCraftResult(zone);
  }

  /** 从网格取走产物（消耗材料，可连续合成） */
  takeCraftResult(zone: string) {
    const result = zone === 'craft' ? this.craftResult3 : this.craftResult2;
    if (!result) return;
    if (this.mode === 'survival' && !this.canAdd(result.id, result.count)) {
      this.opts.onToast('🎒 背包已满！');
      return;
    }
    const grid = this.craftGrid(zone);
    for (const stack of grid) if (stack) stack.count -= 1;
    grid.forEach((stack, i) => {
      if (stack && stack.count <= 0) grid[i] = null;
    });
    this.addItem(result.id, result.count);
    if (isToolId(result.id)) this.bumpQuest('tool');
    const recipe = matchRecipe(grid.map((s) => (s ? s.id : null)), this.gridSize(zone));
    if (recipe?.id === 'torch') this.bumpQuest('torch');
    if (recipe?.id === 'rainbow') this.bumpQuest('rainbow');
    this.refreshCraftResult(zone);
    this.opts.onToast(`合成成功！`);
    sfx.place();
  }

  /** 配方手册一键摆料：把配方图案放进合成网格（材料从背包扣） */
  loadRecipeToGrid(recipeId: string, zone: string) {
    const recipe = RECIPES.find((entry) => entry.id === recipeId);
    if (!recipe) return;
    const size = this.gridSize(zone);
    const { w, h } = recipePatternSize(recipe);
    if (w > size || h > size) {
      this.opts.onToast('这个配方需要 3x3 工作台！');
      return;
    }
    this.returnCraftGrid(zone); // 先退回当前网格
    const need: Record<number, number> = {};
    recipe.pattern.forEach((row) =>
      row.forEach((cell) => {
        if (cell) need[cell] = (need[cell] ?? 0) + 1;
      }),
    );
    if (this.mode === 'survival') {
      const missing = Object.entries(need).find(([id, cnt]) => this.countItems(Number(id)) < cnt);
      if (missing) {
        this.opts.onToast(`材料不足：${getItemName(Number(missing[0]))}`);
        return;
      }
      Object.entries(need).forEach(([id, cnt]) => this.removeItems(Number(id), cnt));
    }
    const grid = this.craftGrid(zone);
    recipe.pattern.forEach((row, y) =>
      row.forEach((cell, x) => {
        if (cell) grid[y * size + x] = { id: cell, count: 1 };
      }),
    );
    this.refreshCraftResult(zone);
  }

  /** 关闭背包界面：2x2 材料退回 */
  closeCraft2() {
    this.returnCraftGrid('craft2');
  }

  /** 打开工作台（3x3） */
  openCraftTableAt(x: number, y: number, z: number) {
    void x;
    void y;
    void z;
    this.placeCooldown = 0.3;
    this.refreshCraftResult('craft');
  }

  /** 关闭工作台：3x3 材料退回背包 */
  closeCraftTable() {
    this.returnCraftGrid('craft');
  }

  /* ---------------- 背包与箱子（拖拽/点击/Shift快速移动） ---------------- */

  private countItems(blockId: number) {
    return this.inventory.reduce((sum, s) => sum + (s && s.id === blockId ? s.count : 0), 0);
  }

  private canAdd(blockId: number, count: number) {
    if (isToolId(blockId)) return this.inventory.some((slot) => !slot);
    let room = 0;
    for (const s of this.inventory) {
      if (!s) room += MAX_STACK;
      else if (s.id === blockId) room += MAX_STACK - s.count;
    }
    return room >= count;
  }

  addItem(blockId: number, count = 1, notify = true): number {
    if (this.mode === 'creative' || count <= 0) return 0;
    if (isToolId(blockId)) {
      // 工具占一格，不堆叠
      const slot = this.inventory.findIndex((s) => !s);
      if (slot < 0) return count;
      this.inventory[slot] = { id: blockId, count };
      if (notify) this.notifyInventory();
      return 0;
    }
    let remaining = count;
    for (let i = 0; i < INV_SIZE && remaining > 0; i++) {
      const s = this.inventory[i];
      if (s && s.id === blockId && s.count < MAX_STACK) {
        const take = Math.min(MAX_STACK - s.count, remaining);
        s.count += take;
        remaining -= take;
      }
    }
    for (let i = 0; i < INV_SIZE && remaining > 0; i++) {
      if (!this.inventory[i]) {
        const take = Math.min(MAX_STACK, remaining);
        this.inventory[i] = { id: blockId, count: take };
        remaining -= take;
      }
    }
    if (notify) this.notifyInventory();
    return remaining;
  }

  private removeItems(blockId: number, count: number) {
    let remaining = count;
    for (let i = 0; i < INV_SIZE && remaining > 0; i++) {
      const s = this.inventory[i];
      if (s && s.id === blockId) {
        const take = Math.min(s.count, remaining);
        s.count -= take;
        remaining -= take;
        if (s.count <= 0) this.inventory[i] = null;
      }
    }
    this.notifyInventory();
  }

  private consumeFromSlot(index: number, count = 1) {
    if (this.mode === 'creative') return;
    const s = this.inventory[index];
    if (!s) return;
    s.count -= count;
    if (s.count <= 0) {
      this.inventory[index] = null;
      // Auto-pick the next non-empty slot so gameplay never dead-ends.
      const next = this.inventory.findIndex((st) => st && st.id === s.id);
      if (next >= 0) this.selected = next;
      else {
        const any = this.inventory.findIndex((st) => st);
        if (any >= 0) this.selected = any;
      }
      this.updateHandBlock();
    }
    this.notifyInventory();
  }

  private notifyInventory() {
    this.opts.onInventory(this.inventory.map((s) => (s ? { ...s } : null)), this.selected);
  }

  /* ---------------- 目标系统 ---------------- */

  private bumpQuest(questId: string, amount = 1) {
    const quest = QUESTS.find((entry) => entry.id === questId);
    if (!quest) return;
    const before = this.questProgress[questId] ?? 0;
    if (before >= quest.target) return;
    const after = Math.min(quest.target, before + amount);
    this.questProgress[questId] = after;
    if (after >= quest.target) {
      const rewards = QUEST_REWARDS[questId] ?? [];
      rewards.forEach(([id, count]) => this.addItem(id, count, false));
      this.notifyInventory();
      this.opts.onToast(`🎉 目标完成「${quest.name}」！获得奖励！`);
      sfx.break_();
    }
  }

  private questViews(): QuestView[] {
    return QUESTS.map((quest) => {
      const progress = Math.min(quest.target, this.questProgress[quest.id] ?? 0);
      return {
        id: quest.id,
        name: quest.name,
        desc: quest.desc,
        emoji: quest.emoji,
        progress,
        target: quest.target,
        done: progress >= quest.target,
      };
    });
  }

  private loadInventoryFromSave(save: SaveData) {
    this.inventory = Array.from({ length: INV_SIZE }, () => null);
    if (save.inventory) {
      save.inventory.forEach((entry, i) => {
        if (entry && i < INV_SIZE) this.inventory[i] = { id: entry[0], count: Math.min(entry[1], MAX_STACK) };
      });
      if (typeof save.selected === 'number' && save.selected < INV_SIZE) this.selected = save.selected;
    } else if (save.hotbar) {
      // Legacy save migration: hotbar ids + itemCounts → stacks.
      save.hotbar.forEach((id, i) => {
        if (id && i < INV_SIZE) this.inventory[i] = { id, count: save.itemCounts?.[id] ?? 64 };
      });
      let slot = 9;
      for (const [idStr, count] of Object.entries(save.itemCounts ?? {})) {
        const id = Number(idStr);
        if (!id || slot >= INV_SIZE) continue;
        if (this.inventory.some((s) => s?.id === id)) continue;
        this.inventory[slot++] = { id, count: Math.min(count, MAX_STACK) };
      }
    }
  }

  /* ---------------- 宝箱交互 ---------------- */

  private chestPos(): { x: number; y: number; z: number } | null {
    return this.openChestPos;
  }

  openChestAt(x: number, y: number, z: number) {
    this.openChestPos = { x, y, z };
    this.placeCooldown = 0.3;
    this.bumpQuest('chest');
    // 遗迹宝箱被开启时，唤醒守护者 Boss（一次性）
    if (this.mods.has('doubleloot')) {
      // 战利品大师：宝箱内容翻倍
      const slots = this.world.getChestSlots(x, y, z);
      slots.forEach((s, i) => {
        if (s && s.count < MAX_STACK) this.world.setChestSlot(x, y, z, i, { id: s.id, count: Math.min(MAX_STACK, s.count * 2) });
      });
    }
    const type = this.world.getChestType(x, y, z);
    if (type === 'ruin' && !this.spawnedBosses.has(`ruin:${x},${z}`)) {
      const def = MOB_DEFS.find((d) => d.id === 23)!;
      if (this.spawnBoss(def, x + 3, z + 3, `ruin:${x},${z}`)) {
        this.opts.onToast('🗿 你惊醒了遗迹守护者！击败它才能安心搜刮！');
      }
    }
    this.opts.onChest(this.world.getChestSlots(x, y, z).map((s) => (s ? { ...s } : null)));
  }

  closeChest() {
    this.openChestPos = null;
  }

  private getStack(zone: SlotZone, idx: number): ItemStack | null {
    if (zone === 'inv') return this.inventory[idx] ?? null;
    if (zone === 'craft') return this.craftGrid3[idx] ?? null;
    if (zone === 'craft2') return this.craftGrid2[idx] ?? null;
    const pos = this.chestPos();
    if (!pos) return null;
    return this.world.getChestSlots(pos.x, pos.y, pos.z)[idx] ?? null;
  }

  private setStack(zone: SlotZone, idx: number, stack: ItemStack | null) {
    if (zone === 'inv') {
      this.inventory[idx] = stack ? { ...stack } : null;
      return;
    }
    if (zone === 'craft') {
      this.craftGrid3[idx] = stack ? { ...stack } : null;
      return;
    }
    if (zone === 'craft2') {
      this.craftGrid2[idx] = stack ? { ...stack } : null;
      return;
    }
    const pos = this.chestPos();
    if (!pos) return;
    this.world.setChestSlot(pos.x, pos.y, pos.z, idx, stack);
  }

  /** 拖拽/点击移动：合并、拆分剩余、交换。 */
  moveSlot(fromZone: SlotZone, fromIdx: number, toZone: SlotZone, toIdx: number) {
    if (fromIdx === toIdx && fromZone === toZone) return;
    const a = this.getStack(fromZone, fromIdx);
    if (!a) return;
    const b = this.getStack(toZone, toIdx);
    if (!b) {
      this.setStack(toZone, toIdx, a);
      this.setStack(fromZone, fromIdx, null);
    } else if (b.id === a.id) {
      const room = MAX_STACK - b.count;
      if (room >= a.count) {
        b.count += a.count;
        this.setStack(toZone, toIdx, b);
        this.setStack(fromZone, fromIdx, null);
      } else {
        b.count = MAX_STACK;
        a.count -= room;
        this.setStack(toZone, toIdx, b);
        this.setStack(fromZone, fromIdx, a);
      }
    } else {
      this.setStack(toZone, toIdx, a);
      this.setStack(fromZone, fromIdx, b);
    }
    if (fromZone === 'inv' || toZone === 'inv') this.updateHandBlock();
    this.notifyInventory();
    this.emitChest();
    if (fromZone === 'craft' || toZone === 'craft') this.refreshCraftResult('craft');
    if (fromZone === 'craft2' || toZone === 'craft2') this.refreshCraftResult('craft2');
  }

  /** Shift 点击：整组快速转移到背包（从箱子/合成格取出）。 */
  quickMove(zone: SlotZone, idx: number) {
    const target: SlotZone = 'inv';
    const stack = this.getStack(zone, idx);
    if (!stack) return;
    const size = INV_SIZE;
    let best = -1;
    for (let i = 0; i < size; i++) {
      const s = this.getStack(target, i);
      if (s && s.id === stack.id && s.count < MAX_STACK) {
        best = i;
        break;
      }
    }
    if (best < 0) {
      for (let i = 0; i < size; i++) {
        if (!this.getStack(target, i)) {
          best = i;
          break;
        }
      }
    }
    if (best >= 0) {
      this.moveSlot(zone, idx, target, best);
    } else if (target === 'inv') {
      this.opts.onToast('🎒 背包已满！');
    }
  }

  takeAllChest() {
    for (let i = 0; i < CHEST_SIZE; i++) {
      const s = this.getStack('chest', i);
      if (!s) continue;
      if (this.canAdd(s.id, s.count)) this.quickMove('chest', i);
      else {
        this.opts.onToast('🎒 背包已满，装不下了！');
        break;
      }
    }
  }

  private emitChest() {
    const pos = this.chestPos();
    if (!pos) return;
    this.opts.onChest(this.world.getChestSlots(pos.x, pos.y, pos.z).map((s) => (s ? { ...s } : null)));
  }

  triggerJump() {
    this.touchJump = true;
    setTimeout(() => (this.touchJump = false), 120);
  }

  toggleFly() {
    if (this.mode !== 'creative' && !this.mods.has('flight')) {
      this.opts.onToast('🪽 需要「自由飞行」模组才能在生存模式飞行');
      return;
    }
    this.flying = !this.flying;
    this.vel.y = 0;
    this.opts.onToast(this.flying ? '✈️ 飞行模式开启' : '🚶 飞行模式关闭');
  }

  serialize(): SaveData {
    return {
      seed: this.opts.seed,
      worldType: this.opts.worldType,
      mode: this.mode,
      pos: [this.pos.x, this.pos.y, this.pos.z],
      yaw: this.yaw,
      pitch: this.pitch,
      inventory: this.inventory.map((s) => (s ? [s.id, s.count] : null)),
      selected: this.selected,
      edits: this.overworld.exportEdits().slice(-30000),
      timeOfDay: this.timeOfDay,
      chests: this.overworld.exportChests(),
      quests: { ...this.questProgress },
      openedChests: this.overworld.exportOpenedChests(),
      version: 3,
      savedAt: Date.now(),
      dimension: this.dimension,
      netherEdits: this.nether ? this.nether.exportEdits().slice(-30000) : undefined,
    };
  }

  respawn() {
    this.dead = false;
    this.health = 20;
    this.hunger = 20;
    this.air = 1;
    this.vel.set(0, 0, 0);
    const y = this.world.surfaceY(Math.floor(this.pos.x), Math.floor(this.pos.z));
    this.pos.y = Math.max(y, SEA_LEVEL + 1) + 0.2;
  }

  /* ------------------------------------------------ helpers ---------- */

  private forwardVector(includePitch: boolean) {
    const v = new THREE.Vector3(0, 0, -1);
    v.applyEuler(new THREE.Euler(includePitch ? this.pitch : 0, this.yaw, 0, 'YXZ'));
    return v;
  }

  private tileAverageColor(tile: number): THREE.Color {
    const canvas = getTileCanvases()[tile];
    const ctx = canvas.getContext('2d')!;
    const data = ctx.getImageData(0, 0, TILE_PX, TILE_PX).data;
    let r = 0;
    let g = 0;
    let b = 0;
    let n = 0;
    for (let i = 0; i < data.length; i += 4) {
      if (data[i + 3] < 40) continue;
      r += data[i];
      g += data[i + 1];
      b += data[i + 2];
      n++;
    }
    if (!n) return new THREE.Color(0xffffff);
    return new THREE.Color(r / n / 255, g / n / 255, b / n / 255);
  }

  /** 手持物是否是发光方块（火把/荧光石/水晶/彩虹）——给它一点自身的柔和发光，
   *  而不是完全依赖那盏近距离点光源把它"照"到过曝。 */
  private static readonly HELD_GLOW_IDS = new Set([13, 15, 18, 30]);

  /** 第一人称手部/手持物永远画在最上面，不被靠近的墙面/方块正常挡住——
   *  否则玩家一贴近墙，世界的深度就会正常"遮住"手，看起来像手插进墙里/瞬间消失。 */
  private disableHandDepthTest(obj: THREE.Object3D) {
    obj.traverse((o) => {
      const mesh = o as THREE.Mesh;
      if (!mesh.isMesh) return;
      const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
      for (const m of mats) {
        m.depthTest = false;
        m.depthWrite = false;
      }
    });
  }

  private updateHandBlock() {
    const id = this.inventory[this.selected]?.id ?? 0;
    if (this.handMesh) {
      this.handGroup.remove(this.handMesh);
      // handMesh 现在可能是单个 Mesh（方块/工具），也可能是枪械模型那种由多个
      // 子网格拼成的 Group，两种情况都要把几何体/材质释放掉，不然切枪切方块
      // 切多了会攒着一堆没释放的 GPU 资源。
      this.handMesh.traverse((obj) => {
        const m = obj as THREE.Mesh;
        if (m.isMesh) {
          m.geometry.dispose();
          const mat = m.material;
          if (Array.isArray(mat)) mat.forEach((mm) => mm.dispose());
          else mat.dispose();
        }
      });
      this.handMesh = null;
    }
    if (!id) return;
    const atlas = (this.world.materials.opaque as THREE.MeshStandardMaterial).map ?? null;
    const tool = getTool(id);
    if (tool) {
      if (tool.type === 'gun') {
        // 真正的枪械模型（枪管/机匣/握把/瞄准镜拼出来的），
        // 不再是跟镐子/剑一样的一根方棍子
        let gunGroup: THREE.Group;
        if (id === 110) gunGroup = createSniperModel(); // 水晶炮：射程最远，用长管狙击造型
        else if (id === 109) gunGroup = createRifleModel(); // 步枪
        else gunGroup = createPistolModel(); // 木枪：最基础的手枪造型
        gunGroup.scale.setScalar(0.85);
        gunGroup.position.set(0.08, -0.06, -0.05);
        gunGroup.rotation.set(-0.05, 0.08, 0);
        gunGroup.renderOrder = 10;
        this.disableHandDepthTest(gunGroup);
        this.handMesh = gunGroup;
        this.handGroup.add(gunGroup);
        return;
      }
      // 手持工具：细长条模型，材质按材质类型走真正的 PBR（而不是纯色 Lambert）
      const geo = new THREE.BoxGeometry(0.1, 0.5, 0.08);
      let mat: THREE.Material;
      if (tool.material === 'crystal') {
        // 水晶工具：真实折射 + 色散（多重折射），握在手里就能看出层次
        mat = new THREE.MeshPhysicalMaterial({
          color: 0x8fefff,
          roughness: 0.05,
          metalness: 0,
          transmission: 0.85,
          thickness: 0.35,
          ior: 1.5,
          dispersion: 3.2,
          clearcoat: 0.6,
          clearcoatRoughness: 0.08,
        });
      } else if (tool.material === 'stone') {
        mat = new THREE.MeshStandardMaterial({ color: 0xa8a8b4, roughness: 0.8, metalness: 0.06 });
      } else {
        mat = new THREE.MeshStandardMaterial({ color: 0xc9975e, roughness: 0.75, metalness: 0 });
      }
      const mesh = new THREE.Mesh(geo, mat);
      mesh.scale.setScalar(0.32);
      // 握在手掌里、斜向上，像真的握着工具
      mesh.position.set(0.06, 0.1, -0.06);
      mesh.rotation.set(-0.5, -0.35, 0.25);
      mesh.renderOrder = 10;
      this.disableHandDepthTest(mesh);
      this.handMesh = mesh;
      this.handGroup.add(mesh);
      return;
    }
    const def = getBlock(id);
    const geo = new THREE.BoxGeometry(1, 1, 1);
    const uv = geo.getAttribute('uv') as THREE.BufferAttribute;
    for (let f = 0; f < 6; f++) {
      const [u0, v0, u1, v1] = tileUV(def.tiles[f]);
      const o = f * 4;
      uv.setXY(o + 0, u0, v1);
      uv.setXY(o + 1, u1, v1);
      uv.setXY(o + 2, u0, v0);
      uv.setXY(o + 3, u1, v0);
    }
    uv.needsUpdate = true;

    let mat: THREE.Material;
    if (def.pass === 'transparent') {
      // 玻璃/冰/水/水晶：跟世界里一样的真实折射 + 色散，而不是简单的半透明贴图
      mat = new THREE.MeshPhysicalMaterial({
        map: atlas,
        transparent: true,
        opacity: 0.94,
        roughness: 0.08,
        metalness: 0,
        transmission: 0.65,
        thickness: 0.4,
        ior: 1.35,
        dispersion: 1.8,
        clearcoat: 0.35,
        clearcoatRoughness: 0.12,
      });
    } else if (Game.HELD_GLOW_IDS.has(id)) {
      // 火把/荧光石/彩虹块：靠材质自身的 emissive 发光，柔和且不受点光源距离影响，
      // 这样握在手上永远是"淡淡地在发光"，不会被曝成一片死白
      const glowColor = this.tileAverageColor(def.tiles[2]);
      mat = new THREE.MeshStandardMaterial({
        map: atlas,
        alphaTest: def.pass === 'cutout' ? 0.5 : 0,
        // 之前这里写的是 def.pass !== 'opaque'，等于把 cutout（火把这些镂空贴图）也
        // 当成了半透明混合处理——cutout 应该是硬边裁切（alphaTest）而不是真的半透明，
        // 只有 pass==='transparent'（玻璃/冰/水/水晶）才需要真正的透明混合。这个写
        // 错了之前一直没暴露，是因为手持物还在正常写深度缓冲，内部自己的面还能正确
        // 前后排序；上面把手持物的 depthWrite 关掉（修"手插墙里"那个 bug）之后，
        // 一个本该是硬边不透明的方块，被当成半透明混合处理，就会变成能透视穿模的
        // "玻璃感"——这才是"拿着方块变透明"的真正原因。
        transparent: def.pass === 'transparent',
        roughness: 0.55,
        metalness: 0,
        emissive: glowColor,
        emissiveIntensity: 0.85,
      });
    } else {
      mat = new THREE.MeshStandardMaterial({
        map: atlas,
        alphaTest: def.pass === 'cutout' ? 0.5 : 0,
        transparent: def.pass === 'transparent',
        roughness: def.pass === 'cutout' ? 0.78 : 0.82,
        metalness: 0.03,
      });
    }
    const mesh = new THREE.Mesh(geo, mat);
    mesh.scale.setScalar(0.26);
    // 方块托在手掌上方
    mesh.position.set(0.06, 0.09, -0.1);
    mesh.rotation.set(0.12, -0.6, 0.08);
    mesh.renderOrder = 10;
    this.disableHandDepthTest(mesh);
    // 发光方块额外加入"泛光层"：只有它会被 selective bloom 处理，
    // 不会像以前那样把太阳/雪地这些普通亮色也一起吹起泛光
    if (Game.HELD_GLOW_IDS.has(id)) mesh.layers.enable(Game.BLOOM_LAYER);
    this.handMesh = mesh;
    this.handGroup.add(mesh);
  }

  private spawnParticles(x: number, y: number, z: number, id: number) {
    const def = getBlock(id);
    let mat = this.particleMats.get(id);
    if (!mat) {
      mat = new THREE.MeshLambertMaterial({ color: this.tileAverageColor(def.tiles[2]) });
      this.particleMats.set(id, mat);
    }
    for (let i = 0; i < 10; i++) {
      const mesh = new THREE.Mesh(this.particleGeo, mat);
      const s = 0.08 + Math.random() * 0.09;
      mesh.scale.setScalar(s);
      mesh.position.set(x + 0.5 + (Math.random() - 0.5) * 0.8, y + 0.5 + (Math.random() - 0.5) * 0.8, z + 0.5 + (Math.random() - 0.5) * 0.8);
      this.scene.add(mesh);
      this.particles.push({
        mesh,
        vel: new THREE.Vector3((Math.random() - 0.5) * 3.4, 2 + Math.random() * 3, (Math.random() - 0.5) * 3.4),
        life: 0.6 + Math.random() * 0.4,
      });
    }
    if (this.particles.length > 160) {
      const extra = this.particles.splice(0, this.particles.length - 160);
      extra.forEach((p) => this.scene.remove(p.mesh));
    }
  }

  /** 生成掉落物（挖方块/杀怪掉在地上，走近拾取） */
  spawnDrops(x: number, y: number, z: number, id: number, count: number) {
    if (this.mode === 'creative' || count <= 0) return;
    const atlas = (this.world.materials.opaque as THREE.MeshLambertMaterial).map ?? null;
    const n = Math.min(3, Math.max(1, Math.ceil(count / 4)));
    for (let i = 0; i < n; i++) {
      const mesh = createDropMesh(id, atlas);
      mesh.position.set(
        x + (Math.random() - 0.5) * 0.5,
        y + 0.2 + Math.random() * 0.4,
        z + (Math.random() - 0.5) * 0.5,
      );
      this.scene.add(mesh);
      this.drops.push({
        mesh,
        vel: new THREE.Vector3(
          (Math.random() - 0.5) * 2.6,
          3.4 + Math.random() * 1.6,
          (Math.random() - 0.5) * 2.6,
        ),
        id,
        count,
        age: 0,
        frozen: 0.5,
      });
    }
  }

  private updateDrops(dt: number) {
    const pickPos = new THREE.Vector3(this.pos.x, this.pos.y + 1.1, this.pos.z);
    for (let i = this.drops.length - 1; i >= 0; i--) {
      const d = this.drops[i];
      d.age += dt;
      if (d.age > 60) {
        this.scene.remove(d.mesh);
        d.mesh.geometry.dispose();
        (d.mesh.material as THREE.Material).dispose();
        this.drops.splice(i, 1);
        continue;
      }
      d.frozen = Math.max(0, d.frozen - dt);
      const toPlayer = pickPos.clone().sub(d.mesh.position);
      const dist = toPlayer.length();
      d.mesh.visible = d.age < 55 || Math.floor(d.age * 8) % 2 === 0;

      const pickRadius = this.mods.has('magnet') ? 5.1 : 1.7;
      if (d.frozen <= 0 && dist < pickRadius) {
        // 磁吸拾取
        const pull = Math.min(1, (1.7 - dist) * 2.4) * dt * 7;
        d.mesh.position.addScaledVector(toPlayer.normalize(), pull);
        if (dist < 0.65) {
          const leftover = this.addItem(d.id, d.count);
          if (leftover > 0) this.opts.onToast('🎒 背包已满！');
          this.scene.remove(d.mesh);
          d.mesh.geometry.dispose();
          (d.mesh.material as THREE.Material).dispose();
          this.drops.splice(i, 1);
          sfx.click();
          continue;
        }
      } else {
        d.vel.y -= 22 * dt;
        d.mesh.position.addScaledVector(d.vel, dt);
        // 落地后缓慢自转 + 上下浮动，更容易被看见
        const settled = Math.abs(d.vel.y) < 0.4;
        d.mesh.rotation.y += dt * (settled ? 1.6 : 5);
        if (settled) {
          d.mesh.position.y += Math.sin(d.age * 2.6) * 0.0035;
          d.mesh.rotation.x = Math.sin(d.age * 1.8) * 0.12;
        } else {
          d.mesh.rotation.x = Math.sin(d.age * 3) * 0.2;
        }
        const bx = Math.floor(d.mesh.position.x);
        const by = Math.floor(d.mesh.position.y - 0.16);
        const bz = Math.floor(d.mesh.position.z);
        if (getBlock(this.world.getBlock(bx, by, bz)).solid) {
          d.mesh.position.y = by + 1 + 0.16;
          d.vel.y *= -0.32;
          d.vel.x *= 0.72;
          d.vel.z *= 0.72;
        }
      }
    }
  }

  /** 生存系统：体力 / 口渴 / 体温 / 天数 / 恐惧 */
  private updateSurvival(dt: number) {
    const survival = this.mode === 'survival' && !this.dead;
    const biome = this.world.biome(Math.floor(this.pos.x), Math.floor(this.pos.z));
    const night = !this.isDaytime();

    // 天数推进（每 1 个昼夜循环 = 1 天）
    const dayNow = this.isDaytime();
    if (dayNow && !this.lastDayPhase) {
      this.day++;
      if (this.mods.has('hundredDays')) {
        this.opts.onToast(`📅 第 ${this.day} 天${this.day === 100 ? ' —— 你活到了最后！' : ''}`);
        if (this.day === 25 || this.day === 50 || this.day === 100) {
          this.opts.onToast('☣️ 突变事件：怪物全面强化！');
        }
      }
    }
    this.lastDayPhase = dayNow;

    if (!survival) {
      this.stamina = 10;
      this.thirst = 10;
      this.temp = 5;
      return;
    }

    // 体力：疾跑消耗，休息恢复
    const sprinting = this.sprinting && Math.hypot(this.vel.x, this.vel.z) > 3;
    this.stamina = Math.max(0, Math.min(10, this.stamina + (sprinting ? -dt * 1.5 : dt * 0.9)));
    // 口渴：持续下降，沙漠更快
    const thirstRate = this.mods.has('nohunger') ? 0 : biome === 'desert' ? 0.055 : biome === 'swamp' ? 0.045 : 0.035;
    this.thirst = Math.max(0, Math.min(10, this.thirst - dt * thirstRate));
    if (this.thirst <= 0) this.damage(dt * 0.5);

    // 体温：雪原冷、沙漠热、水中冷、靠近火源回暖
    let target = 5;
    if (biome === 'snow') target = 1.5;
    else if (biome === 'desert') target = 8.5;
    else if (biome === 'swamp') target = 6;
    if (this.inWater) target -= 2.5;
    if (night) target -= 1;
    const nearFire =
      this.world.getBlock(Math.floor(this.pos.x) + 1, Math.floor(this.pos.y), Math.floor(this.pos.z)) === 13 ||
      this.world.getBlock(Math.floor(this.pos.x) - 1, Math.floor(this.pos.y), Math.floor(this.pos.z)) === 13 ||
      this.world.getBlock(Math.floor(this.pos.x), Math.floor(this.pos.y), Math.floor(this.pos.z) + 1) === 13 ||
      this.world.getBlock(Math.floor(this.pos.x), Math.floor(this.pos.y), Math.floor(this.pos.z) - 1) === 13 ||
      (this.inventory[this.selected]?.id ?? 0) === 30;
    if (nearFire) target = 6;
    this.temp += (target - this.temp) * Math.min(1, dt * 0.35);
    if (this.temp <= 1.2 || this.temp >= 8.8) this.damage(dt * 0.35);

    // 敲门人：夜晚累积恐惧，满值时敲门人现身
    if (this.mods.has('knocker')) {
      this.knockTimer -= dt;
      if (night) {
        this.fear = Math.min(10, this.fear + dt * 0.28);
        if (this.knockTimer <= 0 && this.fear > 3) {
          this.knockTimer = 9 + Math.random() * 8;
          sfx.dig();
          this.opts.onToast(this.fear > 8 ? '🚪 敲门声就在耳边……别回头' : '🚪 咚、咚、咚……有人在敲门');
        }
        if (this.fear >= 10 && !this.mobs.some((m) => m.def.id === 35)) {
          this.fear = 4;
          const def = MOB_DEFS.find((d) => d.id === 35)!;
          const a = Math.random() * Math.PI * 2;
          if (this.spawnBoss(def, this.pos.x + Math.cos(a) * 6, this.pos.z + Math.sin(a) * 6, `knock:${Date.now()}`)) {
            this.opts.onToast('🚪 门开了。');
          }
        }
      } else {
        this.fear = Math.max(0, this.fear - dt * 0.6);
      }
    }

    // 小心雨：雨天刷新专属恐怖生物
    if (this.mods.has('rainhorror')) {
      if (this.raining && Math.random() < dt * 0.35 && this.mobs.length < this.maxMobs + 6) {
        const pool = MOB_DEFS.filter((d) => d.requiresMod === 'rainhorror');
        const def = pool[Math.floor(Math.random() * pool.length)];
        const a = Math.random() * Math.PI * 2;
        const rx = Math.floor(this.pos.x + Math.cos(a) * 16);
        const rz = Math.floor(this.pos.z + Math.sin(a) * 16);
        const chunk = this.world.getChunk(Math.floor(rx / CHUNK_SIZE), Math.floor(rz / CHUNK_SIZE));
        if (chunk?.generated) {
          this.spawnMob(def, rx, rz);
          if (Math.random() < 0.25) this.opts.onToast('🌧️ 雨里有东西在动……');
        }
      }
    }

    // 破碎的剧本：世界故障
    if (this.mods.has('brokenscript')) {
      this.glitchTimer -= dt;
      if (this.glitchTimer <= 0) {
        this.glitchTimer = 6 + Math.random() * 10;
        this.glitch = 1;
        const lines = ['ERROR: script.chunk not found', '剧本第 ? 页已丢失', '你不该来这里', 'reload... failed'];
        this.opts.onToast(`📼 ${lines[Math.floor(Math.random() * lines.length)]}`);
      }
      this.glitch = Math.max(0, this.glitch - dt * 0.8);
    }
  }

  /** 探矿雷达：定期在附近宝石矿位置冒出光点 */
  private radarTimer = 0;
  private updateRadar(dt: number) {
    if (!this.mods.has('radar')) return;
    this.radarTimer -= dt;
    if (this.radarTimer > 0) return;
    this.radarTimer = 2.5;
    const px = Math.floor(this.pos.x);
    const py = Math.floor(this.pos.y);
    const pz = Math.floor(this.pos.z);
    let found = 0;
    for (let dx = -7; dx <= 7 && found < 3; dx += 2) {
      for (let dz = -7; dz <= 7 && found < 3; dz += 2) {
        for (let dy = -6; dy <= 2 && found < 3; dy += 2) {
          const id = this.world.getBlock(px + dx, py + dy, pz + dz);
          if (id === 21 || id === 13 || id === 15) {
            this.spawnParticles(px + dx, py + dy, pz + dz, id);
            found++;
          }
        }
      }
    }
  }

  /** 天气系统：跟随玩家的雨幕 */
  private rainCycle = 0;

  private updateRain(dt: number) {
    const rainMod = this.mods.has('rain') || this.mods.has('rainhorror');
    if (rainMod) {
      // 天气随时间变化：晴雨交替
      this.rainCycle -= dt;
      if (this.rainCycle <= 0) {
        this.rainCycle = 40 + Math.random() * 60;
        this.raining = !this.raining;
        this.opts.onToast(this.raining ? '🌧️ 开始下雨了' : '☀️ 雨停了');
      }
    }
    if (!rainMod || !this.raining) {
      if (this.rainParticles) {
        this.scene.remove(this.rainParticles);
        this.rainParticles.geometry.dispose();
        (this.rainParticles.material as THREE.Material).dispose();
        this.rainParticles = null;
      }
      return;
    }
    if (!this.rainParticles) {
      const count = 900;
      const positions = new Float32Array(count * 3);
      for (let i = 0; i < count; i++) {
        positions[i * 3] = (Math.random() - 0.5) * 40;
        positions[i * 3 + 1] = Math.random() * 24;
        positions[i * 3 + 2] = (Math.random() - 0.5) * 40;
      }
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      this.rainParticles = new THREE.Points(
        geo,
        new THREE.PointsMaterial({ color: 0xbfe3ff, size: 0.09, transparent: true, opacity: 0.65 }),
      );
      this.scene.add(this.rainParticles);
    }
    const pos = this.rainParticles.geometry.getAttribute('position') as THREE.BufferAttribute;
    for (let i = 0; i < pos.count; i++) {
      let y = pos.getY(i) - dt * 22;
      if (y < -2) y = 22;
      pos.setY(i, y);
    }
    pos.needsUpdate = true;
    this.rainParticles.position.set(this.pos.x, this.pos.y, this.pos.z);
  }

  private updateParticles(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      if (p.life <= 0) {
        this.scene.remove(p.mesh);
        if (p.ownMaterial) (p.mesh.material as THREE.Material).dispose();
        this.particles.splice(i, 1);
        continue;
      }
      p.vel.y -= 18 * dt;
      p.mesh.position.addScaledVector(p.vel, dt);
      const below = this.world.getBlock(
        Math.floor(p.mesh.position.x),
        Math.floor(p.mesh.position.y - 0.05),
        Math.floor(p.mesh.position.z),
      );
      if (getBlock(below).solid && p.vel.y < 0) {
        p.vel.y = 0;
        p.vel.x *= 0.6;
        p.vel.z *= 0.6;
      }
      p.mesh.rotation.x += dt * 6;
      p.mesh.rotation.y += dt * 4;
      const k = Math.min(1, p.life * 3);
      p.mesh.scale.setScalar((p.size ?? 0.12) * k);
    }
  }

  /* ------------------------------------------------ interaction ------ */

  private updateTarget() {
    const origin = new THREE.Vector3(this.pos.x, this.pos.y + EYE, this.pos.z);
    const dir = this.forwardVector(true);
    const hit = this.world.raycast(origin, dir, REACH);
    if (hit) {
      this.target = { x: hit.x, y: hit.y, z: hit.z, id: hit.id };
      this.highlight.position.set(hit.x + 0.5, hit.y + 0.5, hit.z + 0.5);
      this.highlight.visible = true;
      const c = this.breakProgress > 0 ? new THREE.Color().setHSL(0.16 * (1 - this.breakProgress), 1, 0.6) : new THREE.Color(0xffffff);
      (this.highlight.material as THREE.LineBasicMaterial).color = c;
      return hit;
    }
    this.target = null;
    this.highlight.visible = false;
    return null;
  }

  private updateBreaking(dt: number) {
    if (!this.breaking || !this.target || this.dead) {
      this.breakProgress = 0;
      return;
    }
    const def = getBlock(this.target.id);
    if (def.id === 16) {
      this.breakProgress = 0;
      return; // bedrock
    }
    // 工具加速：镐→石/矿，斧→木，铲→土沙雪；火把/工作台等手挖
    const heldStack = this.inventory[this.selected];
    const tool = heldStack ? getTool(heldStack.id) : undefined;
    const need = BLOCK_TOOL[def.id];
    const toolMul = tool && need ? (tool.type === need ? tool.speed : 1) : 1;
    const modMul = this.mods.has('fastmine') ? 3 : 1;
    const speed = this.mode === 'creative' ? 10 : (1 / Math.max(0.2, def.hardness ?? 1)) * toolMul * modMul;
    this.breakProgress += dt * speed;
    this.swing = Math.max(this.swing, 0.001);
    this.digSoundTimer -= dt;
    if (this.digSoundTimer <= 0) {
      sfx.dig();
      this.digSoundTimer = 0.22;
    }
    if (this.breakProgress >= 1) {
      const { x, y, z, id } = this.target;
      this.world.setBlock(x, y, z, AIR);
      if (this.mode === 'survival') {
        // 掉落在地上，走过去捡起来（我的世界式）
        this.spawnDrops(x + 0.5, y + 0.5, z + 0.5, id, this.mods.has('doubleloot') ? 2 : 1);
        if (tool) this.consumeFromSlot(this.selected); // 工具耐久 -1
      }
      if (id === 6) this.bumpQuest('wood'); // 砍树目标
      this.spawnParticles(x, y, z, id);
      sfx.break_();
      this.breakProgress = 0;
      this.swing = 0.001;
      // water flows in a bit: if a neighbour is water, fill
      if (
        this.world.getBlock(x, y + 1, z) === 11 ||
        this.world.getBlock(x + 1, y, z) === 11 ||
        this.world.getBlock(x - 1, y, z) === 11 ||
        this.world.getBlock(x, y, z + 1) === 11 ||
        this.world.getBlock(x, y, z - 1) === 11
      ) {
        if (y <= SEA_LEVEL) this.world.setBlock(x, y, z, 11);
      }
    }
  }

  /** 对着水面右键 → 喝水补充水分 */
  private tryDrink(): boolean {
    if (this.mode !== 'survival' || this.dead || this.eatTimer > 0) return false;
    if (this.thirst >= 10) return false;
    const origin = new THREE.Vector3(this.pos.x, this.pos.y + EYE, this.pos.z);
    const hit = this.world.raycast(origin, this.forwardVector(true), 3.2);
    const lookingAtWater =
      hit && this.world.getBlock(hit.x + hit.nx, hit.y + hit.ny, hit.z + hit.nz) === 11;
    const standingInWater = this.inWater;
    if (!lookingAtWater && !standingInWater) return false;
    this.thirst = Math.min(10, this.thirst + 5);
    this.eatTimer = 0.5;
    sfx.splash();
    this.opts.onToast('💧 喝了几口水，水分 +5');
    return true;
  }

  private tryEat(): boolean {
    if (this.mode !== 'survival' || this.dead || this.eatTimer > 0) return false;
    const stack = this.inventory[this.selected];
    const id = stack?.id ?? 0;
    const food = this.FOODS[id];
    if (!food || !stack || stack.count <= 0) return false;
    if (this.hunger >= 20 && this.health >= 20) return false;
    this.consumeFromSlot(this.selected);
    this.hunger = Math.min(20, this.hunger + food.hunger);
    if (food.health > 0 && this.hunger > 15) this.health = Math.min(20, this.health + food.health);
    this.eatTimer = 0.6;
    this.swing = 0.001;
    sfx.jump();
    this.opts.onToast(`😋 吃掉了${food.label}，饥饿 +${food.hunger}`);
    return true;
  }

  private tryPlace() {
    if (this.placeCooldown > 0 || this.dead) return;
    // 对着水右键优先喝水（生存模式）
    if (this.tryDrink()) return;
    const origin = new THREE.Vector3(this.pos.x, this.pos.y + EYE, this.pos.z);
    const hit = this.world.raycast(origin, this.forwardVector(true), REACH);
    if (!hit) {
      // Right-clicking empty air in survival: drink if near water, else eat.
      if (!this.tryDrink()) this.tryEat();
      return;
    }
    if (hit.id === 28) {
      this.openChestAt(hit.x, hit.y, hit.z);
      return;
    }
    if (hit.id === 31) {
      this.openCraftTableAt(hit.x, hit.y, hit.z);
      return;
    }
    const stack = this.inventory[this.selected];
    if (!stack) return;
    const id = stack.id;
    if (isToolId(id)) return; // 工具不能当方块放置
    if (this.mode === 'survival' && stack.count <= 0) {
      this.opts.onToast(`${getBlock(id).name} 已用完`);
      return;
    }
    const nx = hit.x + hit.nx;
    const ny = hit.y + hit.ny;
    const nz = hit.z + hit.nz;
    if (ny < 0 || ny >= WORLD_HEIGHT) return;
    const existing = this.world.getBlock(nx, ny, nz);
    if (existing !== AIR && !getBlock(existing).liquid) return;
    // do not place inside the player
    const def = getBlock(id);
    if (def.solid) {
      const pminx = this.pos.x - PLAYER_HALF;
      const pmaxx = this.pos.x + PLAYER_HALF;
      const pminz = this.pos.z - PLAYER_HALF;
      const pmaxz = this.pos.z + PLAYER_HALF;
      const pminy = this.pos.y;
      const pmaxy = this.pos.y + PLAYER_HEIGHT;
      if (pmaxx > nx && pminx < nx + 1 && pmaxy > ny && pminy < ny + 1 && pmaxz > nz && pminz < nz + 1) return;
    }
    if (this.mode === 'survival' && (this.inventory[this.selected]?.count ?? 0) <= 0) return;
    if (id === 20) {
      this.spawnTNT(nx, ny, nz);
    } else if (this.mods.has('wallbuild')) {
      // 建筑师之手：一次放置 3 格墙面
      let placed = 0;
      for (let i = 0; i < 3 && placed < 3; i++) {
        const tx = nx + (hit.nx === 0 ? i - 1 : 0);
        const ty = ny + (hit.ny === 0 ? i - 1 : 0);
        const tz = nz + (hit.nz === 0 ? i - 1 : 0);
        if (ty < 1 || ty >= WORLD_HEIGHT) continue;
        if (this.world.getBlock(tx, ty, tz) !== AIR) continue;
        this.world.setBlock(tx, ty, tz, id);
        placed++;
      }
      if (placed === 0) this.world.setBlock(nx, ny, nz, id);
    } else {
      this.world.setBlock(nx, ny, nz, id);
    }
    if (id === 43) this.world.tryIgnitePortal(nx, ny, nz);
    if (this.mode === 'survival') this.consumeFromSlot(this.selected);
    // 放置反馈：方块落位时冒一点尘
    this.spawnDust(nx + 0.5, ny + 0.1, nz + 0.5, 0xd8d8e0, 5, 0.6);
    this.placedBlocks++;
    if (this.placedBlocks >= 25) {
      this.placedBlocks = 0;
      this.bumpQuest('shelter');
    }
    sfx.place();
    this.placeCooldown = 0.16;
    this.swing = 0.001;
  }

  private pickBlock() {
    if (!this.target) return;
    this.selectOrSetBlock(this.target.id);
  }

  /* ------------------------------------------------ Custom original creatures & fun actions ---------------- */

  private spawnTNT(x: number, y: number, z: number) {
    const geo = new THREE.BoxGeometry(1, 1, 1);
    const mat = new THREE.MeshLambertMaterial({ color: 0xff3333 });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(x + 0.5, y + 0.5, z + 0.5);
    this.scene.add(mesh);
    this.tntEntities.push({
      mesh,
      pos: new THREE.Vector3(x + 0.5, y + 0.5, z + 0.5),
      timer: 3.2,
    });
    this.opts.onToast('🧨 TNT已点燃！倒计时 3 秒…');
  }

  private tickTNT(dt: number) {
    for (let i = this.tntEntities.length - 1; i >= 0; i--) {
      const ent = this.tntEntities[i];
      ent.timer -= dt;

      // Pulse red/white color
      const mat = ent.mesh.material as THREE.MeshLambertMaterial;
      const flash = Math.floor(ent.timer * 8) % 2 === 0;
      mat.color.setHex(flash ? 0xffffff : 0xff3333);
      ent.mesh.scale.setScalar(1 + Math.sin(ent.timer * 12) * 0.08);

      if (ent.timer <= 0) {
        // Explode!
        this.scene.remove(ent.mesh);
        ent.mesh.geometry.dispose();
        mat.dispose();
        this.tntEntities.splice(i, 1);

        const tx = Math.floor(ent.pos.x);
        const ty = Math.floor(ent.pos.y);
        const tz = Math.floor(ent.pos.z);
        const radius = this.mods.has('bigexplosion') ? 6.3 : 3.5;

        // Perform block destruction
        const destroyed = this.world.explode(tx, ty, tz, radius);

        // Explode sound & splash particles
        sfx.break_();
        sfx.splash();

        destroyed.forEach(([bx, by, bz, bid]) => {
          this.spawnParticles(bx, by, bz, bid);
        });

        // Player damage & knockback
        const distToPlayer = this.pos.distanceTo(ent.pos);
        if (distToPlayer < radius * 1.5) {
          const force = (radius * 1.5 - distToPlayer) / (radius * 1.5);
          this.damage(Math.floor(force * 12));
          const knock = this.pos.clone().sub(ent.pos).setLength(force * 14);
          this.vel.add(knock);
          this.vel.y += 4;
        }

        // Mob damage & knockback
        this.mobs.forEach((mob) => {
          const d = mob.pos.distanceTo(ent.pos);
          if (d < radius * 1.5) {
            const force = (radius * 1.5 - d) / (radius * 1.5);
            mob.damage(
              Math.floor(force * 18),
              mob.pos.clone().sub(ent.pos).setLength(force)
            );
          }
        });

        this.opts.onToast('💥 轰！大爆炸！');

        // 连锁反应：爆炸范围内如果还有别的正在倒计时的 TNT，直接点燃它们的引信
        // （给一个短随机延迟而不是瞬间同时炸，看起来像真的被"引燃"而不是巧合）
        for (const other of this.tntEntities) {
          if (other === ent) continue;
          const d = other.pos.distanceTo(ent.pos);
          if (d < radius * 1.3 && other.timer > 0.4) {
            other.timer = 0.15 + Math.random() * 0.25;
          }
        }
      }
    }
  }

  /** 枪械模组：发射子弹（hitscan + 曳光），消耗弹药与枪械耐久 */
  private tryShoot(): boolean {
    if (!this.mods.has('guns') || this.dead) return false;
    const held = this.inventory[this.selected];
    if (!held) return false;
    const gun = getTool(held.id);
    if (!gun || gun.type !== 'gun') return false;
    if (this.shootCooldown > 0) return true;

    // 找弹药：优先快捷栏下一格，否则背包里第一份
    let ammoIdx = -1;
    const nextSlot = this.inventory[(this.selected + 1) % INV_SIZE];
    if (nextSlot && isAmmo(nextSlot.id)) ammoIdx = (this.selected + 1) % INV_SIZE;
    else ammoIdx = this.inventory.findIndex((s) => s && isAmmo(s.id));
    if (ammoIdx < 0) {
      this.opts.onToast('🔫 没有子弹了！用木棍/圆石/水晶合成弹药');
      this.shootCooldown = 0.5;
      return true;
    }
    const ammo = this.inventory[ammoIdx]!;
    const ammoBonus = getItem(ammo.id)?.ammoDamage ?? 0;

    const origin = new THREE.Vector3(this.pos.x, this.pos.y + EYE, this.pos.z);
    const dir = this.forwardVector(true);
    const range = gun.range ?? 30;

    // 命中生物？
    let best: { mob: MobEntity; dist: number } | null = null;
    for (const mob of this.mobs) {
      const center = mob.pos.clone().add(new THREE.Vector3(0, mob.scale * 0.6, 0));
      const sphere = new THREE.Sphere(center, mob.scale * 0.55);
      const hitPoint = new THREE.Vector3();
      if (new THREE.Ray(origin, dir).intersectSphere(sphere, hitPoint)) {
        const d = origin.distanceTo(hitPoint);
        if (d <= range && (!best || d < best.dist)) best = { mob, dist: d };
      }
    }
    const blockHit = this.world.raycast(origin, dir, range);
    const endDist = best
      ? best.dist
      : blockHit
        ? Math.min(blockHit.distance, range)
        : range;

    this.drawTracer(origin, dir, endDist, ammo.id);

    if (best) {
      const dmg = gun.damage + ammoBonus + (this.mods.has('swordmaster') ? 0 : 0);
      best.mob.damage(dmg, dir.clone().setY(0).normalize());
      this.opts.onToast(`🔫 命中 [${best.mob.def.name}] -${dmg}`);
      if (best.mob.hp <= 0) this.bumpQuest('boss', best.mob.def.boss ? 1 : 0);
    } else if (blockHit && this.mode === 'survival') {
      this.spawnParticles(blockHit.x, blockHit.y, blockHit.z, blockHit.id);
    }

    this.consumeFromSlot(ammoIdx);
    this.consumeFromSlot(this.selected); // 枪械耐久 -1
    this.shootCooldown = gun.id === 109 ? 0.22 : gun.id === 110 ? 0.5 : 0.34;
    this.swing = 0.001;
    // 后坐力
    this.pitch = Math.min(Math.PI / 2 - 0.01, this.pitch + 0.012);
    sfx.dig();
    return true;
  }

  /** 曳光弹（短暂存在的发光线段） */
  private drawTracer(origin: THREE.Vector3, dir: THREE.Vector3, dist: number, ammoId: number) {
    const color = ammoId === 206 ? 0x5ce1e6 : ammoId === 205 ? 0xf5f5f5 : 0xffd166;
    const geo = new THREE.BufferGeometry().setFromPoints([
      origin.clone().addScaledVector(dir, 0.6),
      origin.clone().addScaledVector(dir, dist),
    ]);
    const line = new THREE.Line(geo, new THREE.LineBasicMaterial({ color, transparent: true, opacity: 0.9 }));
    this.scene.add(line);
    this.tracers.push({ line, life: 0.09 });
  }

  private tryHitMob(): boolean {
    const origin = new THREE.Vector3(this.pos.x, this.pos.y + EYE, this.pos.z);
    const dir = this.forwardVector(true);

    let hitMob: MobEntity | null = null;
    let minDist = REACH;

    this.mobs.forEach((mob) => {
      const mobEye = mob.pos.clone().add(new THREE.Vector3(0, mob.scale * 0.6, 0));
      const sphere = new THREE.Sphere(mobEye, mob.scale * 0.5);
      const ray = new THREE.Ray(origin, dir);
      const target = new THREE.Vector3();
      if (ray.intersectSphere(sphere, target)) {
        const d = origin.distanceTo(target);
        if (d < minDist) {
          minDist = d;
          hitMob = mob;
        }
      }
    });

    if (hitMob) {
      const m = hitMob as MobEntity;
      this.swing = 0.001;
      const force = this.forwardVector(false).normalize();
      const heldStack = this.inventory[this.selected];
      const tool = heldStack ? getTool(heldStack.id) : undefined;
      const masterMul = this.mods.has('swordmaster') ? 1.6 : 1;
      const damage = this.mode === 'creative' ? 99 : Math.round((tool ? tool.damage : 3) * masterMul);
      m.damage(damage, force);
      if (this.mode === 'survival' && tool) this.consumeFromSlot(this.selected);
      this.opts.onToast(
        `⚔️ 击中了 [${m.def.name}]${tool ? `（${tool.name}伤害 ${damage}）` : ''}！HP: ${m.hp}/${m.maxHp}`,
      );

      if (m.hp <= 0) {
        this.spawnParticles(m.pos.x, m.pos.y, m.pos.z, m.def.dropId);
        sfx.break_();
        this.opts.onToast(`💀 击败了 [${m.def.name}]！掉落物掉在地上了`);
      }
      return true;
    }
    return false;
  }

  private tryFeedMob(): boolean {
    const origin = new THREE.Vector3(this.pos.x, this.pos.y + EYE, this.pos.z);
    const dir = this.forwardVector(true);

    let hitMob: MobEntity | null = null;
    let minDist = REACH;

    this.mobs.forEach((mob) => {
      const mobEye = mob.pos.clone().add(new THREE.Vector3(0, mob.scale * 0.6, 0));
      const sphere = new THREE.Sphere(mobEye, mob.scale * 0.5);
      const ray = new THREE.Ray(origin, dir);
      const target = new THREE.Vector3();
      if (ray.intersectSphere(sphere, target)) {
        const d = origin.distanceTo(target);
        if (d < minDist) {
          minDist = d;
          hitMob = mob;
        }
      }
    });

    if (hitMob) {
      const m = hitMob as MobEntity;
      const heldId = this.inventory[this.selected]?.id ?? 0;
      // 驯兽大师：任意食物（含花草蘑菇）都能驯服任意生物
      const isFood = !!this.FOODS[heldId];
      if ((m.def.favFood === heldId || (this.mods.has('tame') && isFood)) && heldId !== 0) {
        this.swing = 0.001;
        m.tamed = true;
        this.bumpQuest('tame');
        if (this.mode === 'survival') this.consumeFromSlot(this.selected);
        sfx.place();
        this.opts.onToast(`💖 驯服成功！[${m.def.name}] 会跟随你并帮你打怪！`);
        // 爱心粒子 + 受击闪白反馈
        for (let i = 0; i < 6; i++) {
          this.spawnParticles(m.pos.x, m.pos.y + 1.1, m.pos.z, 14);
        }
        m.damageFlash = 0.5;
        return true;
      }
    }
    return false;
  }

  private isDaytime() {
    return this.timeOfDay >= 0.25 && this.timeOfDay < 0.75;
  }

  private spawnMob(def: (typeof MOB_DEFS)[number], rx: number, rz: number, y?: number) {
    const sy = y ?? this.world.surfaceY(rx, rz);
    if (sy <= 1 || sy >= WORLD_HEIGHT) return;
    // Never spawn over empty void (e.g. under floating islands).
    if (!getBlock(this.world.getBlock(rx, sy - 1, rz)).solid) return;
    const mob = new MobEntity(def, rx, sy + 0.2, rz);
    this.scene.add(mob.group);
    this.mobs.push(mob);
  }

  private spawnRandomMob(rx: number, rz: number, allowHostile: boolean) {
    // Only spawn on chunks that are already generated, otherwise we would block
    // the main thread with synchronous terrain generation (a major lag source).
    const chunk = this.world.getChunk(Math.floor(rx / CHUNK_SIZE), Math.floor(rz / CHUNK_SIZE));
    if (!chunk || !chunk.generated) return;
    const biome = this.world.biome(rx, rz);
    const inBiome = (d: (typeof MOB_DEFS)[number]) =>
      (!d.biomes || d.biomes.includes(biome)) && (!d.requiresMod || this.mods.has(d.requiresMod));
    // 白天只刷友善生物（不含亡灵）；夜晚才允许敌对/亡灵
    const friendly = MOB_DEFS.filter((def) => def.friendly && !def.boss && !def.undead && inBiome(def));
    const hostile = MOB_DEFS.filter((def) => !def.friendly && !def.boss && !def.undead && inBiome(def));
    const undead = MOB_DEFS.filter((def) => def.undead && !def.boss && inBiome(def));
    const hostileCount = this.mobs.filter((mob) => !mob.def.friendly && !mob.def.boss).length;
    const cap = this.mods.has('horror') ? 9 : 4;
    let pool = friendly;
    if (allowHostile && hostileCount < cap) {
      // 恐怖模组：几乎只刷亡灵
      pool = this.mods.has('horror') ? undead : Math.random() < 0.6 ? hostile : undead;
    }
    const def = pool[Math.floor(Math.random() * pool.length)];
    const sy = this.world.surfaceY(rx, rz);
    this.spawnMob(def, rx, rz, sy);
    // 惊变 100 天：越往后怪物越强
    const scaled = this.mobs[this.mobs.length - 1];
    const k = this.dayScale();
    if (k > 1 && !def.friendly) {
      scaled.maxHp = Math.round(scaled.maxHp * k);
      scaled.hp = scaled.maxHp;
    }
  }

  /** 召唤 Boss 并记录触发键（保证每个触发点只刷一次） */
  private spawnBoss(def: (typeof MOB_DEFS)[number], x: number, z: number, key: string): boolean {
    const chunk = this.world.getChunk(Math.floor(x / CHUNK_SIZE), Math.floor(z / CHUNK_SIZE));
    if (!chunk || !chunk.generated) return false;
    const y = this.world.surfaceY(x, z);
    this.spawnMob(def, x, z, y);
    const mob = this.mobs[this.mobs.length - 1];
    this.bossKeys.set(mob.id, key);
    this.spawnedBosses.add(key);
    return true;
  }

  /** 惊变 100 天：随天数强化怪物 */
  private dayScale() {
    if (!this.mods.has('hundredDays')) return 1;
    return 1 + Math.min(2.5, (this.day - 1) * 0.035);
  }

  private updateMobs(dt: number) {
    // Fixed 20 Hz simulation step for AI + physics; visuals are interpolated
    // every rendered frame below, which removes the "stuttery" look.
    this.mobTickAccumulator += dt;
    let steps = 0;
    while (this.mobTickAccumulator >= MOB_DT && steps < 4) {
      this.tickMobsFixed(MOB_DT);
      this.mobTickAccumulator -= MOB_DT;
      steps++;
    }
    const alpha = Math.min(1, this.mobTickAccumulator / MOB_DT);
    for (const mob of this.mobs) this.updateMobVisual(mob, alpha, dt);
    this.updateRagdolls(dt);
  }

  private tickMobsFixed(step: number) {
    const daytime = this.isDaytime();

    // 联机小游戏「野人来了」：按波次刷怪
    if (this.waveMode && this.loading > 0.9 && !this.dead) {
      this.waveTimer -= step;
      if (this.waveTimer <= 0) {
        this.wave++;
        this.waveTimer = Math.max(13, 20 - this.wave);
        const count = 3 + this.wave * 2;
        const hostile = MOB_DEFS.filter((d) => !d.friendly && !d.boss);
        for (let i = 0; i < count && this.mobs.length < this.maxMobs + 10; i++) {
          const ang = Math.random() * Math.PI * 2;
          const r = 12 + Math.random() * 10;
          const rx = Math.floor(this.pos.x + Math.cos(ang) * r);
          const rz = Math.floor(this.pos.z + Math.sin(ang) * r);
          const chunk = this.world.getChunk(Math.floor(rx / CHUNK_SIZE), Math.floor(rz / CHUNK_SIZE));
          if (!chunk || !chunk.generated) continue;
          const def = hostile[Math.floor(Math.random() * hostile.length)];
          this.spawnMob(def, rx, rz);
        }
        this.opts.onToast(`🌊 野人来了！第 ${this.wave} 波！`);
        sfx.break_();
      }
    }

    // Boss 突袭模组：定期在附近刷一个 Boss
    if (this.mods.has('bossrush') && this.mode === 'survival') {
      this.bossRushTimer -= step;
      if (this.bossRushTimer <= 0) {
        this.bossRushTimer = 50;
        const bosses = MOB_DEFS.filter((d) => d.boss);
        const def = bosses[Math.floor(Math.random() * bosses.length)];
        const ang = Math.random() * Math.PI * 2;
        if (this.spawnBoss(def, this.pos.x + Math.cos(ang) * 10, this.pos.z + Math.sin(ang) * 10, `rush:${Date.now()}`)) {
          this.opts.onToast(`💀 Boss 突袭！${def.name} 出现了！`);
        }
      }
    }

    // 昼夜 Boss 触发：熔岩魔王（献祭岩浆）/ 冰雪女王（雪原）
    if (!daytime && this.mode === 'survival') {
      const px = Math.floor(this.pos.x);
      const py = Math.floor(this.pos.y);
      const pz = Math.floor(this.pos.z);
      if (!this.spawnedBosses.has('lava')) {
        let lava = 0;
        for (let dx = -4; dx <= 4; dx += 2) {
          for (let dz = -4; dz <= 4; dz += 2) {
            for (let dy = -2; dy <= 2; dy += 2) {
              if (this.world.getBlock(px + dx, py + dy, pz + dz) === 17) lava++;
            }
          }
        }
        if (lava >= 5) {
          const def = MOB_DEFS.find((d) => d.id === 22)!;
          if (this.spawnBoss(def, px + 6, pz + 6, 'lava')) {
            this.opts.onToast('🔥 岩浆献祭生效，熔岩魔王苏醒了！');
          }
        }
      }
      if (!this.spawnedBosses.has('snow') && this.world.biome(px, pz) === 'snow') {
        let snow = 0;
        for (let dx = -4; dx <= 4; dx += 2) {
          for (let dz = -4; dz <= 4; dz += 2) {
            if (this.world.getBlock(px + dx, py, pz + dz) === 12) snow++;
          }
        }
        if (snow >= 12) {
          const def = MOB_DEFS.find((d) => d.id === 24)!;
          if (this.spawnBoss(def, px + 6, pz + 6, 'snow')) {
            this.opts.onToast('❄️ 雪原的寒气凝聚，冰雪女王降临了！');
          }
        }
      }
    }

    this.mobSpawnTimer -= step;
    if (this.mobSpawnTimer <= 0 && this.loading > 0.9) {
      this.mobSpawnTimer = 3.2 + Math.random() * 2.2;

      if (this.mobs.length < this.maxMobs) {
        const angle = Math.random() * Math.PI * 2;
        const distance = 18 + Math.random() * 18;
        const rx = Math.floor(this.pos.x + Math.cos(angle) * distance);
        const rz = Math.floor(this.pos.z + Math.sin(angle) * distance);
        // Daylight only spawns friendly creatures. Hostiles begin appearing after dusk.
        this.spawnRandomMob(rx, rz, !daytime);
      }

      if (!daytime && !this.mobs.some((mob) => mob.def.boss)) {
        const bossDef = MOB_DEFS.find((def) => def.boss);
        if (bossDef) {
          for (const marker of this.world.structures.values()) {
            if (marker.type !== 'altar') continue;
            const key = `${marker.x},${marker.z}`;
            const distance = Math.hypot(marker.x - this.pos.x, marker.z - this.pos.z);
            if (distance < 28 && !this.spawnedAltars.has(key)) {
              const altarChunk = this.world.getChunk(
                Math.floor(marker.x / CHUNK_SIZE),
                Math.floor(marker.z / CHUNK_SIZE),
              );
              if (!altarChunk || !altarChunk.generated) continue;
              this.spawnedAltars.add(key);
              this.spawnMob(bossDef, marker.x, marker.z, marker.y);
              this.opts.onToast('祭坛涌出紫色蛊雾，Mini-Boss 蛊真兴现身！');
              break;
            }
          }
        }
      }
    }

    for (let i = this.mobs.length - 1; i >= 0; i--) {
      const mob = this.mobs[i];
      const dist = mob.pos.distanceTo(this.pos);
      if ((dist > 64 && !mob.tamed) || mob.hp <= 0) {
        if (mob.def.boss && mob.hp > 0) {
          for (const marker of this.world.structures.values()) {
            if (marker.type === 'altar' && Math.hypot(marker.x - mob.pos.x, marker.z - mob.pos.z) < 5) {
              this.spawnedAltars.delete(`${marker.x},${marker.z}`);
              break;
            }
          }
        }
        // 死亡 → 掉落物 + 布娃娃
        if (mob.hp <= 0) {
          const lootMul = this.mods.has('doubleloot') ? 2 : 1;
          const bossMul = this.mods.has('bossrush') && mob.def.boss ? 2 : 1;
          this.spawnDrops(
            mob.pos.x,
            mob.pos.y + 0.6,
            mob.pos.z,
            mob.def.dropId,
            (mob.def.boss ? 4 : 1) * lootMul * bossMul,
          );
          if (mob.def.boss) this.bumpQuest('boss');
          this.spawnRagdoll(mob);
        }
        const bossKey = this.bossKeys.get(mob.id);
        if (bossKey) {
          this.spawnedBosses.delete(bossKey);
          this.bossKeys.delete(mob.id);
        }
        this.scene.remove(mob.group);
        mob.dispose();
        this.mobs.splice(i, 1);
        continue;
      }

      if (dist > 56) continue;
      mob.tick(step, this.world, this.pos);

      // 亡灵白天在阳光下燃烧
      if (mob.def.undead && !mob.tamed && daytime) {
        const above = this.world.getBlock(
          Math.floor(mob.pos.x),
          Math.floor(mob.pos.y + 2),
          Math.floor(mob.pos.z),
        );
        const exposed = above === AIR || !getBlock(above).opaque;
        if (exposed) {
          mob.hp -= step * 0.9;
          if (Math.random() < 0.04) this.spawnParticles(mob.pos.x, mob.pos.y + 0.6, mob.pos.z, 13);
        }
      }

      if (mob.def.boss && dist < 13 && mob.specialCooldown <= 0 && this.mode === 'survival') {
        mob.specialCooldown = 4.2;
        this.damage(2);
        this.vel.add(mob.pos.clone().sub(this.pos).setLength(2.5));
        this.spawnParticles(mob.pos.x, mob.pos.y + 1, mob.pos.z, 15);
        this.opts.onToast('蛊真兴施放了「牵魂蛊」！');
      }

      if (
        dist < 1.5 &&
        !mob.def.friendly &&
        !mob.tamed &&
        !this.dead &&
        this.mode === 'survival' &&
        mob.attackCooldown <= 0
      ) {
        mob.attackCooldown = mob.def.boss ? 1.4 : 1.0;
        if (mob.def.behavior === 'explode' && mob.explodeTimer > 1.2) {
          mob.hp = 0;
          const tx = Math.floor(mob.pos.x);
          const ty = Math.floor(mob.pos.y);
          const tz = Math.floor(mob.pos.z);
          const radius = 3.0;
          this.world.explode(tx, ty, tz, radius);
          sfx.break_();
          this.damage(10);
          const knock = this.pos.clone().sub(mob.pos).setLength(8);
          this.vel.add(knock);
        } else {
          // 伤害按生物攻击力 × 天数强化
          const raw = mob.def.attack ?? (mob.def.boss ? 5 : 3);
          this.damage(Math.max(1, Math.round(raw * this.dayScale())));
          const knock = this.pos.clone().sub(mob.pos).setLength(5);
          this.vel.add(knock);
          this.vel.y += 2.2;
        }
      }
    }
  }

  /** Per-frame smooth render pass for a mob (position interpolation + walk cycle). */
  private updateMobVisual(mob: MobEntity, alpha: number, dt: number) {
    const dist = mob.pos.distanceTo(this.pos);
    const fade = THREE.MathUtils.clamp((58 - dist) / 10, 0.1, 1);
    mob.group.visible = dist < 58;
    if (!mob.group.visible) return;

    // 全部姿态交给生物自身的关节动画系统
    mob.animate(dt, alpha, this.pos, true);
    // 距离淡入：远处缩小淡出，避免凭空出现
    if (fade < 1) mob.group.scale.multiplyScalar(fade);
  }

  /** 动态光源：扫描玩家附近的火把/荧光石/岩浆，用点光源池真实照明 */
  private lightPool: THREE.PointLight[] = [];
  private lightTimer = 0;
  private lowPower = false;

  private updateLightProbes(dt: number) {
    if (this.lightPool.length === 0) {
      const poolSize = this.lowPower ? 4 : 12;
      for (let i = 0; i < poolSize; i++) {
        // 始终保持 visible=true、只把 intensity 归零：
        // 若切换 visible，Three.js 会因光源数量变化重新编译着色器，造成卡顿
        // decay 用 1（线性衰减）而不是物理正确的 2（平方反比）：
        // 平方反比在这个尺度下要么近处爆白、要么伸不到几格外就已经看不见，
        // 火把/荧光石这种"游戏里的光源"更适合线性衰减，照得更远也更自然。
        const l = new THREE.PointLight(0xffb86b, 0, 24, 1);
        this.scene.add(l);
        this.lightPool.push(l);
      }
    }
    this.lightTimer -= dt;
    if (this.lightTimer > 0) return;
    this.lightTimer = 0.45;

    const px = Math.floor(this.pos.x);
    const py = Math.floor(this.pos.y);
    const pz = Math.floor(this.pos.z);
    const found: { x: number; y: number; z: number; power: number; color: number }[] = [];

    // 之前搜索范围只有 ±7 格——火把本身的自发光材质（emissive）不管多远都看得见，
    // 但真正照亮周围方块的动态点光源只在这 7 格以内才会生成，站远一点看火把就会
    // 出现"自己在发光、但完全照不亮周围"的怪现象。搜索范围放宽到 ±13 格
    // （跟点光源自身 24 格的衰减距离基本匹配），配合上面把光源池从 8 个加到 12 个，
    // 视野里常见的火把基本都能被照亮。
    const searchR = this.lowPower ? 9 : 13;
    for (let dx = -searchR; dx <= searchR; dx += 1) {
      for (let dz = -searchR; dz <= searchR; dz += 1) {
        for (let dy = -6; dy <= 6; dy += 1) {
          const id = this.world.getBlock(px + dx, py + dy, pz + dz);
          // 13 荧光石 / 30 火把 / 17 岩浆
          if (id === 13 || id === 30 || id === 17) {
            found.push({
              x: px + dx + 0.5,
              y: py + dy + 0.55,
              z: pz + dz + 0.5,
              power: id === 13 ? 2.0 : id === 30 ? 1.5 : 1.3,
              color: id === 17 ? 0xff6a1a : id === 13 ? 0xffd166 : 0xffb86b,
            });
          }
        }
      }
    }

    // 只保留最近的若干个，避免光源过多拖慢渲染
    found.sort(
      (a, b) =>
        (a.x - this.pos.x) ** 2 + (a.y - this.pos.y) ** 2 + (a.z - this.pos.z) ** 2 -
        ((b.x - this.pos.x) ** 2 + (b.y - this.pos.y) ** 2 + (b.z - this.pos.z) ** 2),
    );

    this.lightPool.forEach((light, i) => {
      const src = found[i];
      if (!src) {
        light.intensity = 0;
        return;
      }
      light.position.set(src.x, src.y, src.z);
      light.color.setHex(src.color);
      // 火光轻微摇曳，夜晚更有生气
      const flicker = 0.88 + Math.sin(performance.now() * 0.006 + i * 1.7) * 0.12;
      // 火把/荧光石本身是恒定光源，不应该因为"现在是白天"就变暗——
      // 真实世界里火把中午和半夜发的光是一样的，只是白天环境光更亮，
      // 显得没那么打眼而已，这个对比交给渲染器自己处理就行，
      // 不需要再乘一个昼夜系数人为把光源调暗（这也是之前"洞穴里大白天
      // 火把跟没点一样"的原因）。
      light.intensity = src.power * flicker * 1.8;
    });
  }

  /** 通用尘土粒子（落地、放置方块时的反馈） */
  private spawnDust(x: number, y: number, z: number, color: number, count = 8, power = 1) {
    if (!this.dustMat) {
      this.dustMat = new THREE.MeshLambertMaterial({ color: 0xffffff, transparent: true, opacity: 0.85 });
      this.dustGeo = new THREE.BoxGeometry(1, 1, 1);
    }
    const geo = this.dustGeo!;
    for (let i = 0; i < count; i++) {
      const mat = this.dustMat.clone();
      mat.color.setHex(color);
      const size = 0.05 + Math.random() * 0.07;
      const mesh = new THREE.Mesh(geo, mat);
      mesh.scale.setScalar(size);
      mesh.position.set(x + (Math.random() - 0.5) * 0.5, y, z + (Math.random() - 0.5) * 0.5);
      this.scene.add(mesh);
      this.particles.push({
        mesh,
        vel: new THREE.Vector3(
          (Math.random() - 0.5) * 1.8 * power,
          (0.6 + Math.random() * 1.4) * power,
          (Math.random() - 0.5) * 1.8 * power,
        ),
        life: 0.35 + Math.random() * 0.35,
        ownMaterial: true,
        size,
      });
    }
  }

  /** 死亡 → 布娃娃。开启「真实的布娃娃」模组时带关节联动与更真实的翻滚/弹跳 */
  private spawnRagdoll(mob: MobEntity) {
    if (this.ragdolls.length > 12) return;
    const realistic = this.mods.has('ragdoll');
    const parts: RagdollPart[] = [];
    const impulse = this.forwardVector(false).multiplyScalar(realistic ? 3.4 : 2.2);
    const worldPos = new THREE.Vector3();
    const worldQuat = new THREE.Quaternion();
    const worldScale = new THREE.Vector3();
    mob.group.updateMatrixWorld(true);

    mob.group.traverse((obj) => {
      if (!(obj instanceof THREE.Mesh)) return;
      const sourceMats = Array.isArray(obj.material) ? obj.material : [obj.material];
      const mats = sourceMats.map((m) => m.clone());
      const mesh = new THREE.Mesh(obj.geometry.clone(), mats.length === 1 ? mats[0] : mats);
      obj.getWorldPosition(worldPos);
      mesh.position.copy(worldPos);
      obj.getWorldQuaternion(worldQuat);
      mesh.quaternion.copy(worldQuat);
      obj.getWorldScale(worldScale);
      mesh.scale.copy(worldScale);
      mesh.renderOrder = 5;
      this.scene.add(mesh);

      const geo = obj.geometry;
      if (!geo.boundingBox) geo.computeBoundingBox();
      const halfH = Math.max(0.05, (geo.boundingBox!.max.y - geo.boundingBox!.min.y) / 2) * Math.abs(worldScale.y);

      parts.push({
        mesh,
        vel: new THREE.Vector3(
          (Math.random() - 0.5) * (realistic ? 4.4 : 3),
          (realistic ? 3.4 : 2.6) + Math.random() * 2.4,
          (Math.random() - 0.5) * (realistic ? 4.4 : 3),
        ).add(impulse),
        angVel: new THREE.Vector3(
          (Math.random() - 0.5) * (realistic ? 14 : 10),
          (Math.random() - 0.5) * (realistic ? 14 : 10),
          (Math.random() - 0.5) * (realistic ? 14 : 10),
        ),
        halfH,
      });
    });

    if (!parts.length) return;
    this.ragdolls.push({ parts, life: 6 });
  }

  private updateRagdolls(dt: number) {
    for (let i = this.ragdolls.length - 1; i >= 0; i--) {
      const rag = this.ragdolls[i];
      rag.life -= dt;
      const realistic = this.mods.has('ragdoll');
      for (const part of rag.parts) {
        part.vel.y -= (realistic ? 19 : 24) * dt;
        // 空气阻力（真实布娃娃会逐渐停下）
        if (realistic) part.vel.multiplyScalar(1 - Math.min(0.6, dt * 0.55));
        part.mesh.position.addScaledVector(part.vel, dt);
        part.mesh.rotation.x += part.angVel.x * dt;
        part.mesh.rotation.y += part.angVel.y * dt;
        part.mesh.rotation.z += part.angVel.z * dt;
        if (realistic) part.angVel.multiplyScalar(1 - Math.min(0.7, dt * 0.9));

        // Bounce on solid ground.
        const bx = Math.floor(part.mesh.position.x);
        const by = Math.floor(part.mesh.position.y - part.halfH);
        const bz = Math.floor(part.mesh.position.z);
        if (by >= 0 && getBlock(this.world.getBlock(bx, by, bz)).solid) {
          part.mesh.position.y = by + 1 + part.halfH;
          part.vel.y *= realistic ? -0.24 : -0.34;
          part.vel.x *= realistic ? 0.55 : 0.72;
          part.vel.z *= realistic ? 0.55 : 0.72;
          part.angVel.multiplyScalar(realistic ? 0.5 : 0.72);
        }

        // 真实布娃娃：侧向撞墙也会反弹
        if (realistic) {
          const sx = Math.floor(part.mesh.position.x + Math.sign(part.vel.x) * part.halfH);
          const sz = Math.floor(part.mesh.position.z + Math.sign(part.vel.z) * part.halfH);
          const sy = Math.floor(part.mesh.position.y);
          if (getBlock(this.world.getBlock(sx, sy, Math.floor(part.mesh.position.z))).solid) part.vel.x *= -0.4;
          if (getBlock(this.world.getBlock(Math.floor(part.mesh.position.x), sy, sz)).solid) part.vel.z *= -0.4;
        }

        if (rag.life < 1.4) part.mesh.scale.multiplyScalar(0.93);
      }
      // 真实布娃娃：关节牵引（部件之间互相拉扯，更像整具躯体）
      if (realistic && rag.parts.length > 1) {
        for (let k = 1; k < rag.parts.length; k++) {
          const a = rag.parts[k - 1];
          const b = rag.parts[k];
          const diff = b.mesh.position.clone().sub(a.mesh.position);
          const d = diff.length();
          const rest = 0.24;
          if (d > rest) {
            const pull = diff.multiplyScalar(((d - rest) / d) * Math.min(1, dt * 9));
            a.mesh.position.add(pull);
            b.mesh.position.sub(pull);
          }
        }
      }
      if (rag.life <= 0) {
        for (const part of rag.parts) {
          this.scene.remove(part.mesh);
          part.mesh.geometry.dispose();
          const mats = Array.isArray(part.mesh.material) ? part.mesh.material : [part.mesh.material];
          mats.forEach((m) => m.dispose());
        }
        this.ragdolls.splice(i, 1);
      }
    }
  }

  /* ------------------------------------------------ physics ---------- */

  private isSolidAt(x: number, y: number, z: number) {
    return getBlock(this.world.getBlock(Math.floor(x), Math.floor(y), Math.floor(z))).solid;
  }

  private collides(px: number, py: number, pz: number) {
    const minX = Math.floor(px - PLAYER_HALF);
    const maxX = Math.floor(px + PLAYER_HALF);
    const minY = Math.floor(py + 0.001);
    const maxY = Math.floor(py + PLAYER_HEIGHT - 0.001);
    const minZ = Math.floor(pz - PLAYER_HALF);
    const maxZ = Math.floor(pz + PLAYER_HALF);
    for (let x = minX; x <= maxX; x++) {
      for (let y = minY; y <= maxY; y++) {
        for (let z = minZ; z <= maxZ; z++) {
          if (this.isSolidAt(x, y, z)) return true;
        }
      }
    }
    return false;
  }

  private moveAxis(axis: 'x' | 'y' | 'z', amount: number) {
    if (amount === 0) return;
    const steps = Math.ceil(Math.abs(amount) / 0.2);
    const inc = amount / steps;
    for (let i = 0; i < steps; i++) {
      const prev = this.pos[axis];
      this.pos[axis] += inc;
      if (this.collides(this.pos.x, this.pos.y, this.pos.z)) {
        this.pos[axis] = prev;
        if (axis === 'y') {
          if (this.vel.y < 0) {
            this.onGround = true;
            if (this.mode === 'survival' && this.vel.y < -16) {
              const dmg = Math.floor((-this.vel.y - 16) / 2.2) + 1;
              this.damage(dmg);
            }
          }
          this.vel.y = 0;
        } else {
          this.vel[axis] = 0;
        }
        return;
      }
    }
  }

  damage(amount: number) {
    if (this.mode !== 'survival' || this.dead) return;
    this.health = Math.max(0, this.health - amount);
    sfx.hurt();
    if (this.health <= 0) {
      this.dead = true;
      this.opts.onToast('💀 你倒下了…');
    }
  }

  private updatePhysics(dt: number) {
    const eyeY = this.pos.y + EYE;
    const headBlock = this.world.getBlock(Math.floor(this.pos.x), Math.floor(eyeY), Math.floor(this.pos.z));
    const feetBlock = this.world.getBlock(Math.floor(this.pos.x), Math.floor(this.pos.y + 0.2), Math.floor(this.pos.z));
    const wasInWater = this.inWater;
    this.inWater = feetBlock === 11 || headBlock === 11;
    if (this.inWater && !wasInWater && this.vel.y < -6) sfx.splash();

    const inLava = feetBlock === 17;
    if (inLava) this.damage(dt * 3);
    const onCactus = feetBlock === 29 || headBlock === 29;
    if (onCactus) this.damage(dt * 1.4);

    // 下界传送门：脚下或头部踩进传送门方块就触发跨维度传送；冷却防止落地瞬间被立刻吸回去
    if (this.portalCooldown > 0) {
      this.portalCooldown = Math.max(0, this.portalCooldown - dt);
    } else if (feetBlock === 45 || headBlock === 45) {
      this.enterPortal();
    }

    // input direction
    let ix = 0;
    let iz = 0;
    if (!this.paused && !this.dead) {
      if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) iz -= 1;
      if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) iz += 1;
      if (this.keys.has('KeyA') || this.keys.has('ArrowLeft')) ix -= 1;
      if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) ix += 1;
      ix += this.touchMove.x;
      iz += this.touchMove.z;
    }
    const len = Math.hypot(ix, iz);
    if (len > 1) {
      ix /= len;
      iz /= len;
    }

    const sneaking = this.keys.has('ControlLeft') || this.keys.has('ShiftRight');
    const sprinting = (this.keys.has('ShiftLeft') || this.keys.has('KeyR')) && !sneaking;
    this.sprinting = sprinting;
    let speed = this.flying ? 11 : sprinting ? 6.6 : sneaking ? 2.0 : 4.7;
    if (this.mods.has('speed')) speed *= 1.4;
    if (this.inWater && !this.flying) speed *= 0.6;

    const forward = this.forwardVector(false);
    const right = new THREE.Vector3(forward.z, 0, -forward.x);
    const wish = new THREE.Vector3()
      .addScaledVector(forward, -iz)
      .addScaledVector(right, -ix);
    if (wish.lengthSq() > 0) wish.normalize();

    const targetVX = wish.x * speed;
    const targetVZ = wish.z * speed;
    // 真实物理：地面摩擦小、惯性大，空中几乎不损失动量
    const accel = this.mods.has('physics')
      ? this.onGround || this.flying
        ? 8
        : 2.2
      : this.onGround || this.flying
        ? 14
        : 6;
    this.vel.x += (targetVX - this.vel.x) * Math.min(1, accel * dt);
    this.vel.z += (targetVZ - this.vel.z) * Math.min(1, accel * dt);

    const jumpPressed = (!this.paused && !this.dead && (this.keys.has('Space') || this.touchJump));

    if (this.flying) {
      let vy = 0;
      if (jumpPressed) vy += 9;
      if (sneaking) vy -= 9;
      this.vel.y += (vy - this.vel.y) * Math.min(1, 12 * dt);
    } else if (this.inWater) {
      const targetY = jumpPressed ? 3.6 : sneaking ? -3.2 : -1.8;
      this.vel.y += (targetY - this.vel.y) * Math.min(1, 6 * dt);
      this.vel.y = Math.max(-6, Math.min(5, this.vel.y));
    } else {
      // 真实物理：更柔和的重力 + 抛物线感 + 二段跳支持
      const g = this.mods.has('physics') ? 21 : GRAVITY;
      this.vel.y -= g * dt;
      if (this.vel.y < -60) this.vel.y = -60;
      const wantJump = jumpPressed && !this.jumpHeld;
      this.jumpHeld = jumpPressed;
      if (this.onGround) this.airJumps = this.mods.has('doublejump') ? 1 : 0;
      if (wantJump && (this.onGround || this.airJumps > 0)) {
        if (!this.onGround) this.airJumps--;
        this.vel.y = this.mods.has('physics') ? 8.2 : JUMP_V;
        this.onGround = false;
        sfx.jump();
      }
    }

    this.onGround = false;
    this.moveAxis('x', this.vel.x * dt);
    this.moveAxis('z', this.vel.z * dt);
    this.moveAxis('y', this.vel.y * dt);

    // 落地扬尘：从空中落地时脚下冒尘，落地感更实
    if (this.onGround && !this.wasOnGround) {
      const below = this.world.getBlock(
        Math.floor(this.pos.x),
        Math.floor(this.pos.y - 0.2),
        Math.floor(this.pos.z),
      );
      if (below !== AIR) {
        const dustColor =
          below === 5 ? 0xf6e3a6 : below === 12 ? 0xf7fbff : below === 1 ? 0x8a6a45 : 0xbfbfc8;
        this.spawnDust(this.pos.x, this.pos.y + 0.06, this.pos.z, dustColor, 9, 1.1);
      }
    }
    this.wasOnGround = this.onGround;

    if (this.pos.y < -12) {
      if (this.mode === 'survival') this.damage(20);
      else {
        this.pos.y = WORLD_HEIGHT - 10;
        this.vel.y = 0;
      }
    }

    // footsteps
    const horizontal = Math.hypot(this.vel.x, this.vel.z);
    if (this.onGround && horizontal > 1.5) {
      this.stepTimer -= dt * horizontal;
      this.bob += dt * horizontal * 1.7;
      if (this.stepTimer <= 0) {
        sfx.step();
        this.stepTimer = 2.4;
      }
    } else {
      this.bob *= 1 - Math.min(1, dt * 6);
    }

    // survival stats
    if (this.mode === 'survival' && !this.dead) {
      const hungerMul = this.mods.has('nohunger') ? 0 : this.mods.has('regen') ? 0.5 : 1;
      this.hunger = Math.max(0, this.hunger - dt * (sprinting && horizontal > 2 ? 0.06 : 0.02) * hungerMul);
      const regenRate = this.mods.has('regen') ? 1.2 : 0.4;
      if (this.hunger > 16 && this.health < 20) this.health = Math.min(20, this.health + dt * regenRate);
      if (this.hunger <= 0) this.damage(dt * 0.4);
      const headInWater = headBlock === 11;
      if (headInWater) {
        this.air = Math.max(0, this.air - dt / 14);
        if (this.air <= 0) this.damage(dt * 2);
      } else this.air = Math.min(1, this.air + dt / 3);
    } else {
      this.air = 1;
    }
  }

  /* ------------------------------------------------ chunks ----------- */

  private updateChunks() {
    const pcx = Math.floor(this.pos.x / CHUNK_SIZE);
    const pcz = Math.floor(this.pos.z / CHUNK_SIZE);
    const key = `${pcx},${pcz},${this.renderDistance}`;
    if (key !== this.lastChunkKey) {
      this.lastChunkKey = key;
      const list: { cx: number; cz: number; d: number }[] = [];
      const r = this.renderDistance;
      for (let dx = -r; dx <= r; dx++) {
        for (let dz = -r; dz <= r; dz++) {
          const d = Math.hypot(dx, dz);
          if (d > r + 0.4) continue;
          list.push({ cx: pcx + dx, cz: pcz + dz, d });
        }
      }
      list.sort((a, b) => a.d - b.d);
      // Reverse the list so pop() returns the nearest chunk without O(n) shifts.
      this.chunkQueue = list.map(({ cx, cz }) => ({ cx, cz })).reverse();
      this.chunkQueueTotal = this.chunkQueue.length;
      // unload far chunks
      for (const chunk of [...this.world.chunks.values()]) {
        if (Math.hypot(chunk.cx - pcx, chunk.cz - pcz) > r + 2.5) this.world.disposeChunk(chunk);
      }
    }

    // Time-sliced generation + meshing: each frame does a small slice of work so
    // no single chunk build ever blocks a frame (this kills the "sudden hitch").
    const budget = this.loading < 1 ? 14 : 5;
    const t0 = performance.now();
    const remaining = () => Math.max(1, budget - (performance.now() - t0));
    while (this.chunkQueue.length && performance.now() - t0 < budget) {
      const front = this.chunkQueue[this.chunkQueue.length - 1];
      let chunk = this.world.getChunk(front.cx, front.cz);
      if (!chunk) chunk = this.world.createChunk(front.cx, front.cz);
      if (!chunk.generated) {
        if (!this.world.generateSlice(chunk, remaining())) break;
        continue;
      }
      // CRITICAL: face culling + AO read neighbour blocks, so the 4 neighbours
      // MUST be generated (data only) before meshing — otherwise chunk borders
      // get duplicate coplanar faces / z-fighting seams and bright AO edges.
      let neighborPending = false;
      for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nc = this.world.getChunk(front.cx + dx, front.cz + dz);
        const target = nc ?? this.world.createChunk(front.cx + dx, front.cz + dz);
        if (!target.generated && !this.world.generateSlice(target, remaining())) {
          neighborPending = true;
        }
      }
      if (neighborPending) break; // defer meshing until all borders are solid
      if (chunk.dirty || !chunk.meshed) {
        if (!this.world.buildChunkMeshSlice(chunk, remaining())) break;
      }
      this.chunkQueue.pop();
    }
    this.loading = this.chunkQueueTotal
      ? Math.min(1, 1 - this.chunkQueue.length / this.chunkQueueTotal)
      : 1;

    // Rebuild at most one edited nearby chunk per frame, also time-sliced.
    for (const chunk of this.world.chunks.values()) {
      if (chunk.generated && chunk.dirty && Math.hypot(chunk.cx - pcx, chunk.cz - pcz) <= 2) {
        this.world.buildChunkMeshSlice(chunk, 4);
        break;
      }
    }
  }

  /* ------------------------------------------------ sky -------------- */

  // 常驻临时对象：天空每帧都要算，避免每帧 new 出十几个对象触发 GC 卡顿
  private skyScratch = {
    sunDir: new THREE.Vector3(),
    day: new THREE.Color(0x8fd3ff),
    night: new THREE.Color(0x0d1533),
    dusk: new THREE.Color(0xff9e6b),
    sky: new THREE.Color(),
    warm: new THREE.Color(0xffb46b),
    white: new THREE.Color(0xffffff),
    horror: new THREE.Color(0xff4d4d),
    hemiTarget: new THREE.Color(),
  };

  /** 天穹调色板（常驻，避免每帧分配） */
  private skyPalette = {
    nightTop: new THREE.Color(0x050a1e),
    nightMid: new THREE.Color(0x0d1533),
    duskTop: new THREE.Color(0x2a4a8c),
    duskMid: new THREE.Color(0xff9e6b),
    dayTop: new THREE.Color(0x2f7fe0),
    dayMid: new THREE.Color(0x8fd3ff),
    horizon: new THREE.Color(0xffe0b0),
  };

  private updateSky(dt: number) {
    if (this.dayNight && !this.paused) this.timeOfDay = (this.timeOfDay + dt * this.daySpeed) % 1;
    const t = this.timeOfDay;
    const angle = (t - 0.25) * Math.PI * 2;
    const S = this.skyScratch;
    const sunDir = S.sunDir.set(Math.cos(angle), Math.sin(angle), 0.35).normalize();
    const dayAmount = Math.max(0, Math.min(1, sunDir.y * 2.2 + 0.35));
    const duskAmount = Math.max(0, 1 - Math.abs(sunDir.y) * 5);

    const sky = S.sky.copy(S.night).lerp(S.day, dayAmount).lerp(S.dusk, duskAmount * 0.55);
    this.renderer.setClearColor(sky);
    (this.scene.fog as THREE.FogExp2).color.copy(sky);
    this.scene.background = sky;

    // 高清光影：更暖的阳光、更强对比、体积感雾（每帧都以基准值重新计算，不再逐帧复合）
    let effectiveFogFar = this.baseFogFar;
    let fogDensityMul = 1;
    if (this.mods.has('hdshader')) {
      this.sun.color.lerp(S.warm, 0.45);
      fogDensityMul *= 1.43; // 原来是把 near 拉近到 0.7 倍，等效于雾更浓一点
    }
    // 光线追踪：更远的可视距离（配合逐顶点射线遮蔽）
    if (this.mods.has('raytracing')) {
      effectiveFogFar *= 1.35;
    }
    (this.scene.fog as THREE.FogExp2).density = this.fogDensityFor(effectiveFogFar) * fogDensityMul;

    // 夜视模组 / 恐怖模组：调整夜晚光照
    const nightBoost = this.mods.has('nightvision') ? 0.55 : 0;
    const horrorDim = this.mods.has('horror') && !dayAmount ? 0.45 : 0;
    this.hemi.intensity = Math.max(0.08, 0.17 + dayAmount * 1.05 + nightBoost - horrorDim);
    if (this.mods.has('horror') && !dayAmount) {
      this.hemi.color.copy(S.horror);
    } else {
      this.hemi.color.copy(S.hemiTarget.copy(sky).lerp(S.white, 0.35));
    }
    if (this.mods.has('horror') && !dayAmount) {
      (this.scene.fog as THREE.FogExp2).color.setHex(0x2a0808);
      (this.scene.fog as THREE.FogExp2).density = Math.max(
        (this.scene.fog as THREE.FogExp2).density,
        this.fogDensityFor(42),
      );
    }
    this.sun.intensity = 0.2 + dayAmount * 1.9;
    this.sun.color.setHSL(0.11, 0.55, 0.58 + dayAmount * 0.25);
    this.sun.position.copy(this.pos).addScaledVector(sunDir, 120);
    this.sun.target.position.copy(this.pos);

    // 补光始终待在太阳的反方向（背光面），强度跟随昼夜微调，
    // 夜里几乎不需要（月光本来就暗，不需要额外补），白天稍微明显一点
    this.fillLight.position.copy(this.pos).addScaledVector(sunDir, -80);
    this.fillLight.target.position.copy(this.pos);
    this.fillLight.intensity = 0.12 + dayAmount * 0.24;
    this.fillLight.target.updateMatrixWorld();

    // 天穹颜色跟随昼夜：夜空深蓝、黄昏橙红、正午清亮（全部复用常驻对象）
    const skyUniforms = (this.skyDome.material as THREE.ShaderMaterial).uniforms;
    const P = this.skyPalette;
    (skyUniforms.uTop.value as THREE.Color).copy(P.nightTop).lerp(P.dayTop, dayAmount).lerp(P.duskTop, duskAmount * 0.7);
    (skyUniforms.uMid.value as THREE.Color).copy(P.nightMid).lerp(P.dayMid, dayAmount).lerp(P.duskMid, duskAmount * 0.6);
    (skyUniforms.uBottom.value as THREE.Color).copy(sky).lerp(P.horizon, duskAmount * 0.4);
    (skyUniforms.uSunDir.value as THREE.Vector3).copy(sunDir);
    (skyUniforms.uSunColor.value as THREE.Color).setHex(0xfff0c0).multiplyScalar(0.25 + dayAmount * 0.95);
    this.skyDome.position.copy(this.camera.position);
    // 阴影相机跟随玩家
    this.sun.target.position.copy(this.pos);
    this.sun.target.updateMatrixWorld();

    this.sunSprite.position.copy(this.camera.position).addScaledVector(sunDir, 420);
    this.moonSprite.position.copy(this.camera.position).addScaledVector(sunDir, -420);
    (this.sunSprite.material as THREE.SpriteMaterial).opacity = Math.max(0, sunDir.y * 3);
    (this.moonSprite.material as THREE.SpriteMaterial).opacity = Math.max(0, -sunDir.y * 3);

    // 方块云缓慢往一个方向飘（wind drift），同时跟随玩家水平位置，
    // 让云层看起来始终"在附近"而不会飘到很远的地方看不见
    this.cloudDriftX += dt * 0.7;
    this.clouds.position.x = this.pos.x + this.cloudDriftX;
    this.clouds.position.z = this.pos.z;
    (this.clouds.material as THREE.MeshLambertMaterial).opacity = 0.55 + dayAmount * 0.37;

    // 下界氛围覆盖：上面这一整套是主世界的昼夜/天空逻辑，每帧照常跑一遍无所谓
    // （反正马上就被这里的固定值覆盖掉），这样不用去改上面那一大坨逻辑本身，风险更低。
    if (this.dimension === 'nether') {
      const netherFog = 0x2b0906;
      this.renderer.setClearColor(netherFog);
      (this.scene.fog as THREE.FogExp2).color.setHex(netherFog);
      this.scene.background = new THREE.Color(netherFog);
      (this.scene.fog as THREE.FogExp2).density = this.fogDensityFor(Math.min(this.baseFogFar, 46)); // 下界能见度短一些，更压抑
      this.hemi.intensity = 0.55;
      this.hemi.color.setHex(0xff6a3c);
      this.hemi.groundColor.setHex(0x1a0503);
      this.sun.intensity = 0; // 下界没有太阳，光照全靠上面这层半球光 + 熔岩/荧光石自发光
      this.fillLight.intensity = 0;
      (this.sunSprite.material as THREE.SpriteMaterial).opacity = 0;
      (this.moonSprite.material as THREE.SpriteMaterial).opacity = 0;
      (this.clouds.material as THREE.MeshLambertMaterial).opacity = 0;
      (skyUniforms.uTop.value as THREE.Color).setHex(0x1a0503);
      (skyUniforms.uMid.value as THREE.Color).setHex(0x3a0f08);
      (skyUniforms.uBottom.value as THREE.Color).setHex(netherFog);
      (skyUniforms.uSunColor.value as THREE.Color).setHex(0x000000);
    }
  }

  /* ------------------------------------------------ loop ------------- */

  private loop = () => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const dt = Math.min(0.05, this.clock.getDelta());

    if (!this.paused) {
      this.updatePhysics(dt);
      this.placeCooldown = Math.max(0, this.placeCooldown - dt);
      this.updateTarget();
      this.updateBreaking(dt);
      if (this.placing && this.placeCooldown <= 0) this.tryPlace();
      this.updateParticles(dt);
      this.tickTNT(dt);
      this.updateMobs(dt);
      this.updateDrops(dt);
      this.shootCooldown = Math.max(0, this.shootCooldown - dt);
      // 曳光弹淡出
      for (let i = this.tracers.length - 1; i >= 0; i--) {
        const t = this.tracers[i];
        t.life -= dt;
        (t.line.material as THREE.LineBasicMaterial).opacity = Math.max(0, t.life / 0.09);
        if (t.life <= 0) {
          this.scene.remove(t.line);
          t.line.geometry.dispose();
          (t.line.material as THREE.Material).dispose();
          this.tracers.splice(i, 1);
        }
      }
      this.updateRain(dt);
      this.updateRadar(dt);
      this.updateSurvival(dt);
      this.updateLightProbes(dt);
      this.eatTimer = Math.max(0, this.eatTimer - dt);
    }
    this.updateChunks();
    this.updateSky(dt);

    // camera
    const bobY = Math.sin(this.bob * 2) * 0.045;
    const bobX = Math.cos(this.bob) * 0.035;
    const eyeX = this.pos.x + bobX * 0.5;
    const eyeY = this.pos.y + EYE + bobY;
    const eyeZ = this.pos.z;
    this.camera.rotation.set(this.pitch, this.yaw, 0, 'YXZ');
    if (this.cameraMode === 0) {
      this.camera.position.set(eyeX, eyeY, eyeZ);
    } else {
      const sign = this.cameraMode === 1 ? -1 : 1;
      const dir = this.forwardVector(true).multiplyScalar(sign);
      const eye = new THREE.Vector3(eyeX, eyeY, eyeZ);
      let dist = 4.2;
      const hit = this.world.raycast(eye, dir, 4.6);
      if (hit) dist = Math.max(0.5, hit.distance - 0.4);
      this.camera.position.copy(eye).addScaledVector(dir, dist);
      if (this.cameraMode === 2) this.camera.rotation.set(-this.pitch, this.yaw + Math.PI, 0, 'YXZ');
    }
    this.updateAvatar(dt, bobY);
    const speedNow = Math.hypot(this.vel.x, this.vel.z);
    const targetFov = this.sprinting && speedNow > 2.5 ? 80 : this.flying && speedNow > 2.5 ? 78 : 72;
    if (Math.abs(this.camera.fov - targetFov) > 0.05) {
      this.camera.fov += (targetFov - this.camera.fov) * Math.min(1, dt * 6);
      this.camera.updateProjectionMatrix();
    }

    // hand animation
    if (this.swing > 0) {
      this.swing += dt * 4.2;
      if (this.swing >= 1) this.swing = 0;
    }
    {
      const s = this.swing > 0 ? Math.sin(this.swing * Math.PI) : 0;
      // 走路时手臂自然摆动 + 挖掘时大幅挥动
      const walkBob = Math.sin(this.bob * 2) * 0.012 * Math.min(1, Math.hypot(this.vel.x, this.vel.z) / 4);
      this.handGroup.position.set(
        0.5 - s * 0.18 + walkBob,
        -0.42 - s * 0.2 + bobY * 0.7 - walkBob * 0.6,
        -0.7 + s * 0.14,
      );
      this.handGroup.rotation.set(-s * 1.1, s * 0.3, s * 0.18);
      if (this.handArm) {
        this.handArm.rotation.x = -s * 0.5;
        this.handArm.rotation.z = s * 0.25;
      }
      if (this.handMesh) {
        const brk = this.breakProgress;
        this.handMesh.scale.setScalar(0.3 - brk * 0.02);
      }
    }

    // 破坏裂纹：贴合正在挖掘的方块，按进度换 8 级裂纹贴图
    if (this.target && this.breakProgress > 0.02) {
      const stage = Math.min(this.crackTextures.length - 1, Math.floor(this.breakProgress * this.crackTextures.length));
      if (stage !== this.crackStage) {
        this.crackStage = stage;
        (this.crackMesh.material as THREE.MeshBasicMaterial).map = this.crackTextures[stage];
        (this.crackMesh.material as THREE.MeshBasicMaterial).needsUpdate = true;
      }
      this.crackMesh.position.set(this.target.x + 0.5, this.target.y + 0.5, this.target.z + 0.5);
      this.crackMesh.visible = true;
    } else {
      this.crackMesh.visible = false;
      this.crackStage = -1;
    }

    // underwater fog tint
    if (this.inWater) {
      (this.scene.fog as THREE.FogExp2).color.setHex(0x2a6f9e);
      (this.scene.fog as THREE.FogExp2).density = this.fogDensityFor(26);
      this.scene.background = new THREE.Color(0x2a6f9e);
    } else {
      (this.scene.fog as THREE.FogExp2).density = this.fogDensityFor(this.renderDistance * CHUNK_SIZE * 0.95);
    }

    // 手持发光物（火把/荧光石/水晶/彩虹）始终提供动态光源，不再受时间限制
    const heldId = this.inventory[this.selected]?.id ?? 0;
    const holdingGlow = heldId === 30 || heldId === 13 || heldId === 15 || heldId === 18;
    // 注意：这个点光源离手持物体本身很近（同样挂在摄像机下）。之前用 1.4 的强度会在
    // 物理正确的平方反比衰减下把手上的物品直接曝成一片死白/巨大辉光。
    // 手持物品自身的发光感改由 updateHandBlock() 里的自发光材质负责，这里只需要
    // 一个柔和很多的强度，用来把周围场景（脚下、面前的方块）照亮就够了。
    this.torchLight.intensity = holdingGlow ? 0.85 : 0;

    if (
      (this.bloomEnabled ||
        this.ssrEnabled ||
        this.ssaoEnabled ||
        this.godrayEnabled ||
        this.dofEnabled ||
        this.motionBlurEnabled) &&
      this.composer
    ) {
      try {
        if (this.ssrEnabled) this.refreshSSRSelects();

        if (this.dofEnabled && this.dofPass) {
          // 准星瞄准的方块就是对焦点；没瞄到东西（看着天空/远处）就对焦到一个较远的距离，
          // 免得镜头一直往近处收缩显得很怪
          const focusDist = this.target
            ? Math.hypot(
                this.target.x + 0.5 - this.pos.x,
                this.target.y + 0.5 - (this.pos.y + EYE),
                this.target.z + 0.5 - this.pos.z,
              )
            : 22;
          const targetFocus = THREE.MathUtils.clamp(focusDist, 1.5, 60);
          // 对焦距离平滑过渡，不要一帧之内从"贴脸的近处"跳到"很远的地平线"——
          // 突然的大幅虚化切换，加上画面里正好有太阳/荧光石这类亮光源时，
          // 会有一下子"糊成一大片很亮"的观感，跟真实相机忽然甩焦的感觉类似。
          const smoothing = 1 - Math.pow(0.001, dt);
          this.dofFocusSmoothed += (targetFocus - this.dofFocusSmoothed) * smoothing;
          this.dofPass.uniforms.focus.value = this.dofFocusSmoothed;
        }

        if (this.motionBlurEnabled && this.motionBlurPass) {
          // 这一帧转了多少角度，换算成屏幕空间的一个方向向量（水平/垂直分开算，
          // 幅度做了限制，避免瞬间大角度甩头把画面拖成一坨）
          let dYaw = this.yaw - this.prevYawForBlur;
          while (dYaw > Math.PI) dYaw -= Math.PI * 2;
          while (dYaw < -Math.PI) dYaw += Math.PI * 2;
          const dPitch = this.pitch - this.prevPitchForBlur;
          this.prevYawForBlur = this.yaw;
          this.prevPitchForBlur = this.pitch;
          const kx = THREE.MathUtils.clamp(dYaw * 1.4, -0.05, 0.05);
          const ky = THREE.MathUtils.clamp(dPitch * 1.4, -0.05, 0.05);
          (this.motionBlurPass.uniforms.uDir.value as THREE.Vector2).set(kx, ky);
        }

        if (this.ssaoEnabled && this.ssaoPass && this.ssaoRawTarget && this.ssaoDummyTarget) {
          // 把这一帧的灰度遮蔽图渲染进 ssaoRawTarget，aoApplyPass 会在 composer 链里读它。
          // dummyTarget 只是占位满足 readBuffer 参数，OUTPUT.SSAO 模式下不会真的采样它。
          this.ssaoPass.render(this.renderer, this.ssaoRawTarget, this.ssaoDummyTarget, dt, false);
        }

        if (this.godrayEnabled && this.godrayMaskTarget && this.godrayBlurTarget && this.godrayBlurPass && this.godrayMixPass) {
          // 太阳精灵在相机背后就没有"丁达尔"这回事，顺手用来在太阳快移出屏幕边缘时
          // 把强度拉回 0，避免径向采样在越界的 UV 上抽风
          const sunPos = this.sunSprite.position;
          const camSpace = sunPos.clone().applyMatrix4(this.camera.matrixWorldInverse);
          if (camSpace.z > 0) {
            this.godrayIntensity = 0;
          } else {
            const ndc = sunPos.clone().project(this.camera);
            this.godraySunUV.set(ndc.x * 0.5 + 0.5, ndc.y * 0.5 + 0.5);
            const edgeFade = THREE.MathUtils.clamp(1 - Math.max(Math.abs(ndc.x), Math.abs(ndc.y)), 0, 1);
            const dayFade = Math.max(0, Math.min(1, (this.sunSprite.material as THREE.SpriteMaterial).opacity));
            this.godrayIntensity = edgeFade * dayFade;
          }

          if (this.godrayIntensity > 0.005) {
            // 遮罩通道：把整个场景涂黑，只留下太阳精灵（靠深度测试自然被地形/树冠遮挡），
            // 月亮和雨滴这些跟"阳光"无关的东西也顺手临时隐藏，免得污染这张遮罩。
            // try/finally 保证就算中间渲染报错，材质/可见性也一定会恢复原样——
            // 不然一旦哪帧异常，方块材质会永久卡在"涂黑"状态出不来。
            this.scene.traverse((o) => this.darkenExcept(o, this.sunLayers));
            const prevMoonVisible = this.moonSprite.visible;
            const prevRainVisible = this.rainParticles?.visible ?? false;
            const prevClear = new THREE.Color();
            this.renderer.getClearColor(prevClear);
            const prevAlpha = this.renderer.getClearAlpha();
            try {
              this.moonSprite.visible = false;
              if (this.rainParticles) this.rainParticles.visible = false;
              this.renderer.setClearColor(0x000000, 1);
              this.renderer.setRenderTarget(this.godrayMaskTarget);
              this.renderer.clear();
              this.renderer.render(this.scene, this.camera);
            } finally {
              this.renderer.setRenderTarget(null);
              this.renderer.setClearColor(prevClear, prevAlpha);
              this.moonSprite.visible = prevMoonVisible;
              if (this.rainParticles) this.rainParticles.visible = prevRainVisible;
              this.scene.traverse((o) => this.restoreDarkened(o));
            }

            // 径向模糊：以太阳屏幕坐标为中心往外扩散采样，产出光柱纹理
            this.godrayBlurPass.render(this.renderer, this.godrayBlurTarget, this.godrayMaskTarget, dt, false);
          }
          this.godrayMixPass.uniforms.uIntensity.value = this.godrayIntensity;
        }

        if (this.bloomEnabled && this.bloomComposer) {
          // selective bloom 第一遍：把不发光的东西全部涂黑，只画出发光层
          this.scene.traverse((o) => this.darkenExcept(o, this.bloomLayers));
          try {
            this.bloomComposer.render();
          } finally {
            this.scene.traverse((o) => this.restoreDarkened(o));
          }
        }
        this.composer.render();
      } catch (err) {
        // 渲染期间出错也不让游戏黑屏/崩溃：立即关闭特效，回退普通渲染
        console.warn('后处理渲染出错，已关闭泛光/反射/遮蔽/体积光/景深/动态模糊效果', err);
        this.bloomEnabled = false;
        this.ssrEnabled = false;
        this.ssaoEnabled = false;
        this.godrayEnabled = false;
        this.dofEnabled = false;
        this.motionBlurEnabled = false;
        if (this.godrayMixPass) this.godrayMixPass.enabled = false;
        if (this.dofPass) this.dofPass.enabled = false;
        if (this.motionBlurPass) this.motionBlurPass.enabled = false;
        this.renderer.render(this.scene, this.camera);
      }
    } else {
      this.renderer.render(this.scene, this.camera);
    }

    // hud state
    this.fpsAcc += dt;
    this.fpsCount++;
    this.stateTimer += dt;
    if (this.stateTimer > 0.16) {
      this.fps = this.fpsCount / Math.max(0.0001, this.fpsAcc);
      this.fpsAcc = 0;
      this.fpsCount = 0;
      this.stateTimer = 0;
      const boss = this.mobs.find((mob) => mob.def.boss && mob.hp > 0 && mob.pos.distanceTo(this.pos) < 30);
      this.opts.onState({
        fps: Math.round(this.fps),
        x: this.pos.x,
        y: this.pos.y,
        z: this.pos.z,
        mode: this.mode,
        health: this.health,
        hunger: this.hunger,
        air: this.air,
        timeOfDay: this.timeOfDay,
        biome: this.world.biome(Math.floor(this.pos.x), Math.floor(this.pos.z)),
        chunks: this.world.chunks.size,
        flying: this.flying,
        inWater: this.inWater,
        breakProgress: this.breakProgress,
        targetName: this.target ? getBlock(this.target.id).name : null,
        loading: this.loading,
        dead: this.dead,
        mobCount: this.mobs.length,
        hostileCount: this.mobs.filter((mob) => !mob.def.friendly).length,
        bossName: boss?.def.name ?? null,
        bossHealth: boss?.hp ?? 0,
        bossMaxHealth: boss?.maxHp ?? 0,
        quests: this.questViews(),
        wave: this.wave,
        waveMode: this.waveMode,
        activeMods: [...this.mods],
        raining: this.raining,
        ammo: this.inventory.reduce((sum, s) => sum + (s && isAmmo(s.id) ? s.count : 0), 0),
        stamina: this.stamina,
        thirst: this.thirst,
        temp: this.temp,
        day: this.day,
        fear: this.fear,
        glitch: this.glitch,
      });
    }
  };

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    document.removeEventListener('mousemove', this.onMouseMove);
    document.removeEventListener('pointerlockchange', this.onPointerLockChange);
    this.canvas.removeEventListener('mousedown', this.onMouseDown);
    window.removeEventListener('mouseup', this.onMouseUp);
    window.removeEventListener('resize', this.onResize);
    this.mobs.forEach((mob) => {
      this.scene.remove(mob.group);
      mob.dispose();
    });
    this.mobs = [];
    this.tntEntities.forEach((entity) => {
      this.scene.remove(entity.mesh);
      entity.mesh.geometry.dispose();
      (entity.mesh.material as THREE.Material).dispose();
    });
    this.tntEntities = [];
    for (const drop of this.drops) {
      this.scene.remove(drop.mesh);
      drop.mesh.geometry.dispose();
      (drop.mesh.material as THREE.Material).dispose();
    }
    this.drops = [];
    for (const rag of this.ragdolls) {
      for (const part of rag.parts) {
        this.scene.remove(part.mesh);
        part.mesh.geometry.dispose();
        const mats = Array.isArray(part.mesh.material) ? part.mesh.material : [part.mesh.material];
        mats.forEach((m) => m.dispose());
      }
    }
    this.ragdolls = [];
    // 两个维度都可能残留已生成的区块网格（哪怕当前站在另一边），都要清理掉显存
    const worldsToDispose = this.nether && this.nether !== this.overworld
      ? [this.overworld, this.nether]
      : [this.overworld];
    for (const w of worldsToDispose) {
      for (const chunk of [...w.chunks.values()]) w.disposeChunk(chunk);
    }
    this.renderer.dispose();
  }
}

export const BLOCK_LIST = BLOCKS;
