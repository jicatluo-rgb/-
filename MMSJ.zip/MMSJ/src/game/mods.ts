/** 玩法模组：20 个玩法模组 + 1 个真实物理模组 */

export type ModCategory = 'combat' | 'explore' | 'build' | 'fun' | 'horror' | 'visual' | 'system';

export interface ModDef {
  id: string;
  name: string;
  emoji: string;
  desc: string;
  price: number;
  category: ModCategory;
  /** 是否默认开启（免费） */
  free?: boolean;
}

export const MOD_CATEGORIES: { id: ModCategory; name: string }[] = [
  { id: 'combat', name: '战斗' },
  { id: 'explore', name: '探索' },
  { id: 'build', name: '建造' },
  { id: 'fun', name: '趣味' },
  { id: 'horror', name: '恐怖' },
  { id: 'visual', name: '画质' },
  { id: 'system', name: '系统' },
];

export const MODS: ModDef[] = [
  /* ---- 战斗 ---- */
  {
    id: 'guns',
    name: '枪械模组',
    emoji: '🔫',
    desc: '合成枪管与击发器，制作木枪/步枪/水晶炮，三种子弹不同伤害与穿透',
    price: 320,
    category: 'combat',
  },
  { id: 'horror', name: '恐怖模组', emoji: '👻', desc: '血月之夜、浓雾低语，亡灵成群且更凶猛', price: 260, category: 'combat' },
  { id: 'bossrush', name: 'Boss 突袭', emoji: '💀', desc: 'Boss 频繁现身，讨伐奖励翻倍', price: 300, category: 'combat' },
  { id: 'petdragon', name: '飞龙伙伴', emoji: '🐉', desc: '开局获得一只驯服的小飞龙，帮你打怪', price: 280, category: 'combat' },
  { id: 'tame', name: '驯兽大师', emoji: '🦴', desc: '任意食物都能驯服任意生物，宠物更勇猛', price: 200, category: 'combat' },
  { id: 'swordmaster', name: '剑术精通', emoji: '🗡️', desc: '近战伤害 +60%，攻击附带击退', price: 180, category: 'combat' },

  /* ---- 探索 ---- */
  { id: 'nightvision', name: '夜视模组', emoji: '👁️', desc: '黑夜与洞穴永远清晰可见', price: 150, category: 'explore' },
  { id: 'radar', name: '探矿雷达', emoji: '📡', desc: '附近的宝石矿会发出光点提示', price: 190, category: 'explore' },
  { id: 'magnet', name: '磁铁背包', emoji: '🧲', desc: '拾取范围扩大到 3 倍', price: 120, category: 'explore' },
  { id: 'doublejump', name: '二段跳', emoji: '🦘', desc: '空中还能再跳一次', price: 140, category: 'explore' },
  { id: 'speed', name: '疾跑强化', emoji: '💨', desc: '移动速度 +40%', price: 130, category: 'explore' },
  { id: 'doubleloot', name: '战利品大师', emoji: '🎁', desc: '宝箱与掉落物数量翻倍', price: 210, category: 'explore' },
  { id: 'regen', name: '生命回复强化', emoji: '❤️‍🩹', desc: '回血速度 x3，饥饿下降减半', price: 170, category: 'explore' },
  { id: 'nohunger', name: '无限饱食', emoji: '🍗', desc: '永不饥饿，专心冒险', price: 160, category: 'explore' },

  /* ---- 建造 ---- */
  { id: 'fastmine', name: '极速挖矿', emoji: '⛏️', desc: '挖掘速度 x3', price: 140, category: 'build' },
  { id: 'wallbuild', name: '建筑师之手', emoji: '🧱', desc: '一次放置 3 格墙面', price: 220, category: 'build' },
  { id: 'bigexplosion', name: '爆破专家', emoji: '💥', desc: 'TNT 爆炸范围 x1.8', price: 200, category: 'build' },
  { id: 'flight', name: '自由飞行', emoji: '🪽', desc: '生存模式也能双击空格飞行', price: 250, category: 'build' },

  /* ---- 趣味 ---- */
  { id: 'rain', name: '天气系统', emoji: '🌧️', desc: '随机降雨，雨夜更危险也更有氛围', price: 110, category: 'fun' },
  { id: 'timecontrol', name: '时间掌控', emoji: '🕰️', desc: '按 T 随时切换白天黑夜', price: 180, category: 'fun' },

  /* ---- 恐怖（真实玩法，不是换皮） ---- */
  {
    id: 'knocker',
    name: '敲门人',
    emoji: '🚪',
    desc: '深夜会听见敲门声与脚步，回头看时它就在身后。恐惧值满时它会现身',
    price: 380,
    category: 'horror',
  },
  {
    id: 'rainhorror',
    name: '小心雨',
    emoji: '🌧️',
    desc: '下雨时刷新雨夜怨灵与湿骨行尸，视野骤降、雨水变浑浊，撑到雨停',
    price: 360,
    category: 'horror',
  },
  {
    id: 'brokenscript',
    name: '破碎的剧本',
    emoji: '📼',
    desc: '世界开始出错：区块闪烁、方块错位、字幕乱码，剧本正在崩坏',
    price: 340,
    category: 'horror',
  },
  {
    id: 'unknown',
    name: '未知生物',
    emoji: '❓',
    desc: '影袭者、拟态宝箱怪、虚空爬行者等未记录生物出现在世界里',
    price: 320,
    category: 'horror',
  },
  {
    id: 'hundredDays',
    name: '惊变 100 天',
    emoji: '📅',
    desc: '生存 100 天：每天怪物更强更快，第 25/50/100 天有突变事件',
    price: 400,
    category: 'horror',
  },

  /* ---- 画质 ---- */
  {
    id: 'hdtexture',
    name: '高清修复材质包',
    emoji: '🖼️',
    desc: '材质分辨率翻倍，重绘噪点与边缘细节，方块更有质感',
    price: 300,
    category: 'visual',
  },
  {
    id: 'hdshader',
    name: '高清光影',
    emoji: '✨',
    desc: '柔和阴影、体积雾、暖色阳光与暗角调色，画面更电影化',
    price: 350,
    category: 'visual',
  },
  {
    id: 'raytracing',
    name: '光线追踪',
    emoji: '🔦',
    desc: '逐顶点射线求天空遮蔽与软阴影，水面反射天光，真实光照',
    price: 420,
    category: 'visual',
  },

  /* ---- 系统 ---- */
  {
    id: 'ragdoll',
    name: '真实的布娃娃',
    emoji: '🪆',
    desc: '生物死亡后变成带关节的布娃娃，翻滚、弹跳、逐步停下',
    price: 260,
    category: 'system',
  },
  {
    id: 'physics',
    name: '真实物理模组',
    emoji: '🌍',
    desc: '真实重力与惯性：跳跃抛物线、动量保留、坠落伤害更真实',
    price: 240,
    category: 'system',
  },
];

export function getMod(id: string): ModDef | undefined {
  return MODS.find((m) => m.id === id);
}
