// Block registry. Faces order: [+X, -X, +Y, -Y, +Z, -Z]

export const TILE_NAMES = [
  'grass_top', // 0
  'grass_side', // 1
  'dirt', // 2
  'stone', // 3
  'cobble', // 4
  'sand', // 5
  'log_side', // 6
  'log_top', // 7
  'leaves', // 8
  'planks', // 9
  'glass', // 10
  'brick', // 11
  'water', // 12
  'snow_top', // 13
  'snow_side', // 14
  'glow', // 15
  'candy', // 16
  'crystal', // 17
  'bedrock', // 18
  'lava', // 19
  'rainbow', // 20
  'cloud', // 21
  'tnt_side', // 22
  'tnt_top', // 23
  'gem_ore', // 24
  'flower_red', // 25
  'flower_blue', // 26
  'tallgrass', // 27
  'mushroom', // 28
  'pumpkin_side', // 29
  'pumpkin_top', // 30
  'ice', // 31
  'chest_side', // 32
  'chest_top', // 33
  'cactus_side', // 34
  'cactus_top', // 35
  'torch', // 36
  'crafting_side', // 37
  'crafting_top', // 38
  'ore_iron', // 39
  'ore_gold', // 40
  'ore_coal', // 41
  'ore_redstone', // 42
  'furnace_side', // 43
  'furnace_front', // 44
  'furnace_top', // 45
  'bookshelf', // 46
  'clay', // 47
  'wool_yellow', // 48
  'wool_red', // 49
  'wool_blue', // 50
  'wool_green', // 51
  'obsidian', // 52
  'netherrack', // 53
  'portal', // 54
  'terracotta_red', // 55
  'terracotta_orange', // 56
  'terracotta_pale', // 57
  'glass_white', // 58
  'glass_orange', // 59
  'glass_magenta', // 60
  'glass_light_blue', // 61
  'glass_yellow', // 62
  'glass_lime', // 63
  'glass_pink', // 64
  'glass_gray', // 65
  'glass_light_gray', // 66
  'glass_cyan', // 67
  'glass_purple', // 68
  'glass_blue', // 69
  'glass_brown', // 70
  'glass_green', // 71
  'glass_red', // 72
  'glass_black', // 73
] as const;

export type Pass = 'opaque' | 'cutout' | 'transparent' | 'glow';
export type RenderKind = 'cube' | 'cross';

export interface BlockDef {
  id: number;
  name: string;
  tiles: [number, number, number, number, number, number];
  /** blocks light / hides neighbour faces */
  opaque: boolean;
  /** stops the player */
  solid: boolean;
  liquid?: boolean;
  pass: Pass;
  render: RenderKind;
  light?: number;
  /** hex tint applied to vertex colours */
  tint?: number;
  category: string;
  hardness?: number;
}

function cube(
  id: number,
  name: string,
  side: number,
  top = side,
  bottom = side,
  extra: Partial<BlockDef> = {},
): BlockDef {
  return {
    id,
    name,
    tiles: [side, side, top, bottom, side, side],
    opaque: true,
    solid: true,
    pass: 'opaque',
    render: 'cube',
    category: '方块',
    hardness: 1,
    ...extra,
  };
}

/** 染色玻璃：跟普通玻璃(id 9)同一套渲染方式，只是每种颜色各用一个独立的贴图槽位。 */
function glassBlock(id: number, name: string, tile: number): BlockDef {
  return {
    id,
    name,
    tiles: [tile, tile, tile, tile, tile, tile],
    opaque: false,
    solid: true,
    pass: 'transparent',
    render: 'cube',
    category: '建筑',
    hardness: 0.5,
  };
}

function cross(id: number, name: string, tile: number, category = '装饰'): BlockDef {
  return {
    id,
    name,
    tiles: [tile, tile, tile, tile, tile, tile],
    opaque: false,
    solid: false,
    pass: 'cutout',
    render: 'cross',
    category,
    hardness: 0.2,
  };
}

export const AIR = 0;

export const BLOCKS: BlockDef[] = [
  {
    id: 0,
    name: '空气',
    tiles: [0, 0, 0, 0, 0, 0],
    opaque: false,
    solid: false,
    pass: 'opaque',
    render: 'cube',
    category: '',
  },
  cube(1, '草地', 1, 0, 2, { category: '自然' }),
  cube(2, '泥土', 2, 2, 2, { category: '自然' }),
  cube(3, '石头', 3, 3, 3, { category: '自然', hardness: 2 }),
  cube(4, '圆石', 4, 4, 4, { category: '建筑', hardness: 2 }),
  cube(5, '沙子', 5, 5, 5, { category: '自然' }),
  cube(6, '原木', 6, 7, 7, { category: '自然' }),
  {
    id: 7,
    name: '树叶',
    tiles: [8, 8, 8, 8, 8, 8],
    opaque: false,
    solid: true,
    pass: 'cutout',
    render: 'cube',
    category: '自然',
    hardness: 0.4,
  },
  cube(8, '木板', 9, 9, 9, { category: '建筑' }),
  {
    id: 9,
    name: '玻璃',
    tiles: [10, 10, 10, 10, 10, 10],
    opaque: false,
    solid: true,
    pass: 'transparent',
    render: 'cube',
    category: '建筑',
    hardness: 0.5,
  },
  cube(10, '红砖', 11, 11, 11, { category: '建筑', hardness: 2 }),
  {
    id: 11,
    name: '水',
    tiles: [12, 12, 12, 12, 12, 12],
    opaque: false,
    solid: false,
    liquid: true,
    pass: 'transparent',
    render: 'cube',
    category: '自然',
  },
  cube(12, '雪块', 14, 13, 2, { category: '自然' }),
  cube(13, '荧光石', 15, 15, 15, { category: '奇趣', light: 1 }),
  cube(14, '糖果块', 16, 16, 16, { category: '奇趣' }),
  // 水晶用 'transparent' 通道渲染：真正的折射 + 色散（多重折射），不再是死板的纯色方块
  cube(15, '水晶', 17, 17, 17, { category: '奇趣', light: 0.4, pass: 'transparent' }),
  cube(16, '基岩', 18, 18, 18, { category: '自然', hardness: 8 }),
  {
    id: 17,
    name: '岩浆',
    tiles: [19, 19, 19, 19, 19, 19],
    opaque: true,
    solid: false,
    liquid: true,
    pass: 'opaque',
    render: 'cube',
    category: '自然',
    light: 0.9,
  },
  cube(18, '彩虹块', 20, 20, 20, { category: '奇趣', light: 0.3 }),
  cube(19, '云朵块', 21, 21, 21, { category: '奇趣' }),
  cube(20, '炸药块', 22, 23, 23, { category: '奇趣' }),
  cube(21, '宝石矿', 24, 24, 24, { category: '自然', hardness: 3 }),
  cube(22, '南瓜', 29, 30, 30, { category: '自然' }),
  {
    id: 23,
    name: '冰块',
    tiles: [31, 31, 31, 31, 31, 31],
    opaque: false,
    solid: true,
    pass: 'transparent',
    render: 'cube',
    category: '自然',
  },
  cross(24, '红花', 25, '装饰'),
  cross(25, '蓝花', 26, '装饰'),
  cross(26, '草丛', 27, '装饰'),
  cross(27, '蘑菇', 28, '装饰'),
  cube(28, '惊喜宝箱', 32, 33, 32, { category: '建筑', hardness: 2 }),
  cube(29, '仙人掌', 34, 35, 35, { category: '自然', hardness: 0.6 }),
  {
    id: 30,
    name: '火把',
    tiles: [36, 36, 36, 36, 36, 36],
    opaque: false,
    solid: false,
    pass: 'cutout',
    render: 'cross',
    category: '建筑',
    light: 0.85,
    hardness: 0.1,
  },
  cube(31, '工作台', 37, 38, 38, { category: '建筑', hardness: 2 }),
  cube(32, '铁矿石', 39, 39, 39, { category: '自然', hardness: 3 }),
  cube(33, '金矿石', 40, 40, 40, { category: '自然', hardness: 3 }),
  cube(34, '煤矿', 41, 41, 41, { category: '自然', hardness: 2 }),
  cube(35, '红石矿', 42, 42, 42, { category: '自然', hardness: 3, light: 0.3 }),
  cube(36, '熔炉', 43, 45, 45, { category: '建筑', hardness: 3 }),
  cube(37, '书架', 46, 38, 38, { category: '建筑', hardness: 1 }),
  cube(38, '粘土', 47, 47, 47, { category: '自然', hardness: 0.5 }),
  cube(39, '黄羊毛', 48, 48, 48, { category: '建筑' }),
  cube(40, '红羊毛', 49, 49, 49, { category: '建筑' }),
  cube(41, '蓝羊毛', 50, 50, 50, { category: '建筑' }),
  cube(42, '绿羊毛', 51, 51, 51, { category: '建筑' }),
  // ---- 下界维度专用方块 ----
  cube(43, '黑曜石', 52, 52, 52, { category: '建筑', hardness: 8 }), // 传送门边框材料
  cube(44, '下界岩', 53, 53, 53, { category: '自然', hardness: 1.5 }), // 下界地形主体
  {
    id: 45,
    name: '传送门',
    tiles: [54, 54, 54, 54, 54, 54],
    opaque: false, // 别挡光、别挡视线
    solid: false, // 能走进去——走进去就会触发跨维度传送
    pass: 'glow', // 自发光通道，紫色漩涡本身就该是亮的
    render: 'cube',
    category: '', // 不进制作台/背包可放置列表，只能靠点燃黑曜石框自动生成
    light: 0.8,
  },
  // ---- 恶地/悬崖高原（mesa）专用的陶土条带方块 ----
  cube(46, '红陶土', 55, 55, 55, { category: '建筑' }),
  cube(47, '橙陶土', 56, 56, 56, { category: '建筑' }),
  cube(48, '白陶土', 57, 57, 57, { category: '建筑' }),
  // ---- 16 色染色玻璃：默认用程序化贴图，开启"HD PBR 材质包"实验选项后
  //      会换成用户提供的真实贴图（含法线/粗糙度/金属度），见 textures.ts 里的
  //      setHDGlassTextures()。方块定义本身跟普通玻璃(id 9)完全一样，只是
  //      每个用了自己专属的贴图槽位，所以能各自独立换肤。 ----
  glassBlock(49, '白色染色玻璃', 58),
  glassBlock(50, '橙色染色玻璃', 59),
  glassBlock(51, '品红色染色玻璃', 60),
  glassBlock(52, '淡蓝色染色玻璃', 61),
  glassBlock(53, '黄色染色玻璃', 62),
  glassBlock(54, '黄绿色染色玻璃', 63),
  glassBlock(55, '粉色染色玻璃', 64),
  glassBlock(56, '灰色染色玻璃', 65),
  glassBlock(57, '淡灰色染色玻璃', 66),
  glassBlock(58, '青色染色玻璃', 67),
  glassBlock(59, '紫色染色玻璃', 68),
  glassBlock(60, '蓝色染色玻璃', 69),
  glassBlock(61, '棕色染色玻璃', 70),
  glassBlock(62, '绿色染色玻璃', 71),
  glassBlock(63, '红色染色玻璃', 72),
  glassBlock(64, '黑色染色玻璃', 73),
];

export const BLOCK_COUNT = BLOCKS.length;

export function getBlock(id: number): BlockDef {
  return BLOCKS[id] ?? BLOCKS[0];
}

export function isSolid(id: number): boolean {
  return getBlock(id).solid;
}

export function isOpaque(id: number): boolean {
  return getBlock(id).opaque;
}

export const PLACEABLE_IDS = BLOCKS.filter((b) => b.id !== 0 && b.id !== 11 && b.id !== 16 && b.id !== 45).map(
  (b) => b.id,
);

export const CATEGORIES = ['自然', '建筑', '奇趣', '装饰'];
