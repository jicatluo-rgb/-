/** 我的世界式 3x3 合成系统 */

export interface CraftingRecipe {
  id: string;
  name: string;
  pattern: (number | null)[][]; // 3x3 网格，null 表示空
  result: { id: number; count: number };
  description?: string;
}

// 合成配方
export const CRAFTING_RECIPES: CraftingRecipe[] = [
  // 基础工具
  {
    id: 'crafting_table',
    name: '工作台',
    pattern: [
      [8, 8, null],
      [8, 8, null],
      [null, null, null],
    ],
    result: { id: 481, count: 1 },
    description: '4个木板合成工作台',
  },
  {
    id: 'wooden_pickaxe',
    name: '木镐',
    pattern: [
      [8, 8, 8],
      [null, 200, null],
      [null, 200, null],
    ],
    result: { id: 200, count: 1 },
    description: '3个木板+2个木棍合成木镐',
  },
  {
    id: 'stone_pickaxe',
    name: '石镐',
    pattern: [
      [4, 4, 4],
      [null, 200, null],
      [null, 200, null],
    ],
    result: { id: 201, count: 1 },
    description: '3个圆石+2个木棍合成石镐',
  },
  {
    id: 'iron_pickaxe',
    name: '铁镐',
    pattern: [
      [230, 230, 230],
      [null, 200, null],
      [null, 200, null],
    ],
    result: { id: 202, count: 1 },
    description: '3个铁锭+2个木棍合成铁镐',
  },
  {
    id: 'diamond_pickaxe',
    name: '钻石镐',
    pattern: [
      [232, 232, 232],
      [null, 200, null],
      [null, 200, null],
    ],
    result: { id: 203, count: 1 },
    description: '3个钻石+2个木棍合成钻石镐',
  },
  
  // 剑
  {
    id: 'wooden_sword',
    name: '木剑',
    pattern: [
      [8, null, null],
      [8, null, null],
      [200, null, null],
    ],
    result: { id: 210, count: 1 },
    description: '2个木板+1个木棍合成木剑',
  },
  {
    id: 'stone_sword',
    name: '石剑',
    pattern: [
      [4, null, null],
      [4, null, null],
      [200, null, null],
    ],
    result: { id: 211, count: 1 },
    description: '2个圆石+1个木棍合成石剑',
  },
  {
    id: 'iron_sword',
    name: '铁剑',
    pattern: [
      [230, null, null],
      [230, null, null],
      [200, null, null],
    ],
    result: { id: 212, count: 1 },
    description: '2个铁锭+1个木棍合成铁剑',
  },
  {
    id: 'diamond_sword',
    name: '钻石剑',
    pattern: [
      [232, null, null],
      [232, null, null],
      [200, null, null],
    ],
    result: { id: 213, count: 1 },
    description: '2个钻石+1个木棍合成钻石剑',
  },
  
  // 斧头
  {
    id: 'wooden_axe',
    name: '木斧',
    pattern: [
      [8, 8, null],
      [8, 200, null],
      [null, 200, null],
    ],
    result: { id: 214, count: 1 },
    description: '3个木板+2个木棍合成木斧',
  },
  {
    id: 'stone_axe',
    name: '石斧',
    pattern: [
      [4, 4, null],
      [4, 200, null],
      [null, 200, null],
    ],
    result: { id: 215, count: 1 },
    description: '3个圆石+2个木棍合成石斧',
  },
  
  // 铲子
  {
    id: 'wooden_shovel',
    name: '木铲',
    pattern: [
      [8, null, null],
      [200, null, null],
      [200, null, null],
    ],
    result: { id: 216, count: 1 },
    description: '1个木板+2个木棍合成木铲',
  },
  {
    id: 'stone_shovel',
    name: '石铲',
    pattern: [
      [4, null, null],
      [200, null, null],
      [200, null, null],
    ],
    result: { id: 217, count: 1 },
    description: '1个圆石+2个木棍合成石铲',
  },
  
  // 材料
  {
    id: 'stick',
    name: '木棍',
    pattern: [
      [8, null, null],
      [8, null, null],
      [null, null, null],
    ],
    result: { id: 200, count: 4 },
    description: '2个木板合成4个木棍',
  },
  {
    id: 'planks',
    name: '木板',
    pattern: [
      [6, null, null],
      [null, null, null],
      [null, null, null],
    ],
    result: { id: 8, count: 4 },
    description: '1个原木合成4个木板',
  },
  
  // 火把
  {
    id: 'torch',
    name: '火把',
    pattern: [
      [234, null, null],
      [200, null, null],
      [null, null, null],
    ],
    result: { id: 30, count: 4 },
    description: '1个煤炭+1个木棍合成4个火把',
  },
  
  // TNT
  {
    id: 'tnt',
    name: 'TNT',
    pattern: [
      [234, 5, 234],
      [5, 234, 5],
      [234, 5, 234],
    ],
    result: { id: 480, count: 1 },
    description: '5个火药+4个沙子合成TNT',
  },
  
  // 熔炉
  {
    id: 'furnace',
    name: '熔炉',
    pattern: [
      [4, 4, 4],
      [4, null, 4],
      [4, 4, 4],
    ],
    result: { id: 482, count: 1 },
    description: '8个圆石合成熔炉',
  },
  
  // 箱子
  {
    id: 'chest',
    name: '箱子',
    pattern: [
      [8, 8, 8],
      [8, null, 8],
      [8, 8, 8],
    ],
    result: { id: 483, count: 1 },
    description: '8个木板合成箱子',
  },
  
  // 书架
  {
    id: 'bookshelf',
    name: '书架',
    pattern: [
      [8, 8, 8],
      [220, 220, 220],
      [8, 8, 8],
    ],
    result: { id: 484, count: 1 },
    description: '6个木板+3本书合成书架',
  },
  
  // 附魔台
  {
    id: 'enchanting_table',
    name: '附魔台',
    pattern: [
      [null, 220, null],
      [232, 4, 232],
      [4, 232, 4],
    ],
    result: { id: 485, count: 1 },
    description: '4个黑曜石+2个钻石+1本书合成附魔台',
  },
  
  // 弓
  {
    id: 'bow',
    name: '弓',
    pattern: [
      [null, 200, 237],
      [200, null, 237],
      [null, 200, 237],
    ],
    result: { id: 218, count: 1 },
    description: '3个木棍+3个线合成弓',
  },
  
  // 箭
  {
    id: 'arrow',
    name: '箭',
    pattern: [
      [239, null, null],
      [200, null, null],
      [238, null, null],
    ],
    result: { id: 240, count: 4 },
    description: '1个燧石+1个木棍+1个羽毛合成4个箭',
  },
];

// 2x2 快捷合成（背包内）
export const QUICK_RECIPES: CraftingRecipe[] = [
  {
    id: 'quick_planks',
    name: '木板',
    pattern: [
      [6, null],
      [null, null],
    ],
    result: { id: 8, count: 4 },
    description: '1个原木合成4个木板',
  },
  {
    id: 'quick_stick',
    name: '木棍',
    pattern: [
      [8, null],
      [8, null],
    ],
    result: { id: 200, count: 4 },
    description: '2个木板合成4个木棍',
  },
  {
    id: 'quick_torch',
    name: '火把',
    pattern: [
      [234, null],
      [200, null],
    ],
    result: { id: 30, count: 4 },
    description: '1个煤炭+1个木棍合成4个火把',
  },
  {
    id: 'quick_crafting_table',
    name: '工作台',
    pattern: [
      [8, 8],
      [8, 8],
    ],
    result: { id: 481, count: 1 },
    description: '4个木板合成工作台',
  },
];

/** 检查合成网格是否匹配配方 */
export function matchRecipe(grid: (number | null)[][], recipes: CraftingRecipe[]): CraftingRecipe | null {
  for (const recipe of recipes) {
    if (matchesPattern(grid, recipe.pattern)) {
      return recipe;
    }
  }
  return null;
}

function matchesPattern(grid: (number | null)[][], pattern: (number | null)[][]): boolean {
  // 检查3x3网格
  if (grid.length === 3 && pattern.length === 3) {
    for (let y = 0; y < 3; y++) {
      for (let x = 0; x < 3; x++) {
        const gridItem = grid[y][x];
        const patternItem = pattern[y][x];
        if (gridItem !== patternItem) return false;
      }
    }
    return true;
  }
  
  // 检查2x2网格
  if (grid.length === 2 && pattern.length === 2) {
    for (let y = 0; y < 2; y++) {
      for (let x = 0; x < 2; x++) {
        const gridItem = grid[y][x];
        const patternItem = pattern[y][x];
        if (gridItem !== patternItem) return false;
      }
    }
    return true;
  }
  
  return false;
}

/** 获取配方所需材料 */
export function getRecipeIngredients(recipe: CraftingRecipe): { id: number; count: number }[] {
  const ingredients: Map<number, number> = new Map();
  
  for (let y = 0; y < recipe.pattern.length; y++) {
    for (let x = 0; x < recipe.pattern[y].length; x++) {
      const item = recipe.pattern[y][x];
      if (item !== null) {
        const current = ingredients.get(item) || 0;
        ingredients.set(item, current + 1);
      }
    }
  }
  
  return Array.from(ingredients.entries()).map(([id, count]) => ({ id, count }));
}
