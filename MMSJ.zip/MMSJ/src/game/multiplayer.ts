/** 联机模式系统 - 谁是狙神、躲猫猫 */

export type GameMode = 'normal' | 'sniper' | 'hideAndSeek';

export interface PlayerState {
  id: string;
  name: string;
  position: [number, number, number];
  rotation: [number, number];
  health: number;
  score: number;
  team: 'red' | 'blue' | 'seeker' | 'hider';
  isAlive: boolean;
  inventory: number[];
}

export interface GameState {
  mode: GameMode;
  players: PlayerState[];
  roundTime: number;
  roundNumber: number;
  isPlaying: boolean;
  winner: string | null;
}

// 谁是狙神模式配置
export interface SniperConfig {
  roundTime: number; // 每回合时间（秒）
  mapSize: number; // 地图大小
  sniperRifles: number[]; // 可用狙击枪ID
  maxPlayers: number;
}

// 躲猫猫模式配置
export interface HideAndSeekConfig {
  roundTime: number; // 躲藏时间（秒）
  seekTime: number; // 寻找时间（秒）
  mapSize: number; // 地图大小
  maxPlayers: number;
  seekerRatio: number; // 寻找者比例（0-1）
}

export const DEFAULT_SNIPER_CONFIG: SniperConfig = {
  roundTime: 180, // 3分钟
  mapSize: 64,
  sniperRifles: [108, 109, 110], // 木枪、步枪、水晶炮
  maxPlayers: 8,
};

export const DEFAULT_HIDE_AND_SEEK_CONFIG: HideAndSeekConfig = {
  roundTime: 30, // 30秒躲藏时间
  seekTime: 180, // 3分钟寻找时间
  mapSize: 48,
  maxPlayers: 10,
  seekerRatio: 0.3, // 30%玩家是寻找者
};

// 谁是狙神模式逻辑
export class SniperMode {
  private config: SniperConfig;
  private state: GameState;
  private players: Map<string, PlayerState>;

  constructor(config: SniperConfig = DEFAULT_SNIPER_CONFIG) {
    this.config = config;
    this.state = {
      mode: 'sniper',
      players: [],
      roundTime: config.roundTime,
      roundNumber: 0,
      isPlaying: false,
      winner: null,
    };
    this.players = new Map();
  }

  addPlayer(id: string, name: string): PlayerState {
    const player: PlayerState = {
      id,
      name,
      position: [0, 0, 0],
      rotation: [0, 0],
      health: 100,
      score: 0,
      team: Math.random() < 0.5 ? 'red' : 'blue',
      isAlive: true,
      inventory: [...this.config.sniperRifles],
    };
    this.players.set(id, player);
    this.state.players.push(player);
    return player;
  }

  removePlayer(id: string) {
    this.players.delete(id);
    this.state.players = this.state.players.filter(p => p.id !== id);
  }

  startRound() {
    this.state.roundNumber++;
    this.state.roundTime = this.config.roundTime;
    this.state.isPlaying = true;
    this.state.winner = null;
    
    // 重置玩家状态
    this.players.forEach(player => {
      player.health = 100;
      player.isAlive = true;
      player.position = [
        (Math.random() - 0.5) * this.config.mapSize,
        5,
        (Math.random() - 0.5) * this.config.mapSize,
      ];
    });
  }

  endRound(winnerTeam: 'red' | 'blue') {
    this.state.isPlaying = false;
    this.state.winner = winnerTeam;
    
    // 更新分数
    this.players.forEach(player => {
      if (player.team === winnerTeam) {
        player.score += 100;
      }
    });
  }

  playerHit(attackerId: string, targetId: string, damage: number) {
    const attacker = this.players.get(attackerId);
    const target = this.players.get(targetId);
    
    if (!attacker || !target || !target.isAlive) return;
    
    target.health -= damage;
    if (target.health <= 0) {
      target.isAlive = false;
      attacker.score += 50;
      
      // 检查是否一方全灭
      const redAlive = Array.from(this.players.values()).filter(p => p.team === 'red' && p.isAlive).length;
      const blueAlive = Array.from(this.players.values()).filter(p => p.team === 'blue' && p.isAlive).length;
      
      if (redAlive === 0) {
        this.endRound('blue');
      } else if (blueAlive === 0) {
        this.endRound('red');
      }
    }
  }

  updatePlayerPosition(id: string, position: [number, number, number], rotation: [number, number]) {
    const player = this.players.get(id);
    if (player) {
      player.position = position;
      player.rotation = rotation;
    }
  }

  getState(): GameState {
    return { ...this.state };
  }

  getPlayers(): PlayerState[] {
    return Array.from(this.players.values());
  }
}

// 躲猫猫模式逻辑
export class HideAndSeekMode {
  private config: HideAndSeekConfig;
  private state: GameState;
  private players: Map<string, PlayerState>;
  private phase: 'hiding' | 'seeking' | 'ended';
  private timer: number;

  constructor(config: HideAndSeekConfig = DEFAULT_HIDE_AND_SEEK_CONFIG) {
    this.config = config;
    this.state = {
      mode: 'hideAndSeek',
      players: [],
      roundTime: config.roundTime,
      roundNumber: 0,
      isPlaying: false,
      winner: null,
    };
    this.players = new Map();
    this.phase = 'hiding';
    this.timer = config.roundTime;
  }

  addPlayer(id: string, name: string): PlayerState {
    const player: PlayerState = {
      id,
      name,
      position: [0, 0, 0],
      rotation: [0, 0],
      health: 100,
      score: 0,
      team: 'hider',
      isAlive: true,
      inventory: [],
    };
    this.players.set(id, player);
    this.state.players.push(player);
    return player;
  }

  removePlayer(id: string) {
    this.players.delete(id);
    this.state.players = this.state.players.filter(p => p.id !== id);
  }

  startRound() {
    this.state.roundNumber++;
    this.phase = 'hiding';
    this.timer = this.config.roundTime;
    this.state.isPlaying = true;
    this.state.winner = null;
    
    // 分配角色
    const playerArray = Array.from(this.players.values());
    const seekerCount = Math.max(1, Math.floor(playerArray.length * this.config.seekerRatio));
    
    // 随机选择寻找者
    const shuffled = [...playerArray].sort(() => Math.random() - 0.5);
    for (let i = 0; i < seekerCount; i++) {
      shuffled[i].team = 'seeker';
    }
    
    // 重置玩家状态
    this.players.forEach(player => {
      player.health = 100;
      player.isAlive = true;
      player.position = [
        (Math.random() - 0.5) * this.config.mapSize,
        5,
        (Math.random() - 0.5) * this.config.mapSize,
      ];
    });
  }

  endRound(winnerTeam: 'seeker' | 'hider') {
    this.state.isPlaying = false;
    this.state.winner = winnerTeam;
    this.phase = 'ended';
    
    // 更新分数
    this.players.forEach(player => {
      if (player.team === winnerTeam) {
        player.score += 100;
      }
    });
  }

  playerFound(seekerId: string, hiderId: string) {
    const seeker = this.players.get(seekerId);
    const hider = this.players.get(hiderId);
    
    if (!seeker || !hider || !hider.isAlive) return;
    
    hider.isAlive = false;
    hider.team = 'seeker'; // 被找到的人变成寻找者
    seeker.score += 50;
    
    // 检查是否所有躲藏者都被找到
    const hidersAlive = Array.from(this.players.values()).filter(p => p.team === 'hider' && p.isAlive).length;
    
    if (hidersAlive === 0) {
      this.endRound('seeker');
    }
  }

  updatePlayerPosition(id: string, position: [number, number, number], rotation: [number, number]) {
    const player = this.players.get(id);
    if (player) {
      player.position = position;
      player.rotation = rotation;
    }
  }

  update(deltaTime: number) {
    if (!this.state.isPlaying) return;
    
    this.timer -= deltaTime;
    
    if (this.phase === 'hiding' && this.timer <= 0) {
      // 躲藏时间结束，开始寻找
      this.phase = 'seeking';
      this.timer = this.config.seekTime;
    } else if (this.phase === 'seeking' && this.timer <= 0) {
      // 寻找时间结束，躲藏者胜利
      this.endRound('hider');
    }
    
    this.state.roundTime = this.timer;
  }

  getState(): GameState & { phase: string; timer: number } {
    return { ...this.state, phase: this.phase, timer: this.timer };
  }

  getPlayers(): PlayerState[] {
    return Array.from(this.players.values());
  }
}

// 游戏模式管理器
export class MultiplayerManager {
  private currentMode: GameMode = 'normal';
  private sniperMode: SniperMode | null = null;
  private hideAndSeekMode: HideAndSeekMode | null = null;

  setMode(mode: GameMode) {
    this.currentMode = mode;
    
    if (mode === 'sniper') {
      this.sniperMode = new SniperMode();
      this.hideAndSeekMode = null;
    } else if (mode === 'hideAndSeek') {
      this.hideAndSeekMode = new HideAndSeekMode();
      this.sniperMode = null;
    } else {
      this.sniperMode = null;
      this.hideAndSeekMode = null;
    }
  }

  getMode(): GameMode {
    return this.currentMode;
  }

  getSniperMode(): SniperMode | null {
    return this.sniperMode;
  }

  getHideAndSeekMode(): HideAndSeekMode | null {
    return this.hideAndSeekMode;
  }

  update(deltaTime: number) {
    if (this.currentMode === 'hideAndSeek' && this.hideAndSeekMode) {
      this.hideAndSeekMode.update(deltaTime);
    }
  }
}
