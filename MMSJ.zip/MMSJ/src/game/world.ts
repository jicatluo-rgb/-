import * as THREE from 'three';
import { Noise, hash2, hash3 } from './noise';
import { AIR, BLOCKS, getBlock, type Pass } from './blocks';
import { CHEST_SIZE, type ItemStack } from './items';
import { tileUV, getProceduralNormalAtlasTexture } from './textures';
import { getBiome, BIOMES, type BiomeType } from './biome';
import {
  buildAltar,
  buildCamp,
  buildHut,
  buildIgloo,
  buildMineshaft,
  buildRuin,
  buildTemple,
  buildTower,
  buildTreehouse,
  buildVillage,
  type StructCtx,
} from './structures';

export const CHUNK_SIZE = 16;
export const WORLD_HEIGHT = 72;
export const SEA_LEVEL = 22;

const idx = (x: number, y: number, z: number) => x + z * CHUNK_SIZE + y * CHUNK_SIZE * CHUNK_SIZE;

export type WorldType = 'normal' | 'flat' | 'islands' | 'nether';

export type StructureType =
  | 'village'
  | 'ruin'
  | 'altar'
  | 'temple'
  | 'igloo'
  | 'tower'
  | 'camp'
  | 'mineshaft'
  | 'treehouse'
  | 'hut';

export interface StructureMarker {
  type: StructureType;
  x: number;
  y: number;
  z: number;
}

export interface LootEntry {
  blockId: number;
  count: number;
}

/** 驯服宠物索敌所需的最小生物接口 */
export interface MobLike {
  pos: THREE.Vector3;
  tamed: boolean;
  def: { friendly: boolean };
  hp: number;
  damage(amount: number, dir: THREE.Vector3): void;
}

interface FaceDef {
  n: [number, number, number];
  u: [number, number, number];
  v: [number, number, number];
  base: [number, number, number];
  shade: number;
  swap: boolean;
  tile: number;
}

const FACES: FaceDef[] = [
  { n: [1, 0, 0], u: [0, 1, 0], v: [0, 0, 1], base: [1, 0, 0], shade: 0.84, swap: true, tile: 0 },
  { n: [-1, 0, 0], u: [0, 0, 1], v: [0, 1, 0], base: [0, 0, 0], shade: 0.84, swap: false, tile: 1 },
  { n: [0, 1, 0], u: [0, 0, 1], v: [1, 0, 0], base: [0, 1, 0], shade: 1.0, swap: true, tile: 2 },
  { n: [0, -1, 0], u: [1, 0, 0], v: [0, 0, 1], base: [0, 0, 0], shade: 0.52, swap: false, tile: 3 },
  { n: [0, 0, 1], u: [1, 0, 0], v: [0, 1, 0], base: [0, 0, 1], shade: 0.7, swap: false, tile: 4 },
  { n: [0, 0, -1], u: [0, 1, 0], v: [1, 0, 0], base: [0, 0, 0], shade: 0.7, swap: true, tile: 5 },
];

const AO_LEVELS = [0.48, 0.68, 0.85, 1.0];
const NO_TINT: [number, number, number] = [1, 1, 1];

class GeomBuilder {
  pos: number[] = [];
  nor: number[] = [];
  uv: number[] = [];
  col: number[] = [];
  idxs: number[] = [];

  get empty() {
    return this.pos.length === 0;
  }

  toGeometry(): THREE.BufferGeometry {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(this.pos, 3));
    g.setAttribute('normal', new THREE.Float32BufferAttribute(this.nor, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(this.uv, 2));
    g.setAttribute('color', new THREE.Float32BufferAttribute(this.col, 3));
    g.setIndex(this.idxs);
    g.computeBoundingSphere();
    return g;
  }
}

export class Chunk {
  cx: number;
  cz: number;
  blocks: Uint8Array;
  dirty = true;
  meshed = false;
  generated = false;
  genCol = 0; // next terrain column to generate (time-sliced)
  meshJob: MeshJob | null = null;
  meshes: Partial<Record<Pass, THREE.Mesh>> = {};

  constructor(cx: number, cz: number) {
    this.cx = cx;
    this.cz = cz;
    this.blocks = new Uint8Array(CHUNK_SIZE * CHUNK_SIZE * WORLD_HEIGHT);
  }

  get(x: number, y: number, z: number) {
    if (y < 0 || y >= WORLD_HEIGHT) return AIR;
    return this.blocks[idx(x, y, z)];
  }

  set(x: number, y: number, z: number, id: number) {
    if (y < 0 || y >= WORLD_HEIGHT) return;
    this.blocks[idx(x, y, z)] = id;
  }
}

interface MeshJob {
  builders: Record<Pass, GeomBuilder>;
  topMap: Int16Array;
  y: number;
  lz: number;
  lx: number;
}

export interface RaycastHit {
  x: number;
  y: number;
  z: number;
  nx: number;
  ny: number;
  nz: number;
  id: number;
  distance: number;
}

export class World {
  chunks = new Map<string, Chunk>();
  noise: Noise;
  noise2: Noise;
  seed: number;
  type: WorldType;
  group = new THREE.Group();
  materials: Record<Pass, THREE.Material>;
  structures = new Map<string, StructureMarker>();
  /** 由 engine 注入，供驯服宠物寻找攻击目标 */
  mobList: MobLike[] = [];
  private edits = new Map<string, number>();
  private openedChests = new Set<string>();
  private chestTypes = new Map<string, StructureType>();
  private chestContents = new Map<string, (ItemStack | null)[]>();
  private heightCache = new Map<number, number>();

  constructor(seed: number, type: WorldType, atlas: THREE.Texture) {
    this.seed = seed;
    this.type = type;
    this.noise = new Noise(seed);
    this.noise2 = new Noise(seed * 7 + 13);
    const common = {
      map: atlas,
      vertexColors: true,
      // 默认（没开 HD PBR 材质包时）也给方块来点凹凸——从贴图自身的亮度变化
      // 反推出来的"假凹凸"法线贴图，没有真实高度数据，但对本来就带噪点/颗粒感
      // 的程序化贴图（泥土、石头、木纹……）效果很自然，好过完全没有凹凸的纯平贴图。
      // HD PBR 开启时 Game.setHDPBR() 会把这里换成材质包的真实法线贴图。
      normalMap: getProceduralNormalAtlasTexture(),
    };
    this.materials = {
      // PBR：粗糙度/金属度材质，让方块在不同光照角度下有更真实的明暗过渡
      // 地面整体做了轻微的"微湿/微反光"处理（粗糙度调低、金属度略提），
      // 配合 SSR 会有淡淡的镜面高光，不是那种一眼假的镜面地板——毕竟这是共享给
      // 所有不透明方块（泥土/草地/石头……）的同一份材质，没法按方块类型单独调，
      // 调太狠会让草地看起来像塑料，这里刻意控制得比较克制。
      opaque: new THREE.MeshStandardMaterial({ ...common, roughness: 0.62, metalness: 0.06 }),
      // 树叶/花草/火把等薄片状物体：加一点点 transmission，
      // 模拟光从背后透过叶片的次表面散射感（不是真的 SSS，但便宜且效果接近）
      cutout: new THREE.MeshPhysicalMaterial({
        ...common,
        alphaTest: 0.5,
        transparent: false,
        roughness: 0.78,
        metalness: 0,
        transmission: 0.16,
        thickness: 0.25,
        ior: 1.35,
        attenuationColor: new THREE.Color(0xbfe08a),
        attenuationDistance: 0.6,
      }),
      // 半透明层用 MeshPhysicalMaterial：transmission 提供真实的折射（不是贴图假透明），
      // 水/冰/玻璃/水晶能看到背后的场景发生真实弯折；dispersion 让折射按波长轻微分裂，
      // 也就是"光线多重折射"（色散）。这一层的反光/折射只来自真实的直射光源
      // （太阳/半球光/点光源），没有额外的环境贴图叠加，所以不会整体偏亮。
      transparent: new THREE.MeshPhysicalMaterial({
        ...common,
        transparent: true,
        // 这里原来是 depthWrite:false（半透明物体的常规写法，保证跟其它半透明面
        // 混合排序正确）。但开启 SSR 之后，SSRPass 是靠"主深度缓冲在这个像素上的
        // 深度"来判断这里有没有东西、该不该参与反射合成的；depthWrite:false 意味着
        // 这个像素的深度其实是"这个方块后面/下面那个东西"的深度，SSR 一读就以为这里
        // 是空的，于是直接把这块渲染成空洞——也就是放一个玻璃/冰块，就能直接看穿
        // 地板看到下面。让反光方块自己写深度就不会再有这个问题；代价是极少数"两层
        // 半透明面贴在一起"的场景排序会略微不如以前精细，但比"能看穿地板"优先级低得多。
        depthWrite: true,
        opacity: 0.92,
        roughness: 0.08,
        metalness: 0,
        transmission: 0.55,
        thickness: 0.6,
        ior: 1.31,
        dispersion: 1.6,
        clearcoat: 0.3,
        clearcoatRoughness: 0.15,
      }),
      // 真正会发光的方块（火把/荧光石/岩浆/彩虹块/红石矿）独立成一个通道：
      // emissiveMap 直接复用同一张贴图，让每种方块自己纹理的颜色变成对应的
      // 发光颜色（荧光石发黄白光、岩浆发橙红光……），不需要为每种方块单独调材质。
      // 之前放下这些方块只是纹理"看起来亮"，并不是真的自发光，白天也完全
      // 看不出区别；现在无论几点、无论泛光开不开，它们本身就是亮的，
      // 泛光开启时也只有这层通道会真正"发光"，不会把太阳、雪地一起吹亮。
      glow: new THREE.MeshStandardMaterial({
        ...common,
        alphaTest: 0.5,
        roughness: 0.6,
        metalness: 0,
        emissiveMap: atlas,
        emissive: new THREE.Color(0xffffff),
        emissiveIntensity: 0.95,
      }),
    };
  }

  key(cx: number, cz: number) {
    return `${cx},${cz}`;
  }

  exportEdits(): [string, number][] {
    return [...this.edits.entries()];
  }

  importEdits(entries: [string, number][]) {
    for (const [k, v] of entries) this.edits.set(k, v);
  }

  exportOpenedChests(): string[] {
    return [...this.openedChests];
  }

  importOpenedChests(entries: string[]) {
    for (const key of entries) this.openedChests.add(key);
  }

  /** 27 格宝箱内容；玩家改过的箱子优先，否则按位置确定性生成战利品。 */
  getChestSlots(x: number, y: number, z: number): (ItemStack | null)[] {
    const key = `${x},${y},${z}`;
    const saved = this.chestContents.get(key);
    if (saved) return saved;
    const type = this.chestTypes.get(key);
    const slots: (ItemStack | null)[] = Array.from({ length: CHEST_SIZE }, () => null);
    if (!type) return slots;
    const pools: Record<StructureType, number[]> = {
      village: [6, 8, 10, 14, 22, 24, 25],
      ruin: [4, 9, 13, 20, 21, 23],
      altar: [13, 15, 18, 20, 21],
      temple: [5, 13, 15, 21, 18],
      igloo: [12, 23, 13, 19, 14],
      tower: [30, 4, 9, 20, 13],
      camp: [6, 8, 30, 22, 27],
      mineshaft: [6, 8, 21, 13, 20, 30],
      treehouse: [6, 7, 8, 22, 30, 24],
      hut: [6, 8, 26, 22, 13, 14],
    };
    const pool = pools[type];
    const count = 2 + Math.floor(hash2(x, z, this.seed + 811) * 3);
    for (let i = 0; i < count && i < CHEST_SIZE; i++) {
      const itemRoll = hash2(x + i * 17, z - i * 23, this.seed + 823);
      const blockId = pool[Math.floor(itemRoll * pool.length) % pool.length];
      const amount = type === 'altar' ? 1 + Math.floor(itemRoll * 3) : 2 + Math.floor(itemRoll * 6);
      slots[i] = { id: blockId, count: Math.min(amount, 64) };
    }
    return slots;
  }

  getChestType(x: number, y: number, z: number): StructureType | null {
    return this.chestTypes.get(`${x},${y},${z}`) ?? null;
  }

  setChestSlot(x: number, y: number, z: number, index: number, stack: ItemStack | null) {
    const key = `${x},${y},${z}`;
    const slots = this.getChestSlots(x, y, z).map((s) => (s ? { ...s } : null));
    slots[index] = stack ? { ...stack } : null;
    this.chestContents.set(key, slots);
  }

  exportChests(): Record<string, ([number, number] | null)[]> {
    const out: Record<string, ([number, number] | null)[]> = {};
    for (const [key, slots] of this.chestContents) {
      out[key] = slots.map((s) => (s ? [s.id, s.count] : null));
    }
    return out;
  }

  importChests(entries: Record<string, ([number, number] | null)[]>) {
    for (const [key, arr] of Object.entries(entries ?? {})) {
      this.chestContents.set(
        key,
        arr.map((entry) => (entry ? { id: entry[0], count: entry[1] } : null)),
      );
    }
  }

  getChunk(cx: number, cz: number): Chunk | undefined {
    return this.chunks.get(this.key(cx, cz));
  }

  createChunk(cx: number, cz: number): Chunk {
    const k = this.key(cx, cz);
    let c = this.chunks.get(k);
    if (!c) {
      c = new Chunk(cx, cz);
      this.chunks.set(k, c);
    }
    return c;
  }

  /** Create the chunk if missing (no terrain generation). */
  ensureChunk(cx: number, cz: number): Chunk {
    return this.createChunk(cx, cz);
  }

  /** Synchronously finish generating a chunk (used at spawn / rare teleports). */
  forceGenerate(cx: number, cz: number): Chunk {
    const c = this.createChunk(cx, cz);
    while (!c.generated) this.generateSlice(c, 1000);
    return c;
  }

  getBlock(x: number, y: number, z: number): number {
    if (y < 0 || y >= WORLD_HEIGHT) return AIR;
    const cx = Math.floor(x / CHUNK_SIZE);
    const cz = Math.floor(z / CHUNK_SIZE);
    const c = this.chunks.get(this.key(cx, cz));
    if (!c || !c.generated) return AIR;
    return c.get(x - cx * CHUNK_SIZE, y, z - cz * CHUNK_SIZE);
  }

  isOpaqueAt(x: number, y: number, z: number) {
    return getBlock(this.getBlock(x, y, z)).opaque;
  }

  private tintCache = new Map<string, [number, number, number]>();

  /** 逐列色彩扰动：草地/树叶/沙子按位置轻微变色，避免大片纯色 */
  /** 把一个十六进制颜色标准化成"保留主色调、亮度不整体变暗"的倍率，
   *  再跟中性色 (1,1,1) 混合一部分，避免整片纯色显得假。 */
  private static hueMultiplier(hex: number, mix = 0.6): [number, number, number] {
    const r = ((hex >> 16) & 0xff) / 255;
    const g = ((hex >> 8) & 0xff) / 255;
    const b = (hex & 0xff) / 255;
    const maxC = Math.max(r, g, b, 0.001);
    const nr = r / maxC;
    const ng = g / maxC;
    const nb = b / maxC;
    return [1 + (nr - 1) * mix, 1 + (ng - 1) * mix, 1 + (nb - 1) * mix];
  }

  private colorTint(id: number, x: number, z: number): [number, number, number] {
    // 只有植被与地表需要扰动，其它方块保持原色
    if (id !== 1 && id !== 7 && id !== 5 && id !== 26 && id !== 24 && id !== 25 && id !== 27 && id !== 12) {
      return [1, 1, 1];
    }
    const key = `${id}:${x}:${z}`;
    const cached = this.tintCache.get(key);
    if (cached) return cached;
    const n = hash2(x, z, this.seed + id * 131);
    const m = this.noise.value2(x * 0.07, z * 0.07);
    let r = 1;
    let g = 1;
    let b = 1;
    // 群系差异化：草丛/树叶的底色先按所在群系的 grassColor/foliageColor 偏一次，
    // 再叠加原来的逐格噪声抖动——这样雪原的草丛发白、沼泽的树叶发暗黄绿，
    // 平原/森林保持原来偏翠绿的样子，不再是不管走到哪儿都完全一个颜色。
    let bias: [number, number, number] = [1, 1, 1];
    if (id === 1 || id === 26) {
      bias = World.hueMultiplier(BIOMES[this.biome(x, z)].grassColor, 0.55);
    } else if (id === 7) {
      bias = World.hueMultiplier(BIOMES[this.biome(x, z)].foliageColor, 0.55);
    }
    if (id === 1 || id === 26 || id === 27) {
      // 草：偏黄绿 ↔ 偏青绿
      const v = (n - 0.5) * 0.16 + (m - 0.5) * 0.2;
      r = 1 - v * 0.55;
      g = 1 + v * 0.22;
      b = 1 - v * 0.7;
    } else if (id === 7) {
      // 树叶：更明显的深浅斑块
      const v = (n - 0.5) * 0.26 + (m - 0.5) * 0.24;
      r = 1 - v * 0.6;
      g = 1 + v * 0.26;
      b = 1 - v * 0.75;
    } else if (id === 5) {
      const v = (n - 0.5) * 0.1;
      r = 1 + v * 0.4;
      g = 1 + v * 0.3;
      b = 1 - v * 0.3;
    } else if (id === 12) {
      const v = (n - 0.5) * 0.06;
      r = 1 - v * 0.3;
      g = 1;
      b = 1 + v * 0.4;
    } else {
      const v = (n - 0.5) * 0.18;
      r = 1 + v * 0.5;
      g = 1 - v * 0.3;
      b = 1 - v * 0.2;
    }
    const out: [number, number, number] = [r * bias[0], g * bias[1], b * bias[2]];
    if (this.tintCache.size > 80000) this.tintCache.clear();
    this.tintCache.set(key, out);
    return out;
  }

  setBlock(x: number, y: number, z: number, id: number, record = true) {
    if (y < 0 || y >= WORLD_HEIGHT) return;
    const cx = Math.floor(x / CHUNK_SIZE);
    const cz = Math.floor(z / CHUNK_SIZE);
    const c = this.chunks.get(this.key(cx, cz));
    if (!c || !c.generated) return;
    const lx = x - cx * CHUNK_SIZE;
    const lz = z - cz * CHUNK_SIZE;
    c.set(lx, y, lz, id);
    c.dirty = true;
    c.meshJob = null; // restart any in-progress mesh build with fresh block data
    this.skyCache.clear(); // 方块变了，射线求得的天空遮蔽需要重算
    if (record) this.edits.set(`${x},${y},${z}`, id);
    if (lx === 0) this.markDirty(cx - 1, cz);
    if (lx === CHUNK_SIZE - 1) this.markDirty(cx + 1, cz);
    if (lz === 0) this.markDirty(cx, cz - 1);
    if (lz === CHUNK_SIZE - 1) this.markDirty(cx, cz + 1);
  }

  /** 结构方块登记：默认受爆炸保护，避免村庄/遗迹被打烂 */
  structureBlocks = new Set<number>();
  protectStructures = true;
  /** 光线追踪：逐顶点射线求天空遮蔽与软阴影 */
  raytraced = false;
  private skyCache = new Map<number, number>();

  /** 单条射线的体素行进：命中不透明方块则被遮挡 */
  private rayBlocked(x: number, y: number, z: number, dx: number, dy: number, dz: number, maxSteps: number) {
    let px = x;
    let py = y;
    let pz = z;
    for (let i = 0; i < maxSteps; i++) {
      px += dx;
      py += dy;
      pz += dz;
      if (py >= WORLD_HEIGHT) return false; // 射出世界 = 见到天空
      if (this.isOpaqueAt(Math.floor(px), Math.floor(py), Math.floor(pz))) return true;
    }
    return false;
  }

  /** 锥采样天空可见度（0~1）：5 条射线向上散开，取平均 */
  skyVisibility(x: number, y: number, z: number): number {
    const key = (Math.floor(x) + 4096) * 67108864 + (Math.floor(y) + 512) * 8192 + (Math.floor(z) + 4096);
    const cached = this.skyCache.get(key);
    if (cached !== undefined) return cached;
    const dirs: [number, number, number][] = [
      [0, 1, 0],
      [0.42, 0.9, 0],
      [-0.42, 0.9, 0],
      [0, 0.9, 0.42],
      [0, 0.9, -0.42],
    ];
    let open = 0;
    for (const [dx, dy, dz] of dirs) {
      if (!this.rayBlocked(x + 0.5, y + 0.9, z + 0.5, dx * 0.55, dy * 0.55, dz * 0.55, 14)) open++;
    }
    const v = open / dirs.length;
    if (this.skyCache.size > 60000) this.skyCache.clear();
    this.skyCache.set(key, v);
    return v;
  }

  private structKey(x: number, y: number, z: number) {
    return (x + 4096) * 67108864 + (y + 512) * 8192 + (z + 4096);
  }

  /** Trigger an explosion centered at (ex, ey, ez). */
  explode(ex: number, ey: number, ez: number, radius: number): [number, number, number, number][] {
    const destroyed: [number, number, number, number][] = [];
    const rSq = radius * radius;
    const minX = Math.floor(ex - radius);
    const maxX = Math.ceil(ex + radius);
    const minY = Math.max(0, Math.floor(ey - radius));
    const maxY = Math.min(WORLD_HEIGHT - 1, Math.ceil(ey + radius));
    const minZ = Math.floor(ez - radius);
    const maxZ = Math.ceil(ez + radius);

    for (let x = minX; x <= maxX; x++) {
      for (let y = minY; y <= maxY; y++) {
        for (let z = minZ; z <= maxZ; z++) {
          const dx = x - ex;
          const dy = y - ey;
          const dz = z - ez;
          if (dx * dx + dy * dy + dz * dz <= rSq) {
            const id = this.getBlock(x, y, z);
            if (this.protectStructures && this.structureBlocks.has(this.structKey(x, y, z))) continue;
            if (id !== AIR && id !== 16) {
              this.setBlock(x, y, z, AIR);
              destroyed.push([x, y, z, id]);
            }
          }
        }
      }
    }

    const chunkRadius = Math.ceil((radius + 1) / CHUNK_SIZE);
    const ccx = Math.floor(ex / CHUNK_SIZE);
    const ccz = Math.floor(ez / CHUNK_SIZE);
    for (let dx = -chunkRadius; dx <= chunkRadius; dx++) {
      for (let dz = -chunkRadius; dz <= chunkRadius; dz++) {
        const c = this.getChunk(ccx + dx, ccz + dz);
        if (c) c.dirty = true;
      }
    }

    return destroyed;
  }

  private markDirty(cx: number, cz: number) {
    const c = this.chunks.get(this.key(cx, cz));
    if (c) {
      c.dirty = true;
      c.meshJob = null;
    }
  }

  /* ---------------- terrain generation (time-sliced) ---------------- */

  private heightKey(x: number, z: number) {
    return x * 100003 + z;
  }

  columnHeight(x: number, z: number): number {
    const cacheKey = this.heightKey(x, z);
    const cached = this.heightCache.get(cacheKey);
    if (cached !== undefined) return cached;
    let h: number;
    if (this.type === 'nether') {
      // 下界是满高度洞窟结构，没有"地表"这个概念；这里只给一个安全的中间值，
      // 供极少数仍会调用 columnHeight() 的通用逻辑（比如兜底找落脚点）使用。
      h = Math.floor(WORLD_HEIGHT / 2);
    } else if (this.type === 'flat') {
      h = 12;
    } else if (this.type === 'islands') {
      // Floating islands: most columns are void, some hold sky islands.
      const v = this.noise2.fbm2(x * 0.011 + 300, z * 0.011 - 500, 3);
      if (v <= 0.62) {
        h = 0;
      } else {
        h = 44 + (v - 0.62) * 105;
        h += this.noise.fbm2(x * 0.08, z * 0.08, 2) * 2 - 1;
        h = Math.min(h, WORLD_HEIGHT - 8);
      }
      // Guarantee the spawn area has a home island.
      const d = Math.hypot(x - 8, z - 8);
      if (d < 24) h = Math.max(h, 44 - d * 0.28);
      h = Math.floor(h);
    } else {
      const base = this.noise.fbm2(x * 0.012, z * 0.012, 4);
      const detail = this.noise.fbm2(x * 0.05, z * 0.05, 2);
      const mountain = Math.pow(Math.max(0, this.noise2.fbm2(x * 0.006, z * 0.006, 3) - 0.45) * 2.6, 2);
      h = 18 + base * 14 + detail * 3 + mountain * 26;
      h = Math.max(2, Math.min(WORLD_HEIGHT - 12, Math.floor(h)));
    }
    if (this.heightCache.size > 400000) this.heightCache.clear();
    this.heightCache.set(cacheKey, h);
    return h;
  }

  biome(x: number, z: number): BiomeType {
    if (this.type === 'flat' || this.type === 'islands' || this.type === 'nether') return 'plains';
    // 把这一列的实际地形高度传进去，海洋/海滩才能跟着真实海岸线走，
    // 而不是完全由温湿度噪声决定（后者会让海洋出现在陆地高处）。
    return getBiome(x, z, this.seed, this.columnHeight(x, z), SEA_LEVEL);
  }

  /** 恶地条带配色：用低频噪声在红/橙/白三种陶土之间过渡，做出水平层理感，
   *  而不是每隔固定 3 格就死板地切换一次颜色。 */
  private terracottaVariant(x: number, y: number, z: number): number {
    const variants = [46, 47, 48];
    const band = Math.floor(y / 3 + hash2(x, z, this.seed + 900) * 2.5);
    return variants[((band % variants.length) + variants.length) % variants.length];
  }

  /** Generates part of a chunk's terrain. Returns true when fully generated. */
  generateSlice(c: Chunk, budgetMs: number): boolean {
    if (c.generated) return true;
    if (this.type === 'nether') return this.generateNetherSlice(c, budgetMs);
    const ox = c.cx * CHUNK_SIZE;
    const oz = c.cz * CHUNK_SIZE;
    const t0 = performance.now();

    while (c.genCol < CHUNK_SIZE) {
      const lx = c.genCol;
      for (let lz = 0; lz < CHUNK_SIZE; lz++) {
        const x = ox + lx;
        const z = oz + lz;
        const h = this.columnHeight(x, z);
        if (this.type === 'islands' && h <= 0) continue;
        const biome = this.biome(x, z);
        // Floating islands: only fill the TOP of each column (tapered core),
        // leaving real void below so islands actually float in the sky.
        const yStart =
          this.type === 'islands'
            ? Math.max(0, h - 11 - Math.floor(hash2(x, z, this.seed + 909) * 7))
            : 0;
        const maxY = this.type === 'islands' ? h : Math.max(h, SEA_LEVEL);
        for (let y = yStart; y <= maxY; y++) {
          let id = AIR;
          if (y === 0 && this.type !== 'islands') id = 16;
          // 恶地条带：陶土层从表面往下延伸一段深度，切出去的悬崖也会有横向层理，
          // 而不是只有最表面一层薄皮是彩色、往下一挖就变回普通石头
          else if (biome === 'mesa' && y < h && y > h - 26) id = this.terracottaVariant(x, y, z);
          else if (y < h - 4) id = 3;
          else if (y < h) id = biome === 'desert' ? 5 : biome === 'mountains' ? 3 : 2;
          else if (y === h) {
            if (this.type === 'flat') id = 1;
            else if (biome === 'desert') id = 5;
            else if (biome === 'beach') id = 5;
            else if (biome === 'snow' || biome === 'tundra') id = 12;
            else if (biome === 'mesa') id = this.terracottaVariant(x, y, z);
            // 山地：海拔越高露出的岩石越多，山顶再盖一层雪，比"整座山糊着草皮"更有层次
            else if (biome === 'mountains') id = h > SEA_LEVEL + 34 ? 12 : h > SEA_LEVEL + 14 ? 3 : 1;
            else id = h <= SEA_LEVEL ? 5 : 1;
          } else if (y <= SEA_LEVEL && this.type !== 'islands') id = 11;

          if (id === 3 || id === 2) {
            const cave = this.noise.fbm3(x * 0.055, y * 0.08, z * 0.055, 3);
            if (cave > 0.7 && y > 1 && y < h - 2) id = AIR;
          }
          if (id === 3 && y < h - 6 && hash3(x, y, z, this.seed + 5) < 0.012) id = 21;
          if (id === 3 && y < 10 && hash3(x, y, z, this.seed + 9) < 0.006) id = 13;
          if (id !== AIR) c.set(lx, y, lz, id);
        }

        // surface decoration
        const surface = c.get(lx, h, lz);
        if (biome === 'mushroom_fields' && h > SEA_LEVEL && surface === 1) {
          // 蘑菇岛没有正常的树/花——遍地都是巨型蘑菇（这里简化成大量摆放装饰蘑菇方块）
          const rv = hash2(x, z, this.seed + 31);
          if (rv > 0.85) c.set(lx, h + 1, lz, 27);
        } else if (h > SEA_LEVEL && (surface === 1 || surface === 12)) {
          const rv = hash2(x, z, this.seed + 31);
          // 树木密度按群系数据表来（丛林/森林明显比平原/热带草原密），
          // 之前所有群系共用同一个 1% 阈值，导致丛林和草原看起来一样稀疏。
          const treeDensity = BIOMES[biome]?.trees.density ?? 0.05;
          // 原来平原（density 0.05）大约是 1% 的落树概率，按同一比例换算到其它群系，
          // 并设一个上限，免得丛林密到走不动路。
          const treeThreshold = 1 - Math.min(0.16, treeDensity * 0.2);
          if (rv > treeThreshold) {
            this.plantTree(c, lx, h + 1, lz, biome);
          } else if (rv > 0.972) {
            c.set(lx, h + 1, lz, 26); // 草丛
          } else if (rv > 0.966) {
            c.set(lx, h + 1, lz, hash2(x, z, this.seed + 77) > 0.5 ? 24 : 25); // 花
          } else if (rv > 0.963) {
            c.set(lx, h + 1, lz, 27); // 蘑菇
          } else if (rv > 0.9615) {
            c.set(lx, h + 1, lz, 22); // 南瓜
          }
        }
        // Desert gets cactus instead of any crystal!
        if (biome === 'desert' && h > SEA_LEVEL) {
          const rv = hash2(x, z, this.seed + 55);
          if (rv > 0.993) {
            const height = 2 + Math.floor(hash2(x, z, this.seed + 56) * 2);
            for (let i = 1; i <= height; i++) c.set(lx, h + i, lz, 29);
          }
        }
      }
      c.genCol++;
      if (performance.now() - t0 > budgetMs) return false;
    }

    this.generateStructure(c);
    for (const [k, id] of this.edits) {
      const [ex, ey, ez] = k.split(',').map(Number);
      if (Math.floor(ex / CHUNK_SIZE) === c.cx && Math.floor(ez / CHUNK_SIZE) === c.cz) {
        c.set(ex - c.cx * CHUNK_SIZE, ey, ez - c.cz * CHUNK_SIZE, id);
      }
    }
    c.generated = true;
    c.dirty = true;
    return true;
  }

  /** 下界地形生成：满高度洞窟结构，上下用基岩封住，中间是下界岩夹着大片熔岩空腔。
   *  跟主世界完全独立的一套逻辑，不复用 columnHeight/biome 那套"地表"概念。 */
  private generateNetherSlice(c: Chunk, budgetMs: number): boolean {
    const ox = c.cx * CHUNK_SIZE;
    const oz = c.cz * CHUNK_SIZE;
    const t0 = performance.now();

    while (c.genCol < CHUNK_SIZE) {
      const lx = c.genCol;
      for (let lz = 0; lz < CHUNK_SIZE; lz++) {
        const x = ox + lx;
        const z = oz + lz;
        for (let y = 0; y < WORLD_HEIGHT; y++) {
          let id = AIR;
          if (y === 0 || y === WORLD_HEIGHT - 1) {
            id = 16; // 基岩地板/天花板，把整个下界圈成一个封闭空间
          } else {
            // 两层噪声叠加：macro 决定"这一片是大洞穴区还是实心区"，
            // density 在实心区里再挖出细节洞窟——比主世界的洞穴噪声开得多，
            // 做出下界那种大片开阔空腔夹着裂缝的感觉，而不是零星小洞。
            const density = this.noise.fbm3(x * 0.045, y * 0.07, z * 0.045, 3);
            const macro = this.noise2.fbm3(x * 0.018, y * 0.03, z * 0.018, 2);
            const carved = macro > 0.6 || density > 0.58;
            if (!carved) {
              id = 44; // 下界岩
            } else if (y < 9) {
              id = 17; // 低海拔的空腔直接是熔岩海
            }
          }
          if (id !== AIR) c.set(lx, y, lz, id);
        }
        // 洞穴顶上偶尔挂一撮荧光石照明，找"下面是空气、上面是下界岩"的第一个位置就够了
        for (let y = 10; y < WORLD_HEIGHT - 2; y++) {
          if (c.get(lx, y, lz) === AIR && c.get(lx, y + 1, lz) === 44) {
            if (hash3(x, y, z, this.seed + 601) > 0.9975) c.set(lx, y, lz, 13);
            break;
          }
        }
      }
      c.genCol++;
      if (performance.now() - t0 > budgetMs) return false;
    }

    for (const [k, id] of this.edits) {
      const [ex, ey, ez] = k.split(',').map(Number);
      if (Math.floor(ex / CHUNK_SIZE) === c.cx && Math.floor(ez / CHUNK_SIZE) === c.cz) {
        c.set(ex - c.cx * CHUNK_SIZE, ey, ez - c.cz * CHUNK_SIZE, id);
      }
    }
    c.generated = true;
    c.dirty = true;
    return true;
  }

  /* ---------------- 下界传送门 ---------------- */

  /** 通用的"检测一个 4宽x5高 黑曜石框、内部 2x3 净空"的扫描器，在一个抽象的 (u,v) 平面坐标系里工作，
   *  由调用方决定 u/v 分别对应世界坐标的哪两根轴，这样 X 朝向和 Z 朝向的框架能复用同一份逻辑。
   *  找到就把内部填成传送门方块，返回 true。 */
  private tryFrame(
    readAt: (u: number, v: number) => number,
    writeAt: (u: number, v: number, id: number) => void,
    placedU: number,
    placedV: number,
  ): boolean {
    const W = 4;
    const H = 5;
    for (let ou = placedU - W + 1; ou <= placedU; ou++) {
      for (let ov = placedV - H + 1; ov <= placedV; ov++) {
        let ok = true;
        for (let du = 0; du < W && ok; du++) {
          for (let dv = 0; dv < H && ok; dv++) {
            const border = du === 0 || du === W - 1 || dv === 0 || dv === H - 1;
            const id = readAt(ou + du, ov + dv);
            if (border) {
              if (id !== 43) ok = false; // 边框必须是黑曜石
            } else if (id !== AIR && id !== 45) {
              ok = false; // 内部必须是空气（允许已经是传送门——支持重新点燃）
            }
          }
        }
        if (ok) {
          for (let du = 1; du < W - 1; du++) {
            for (let dv = 1; dv < H - 1; dv++) writeAt(ou + du, ov + dv, 45);
          }
          return true;
        }
      }
    }
    return false;
  }

  /** 玩家刚放下一块黑曜石时调用：检查这块黑曜石有没有凑成一个合法的传送门框，
   *  两种朝向（沿 X 轴的竖直面 / 沿 Z 轴的竖直面）都会尝试。 */
  tryIgnitePortal(x: number, y: number, z: number): boolean {
    const foundAlongZ = this.tryFrame(
      (u, v) => this.getBlock(u, v, z),
      (u, v, id) => this.setBlock(u, v, z, id),
      x,
      y,
    );
    if (foundAlongZ) return true;
    return this.tryFrame(
      (u, v) => this.getBlock(x, v, u),
      (u, v, id) => this.setBlock(x, v, u, id),
      z,
      y,
    );
  }

  /** 传送落地时调用：优先找附近现成的传送门站过去；找不到就地清出空间、造一个新的。
   *  返回玩家应该落脚的世界坐标。 */
  ensurePortalNear(tx: number, tz: number): THREE.Vector3 {
    const tcx = Math.floor(tx / CHUNK_SIZE);
    const tcz = Math.floor(tz / CHUNK_SIZE);
    for (let dcx = -1; dcx <= 1; dcx++) {
      for (let dcz = -1; dcz <= 1; dcz++) this.forceGenerate(tcx + dcx, tcz + dcz);
    }

    const centerY =
      this.type === 'nether' ? 34 : Math.min(WORLD_HEIGHT - 6, this.surfaceY(tx, tz) + 1);

    let found: { x: number; y: number; z: number } | null = null;
    for (let dx = -8; dx <= 8 && !found; dx++) {
      for (let dy = -10; dy <= 10 && !found; dy++) {
        for (let dz = -8; dz <= 8 && !found; dz++) {
          if (this.getBlock(tx + dx, centerY + dy, tz + dz) === 45) {
            found = { x: tx + dx, y: centerY + dy, z: tz + dz };
          }
        }
      }
    }

    let px: number, py: number, pz: number;
    if (found) {
      px = found.x;
      py = found.y;
      pz = found.z;
    } else {
      const by = centerY;
      // 先清空 4宽x5高（外加两侧各留一格）的空间，免得造框的地方本来就是实心岩层
      for (let du = -1; du <= 4; du++) {
        for (let dv = 0; dv <= 4; dv++) this.setBlock(tx + du, by + dv, tz, AIR);
      }
      for (let du = 0; du < 4; du++) {
        for (let dv = 0; dv < 5; dv++) {
          const border = du === 0 || du === 3 || dv === 0 || dv === 4;
          this.setBlock(tx + du, by + dv, tz, border ? 43 : 45);
        }
      }
      px = tx + 1;
      py = by + 1;
      pz = tz;
    }
    return new THREE.Vector3(px + 0.5, py + 0.1, pz + 0.5);
  }

  /* ---------------- structures ---------------- */

  private generateStructure(c: Chunk) {
    // Floating islands: only build structures on islands big enough to hold them.
    if (this.type === 'islands') {
      const ox = c.cx * CHUNK_SIZE;
      const oz = c.cz * CHUNK_SIZE;
      let solid = true;
      for (let x = 1; x <= 14 && solid; x++) {
        for (let z = 1; z <= 14; z++) {
          if (this.columnHeight(ox + x, oz + z) <= 0) {
            solid = false;
            break;
          }
        }
      }
      if (!solid) return;
    }
    const roll = hash2(c.cx, c.cz, this.seed + 701);
    const roll2 = hash2(c.cz, c.cx, this.seed + 977);
    const ox = c.cx * CHUNK_SIZE;
    const oz = c.cz * CHUNK_SIZE;
    const biome = this.biome(ox + 8, oz + 8);
    let type: StructureType | null = null;

    // 出生点周围固定三处，保证新手一定看得到
    if (c.cx === 1 && c.cz === 0) type = 'village';
    else if (c.cx === -1 && c.cz === 1) type = 'ruin';
    else if (c.cx === 0 && c.cz === -2) type = 'altar';
    // 其余区块：总计约 6%（之前 20% 太密），且按群系分派不同建筑
    else if (roll > 0.9925) type = 'village';
    else if (roll > 0.9875) type = 'altar';
    else if (roll > 0.9825) type = 'ruin';
    else if (roll > 0.9775) type = biome === 'desert' ? 'temple' : 'tower';
    else if (roll > 0.9725) type = biome === 'snow' ? 'igloo' : 'camp';
    else if (roll > 0.9675) type = biome === 'snow' ? 'igloo' : roll2 > 0.5 ? 'treehouse' : 'hut';
    else if (roll > 0.9625) type = 'mineshaft';

    if (!type) return;
    const ctx = this.structCtx(c);
    switch (type) {
      case 'village':
        buildVillage(ctx);
        break;
      case 'ruin':
        buildRuin(ctx);
        break;
      case 'altar':
        buildAltar(ctx);
        break;
      case 'temple':
        buildTemple(ctx);
        break;
      case 'igloo':
        buildIgloo(ctx);
        break;
      case 'tower':
        buildTower(ctx);
        break;
      case 'camp':
        buildCamp(ctx);
        break;
      case 'mineshaft':
        buildMineshaft(ctx);
        break;
      case 'treehouse':
        buildTreehouse(ctx);
        break;
      case 'hut':
        buildHut(ctx);
        break;
    }
  }

  /** 供 structures.ts 使用的建造上下文 */
  private structCtx(c: Chunk): StructCtx {
    const ox = c.cx * CHUNK_SIZE;
    const oz = c.cz * CHUNK_SIZE;
    return {
      seed: this.seed,
      cx: c.cx,
      cz: c.cz,
      set: (x, y, z, id) => {
        if (x < 0 || x >= CHUNK_SIZE || z < 0 || z >= CHUNK_SIZE) return;
        if (y < 0 || y >= WORLD_HEIGHT) return;
        c.set(x, y, z, id);
        if (id !== AIR) this.structureBlocks.add(this.structKey(ox + x, y, oz + z));
      },
      height: (wx, wz) => this.columnHeight(wx, wz),
      chest: (x, y, z, type) => {
        if (x < 0 || x >= CHUNK_SIZE || z < 0 || z >= CHUNK_SIZE) return;
        c.set(x, y, z, 28);
        this.structureBlocks.add(this.structKey(ox + x, y, oz + z));
        this.chestTypes.set(`${ox + x},${y},${oz + z}`, type);
      },
      mark: (type, x, y, z) => {
        this.structures.set(`${type}:${c.cx},${c.cz}`, { type, x: ox + x, y, z: oz + z });
      },
    };
  }

  private plantTree(c: Chunk, lx: number, y: number, lz: number, biome: string) {
    const leafId = 7;
    const seedBase = lx + c.cx * 16 + (lz + c.cz * 16) * 811;
    if (biome === 'snow' || biome === 'taiga' || biome === 'mountains') {
      // 雪原/针叶林/山地：矮一截、锥形树冠（一层比一层收窄），更像针叶林的松树剪影
      const h = 4 + Math.floor(hash2(lx + c.cx * 16, lz + c.cz * 16, this.seed + 3) * 2);
      for (let i = 0; i < h; i++) c.set(lx, y + i, lz, 6);
      const tiers = [2, 2, 1, 1, 0];
      for (let t = 0; t < tiers.length; t++) {
        const r = tiers[t];
        const yy = y + h - 3 + t;
        for (let dx = -r; dx <= r; dx++) {
          for (let dz = -r; dz <= r; dz++) {
            if (Math.abs(dx) === r && Math.abs(dz) === r && r > 1) continue;
            const x = lx + dx;
            const z = lz + dz;
            if (x < 0 || x >= CHUNK_SIZE || z < 0 || z >= CHUNK_SIZE) continue;
            if (c.get(x, yy, z) === AIR) c.set(x, yy, z, leafId);
          }
        }
      }
      return;
    }
    if (biome === 'swamp') {
      // 沼泽：矮粗、树冠又宽又扁，稍微下垂，一股湿地老树的感觉
      const h = 3 + Math.floor(hash2(seedBase, 0, this.seed + 3) * 2);
      for (let i = 0; i < h; i++) c.set(lx, y + i, lz, 6);
      for (let dy = -1; dy <= 1; dy++) {
        const r = dy <= 0 ? 3 : 2;
        for (let dx = -r; dx <= r; dx++) {
          for (let dz = -r; dz <= r; dz++) {
            if (Math.abs(dx) === r && Math.abs(dz) === r) continue;
            const x = lx + dx;
            const z = lz + dz;
            if (x < 0 || x >= CHUNK_SIZE || z < 0 || z >= CHUNK_SIZE) continue;
            const yy = y + h - 1 + dy;
            if (c.get(x, yy, z) === AIR) c.set(x, yy, z, leafId);
          }
        }
      }
      return;
    }
    // 平原/森林/其它：原来的圆冠大树
    const h = 4 + Math.floor(hash2(lx + c.cx * 16, lz + c.cz * 16, this.seed + 3) * 3);
    for (let i = 0; i < h; i++) c.set(lx, y + i, lz, 6);
    for (let dy = -2; dy <= 1; dy++) {
      const r = dy <= -1 ? 2 : 1;
      for (let dx = -r; dx <= r; dx++) {
        for (let dz = -r; dz <= r; dz++) {
          if (Math.abs(dx) === r && Math.abs(dz) === r && r > 1) continue;
          const x = lx + dx;
          const z = lz + dz;
          if (x < 0 || x >= CHUNK_SIZE || z < 0 || z >= CHUNK_SIZE) continue;
          const yy = y + h + dy;
          if (c.get(x, yy, z) === AIR) c.set(x, yy, z, leafId);
        }
      }
    }
    if (lx >= 0 && lx < CHUNK_SIZE && lz >= 0 && lz < CHUNK_SIZE) c.set(lx, y + h + 1, lz, leafId);
  }

  /* ---------------- meshing (time-sliced) ---------------- */

  /** Builds part of a chunk's mesh. Returns true when fully meshed. */
  buildChunkMeshSlice(c: Chunk, budgetMs: number): boolean {
    if (c.meshed && !c.dirty) return true;
    // NOTE: an in-progress meshJob is only invalidated by setBlock/markDirty
    // (which null it). Never restart based on `dirty` here, or a multi-frame
    // rebuild would be killed every frame and blocks would never re-render.

    if (!c.meshJob) {
      const topMap = new Int16Array(CHUNK_SIZE * CHUNK_SIZE);
      for (let lx = 0; lx < CHUNK_SIZE; lx++) {
        for (let lz = 0; lz < CHUNK_SIZE; lz++) {
          let top = -1;
          for (let y = WORLD_HEIGHT - 1; y >= 0; y--) {
            if (getBlock(c.get(lx, y, lz)).opaque) {
              top = y;
              break;
            }
          }
          topMap[lx + lz * CHUNK_SIZE] = top;
        }
      }
      c.meshJob = {
        builders: {
          opaque: new GeomBuilder(),
          cutout: new GeomBuilder(),
          transparent: new GeomBuilder(),
          glow: new GeomBuilder(),
        },
        topMap,
        y: 0,
        lz: 0,
        lx: 0,
      };
    }

    const job = c.meshJob;
    const ox = c.cx * CHUNK_SIZE;
    const oz = c.cz * CHUNK_SIZE;
    const t0 = performance.now();

    while (job.y < WORLD_HEIGHT) {
      while (job.lz < CHUNK_SIZE) {
        if (performance.now() - t0 > budgetMs) return false;
        const lz = job.lz;
        for (let lx = job.lx; lx < CHUNK_SIZE; lx++) {
          const id = c.get(lx, job.y, lz);
          if (id === AIR) continue;
          const def = BLOCKS[id];
          const wx = ox + lx;
          const wz = oz + lz;
          // 会发光的方块（水晶除外——它走真正的折射/色散材质，不需要再叠一层
          // 自发光）单独进 'glow' 通道，这样它们才有真正的自发光贴图，
          // 而不是靠 AO 顶到的一点点亮度提示。
          const b = def.light && id !== 15 ? job.builders.glow : job.builders[def.pass];
          const covered = job.y < job.topMap[lx + lz * CHUNK_SIZE] - 1;
          const skyMul = def.light ? 1 : covered ? 0.66 : 1;

          if (def.render === 'cross') {
            this.emitCross(b, wx, job.y, wz, def.tiles[0], skyMul);
            continue;
          }

          const liquidTop = !!def.liquid && this.getBlock(wx, job.y + 1, wz) !== id;

          for (let f = 0; f < 6; f++) {
            const face = FACES[f];
            const nx = wx + face.n[0];
            const ny = job.y + face.n[1];
            const nz = wz + face.n[2];
            const nb = this.getBlock(nx, ny, nz);
            const nbDef = getBlock(nb);
            if (nbDef.opaque) continue;
            if (nb === id && !def.opaque) continue;
            if (def.liquid && nbDef.liquid) continue;

            const tileIdx = def.tiles[face.tile];
            const [u0, v0, u1, v1] = tileUV(tileIdx);
            const start = b.pos.length / 3;
            const aoVals: number[] = [];

            for (let corner = 0; corner < 4; corner++) {
              const a = corner === 1 || corner === 2 ? 1 : 0;
              const bb = corner === 2 || corner === 3 ? 1 : 0;
              let vx = face.base[0] + face.u[0] * a + face.v[0] * bb;
              let vy = face.base[1] + face.u[1] * a + face.v[1] * bb;
              let vz = face.base[2] + face.u[2] * a + face.v[2] * bb;
              if (liquidTop && vy === 1) vy = 0.88;

              let ao = 3;
              if (def.opaque || def.pass === 'cutout') {
                const du = a ? 1 : -1;
                const dv = bb ? 1 : -1;
                const s1 = this.isOpaqueAt(
                  wx + face.n[0] + face.u[0] * du,
                  job.y + face.n[1] + face.u[1] * du,
                  wz + face.n[2] + face.u[2] * du,
                )
                  ? 1
                  : 0;
                const s2 = this.isOpaqueAt(
                  wx + face.n[0] + face.v[0] * dv,
                  job.y + face.n[1] + face.v[1] * dv,
                  wz + face.n[2] + face.v[2] * dv,
                )
                  ? 1
                  : 0;
                const cr = this.isOpaqueAt(
                  wx + face.n[0] + face.u[0] * du + face.v[0] * dv,
                  job.y + face.n[1] + face.u[1] * du + face.v[1] * dv,
                  wz + face.n[2] + face.u[2] * du + face.v[2] * dv,
                )
                  ? 1
                  : 0;
                ao = s1 && s2 ? 0 : 3 - (s1 + s2 + cr);
              }
              aoVals.push(ao);

              b.pos.push(wx + vx, job.y + vy, wz + vz);
              b.nor.push(face.n[0], face.n[1], face.n[2]);
              const tu = face.swap ? bb : a;
              const tv = face.swap ? a : bb;
              b.uv.push(u0 + (u1 - u0) * tu, v0 + (v1 - v0) * tv);
              // 光线追踪：用射线求得的天空可见度替代简单的“是否被盖住”判断，
              // 得到树冠下、屋檐下、洞口的柔和渐变阴影
              const sky = this.raytraced
                ? 0.32 + 0.68 * this.skyVisibility(wx, job.y, wz)
                : skyMul;
              const baseLight = face.shade * AO_LEVELS[ao] * sky;
              // 自发光方块（荧光石/水晶/岩浆等）不受环境光遮蔽/天空可见度影响，
              // 始终保持与自身发光等级对应的最低亮度，看起来才像真的在发光
              const light = def.light ? Math.max(baseLight, 0.55 + def.light * 0.45) : baseLight;
              // 逐列色彩扰动：让草地/树叶不再是死板的一片纯绿。
              // 草方块只有顶面是草，侧面/底面是泥土，不能一起染绿。
              const tint = id === 1 && f !== 2 ? NO_TINT : this.colorTint(id, wx, wz);
              b.col.push(light * tint[0], light * tint[1], light * tint[2]);
            }

            if (aoVals[0] + aoVals[2] > aoVals[1] + aoVals[3]) {
              b.idxs.push(start, start + 1, start + 2, start, start + 2, start + 3);
            } else {
              b.idxs.push(start + 1, start + 2, start + 3, start + 1, start + 3, start);
            }
          }
        }
        job.lx = 0;
        job.lz++;
      }
      job.lz = 0;
      job.y++;
    }

    // done: swap geometries into meshes
    const builders = job.builders;
    (Object.keys(builders) as Pass[]).forEach((pass) => {
      const builder = builders[pass];
      const existing = c.meshes[pass];
      if (builder.empty) {
        if (existing) {
          this.group.remove(existing);
          existing.geometry.dispose();
          delete c.meshes[pass];
        }
        return;
      }
      const geo = builder.toGeometry();
      if (existing) {
        existing.geometry.dispose();
        existing.geometry = geo;
      } else {
        const mesh = new THREE.Mesh(geo, this.materials[pass]);
        mesh.renderOrder = pass === 'transparent' ? 2 : 0;
        mesh.frustumCulled = true;
        // 不透明地形投射并接收阴影；cutout（树叶/花草/火把）现在也投射阴影——
        // 树叶用的是 alphaTest 材质，three.js 的阴影贴图会自动尊重 alphaTest/贴图的
        // 透明部分，所以投出来的是"树叶形状"的斑驳阴影，而不是一整块方块的实心阴影。
        // 之前关掉是为了避免阴影瑕疵，这里配合下面调大的 normalBias 一起处理。
        mesh.castShadow = pass === 'opaque' || pass === 'cutout';
        mesh.receiveShadow = true;
        // 泛光层用的图层编号 1，要跟 engine.ts 里 Game.BLOOM_LAYER 保持一致：
        // 只有走这个通道的方块（火把/荧光石/岩浆……）会被 selective bloom
        // 处理，太阳、雪地这些普通亮色不会被一起吹起来。
        if (pass === 'glow') mesh.layers.enable(1);
        c.meshes[pass] = mesh;
        this.group.add(mesh);
      }
    });
    c.meshJob = null;
    c.dirty = false;
    c.meshed = true;
    return true;
  }

  private emitCross(b: GeomBuilder, x: number, y: number, z: number, tile: number, light: number) {
    const [u0, v0, u1, v1] = tileUV(tile);
    const s = 0.15;
    const quads: [number, number, number, number][] = [
      [s, s, 1 - s, 1 - s],
      [1 - s, s, s, 1 - s],
    ];
    const l = 0.92 * light;
    for (const [x0, z0, x1, z1] of quads) {
      for (let side = 0; side < 2; side++) {
        const start = b.pos.length / 3;
        const pts: [number, number, number][] = [
          [x + x0, y, z + z0],
          [x + x1, y, z + z1],
          [x + x1, y + 1, z + z1],
          [x + x0, y + 1, z + z0],
        ];
        const uvs: [number, number][] = [
          [u0, v0],
          [u1, v0],
          [u1, v1],
          [u0, v1],
        ];
        for (let i = 0; i < 4; i++) {
          const p = pts[i];
          b.pos.push(p[0], p[1], p[2]);
          b.nor.push(0, 1, 0);
          b.uv.push(uvs[i][0], uvs[i][1]);
          b.col.push(l, l, l);
        }
        if (side === 0) b.idxs.push(start, start + 1, start + 2, start, start + 2, start + 3);
        else b.idxs.push(start, start + 2, start + 1, start, start + 3, start + 2);
      }
    }
  }

  disposeChunk(c: Chunk) {
    for (const pass of Object.keys(c.meshes) as Pass[]) {
      const m = c.meshes[pass]!;
      this.group.remove(m);
      m.geometry.dispose();
    }
    c.meshes = {};
    c.meshJob = null;
    this.chunks.delete(this.key(c.cx, c.cz));
  }

  /* ---------------- raycast ---------------- */

  raycast(origin: THREE.Vector3, dir: THREE.Vector3, maxDist = 6): RaycastHit | null {
    let x = Math.floor(origin.x);
    let y = Math.floor(origin.y);
    let z = Math.floor(origin.z);
    const stepX = Math.sign(dir.x);
    const stepY = Math.sign(dir.y);
    const stepZ = Math.sign(dir.z);
    const tDeltaX = stepX !== 0 ? Math.abs(1 / dir.x) : Infinity;
    const tDeltaY = stepY !== 0 ? Math.abs(1 / dir.y) : Infinity;
    const tDeltaZ = stepZ !== 0 ? Math.abs(1 / dir.z) : Infinity;
    const boundary = (p: number, s: number) => (s > 0 ? Math.floor(p) + 1 - p : p - Math.floor(p));
    let tMaxX = stepX !== 0 ? boundary(origin.x, stepX) * tDeltaX : Infinity;
    let tMaxY = stepY !== 0 ? boundary(origin.y, stepY) * tDeltaY : Infinity;
    let tMaxZ = stepZ !== 0 ? boundary(origin.z, stepZ) * tDeltaZ : Infinity;
    let nx = 0;
    let ny = 0;
    let nz = 0;
    let t = 0;

    for (let i = 0; i < 256; i++) {
      const id = this.getBlock(x, y, z);
      const def = getBlock(id);
      if (id !== AIR && !def.liquid) {
        return { x, y, z, nx, ny, nz, id, distance: t };
      }
      if (tMaxX < tMaxY && tMaxX < tMaxZ) {
        x += stepX;
        t = tMaxX;
        tMaxX += tDeltaX;
        nx = -stepX;
        ny = 0;
        nz = 0;
      } else if (tMaxY < tMaxZ) {
        y += stepY;
        t = tMaxY;
        tMaxY += tDeltaY;
        nx = 0;
        ny = -stepY;
        nz = 0;
      } else {
        z += stepZ;
        t = tMaxZ;
        tMaxZ += tDeltaZ;
        nx = 0;
        ny = 0;
        nz = -stepZ;
      }
      if (t > maxDist) break;
    }
    return null;
  }

  /** Highest non-air block at a column (for spawning). Generates the chunk if needed. */
  surfaceY(x: number, z: number): number {
    const cx = Math.floor(x / CHUNK_SIZE);
    const cz = Math.floor(z / CHUNK_SIZE);
    const c = this.getChunk(cx, cz);
    if (!c || !c.generated) this.forceGenerate(cx, cz);
    for (let y = WORLD_HEIGHT - 1; y >= 0; y--) {
      const id = this.getBlock(x, y, z);
      if (id !== AIR && getBlock(id).solid) return y + 1;
    }
    return SEA_LEVEL + 1;
  }
}
