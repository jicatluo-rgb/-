/** 物品堆叠、工具与容器尺寸定义 */

import { getBlock } from './blocks';

export interface ItemStack {
  id: number; // block id, or 100+ tool id
  count: number; // block: stack size; tool: remaining durability
}

export const MAX_STACK = 64;
export const INV_SIZE = 36; // 9 hotbar + 27 inventory
export const CHEST_SIZE = 27;

export function emptyInventory(): (ItemStack | null)[] {
  return Array.from({ length: INV_SIZE }, () => null);
}

/* ---------------- 工具 ---------------- */

export type ToolType = 'pickaxe' | 'axe' | 'shovel' | 'sword' | 'gun';
export type ToolMaterial = 'wood' | 'stone' | 'crystal';

export interface ToolDef {
  id: number;
  name: string;
  type: ToolType;
  material: ToolMaterial;
  durability: number;
  /** mining speed multiplier on matching blocks */
  speed: number;
  /** attack damage */
  damage: number;
  /** 枪械：射程 */
  range?: number;
}

export const TOOLS: ToolDef[] = [
  { id: 100, name: '木镐', type: 'pickaxe', material: 'wood', durability: 80, speed: 2.4, damage: 3 },
  { id: 101, name: '石镐', type: 'pickaxe', material: 'stone', durability: 160, speed: 3.6, damage: 4 },
  { id: 102, name: '水晶镐', type: 'pickaxe', material: 'crystal', durability: 320, speed: 6.5, damage: 5 },
  { id: 103, name: '石斧', type: 'axe', material: 'stone', durability: 160, speed: 3.6, damage: 4 },
  { id: 104, name: '石铲', type: 'shovel', material: 'stone', durability: 130, speed: 3.6, damage: 2 },
  { id: 105, name: '木剑', type: 'sword', material: 'wood', durability: 100, speed: 1, damage: 5 },
  { id: 106, name: '石剑', type: 'sword', material: 'stone', durability: 190, speed: 1, damage: 7 },
  { id: 107, name: '水晶剑', type: 'sword', material: 'crystal', durability: 340, speed: 1, damage: 11 },
  { id: 108, name: '木枪', type: 'gun', material: 'wood', durability: 120, speed: 1, damage: 6, range: 24 },
  { id: 109, name: '步枪', type: 'gun', material: 'stone', durability: 260, speed: 1, damage: 10, range: 40 },
  { id: 110, name: '水晶炮', type: 'gun', material: 'crystal', durability: 400, speed: 1, damage: 18, range: 60 },
];

/** 非方块物品定义（合成材料 / 弹药） */
export interface ItemDef {
  id: number;
  name: string;
  emoji: string;
  /** 弹药伤害加成 */
  ammoDamage?: number;
}

export const ITEMS: ItemDef[] = [
  { id: 201, name: '木棍', emoji: '🪵' },
  { id: 202, name: '枪管', emoji: '🔩' },
  { id: 203, name: '击发器', emoji: '⚙️' },
  { id: 204, name: '木弹', emoji: '🟤', ammoDamage: 0 },
  { id: 205, name: '铁弹', emoji: '⚪', ammoDamage: 4 },
  { id: 206, name: '水晶弹', emoji: '🔷', ammoDamage: 9 },
];

export function getItem(id: number): ItemDef | undefined {
  return ITEMS.find((i) => i.id === id);
}

export function isAmmo(id: number): boolean {
  return id === 204 || id === 205 || id === 206;
}

export function isToolId(id: number): boolean {
  return id >= 100 && id < 200;
}

/** 非方块物品（木棍等合成材料） */
export function isItemId(id: number): boolean {
  return id >= 200;
}

export const STICK_ID = 201;

export function getTool(id: number): ToolDef | undefined {
  return TOOLS.find((tool) => tool.id === id);
}

/** 显示名：工具 / 物品 / 方块 */
export function getItemName(id: number): string {
  const tool = getTool(id);
  if (tool) return tool.name;
  const item = getItem(id);
  if (item) return item.name;
  return getBlock(id).name;
}
