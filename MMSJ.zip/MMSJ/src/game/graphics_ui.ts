/** 画质选项UI界面 */

import { GraphicsSettings, DEFAULT_GRAPHICS_SETTINGS, LOW_GRAPHICS_SETTINGS, HIGH_GRAPHICS_SETTINGS, GraphicsManager } from './graphics';

export class GraphicsOptionsUI {
  private container: HTMLElement;
  private graphicsManager: GraphicsManager;
  private settings: GraphicsSettings;
  private isVisible: boolean = false;

  constructor(container: HTMLElement, graphicsManager: GraphicsManager) {
    this.container = container;
    this.graphicsManager = graphicsManager;
    this.settings = graphicsManager.getSettings();
    this.createUI();
  }

  private createUI() {
    // 创建主面板
    const panel = document.createElement('div');
    panel.id = 'graphics-panel';
    panel.style.cssText = `
      display: none;
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: rgba(20, 20, 30, 0.95);
      border: 3px solid #ffd166;
      border-radius: 16px;
      padding: 24px;
      min-width: 500px;
      max-width: 600px;
      max-height: 80vh;
      overflow-y: auto;
      z-index: 1000;
      font-family: 'Arial', sans-serif;
    `;

    // 标题
    const title = document.createElement('h2');
    title.textContent = '画质设置';
    title.style.cssText = `
      margin: 0 0 20px 0;
      color: #ffd166;
      font-size: 24px;
      text-align: center;
    `;
    panel.appendChild(title);

    // 预设按钮组
    const presetGroup = this.createSection('画质预设');
    const presetButtons = document.createElement('div');
    presetButtons.style.cssText = 'display: flex; gap: 10px; margin-bottom: 20px;';
    
    const lowBtn = this.createPresetButton('低画质', () => this.applyPreset(LOW_GRAPHICS_SETTINGS));
    const medBtn = this.createPresetButton('中画质', () => this.applyPreset(DEFAULT_GRAPHICS_SETTINGS));
    const highBtn = this.createPresetButton('高画质', () => this.applyPreset(HIGH_GRAPHICS_SETTINGS));
    
    presetButtons.appendChild(lowBtn);
    presetButtons.appendChild(medBtn);
    presetButtons.appendChild(highBtn);
    presetGroup.appendChild(presetButtons);
    panel.appendChild(presetGroup);

    // 基础画质设置
    const basicGroup = this.createSection('基础画质');
    basicGroup.appendChild(this.createSlider('渲染距离', 'renderDistance', 2, 12, 1, this.settings.renderDistance));
    basicGroup.appendChild(this.createSlider('像素比', 'pixelRatio', 0.5, 2.0, 0.25, this.settings.pixelRatio));
    basicGroup.appendChild(this.createCheckbox('抗锯齿', 'antialias', this.settings.antialias));
    panel.appendChild(basicGroup);

    // 光影设置
    const shadowGroup = this.createSection('光影效果');
    shadowGroup.appendChild(this.createCheckbox('阴影', 'shadows', this.settings.shadows));
    shadowGroup.appendChild(this.createSelect('阴影质量', 'shadowQuality', ['low', 'medium', 'high'], this.settings.shadowQuality));
    panel.appendChild(shadowGroup);

    // 实验性功能（默认关闭）
    const experimentalGroup = this.createSection('实验性功能（可能影响性能）');
    experimentalGroup.appendChild(this.createCheckbox('屏幕空间环境光遮蔽 (SSAO)', 'experimentalSSAO', this.settings.experimentalSSAO));
    experimentalGroup.appendChild(this.createCheckbox('泛光效果 (Bloom)', 'experimentalBloom', this.settings.experimentalBloom));
    experimentalGroup.appendChild(this.createCheckbox('光线追踪', 'experimentalRaytracing', this.settings.experimentalRaytracing));
    experimentalGroup.appendChild(this.createCheckbox('体积光', 'experimentalVolumetricLight', this.settings.experimentalVolumetricLight));
    panel.appendChild(experimentalGroup);

    // 后处理设置
    const postProcessGroup = this.createSection('后处理');
    postProcessGroup.appendChild(this.createSelect('色调映射', 'toneMapping', ['none', 'aces', 'filmic', 'reinhard'], this.settings.toneMapping));
    postProcessGroup.appendChild(this.createSlider('曝光度', 'toneMappingExposure', 0.5, 2.0, 0.1, this.settings.toneMappingExposure));
    panel.appendChild(postProcessGroup);

    // 性能设置
    const performanceGroup = this.createSection('性能');
    performanceGroup.appendChild(this.createSlider('最大帧率', 'maxFPS', 30, 120, 10, this.settings.maxFPS));
    performanceGroup.appendChild(this.createCheckbox('垂直同步', 'vsync', this.settings.vsync));
    panel.appendChild(performanceGroup);

    // 按钮组
    const buttonGroup = document.createElement('div');
    buttonGroup.style.cssText = 'display: flex; gap: 10px; justify-content: center; margin-top: 20px;';
    
    const applyBtn = this.createButton('应用', () => this.applySettings());
    const cancelBtn = this.createButton('取消', () => this.hide());
    const resetBtn = this.createButton('重置', () => this.resetToDefault());
    
    buttonGroup.appendChild(applyBtn);
    buttonGroup.appendChild(cancelBtn);
    buttonGroup.appendChild(resetBtn);
    panel.appendChild(buttonGroup);

    this.container.appendChild(panel);
  }

  private createSection(title: string): HTMLElement {
    const section = document.createElement('div');
    section.style.cssText = 'margin-bottom: 20px;';
    
    const sectionTitle = document.createElement('h3');
    sectionTitle.textContent = title;
    sectionTitle.style.cssText = `
      margin: 0 0 12px 0;
      color: #ffd166;
      font-size: 16px;
      border-bottom: 1px solid #ffd166;
      padding-bottom: 4px;
    `;
    section.appendChild(sectionTitle);
    
    return section;
  }

  private createSlider(label: string, key: keyof GraphicsSettings, min: number, max: number, step: number, value: number): HTMLElement {
    const container = document.createElement('div');
    container.style.cssText = 'display: flex; align-items: center; gap: 10px; margin-bottom: 10px;';
    
    const labelEl = document.createElement('label');
    labelEl.textContent = label;
    labelEl.style.cssText = 'flex: 1; color: white; font-size: 14px;';
    
    const slider = document.createElement('input');
    slider.type = 'range';
    slider.min = min.toString();
    slider.max = max.toString();
    slider.step = step.toString();
    slider.value = value.toString();
    slider.style.cssText = 'flex: 2;';
    slider.setAttribute('data-key', key);
    
    const valueDisplay = document.createElement('span');
    valueDisplay.textContent = value.toString();
    valueDisplay.style.cssText = 'min-width: 50px; color: white; font-size: 14px; text-align: right;';
    
    slider.addEventListener('input', (e) => {
      const newValue = parseFloat((e.target as HTMLInputElement).value);
      valueDisplay.textContent = newValue.toString();
      (this.settings as any)[key] = newValue;
    });
    
    container.appendChild(labelEl);
    container.appendChild(slider);
    container.appendChild(valueDisplay);
    
    return container;
  }

  private createCheckbox(label: string, key: keyof GraphicsSettings, checked: boolean): HTMLElement {
    const container = document.createElement('div');
    container.style.cssText = 'display: flex; align-items: center; gap: 10px; margin-bottom: 10px;';
    
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = checked;
    checkbox.style.cssText = 'width: 20px; height: 20px;';
    checkbox.setAttribute('data-key', key);
    
    const labelEl = document.createElement('label');
    labelEl.textContent = label;
    labelEl.style.cssText = 'flex: 1; color: white; font-size: 14px; cursor: pointer;';
    
    checkbox.addEventListener('change', (e) => {
      (this.settings as any)[key] = (e.target as HTMLInputElement).checked;
    });
    
    container.appendChild(checkbox);
    container.appendChild(labelEl);
    
    return container;
  }

  private createSelect(label: string, key: keyof GraphicsSettings, options: string[], value: string): HTMLElement {
    const container = document.createElement('div');
    container.style.cssText = 'display: flex; align-items: center; gap: 10px; margin-bottom: 10px;';
    
    const labelEl = document.createElement('label');
    labelEl.textContent = label;
    labelEl.style.cssText = 'flex: 1; color: white; font-size: 14px;';
    
    const select = document.createElement('select');
    select.style.cssText = 'flex: 1; padding: 6px; border-radius: 4px; border: 1px solid #ffd166; background: #2a2a3a; color: white;';
    select.setAttribute('data-key', key);
    
    options.forEach((option) => {
      const optionEl = document.createElement('option');
      optionEl.value = option;
      optionEl.textContent = option;
      optionEl.selected = option === value;
      select.appendChild(optionEl);
    });
    
    select.addEventListener('change', (e) => {
      (this.settings as any)[key] = (e.target as HTMLSelectElement).value;
    });
    
    container.appendChild(labelEl);
    container.appendChild(select);
    
    return container;
  }

  private createPresetButton(text: string, onClick: () => void): HTMLElement {
    const button = document.createElement('button');
    button.textContent = text;
    button.style.cssText = `
      flex: 1;
      padding: 10px;
      background: #2a2a3a;
      color: white;
      border: 2px solid #ffd166;
      border-radius: 8px;
      cursor: pointer;
      font-size: 14px;
      font-weight: bold;
      transition: all 0.2s;
    `;
    
    button.addEventListener('mouseenter', () => {
      button.style.background = '#ffd166';
      button.style.color = '#14141e';
    });
    
    button.addEventListener('mouseleave', () => {
      button.style.background = '#2a2a3a';
      button.style.color = 'white';
    });
    
    button.addEventListener('click', onClick);
    
    return button;
  }

  private createButton(text: string, onClick: () => void): HTMLElement {
    const button = document.createElement('button');
    button.textContent = text;
    button.style.cssText = `
      padding: 12px 24px;
      background: #2a2a3a;
      color: white;
      border: 2px solid #ffd166;
      border-radius: 8px;
      cursor: pointer;
      font-size: 14px;
      font-weight: bold;
      transition: all 0.2s;
    `;
    
    button.addEventListener('mouseenter', () => {
      button.style.background = '#ffd166';
      button.style.color = '#14141e';
    });
    
    button.addEventListener('mouseleave', () => {
      button.style.background = '#2a2a3a';
      button.style.color = 'white';
    });
    
    button.addEventListener('click', onClick);
    
    return button;
  }

  private applyPreset(preset: GraphicsSettings) {
    this.settings = { ...preset };
    this.updateUI();
  }

  private resetToDefault() {
    this.settings = { ...DEFAULT_GRAPHICS_SETTINGS };
    this.updateUI();
  }

  private applySettings() {
    this.graphicsManager.setSettings(this.settings);
    this.hide();
  }

  private updateUI() {
    const panel = document.getElementById('graphics-panel');
    if (!panel) return;
    
    // 更新所有输入控件的值
    const sliders = panel.querySelectorAll('input[type="range"]');
    sliders.forEach((slider) => {
      const inputEl = slider as HTMLInputElement;
      const key = inputEl.getAttribute('data-key');
      if (key && key in this.settings) {
        inputEl.value = (this.settings as any)[key].toString();
        const valueDisplay = inputEl.parentElement?.querySelector('span');
        if (valueDisplay) {
          valueDisplay.textContent = (this.settings as any)[key].toString();
        }
      }
    });
    
    const checkboxes = panel.querySelectorAll('input[type="checkbox"]');
    checkboxes.forEach((checkbox) => {
      const checkboxEl = checkbox as HTMLInputElement;
      const key = checkboxEl.getAttribute('data-key');
      if (key && key in this.settings) {
        checkboxEl.checked = (this.settings as any)[key];
      }
    });
    
    const selects = panel.querySelectorAll('select');
    selects.forEach((select) => {
      const selectEl = select as HTMLSelectElement;
      const key = selectEl.getAttribute('data-key');
      if (key && key in this.settings) {
        selectEl.value = (this.settings as any)[key];
      }
    });
  }

  show() {
    const panel = document.getElementById('graphics-panel');
    if (panel) {
      panel.style.display = 'block';
      this.isVisible = true;
    }
  }

  hide() {
    const panel = document.getElementById('graphics-panel');
    if (panel) {
      panel.style.display = 'none';
      this.isVisible = false;
    }
  }

  toggle() {
    if (this.isVisible) {
      this.hide();
    } else {
      this.show();
    }
  }
}
