/** 我的世界式形状合成：3x3 / 2x2 网格摆放材料，按形状匹配配方 */

import { STICK_ID } from './items';

const GUN_BARREL = 202;
const TRIGGER = 203;

export interface CraftRecipe {
  id: string;
  name: string;
  desc: string;
  /** 形状配方：1~3 行，每行 1~3 格，0 = 空格 */
  pattern: number[][];
  output: { id: number; count: number };
}

export const RECIPES: CraftRecipe[] = [
  { id: 'planks', name: '木板', desc: '原木 → 木板', pattern: [[6]], output: { id: 8, count: 4 } },
  { id: 'stick', name: '木棍', desc: '两块木板叠放', pattern: [[8], [8]], output: { id: STICK_ID, count: 4 } },
  {
    id: 'workbench',
    name: '工作台',
    desc: '四块木板，解锁 3x3 合成',
    pattern: [
      [8, 8],
      [8, 8],
    ],
    output: { id: 31, count: 1 },
  },
  { id: 'torch', name: '火把', desc: '荧光石 + 木棍', pattern: [[13], [STICK_ID]], output: { id: 30, count: 8 } },
  {
    id: 'pickaxe-wood',
    name: '木镐',
    desc: '三木板 + 两木棍',
    pattern: [
      [8, 8, 8],
      [0, STICK_ID, 0],
      [0, STICK_ID, 0],
    ],
    output: { id: 100, count: 80 },
  },
  {
    id: 'pickaxe-stone',
    name: '石镐',
    desc: '三圆石 + 两木棍',
    pattern: [
      [4, 4, 4],
      [0, STICK_ID, 0],
      [0, STICK_ID, 0],
    ],
    output: { id: 101, count: 160 },
  },
  {
    id: 'pickaxe-crystal',
    name: '水晶镐',
    desc: '三水晶 + 两木棍',
    pattern: [
      [15, 15, 15],
      [0, STICK_ID, 0],
      [0, STICK_ID, 0],
    ],
    output: { id: 102, count: 320 },
  },
  {
    id: 'axe-stone',
    name: '石斧',
    desc: '两圆石 + 两木棍',
    pattern: [
      [4, 4],
      [4, STICK_ID],
      [0, STICK_ID],
    ],
    output: { id: 103, count: 160 },
  },
  {
    id: 'shovel-stone',
    name: '石铲',
    desc: '圆石 + 两木棍',
    pattern: [[4], [STICK_ID], [STICK_ID]],
    output: { id: 104, count: 130 },
  },
  {
    id: 'sword-wood',
    name: '木剑',
    desc: '木板 + 两木棍',
    pattern: [[8], [8], [STICK_ID]],
    output: { id: 105, count: 100 },
  },
  {
    id: 'sword-stone',
    name: '石剑',
    desc: '圆石 + 两木棍',
    pattern: [[4], [4], [STICK_ID]],
    output: { id: 106, count: 190 },
  },
  {
    id: 'sword-crystal',
    name: '水晶剑',
    desc: '水晶 + 两木棍',
    pattern: [[15], [15], [STICK_ID]],
    output: { id: 107, count: 340 },
  },
  { id: 'glass', name: '玻璃', desc: '三块沙子', pattern: [[5, 5, 5]], output: { id: 9, count: 2 } },
  {
    id: 'brick',
    name: '红砖',
    desc: '四块泥土',
    pattern: [
      [2, 2],
      [2, 2],
    ],
    output: { id: 10, count: 3 },
  },
  {
    id: 'glow',
    name: '荧光石',
    desc: '宝石矿 + 沙子',
    pattern: [
      [21, 21],
      [5, 5],
    ],
    output: { id: 13, count: 1 },
  },
  { id: 'candy', name: '闹吃糖果', desc: '红花+蓝花+沙子', pattern: [[24, 25, 5]], output: { id: 14, count: 2 } },
  {
    id: 'crystal',
    name: '秘境水晶',
    desc: '三宝石矿 + 荧光石',
    pattern: [
      [21, 21, 21],
      [0, 13, 0],
    ],
    output: { id: 15, count: 1 },
  },
  {
    id: 'rainbow',
    name: '彩虹核心',
    desc: '糖果×2 + 水晶×2',
    pattern: [
      [14, 15],
      [15, 13],
    ],
    output: { id: 18, count: 1 },
  },
  {
    id: 'cloud',
    name: '云朵块',
    desc: '雪块 + 玻璃',
    pattern: [
      [12, 12],
      [9, 9],
    ],
    output: { id: 19, count: 2 },
  },
  {
    id: 'tnt',
    name: '炸药块',
    desc: '沙×4 + 圆石 + 荧光石',
    pattern: [
      [5, 5],
      [5, 5],
      [4, 13],
    ],
    output: { id: 20, count: 1 },
  },
  {
    id: 'chest',
    name: '惊喜宝箱',
    desc: '八块木板',
    pattern: [
      [8, 8, 8],
      [8, 0, 8],
      [8, 8, 8],
    ],
    output: { id: 28, count: 1 },
  },
  {
    id: 'gem-ore',
    name: '宝石矿块',
    desc: '水晶×2 + 石头×4',
    pattern: [
      [15, 15],
      [3, 3],
      [3, 3],
    ],
    output: { id: 21, count: 1 },
  },

  /* ---------------- 枪械模组 ---------------- */
  {
    id: 'gun-barrel',
    name: '枪管',
    desc: '圆石×3 + 铁? 用圆石与水晶打造',
    pattern: [[4, 4, 4]],
    output: { id: GUN_BARREL, count: 2 },
  },
  {
    id: 'trigger',
    name: '击发器',
    desc: '水晶 + 圆石 + 木棍',
    pattern: [
      [15, 4],
      [0, STICK_ID],
    ],
    output: { id: TRIGGER, count: 2 },
  },
  {
    id: 'ammo-wood',
    name: '木弹',
    desc: '两根木棍 → 16 发',
    pattern: [[STICK_ID, STICK_ID]],
    output: { id: 204, count: 16 },
  },
  {
    id: 'ammo-iron',
    name: '铁弹',
    desc: '两块圆石 → 12 发（+4 伤害）',
    pattern: [
      [4, 4],
      [4, 4],
    ],
    output: { id: 205, count: 12 },
  },
  {
    id: 'ammo-crystal',
    name: '水晶弹',
    desc: '水晶 + 圆石 → 8 发（+9 伤害）',
    pattern: [
      [15, 4],
      [4, 4],
    ],
    output: { id: 206, count: 8 },
  },
  {
    id: 'gun-wood',
    name: '木枪',
    desc: '枪管 + 击发器 + 木棍',
    pattern: [
      [GUN_BARREL, TRIGGER],
      [0, STICK_ID],
    ],
    output: { id: 108, count: 120 },
  },
  {
    id: 'gun-rifle',
    name: '步枪',
    desc: '两枪管 + 击发器 + 木棍',
    pattern: [
      [GUN_BARREL, GUN_BARREL, TRIGGER],
      [0, 0, STICK_ID],
    ],
    output: { id: 109, count: 260 },
  },
  {
    id: 'gun-crystal',
    name: '水晶炮',
    desc: '水晶×2 + 枪管 + 击发器（3×3 工作台）',
    pattern: [
      [15, 15, GUN_BARREL],
      [0, TRIGGER, 0],
      [0, STICK_ID, 0],
    ],
    output: { id: 110, count: 400 },
  },
];

export interface PatternSize {
  w: number;
  h: number;
}

/** 配方图案去掉空格后的实际尺寸 */
export function recipePatternSize(recipe: CraftRecipe): PatternSize {
  let minX = 3;
  let maxX = -1;
  let minY = recipe.pattern.length;
  let maxY = -1;
  recipe.pattern.forEach((row, y) =>
    row.forEach((cell, x) => {
      if (cell) {
        minY = Math.min(minY, y);
        maxY = Math.max(maxY, y);
        minX = Math.min(minX, x);
        maxX = Math.max(maxX, x);
      }
    }),
  );
  if (maxY < 0) return { w: 0, h: 0 };
  return { w: maxX - minX + 1, h: maxY - minY + 1 };
}

/** 用 3x3 或 2x2 网格内容（null=空）匹配配方，支持任意位置摆放 */
export function matchRecipe(grid: (number | null)[], gridSize: number): CraftRecipe | null {
  let minX = gridSize;
  let maxX = -1;
  let minY = gridSize;
  let maxY = -1;
  grid.forEach((cell, i) => {
    if (cell) {
      const y = Math.floor(i / gridSize);
      const x = i % gridSize;
      minY = Math.min(minY, y);
      maxY = Math.max(maxY, y);
      minX = Math.min(minX, x);
      maxX = Math.max(maxX, x);
    }
  });
  if (maxY < 0) return null;
  const gw = maxX - minX + 1;
  const gh = maxY - minY + 1;

  for (const recipe of RECIPES) {
    const size = recipePatternSize(recipe);
    if (size.w !== gw || size.h !== gh) continue;

    // 提取配方图案单元
    const cells: number[] = [];
    recipe.pattern.forEach((row, y) => {
      row.forEach((cell, x) => {
        if (cell) cells.push(recipe.pattern[y][x]);
      });
    });

    let ok = true;
    let ci = 0;
    for (let y = 0; y < gh && ok; y++) {
      for (let x = 0; x < gw; x++) {
        const have = grid[(minY + y) * gridSize + (minX + x)];
        const want = cells[ci++];
        if (have !== want) {
          ok = false;
          break;
        }
      }
    }
    if (ok) return recipe;
  }
  return null;
}
