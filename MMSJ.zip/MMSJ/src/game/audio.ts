// Tiny WebAudio synth for game feedback sounds.

export class Sfx {
  private ctx: AudioContext | null = null;
  enabled = true;
  volume = 0.5;

  private ensure(): AudioContext | null {
    if (!this.enabled) return null;
    if (!this.ctx) {
      const AC = window.AudioContext || (window as any).webkitAudioContext;
      if (!AC) return null;
      this.ctx = new AC();
    }
    if (this.ctx.state === 'suspended') void this.ctx.resume();
    return this.ctx;
  }

  resume() {
    this.ensure();
  }

  private noiseBurst(duration: number, freq: number, gain: number) {
    const ctx = this.ensure();
    if (!ctx) return;
    const frames = Math.floor(ctx.sampleRate * duration);
    const buffer = ctx.createBuffer(1, frames, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < frames; i++) {
      data[i] = (Math.random() * 2 - 1) * (1 - i / frames);
    }
    const src = ctx.createBufferSource();
    src.buffer = buffer;
    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = freq;
    filter.Q.value = 1.1;
    const g = ctx.createGain();
    g.gain.value = gain * this.volume;
    src.connect(filter).connect(g).connect(ctx.destination);
    src.start();
    src.stop(ctx.currentTime + duration);
  }

  private tone(freq: number, duration: number, type: OscillatorType, gain = 0.2, slide = 0) {
    const ctx = this.ensure();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, ctx.currentTime);
    if (slide) osc.frequency.exponentialRampToValueAtTime(freq + slide, ctx.currentTime + duration);
    g.gain.setValueAtTime(gain * this.volume, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
    osc.connect(g).connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + duration);
  }

  dig() {
    this.noiseBurst(0.09, 420 + Math.random() * 260, 0.35);
  }

  break_() {
    this.noiseBurst(0.22, 300 + Math.random() * 200, 0.5);
    this.tone(180, 0.14, 'triangle', 0.12, -60);
  }

  place() {
    this.noiseBurst(0.07, 900, 0.25);
    this.tone(520, 0.09, 'square', 0.08, 120);
  }

  step() {
    this.noiseBurst(0.06, 220 + Math.random() * 120, 0.16);
  }

  jump() {
    this.tone(420, 0.1, 'sine', 0.1, 220);
  }

  hurt() {
    this.tone(200, 0.25, 'sawtooth', 0.16, -110);
  }

  click() {
    this.tone(760, 0.06, 'square', 0.08, 180);
  }

  splash() {
    this.noiseBurst(0.3, 700, 0.3);
  }
}

export const sfx = new Sfx();
