import { hash2 } from './noise';

export type BiomeType =
  | 'plains'
  | 'forest'
  | 'desert'
  | 'snow'
  | 'swamp'
  | 'ocean'
  | 'taiga'
  | 'savanna'
  | 'jungle'
  | 'mountains'
  | 'beach'
  | 'tundra'
  | 'flower_forest'
  | 'mesa'
  | 'mushroom_fields';

export interface Biome {
  type: BiomeType;
  name: string;
  temperature: number; // 0-1
  humidity: number; // 0-1
  heightBase: number; // 基础地形高度
  heightVariation: number; // 地形变化幅度
  surfaceBlock: number; // 地表方块 ID
  subsurfaceBlock: number; // 地表下方块 ID
  grassColor: number; // 草颜色（RGB）
  foliageColor: number; // 树叶颜色（RGB）
  waterColor: number; // 水颜色（RGB）
  fogColor: number; // 雾颜色（RGB）
  fogDensity: number; // 雾密度
  trees: {
    density: number; // 树木密度 0-1
    types: number[]; // 可用的树类型 ID
  };
  flowers: {
    density: number; // 花草密度 0-1
    types: number[]; // 可用的花草类型 ID
  };
  mobs: {
    passive: number[]; // 被动生物 ID
    hostile: number[]; // 敌对生物 ID
    spawnRate: number; // 刷新率
  };
}

// 生物 ID 映射（对应 mobs.ts 中的定义）
export const MOB_IDS = {
  // 被动生物
  PIG: 1,
  COW: 2,
  SHEEP: 3,
  CHICKEN: 4,
  HORSE: 5,
  WOLF: 6,
  CAT: 7,
  RABBIT: 8,
  FOX: 9,
  PANDA: 10,
  // 敌对生物
  ZOMBIE: 11,
  SKELETON: 12,
  SPIDER: 13,
  CREEPER: 14,
  ENDERMAN: 15,
  SLIME: 16,
  WITCH: 17,
  // 水生生物
  DOLPHIN: 18,
  TURTLE: 19,
  DROWNED: 20,
  GUARDIAN: 21,
  FROG: 22,
};

// 树类型 ID
export const TREE_TYPES = {
  OAK: 0,
  BIRCH: 1,
  SPRUCE: 2,
  JUNGLE: 3,
  ACACIA: 4,
  DARK_OAK: 5,
};

// 花草类型 ID
export const FLOWER_TYPES = {
  GRASS: 0,
  DANDELION: 1,
  POPPY: 2,
  BLUE_ORCHID: 3,
  TULIP: 4,
  DEAD_BUSH: 5,
  CACTUS: 6,
  LILY_PAD: 7,
};

export const BIOMES: Record<BiomeType, Biome> = {
  plains: {
    type: 'plains',
    name: '平原',
    temperature: 0.6,
    humidity: 0.5,
    heightBase: 4,
    heightVariation: 3,
    surfaceBlock: 2, // 草方块
    subsurfaceBlock: 3, // 泥土
    grassColor: 0x91bd59,
    foliageColor: 0x77ab2f,
    waterColor: 0x3f76e4,
    fogColor: 0xc0d8ff,
    fogDensity: 0.02,
    trees: {
      density: 0.05,
      types: [TREE_TYPES.OAK, TREE_TYPES.BIRCH],
    },
    flowers: {
      density: 0.3,
      types: [FLOWER_TYPES.GRASS, FLOWER_TYPES.DANDELION, FLOWER_TYPES.POPPY],
    },
    mobs: {
      passive: [MOB_IDS.PIG, MOB_IDS.COW, MOB_IDS.SHEEP, MOB_IDS.CHICKEN, MOB_IDS.HORSE],
      hostile: [MOB_IDS.ZOMBIE, MOB_IDS.SKELETON, MOB_IDS.SPIDER, MOB_IDS.CREEPER],
      spawnRate: 0.4,
    },
  },
  forest: {
    type: 'forest',
    name: '森林',
    temperature: 0.5,
    humidity: 0.7,
    heightBase: 5,
    heightVariation: 4,
    surfaceBlock: 2,
    subsurfaceBlock: 3,
    grassColor: 0x79c05a,
    foliageColor: 0x59ae30,
    waterColor: 0x3f76e4,
    fogColor: 0xa0c0a0,
    fogDensity: 0.03,
    trees: {
      density: 0.6,
      types: [TREE_TYPES.OAK, TREE_TYPES.BIRCH, TREE_TYPES.DARK_OAK],
    },
    flowers: {
      density: 0.2,
      types: [FLOWER_TYPES.GRASS, FLOWER_TYPES.POPPY, FLOWER_TYPES.BLUE_ORCHID],
    },
    mobs: {
      passive: [MOB_IDS.WOLF, MOB_IDS.FOX, MOB_IDS.RABBIT, MOB_IDS.PIG],
      hostile: [MOB_IDS.ZOMBIE, MOB_IDS.SKELETON, MOB_IDS.SPIDER, MOB_IDS.WITCH],
      spawnRate: 0.5,
    },
  },
  desert: {
    type: 'desert',
    name: '沙漠',
    temperature: 1.0,
    humidity: 0.0,
    heightBase: 3,
    heightVariation: 2,
    surfaceBlock: 12, // 沙子
    subsurfaceBlock: 12,
    grassColor: 0xbfb755,
    foliageColor: 0xaea42a,
    waterColor: 0x3f76e4,
    fogColor: 0xf0e0c0,
    fogDensity: 0.015,
    trees: {
      density: 0.0,
      types: [],
    },
    flowers: {
      density: 0.1,
      types: [FLOWER_TYPES.DEAD_BUSH, FLOWER_TYPES.CACTUS],
    },
    mobs: {
      passive: [MOB_IDS.RABBIT],
      hostile: [MOB_IDS.ZOMBIE, MOB_IDS.SKELETON, MOB_IDS.CREEPER, MOB_IDS.SPIDER],
      spawnRate: 0.6,
    },
  },
  snow: {
    type: 'snow',
    name: '雪地',
    temperature: 0.0,
    humidity: 0.3,
    heightBase: 6,
    heightVariation: 5,
    surfaceBlock: 80, // 雪块（需要新增）
    subsurfaceBlock: 3,
    grassColor: 0xe0e0e0,
    foliageColor: 0xc0c0c0,
    waterColor: 0x3f76e4,
    fogColor: 0xe0e8f0,
    fogDensity: 0.04,
    trees: {
      density: 0.3,
      types: [TREE_TYPES.SPRUCE],
    },
    flowers: {
      density: 0.05,
      types: [FLOWER_TYPES.GRASS],
    },
    mobs: {
      passive: [MOB_IDS.RABBIT, MOB_IDS.FOX, MOB_IDS.PANDA],
      hostile: [MOB_IDS.ZOMBIE, MOB_IDS.SKELETON, MOB_IDS.SPIDER],
      spawnRate: 0.3,
    },
  },
  swamp: {
    type: 'swamp',
    name: '沼泽',
    temperature: 0.6,
    humidity: 0.9,
    heightBase: 3,
    heightVariation: 1,
    surfaceBlock: 2,
    subsurfaceBlock: 3,
    grassColor: 0x6a7039,
    foliageColor: 0x4c763c,
    waterColor: 0x617b64,
    fogColor: 0x80a080,
    fogDensity: 0.05,
    trees: {
      density: 0.2,
      types: [TREE_TYPES.OAK, TREE_TYPES.JUNGLE],
    },
    flowers: {
      density: 0.4,
      types: [FLOWER_TYPES.BLUE_ORCHID, FLOWER_TYPES.LILY_PAD],
    },
    mobs: {
      passive: [MOB_IDS.FROG, MOB_IDS.SLIME],
      hostile: [MOB_IDS.ZOMBIE, MOB_IDS.SKELETON, MOB_IDS.SLIME, MOB_IDS.WITCH],
      spawnRate: 0.7,
    },
  },
  ocean: {
    type: 'ocean',
    name: '海洋',
    temperature: 0.5,
    humidity: 1.0,
    heightBase: -10,
    heightVariation: 5,
    surfaceBlock: 12, // 沙子
    subsurfaceBlock: 13, // 沙砾
    grassColor: 0x8eb971,
    foliageColor: 0x71a74d,
    waterColor: 0x1782d4,
    fogColor: 0x4080c0,
    fogDensity: 0.06,
    trees: {
      density: 0.0,
      types: [],
    },
    flowers: {
      density: 0.0,
      types: [],
    },
    mobs: {
      passive: [MOB_IDS.DOLPHIN, MOB_IDS.TURTLE],
      hostile: [MOB_IDS.DROWNED, MOB_IDS.GUARDIAN],
      spawnRate: 0.3,
    },
  },
  taiga: {
    type: 'taiga',
    name: '针叶林',
    temperature: 0.15,
    humidity: 0.55,
    heightBase: 6,
    heightVariation: 4,
    surfaceBlock: 2,
    subsurfaceBlock: 3,
    grassColor: 0x86a56f, // 偏冷偏灰的绿，和 forest/plains 的暖绿明显区分
    foliageColor: 0x5f7f52,
    waterColor: 0x3f76e4,
    fogColor: 0xb9c8c2,
    fogDensity: 0.035,
    trees: {
      density: 0.55,
      types: [TREE_TYPES.SPRUCE],
    },
    flowers: {
      density: 0.08,
      types: [FLOWER_TYPES.GRASS],
    },
    mobs: {
      passive: [MOB_IDS.WOLF, MOB_IDS.FOX, MOB_IDS.RABBIT],
      hostile: [MOB_IDS.ZOMBIE, MOB_IDS.SKELETON, MOB_IDS.SPIDER],
      spawnRate: 0.35,
    },
  },
  savanna: {
    type: 'savanna',
    name: '热带草原',
    temperature: 0.9,
    humidity: 0.25,
    heightBase: 4,
    heightVariation: 2,
    surfaceBlock: 2,
    subsurfaceBlock: 3,
    grassColor: 0xbfb755, // 干燥的黄绿色，区别于沙漠的纯黄和平原的鲜绿
    foliageColor: 0xaa9d3f,
    waterColor: 0x3f76e4,
    fogColor: 0xe8dcae,
    fogDensity: 0.018,
    trees: {
      density: 0.08,
      types: [TREE_TYPES.ACACIA],
    },
    flowers: {
      density: 0.06,
      types: [FLOWER_TYPES.DEAD_BUSH, FLOWER_TYPES.GRASS],
    },
    mobs: {
      passive: [MOB_IDS.HORSE, MOB_IDS.COW, MOB_IDS.RABBIT],
      hostile: [MOB_IDS.ZOMBIE, MOB_IDS.SKELETON, MOB_IDS.CREEPER],
      spawnRate: 0.4,
    },
  },
  jungle: {
    type: 'jungle',
    name: '丛林',
    temperature: 0.75,
    humidity: 0.85,
    heightBase: 6,
    heightVariation: 5,
    surfaceBlock: 2,
    subsurfaceBlock: 3,
    grassColor: 0x4fb52a, // 比 forest 更饱和、更艳的绿，突出湿热感
    foliageColor: 0x36a01f,
    waterColor: 0x2f8fd0,
    fogColor: 0x8fc290,
    fogDensity: 0.045,
    trees: {
      density: 0.75,
      types: [TREE_TYPES.JUNGLE, TREE_TYPES.OAK],
    },
    flowers: {
      density: 0.35,
      types: [FLOWER_TYPES.GRASS, FLOWER_TYPES.POPPY, FLOWER_TYPES.BLUE_ORCHID],
    },
    mobs: {
      passive: [MOB_IDS.PANDA, MOB_IDS.CHICKEN, MOB_IDS.FROG],
      hostile: [MOB_IDS.ZOMBIE, MOB_IDS.SPIDER, MOB_IDS.WITCH],
      spawnRate: 0.55,
    },
  },
  mountains: {
    type: 'mountains',
    name: '山地',
    temperature: 0.3,
    humidity: 0.4,
    heightBase: 14,
    heightVariation: 10,
    surfaceBlock: 1, // 高海拔露出岩石，而不是草
    subsurfaceBlock: 1,
    grassColor: 0x8fae7a,
    foliageColor: 0x6c8f57,
    waterColor: 0x3f76e4,
    fogColor: 0xd6e2ee,
    fogDensity: 0.025,
    trees: {
      density: 0.12,
      types: [TREE_TYPES.SPRUCE],
    },
    flowers: {
      density: 0.02,
      types: [FLOWER_TYPES.GRASS],
    },
    mobs: {
      passive: [MOB_IDS.FOX, MOB_IDS.RABBIT],
      hostile: [MOB_IDS.ZOMBIE, MOB_IDS.SKELETON],
      spawnRate: 0.3,
    },
  },
  beach: {
    type: 'beach',
    name: '海滩',
    temperature: 0.65,
    humidity: 0.5,
    heightBase: 1,
    heightVariation: 1,
    surfaceBlock: 12,
    subsurfaceBlock: 12,
    grassColor: 0xc8c090,
    foliageColor: 0xb0a878,
    waterColor: 0x2f9fd8,
    fogColor: 0xd8ecff,
    fogDensity: 0.015,
    trees: {
      density: 0.0,
      types: [],
    },
    flowers: {
      density: 0.0,
      types: [],
    },
    mobs: {
      passive: [MOB_IDS.TURTLE, MOB_IDS.RABBIT],
      hostile: [MOB_IDS.DROWNED],
      spawnRate: 0.2,
    },
  },
  tundra: {
    type: 'tundra',
    name: '苔原',
    temperature: 0.05,
    humidity: 0.1,
    heightBase: 4,
    heightVariation: 2,
    surfaceBlock: 12, // 跟雪地一样是雪块，靠"几乎没有树/花"来区分出那种荒凉感
    subsurfaceBlock: 3,
    grassColor: 0xc7d2d6, // 比雪地(0xe0e0e0)更冷、更发青灰，草丛稀疏干枯
    foliageColor: 0xaab5b8,
    waterColor: 0x3f76e4,
    fogColor: 0xe8eef2,
    fogDensity: 0.03,
    trees: {
      density: 0.0,
      types: [],
    },
    flowers: {
      density: 0.03,
      types: [FLOWER_TYPES.DEAD_BUSH],
    },
    mobs: {
      passive: [MOB_IDS.RABBIT, MOB_IDS.FOX],
      hostile: [MOB_IDS.ZOMBIE, MOB_IDS.SKELETON],
      spawnRate: 0.25,
    },
  },
  flower_forest: {
    type: 'flower_forest',
    name: '花林',
    temperature: 0.55,
    humidity: 0.6,
    heightBase: 5,
    heightVariation: 3,
    surfaceBlock: 1,
    subsurfaceBlock: 2,
    grassColor: 0x8fd06a,
    foliageColor: 0xf4b8d0, // 粉白的"树叶"色——树叶方块的染色直接复用这个，免费出樱花林效果
    waterColor: 0x3f76e4,
    fogColor: 0xf6d9e6,
    fogDensity: 0.025,
    trees: {
      density: 0.5,
      types: [TREE_TYPES.OAK, TREE_TYPES.BIRCH],
    },
    flowers: {
      density: 0.8, // 花林的标志——满地花比森林密得多
      types: [FLOWER_TYPES.DANDELION, FLOWER_TYPES.POPPY, FLOWER_TYPES.TULIP, FLOWER_TYPES.GRASS],
    },
    mobs: {
      passive: [MOB_IDS.RABBIT, MOB_IDS.SHEEP, MOB_IDS.PIG],
      hostile: [MOB_IDS.ZOMBIE, MOB_IDS.SKELETON],
      spawnRate: 0.4,
    },
  },
  mesa: {
    type: 'mesa',
    name: '恶地',
    temperature: 0.95,
    humidity: 0.05,
    heightBase: 8,
    heightVariation: 6,
    surfaceBlock: 46, // 红陶土——实际条带效果由 world.ts 按高度分层决定，这里只是兜底
    subsurfaceBlock: 46,
    grassColor: 0xb09468, // 陶土不怎么依赖草色染色，这里给个协调的暖棕色以防万一
    foliageColor: 0x8a6a3f,
    waterColor: 0x3f76e4,
    fogColor: 0xe0a878,
    fogDensity: 0.02,
    trees: {
      density: 0.0,
      types: [],
    },
    flowers: {
      density: 0.05,
      types: [FLOWER_TYPES.DEAD_BUSH],
    },
    mobs: {
      passive: [MOB_IDS.RABBIT],
      hostile: [MOB_IDS.ZOMBIE, MOB_IDS.SKELETON, MOB_IDS.CREEPER],
      spawnRate: 0.45,
    },
  },
  mushroom_fields: {
    type: 'mushroom_fields',
    name: '蘑菇岛',
    temperature: 0.5,
    humidity: 0.6,
    heightBase: 5,
    heightVariation: 2,
    surfaceBlock: 1,
    subsurfaceBlock: 2,
    grassColor: 0x8f7bb0, // 蓝紫灰的"菌丝"色调，跟其它任何群系都不会撞色，一眼认出来
    foliageColor: 0x7a6aa0,
    waterColor: 0x3f76e4,
    fogColor: 0xcfc4e8,
    fogDensity: 0.02,
    trees: {
      density: 0.0, // 蘑菇岛没有树——正版里也是，遍地大蘑菇代替树的角色
      types: [],
    },
    flowers: {
      density: 0.0,
      types: [],
    },
    mobs: {
      passive: [],
      hostile: [],
      spawnRate: 0.0, // 蘑菇岛在正版里是唯一不会自然刷怪的群系，保留这个特色
    },
  },
};

/**
 * 根据坐标获取群系类型
 * 使用温度/湿度噪声图 + 一层独立的"地形起伏"噪声来分配群系。
 *
 * 之前只有 6 种群系，且 ocean 完全靠湿度噪声决定、跟真实地形高度毫无关系——
 * 结果就是"海洋"会出现在海拔很高的陆地上，海岸线毫无规律，很难认出到底
 * 换没换群系。这里补齐山地/针叶林/热带草原/丛林/海滩 5 种新群系，把温度/
 * 湿度这张 2D 表格填满（原来一大片中间地带全部塞给了 forest/swamp），并且
 * 让海洋/海滩改由地形高度（是否低于海平面）决定，山地由一层独立的"地势"
 * 噪声决定，而不是全部挤在温度/湿度这一个维度里。
 */
export function getBiome(
  x: number,
  z: number,
  seed: number,
  terrainHeight?: number,
  seaLevel?: number,
): BiomeType {
  // 真实地形低于海平面 -> 海洋；紧贴海平面的窄条 -> 海滩。
  // 这样海岸线跟随实际地形起伏，而不是跟温湿度噪声的等值线走。
  if (terrainHeight !== undefined && seaLevel !== undefined) {
    if (terrainHeight < seaLevel - 1) return 'ocean';
    if (terrainHeight <= seaLevel + 1) {
      const coastNoise = hash2(x * 0.02, z * 0.02, seed + 41);
      if (coastNoise > 0.35) return 'beach';
    }
  }

  const temperature = hash2(x * 0.001, z * 0.001, seed + 1);
  const humidity = hash2(x * 0.001 + 100, z * 0.001 + 100, seed + 2);
  // 独立的低频噪声决定"山地"，不然山地会跟某一撮温湿度组合强绑定，
  // 显得到处都是同一种群系挨着山地出现。
  const relief = hash2(x * 0.0007 + 500, z * 0.0007 + 500, seed + 3);
  if (relief > 0.82 && temperature > 0.15 && temperature < 0.75) {
    return 'mountains';
  }

  // 花林/蘑菇岛都是"稀有特殊群系"，用各自独立的低频噪声在满足基础温湿度条件的
  // 地方偶尔盖过普通判定——这跟正版里"特殊群系比普通群系少见得多"的感觉一致，
  // 也避免它们跟山地一样用同一个 relief 噪声互相抢地盘。
  if (temperature > 0.4 && temperature < 0.7 && humidity > 0.35 && humidity < 0.75) {
    const flowerNoise = hash2(x * 0.0009 + 900, z * 0.0009 + 900, seed + 51);
    if (flowerNoise > 0.9) return 'flower_forest';
  }
  const mushroomNoise = hash2(x * 0.0004 + 1300, z * 0.0004 + 1300, seed + 52);
  if (mushroomNoise > 0.975) return 'mushroom_fields';

  // 温度/湿度 -> 群系映射（5 档温度 × 5 档湿度，尽量把格子填满，
  // 避免像之前那样一大片中间温度全部落进 forest/swamp 两种里）
  if (temperature < 0.2) {
    // 寒带：湿度很低是苔原（比雪原更荒凉），偏低是雪原，偏高是针叶林
    if (humidity < 0.15) return 'tundra';
    return humidity < 0.45 ? 'snow' : 'taiga';
  } else if (temperature < 0.4) {
    // 温带偏冷
    if (humidity < 0.25) return 'plains';
    if (humidity < 0.55) return 'forest';
    if (humidity < 0.8) return 'taiga';
    return 'swamp';
  } else if (temperature < 0.65) {
    // 温带
    if (humidity < 0.2) return 'plains';
    if (humidity < 0.45) return 'forest';
    if (humidity < 0.7) return 'swamp';
    return 'jungle';
  } else if (temperature < 0.85) {
    // 暖带：湿度极低的角落是恶地，比热带沙漠更少见
    if (humidity < 0.08) return 'mesa';
    if (humidity < 0.2) return 'savanna';
    if (humidity < 0.4) return 'plains';
    if (humidity < 0.65) return 'jungle';
    return 'swamp';
  } else {
    // 热带/干热：同样在极干燥角落插入恶地
    if (humidity < 0.06) return 'mesa';
    if (humidity < 0.35) return 'desert';
    if (humidity < 0.6) return 'savanna';
    return 'jungle';
  }
}

/**
 * 获取群系的地形高度
 */
export function getBiomeHeight(biome: Biome, x: number, z: number, noise: (x: number, y: number) => number): number {
  const n = noise(x * 0.01, z * 0.01);
  return biome.heightBase + n * biome.heightVariation;
}

/**
 * 获取群系的方块 ID 列表（用于装饰）
 */
export function getBiomeBlocks(biome: Biome): {
  surface: number;
  subsurface: number;
  stone: number;
  water: number;
  sand: number;
} {
  return {
    surface: biome.surfaceBlock,
    subsurface: biome.subsurfaceBlock,
    stone: 1, // 石头
    water: 9, // 水
    sand: 12, // 沙子
  };
}
