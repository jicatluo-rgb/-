/** 游戏优化综合文件 - 集成所有优化系统 */

import * as THREE from 'three';
import { RagdollSystem, createExplosionRagdoll } from './ragdoll_system';
import { TNTSystem } from './tnt_system';
import { createZombieModel, createSkeletonModel, createSpiderModel, createCreeperModel } from './mob_models_fixed';
import { createPistolModel, createRifleModel, createShotgunModel, createSniperModel } from './gun_models';
import { CRAFTING_RECIPES, QUICK_RECIPES, matchRecipe, getRecipeIngredients } from './crafting_system';
import { NEW_ITEMS, BIOME_ITEMS } from './items_new';
import { NEW_MOBS, BIOME_MOBS } from './mobs_new';
import { NEW_STRUCTURES, BIOME_STRUCTURES } from './structures_new';
import { NEW_BLOCKS, BIOME_BLOCKS } from './blocks_new';
import { GraphicsManager, autoSelectGraphicsPreset, isLowPowerDevice } from './graphics';
import { MultiplayerManager, SniperMode, HideAndSeekMode } from './multiplayer';

/** 游戏优化管理器 */
export class GameOptimizations {
  private scene: THREE.Scene;
  
  // 系统
  private ragdollSystem: RagdollSystem;
  private tntSystem: TNTSystem;
  private graphicsManager: GraphicsManager;
  private multiplayerManager: MultiplayerManager;
  
  // 模型缓存
  private mobModelCache: Map<string, THREE.Group> = new Map();
  private gunModelCache: Map<string, THREE.Group> = new Map();
  
  constructor(scene: THREE.Scene, camera: THREE.Camera, renderer: THREE.WebGLRenderer) {
    this.scene = scene;
    void camera;
    void renderer;
    void this.scene;
    
    // 初始化系统
    this.ragdollSystem = new RagdollSystem(scene);
    this.tntSystem = new TNTSystem(scene);
    this.graphicsManager = new GraphicsManager(autoSelectGraphicsPreset());
    this.multiplayerManager = new MultiplayerManager();
    
    // 应用画质设置
    this.graphicsManager.setRenderer(renderer, renderer.domElement);
    
    // 预加载模型
    this.preloadModels();
  }
  
  /** 预加载所有模型 */
  private preloadModels() {
    // 生物模型
    this.mobModelCache.set('zombie', createZombieModel());
    this.mobModelCache.set('skeleton', createSkeletonModel());
    this.mobModelCache.set('spider', createSpiderModel());
    this.mobModelCache.set('creeper', createCreeperModel());
    
    // 枪械模型
    this.gunModelCache.set('pistol', createPistolModel());
    this.gunModelCache.set('rifle', createRifleModel());
    this.gunModelCache.set('shotgun', createShotgunModel());
    this.gunModelCache.set('sniper', createSniperModel());
  }
  
  /** 获取生物模型 */
  getMobModel(type: string): THREE.Group | undefined {
    return this.mobModelCache.get(type);
  }
  
  /** 获取枪械模型 */
  getGunModel(type: string): THREE.Group | undefined {
    return this.gunModelCache.get(type);
  }
  
  /** 创建布娃娃 */
  createRagdoll(model: THREE.Group, position: THREE.Vector3, impulse: THREE.Vector3) {
    return this.ragdollSystem.createRagdoll(model, position, impulse);
  }
  
  /** 创建爆炸布娃娃 */
  createExplosionRagdoll(position: THREE.Vector3, radius: number = 5) {
    createExplosionRagdoll(this.ragdollSystem, position, radius);
  }
  
  /** 创建TNT */
  createTNT(position: THREE.Vector3, velocity: THREE.Vector3 = new THREE.Vector3()) {
    const tnt = this.tntSystem.createTNT(position, velocity);
    this.tntSystem.primeTNT(tnt);
    return tnt;
  }
  
  /** 更新所有系统 */
  update(deltaTime: number) {
    this.ragdollSystem.update(deltaTime);
    this.tntSystem.update(deltaTime);
    this.multiplayerManager.update(deltaTime);
  }
  
  /** 获取布娃娃系统 */
  getRagdollSystem(): RagdollSystem {
    return this.ragdollSystem;
  }
  
  /** 获取TNT系统 */
  getTNTSystem(): TNTSystem {
    return this.tntSystem;
  }
  
  /** 获取画质管理器 */
  getGraphicsManager(): GraphicsManager {
    return this.graphicsManager;
  }
  
  /** 获取联机管理器 */
  getMultiplayerManager(): MultiplayerManager {
    return this.multiplayerManager;
  }
  
  /** 清理所有资源 */
  dispose() {
    this.ragdollSystem.dispose();
    this.tntSystem.dispose();
    
    // 清理模型缓存
    this.mobModelCache.forEach((model) => {
      model.traverse((obj) => {
        if ((obj as THREE.Mesh).isMesh) {
          (obj as THREE.Mesh).geometry.dispose();
          ((obj as THREE.Mesh).material as THREE.Material).dispose();
        }
      });
    });
    this.mobModelCache.clear();
    
    this.gunModelCache.forEach((model) => {
      model.traverse((obj) => {
        if ((obj as THREE.Mesh).isMesh) {
          (obj as THREE.Mesh).geometry.dispose();
          ((obj as THREE.Mesh).material as THREE.Material).dispose();
        }
      });
    });
    this.gunModelCache.clear();
  }
}

/** 导出所有系统 */
export {
  RagdollSystem,
  TNTSystem,
  GraphicsManager,
  MultiplayerManager,
  SniperMode,
  HideAndSeekMode,
  CRAFTING_RECIPES,
  QUICK_RECIPES,
  matchRecipe,
  getRecipeIngredients,
  NEW_ITEMS,
  BIOME_ITEMS,
  NEW_MOBS,
  BIOME_MOBS,
  NEW_STRUCTURES,
  BIOME_STRUCTURES,
  NEW_BLOCKS,
  BIOME_BLOCKS,
  createZombieModel,
  createSkeletonModel,
  createSpiderModel,
  createCreeperModel,
  createPistolModel,
  createRifleModel,
  createShotgunModel,
  createSniperModel,
  autoSelectGraphicsPreset,
  isLowPowerDevice,
};
