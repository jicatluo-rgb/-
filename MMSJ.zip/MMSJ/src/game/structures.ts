import { hash2 } from './noise';
import { CHUNK_SIZE, type StructureType } from './world';

/** 结构建造上下文 */
export interface StructCtx {
  /** 写入方块（同时登记为“结构方块”，可受爆炸保护） */
  set(x: number, y: number, z: number, id: number): void;
  /** 仅当地表高度（世界坐标） */
  height(wx: number, wz: number): number;
  seed: number;
  cx: number;
  cz: number;
  /** 登记宝箱 */
  chest(x: number, y: number, z: number, type: StructureType): void;
  /** 登记结构中心 */
  mark(type: StructureType, x: number, y: number, z: number): void;
}

const AIR = 0;

/** 平整地基并向下补柱 */
function platform(ctx: StructCtx, x0: number, z0: number, x1: number, z1: number, base: number, fill: number, depth = 12) {
  for (let x = x0; x <= x1; x++) {
    for (let z = z0; z <= z1; z++) {
      for (let y = base; y < base + 14; y++) ctx.set(x, y, z, AIR);
      ctx.set(x, base - 1, z, fill);
      for (let y = base - 2; y > base - depth; y--) {
        if (ctx.height(x + ctx.cx * CHUNK_SIZE, z + ctx.cz * CHUNK_SIZE) > y) break;
        ctx.set(x, y, z, fill);
      }
    }
  }
}

function baseOf(ctx: StructCtx, x0: number, z0: number, x1: number, z1: number) {
  let b = 0;
  for (let x = x0; x <= x1; x++)
    for (let z = z0; z <= z1; z++)
      b = Math.max(b, ctx.height(x + ctx.cx * CHUNK_SIZE, z + ctx.cz * CHUNK_SIZE) + 1);
  return b;
}

/* ================================================================== */

/** 村庄：多栋不同户型 + 水井 + 农田 + 路灯 + 栅栏 + 石板路 */
export function buildVillage(ctx: StructCtx) {
  const base = baseOf(ctx, 1, 1, 14, 14);
  platform(ctx, 1, 1, 14, 14, base, 2);
  const r = hash2(ctx.cx, ctx.cz, ctx.seed + 11);

  // 石板路（十字）
  for (let i = 1; i <= 14; i++) {
    ctx.set(i, base, 7, i % 2 ? 4 : 8);
    ctx.set(7, base, i, i % 2 ? 8 : 4);
  }

  // 户型 A：尖顶木屋（阶梯式屋顶）
  house(ctx, 2, 2, base, { w: 5, d: 5, wall: 8, roof: 10, roofStyle: 'gable', door: true, windows: true, chimney: true });
  // 户型 B：石基砖房（平顶 + 女儿墙）
  house(ctx, 9, 2, base, { w: 5, d: 5, wall: 10, roof: 4, roofStyle: 'flat', door: true, windows: true, chimney: false });
  // 户型 C：小塔楼民居
  house(ctx, 9, 9, base, { w: 4, d: 4, wall: 8, roof: 10, roofStyle: 'pyramid', door: true, windows: true, chimney: true });

  // 水井
  for (let dx = -1; dx <= 1; dx++)
    for (let dz = -1; dz <= 1; dz++) {
      const edge = Math.abs(dx) + Math.abs(dz) > 0;
      ctx.set(4 + dx, base, 12 + dz, edge ? 4 : 11);
      if (edge) ctx.set(4 + dx, base + 1, 12 + dz, 4);
    }
  ctx.set(3, base + 2, 12, 6);
  ctx.set(5, base + 2, 12, 6);
  ctx.set(4, base + 3, 12, 8);

  // 农田
  for (let x = 2; x <= 5; x++)
    for (let z = 9; z <= 10; z++) {
      ctx.set(x, base, z, 2);
      if ((x + z) % 2 === 0) ctx.set(x, base + 1, z, 26);
    }

  // 路灯
  for (const [lx, lz] of [[7, 4], [7, 11], [12, 7]]) {
    ctx.set(lx, base + 1, lz, 6);
    ctx.set(lx, base + 2, lz, 6);
    ctx.set(lx, base + 3, lz, 13);
  }

  // 栅栏
  for (let x = 1; x <= 14; x++) {
    if (x !== 7) {
      ctx.set(x, base + 1, 1, 8);
      ctx.set(x, base + 1, 14, 8);
    }
  }

  ctx.chest(3, base + 1, 3, 'village');
  void r;
  ctx.mark('village', 7, base + 1, 7);
}

/** 通用房屋：支持三种屋顶形式 */
function house(
  ctx: StructCtx,
  x0: number,
  z0: number,
  base: number,
  opt: {
    w: number;
    d: number;
    wall: number;
    roof: number;
    roofStyle: 'gable' | 'flat' | 'pyramid';
    door: boolean;
    windows: boolean;
    chimney: boolean;
  },
) {
  const { w, d, wall, roof, roofStyle } = opt;
  const h = 3;
  // 地板
  for (let x = 0; x < w; x++) for (let z = 0; z < d; z++) ctx.set(x0 + x, base, z0 + z, 8);
  // 墙 + 转角柱
  for (let y = 1; y <= h; y++) {
    for (let x = 0; x < w; x++) {
      for (let z = 0; z < d; z++) {
        const corner = (x === 0 || x === w - 1) && (z === 0 || z === d - 1);
        const edge = x === 0 || x === w - 1 || z === 0 || z === d - 1;
        if (corner) ctx.set(x0 + x, base + y, z0 + z, 6);
        else if (edge) {
          const isWindow = opt.windows && y === 2 && (x === Math.floor(w / 2) || z === Math.floor(d / 2));
          ctx.set(x0 + x, base + y, z0 + z, isWindow ? 9 : wall);
        }
      }
    }
  }
  // 门
  if (opt.door) {
    ctx.set(x0 + Math.floor(w / 2), base + 1, z0, AIR);
    ctx.set(x0 + Math.floor(w / 2), base + 2, z0, AIR);
    ctx.set(x0 + Math.floor(w / 2), base + 3, z0, 8);
  }
  // 屋顶
  if (roofStyle === 'gable') {
    const half = Math.ceil(d / 2);
    for (let i = 0; i <= half; i++) {
      for (let x = -1; x <= w; x++) {
        ctx.set(x0 + x, base + h + 1 + i, z0 + i, roof);
        ctx.set(x0 + x, base + h + 1 + i, z0 + d - 1 - i, roof);
      }
    }
  } else if (roofStyle === 'pyramid') {
    for (let i = 0; i <= Math.min(w, d); i++) {
      for (let x = -1 + i; x <= w - i; x++)
        for (let z = -1 + i; z <= d - i; z++) {
          const edge = x === -1 + i || x === w - i || z === -1 + i || z === d - i;
          if (edge || i === Math.min(w, d)) ctx.set(x0 + x, base + h + 1 + i, z0 + z, roof);
        }
    }
  } else {
    for (let x = -1; x <= w; x++)
      for (let z = -1; z <= d; z++) {
        ctx.set(x0 + x, base + h + 1, z0 + z, roof);
        const edge = x === -1 || x === w || z === -1 || z === d;
        if (edge) ctx.set(x0 + x, base + h + 2, z0 + z, roof);
      }
  }
  // 烟囱
  if (opt.chimney) {
    const cx = x0 + w - 1;
    const cz = z0 + 1;
    for (let y = h + 1; y <= h + 4; y++) ctx.set(cx, base + y, cz, 4);
    ctx.set(cx, base + h + 5, cz, 13);
  }
}

/** 沙漠神庙：阶梯金字塔 + 入口甬道 + 柱厅 + 墓室 + 岩浆陷阱 */
export function buildTemple(ctx: StructCtx) {
  const base = baseOf(ctx, 0, 0, 15, 15);
  platform(ctx, 0, 0, 15, 15, base, 5);

  // 五层阶梯金字塔
  for (let layer = 0; layer < 5; layer++) {
    const inset = layer;
    for (let x = 1 + inset; x <= 14 - inset; x++) {
      for (let z = 1 + inset; z <= 14 - inset; z++) {
        const edge = x === 1 + inset || x === 14 - inset || z === 1 + inset || z === 14 - inset;
        ctx.set(x, base + layer, z, edge ? 5 : layer === 0 ? AIR : 5);
      }
    }
  }
  // 顶部神殿
  for (let x = 5; x <= 10; x++)
    for (let z = 5; z <= 10; z++) {
      ctx.set(x, base + 5, z, 5);
      const edge = x === 5 || x === 10 || z === 5 || z === 10;
      if (edge && !(x === 7 && z === 5)) ctx.set(x, base + 6, z, 5);
      if (edge) ctx.set(x, base + 7, z, 5);
    }
  ctx.set(7, base + 8, 7, 13);
  ctx.set(8, base + 8, 8, 13);

  // 入口甬道（向下）
  for (let i = 0; i < 4; i++) {
    ctx.set(7, base - 1 - i, 1 + i, AIR);
    ctx.set(8, base - 1 - i, 1 + i, AIR);
    ctx.set(7, base - i, 1 + i, AIR);
    ctx.set(8, base - i, 1 + i, AIR);
  }
  // 地下柱厅
  for (let x = 4; x <= 11; x++)
    for (let z = 4; z <= 11; z++) {
      ctx.set(x, base - 4, z, AIR);
      ctx.set(x, base - 3, z, AIR);
      ctx.set(x, base - 2, z, AIR);
      ctx.set(x, base - 5, z, 4);
    }
  for (const [px, pz] of [[5, 5], [10, 5], [5, 10], [10, 10], [7, 7], [8, 8]]) {
    ctx.set(px, base - 4, pz, 5);
    ctx.set(px, base - 3, pz, 5);
    ctx.set(px, base - 2, pz, 21);
  }
  // 岩浆陷阱沟
  for (let x = 5; x <= 10; x++) ctx.set(x, base - 5, 8, 17);
  // 墓室宝箱 + 陪葬品
  ctx.chest(8, base - 4, 6, 'temple');
  ctx.set(6, base - 4, 9, 15);
  ctx.set(9, base - 4, 9, 13);
  for (let i = 0; i < 3; i++) ctx.set(4 + i, base - 2, 4, 30);

  ctx.mark('temple', 7, base + 1, 7);
}

/** 遗迹：断墙残柱 + 倒塌拱门 + 藤蔓 + 半埋石棺 + 裂地 */
export function buildRuin(ctx: StructCtx) {
  const base = baseOf(ctx, 1, 1, 14, 14);
  platform(ctx, 1, 1, 14, 14, base, 3);
  const r = (x: number, z: number) => hash2(x + ctx.cx * 31, z + ctx.cz * 17, ctx.seed + 7);

  // 破碎地面（不规则坑洼 + 裂纹）
  for (let x = 1; x <= 14; x++)
    for (let z = 1; z <= 14; z++) {
      const v = r(x, z);
      if (v > 0.86) ctx.set(x, base - 1, z, AIR);
      else if (v > 0.74) ctx.set(x, base - 1, z, 4);
      else if (v > 0.68) ctx.set(x, base - 1, z, 2);
    }

  // 残墙（高度参差，带缺口）
  const wallLines: [number, number, number, number][] = [
    [2, 2, 8, 2],
    [2, 2, 2, 7],
    [13, 4, 13, 11],
    [6, 13, 12, 13],
  ];
  for (const [x0, z0, x1, z1] of wallLines) {
    const steps = Math.max(Math.abs(x1 - x0), Math.abs(z1 - z0));
    for (let i = 0; i <= steps; i++) {
      const x = x0 + Math.sign(x1 - x0) * i;
      const z = z0 + Math.sign(z1 - z0) * i;
      const h = 1 + Math.floor(r(x, z) * 4);
      if (r(x, z) > 0.22) {
        for (let y = 0; y < h; y++) ctx.set(x, base + y, z, y === h - 1 && r(x, z) > 0.6 ? 4 : 4);
        if (r(x, z) > 0.8) ctx.set(x, base + h, z, 26); // 藤蔓/草
      }
    }
  }

  // 倒塌的柱子（横躺）
  for (let i = 0; i < 5; i++) ctx.set(5 + i, base, 8, 4);
  ctx.set(9, base + 1, 8, 4);
  // 立着的断柱
  for (const [px, pz, h] of [[4, 5, 3], [11, 6, 2], [6, 11, 4], [10, 10, 1]] as const) {
    for (let y = 0; y < h; y++) ctx.set(px, base + y, pz, 4);
    if (h >= 3) ctx.set(px, base + h, pz, 21);
  }

  // 半埋石棺
  ctx.set(7, base, 5, 4);
  ctx.set(8, base, 5, 4);
  ctx.set(7, base + 1, 5, 3);
  ctx.set(8, base + 1, 5, 4);

  // 破碎拱门
  for (let y = 0; y < 3; y++) {
    ctx.set(3, base + y, 10, 4);
    ctx.set(6, base + y, 10, 4);
  }
  ctx.set(4, base + 3, 10, 4);
  ctx.set(5, base + 3, 10, 4);

  ctx.chest(9, base, 12, 'ruin');
  ctx.mark('ruin', 7, base + 1, 7);
}

/** 祭坛：环形台阶 + 石柱环 + 符文地面 + 悬浮水晶 + 火盆 */
export function buildAltar(ctx: StructCtx) {
  const base = baseOf(ctx, 1, 1, 14, 14);
  platform(ctx, 1, 1, 14, 14, base, 3);
  const cx = 7.5;
  const cz = 7.5;

  // 三层圆形台阶
  for (let layer = 0; layer < 3; layer++) {
    const rad = 6 - layer;
    for (let x = 1; x <= 14; x++)
      for (let z = 1; z <= 14; z++) {
        const d = Math.hypot(x + 0.5 - cx, z + 0.5 - cz);
        if (d < rad + 1 && d >= rad) ctx.set(x, base + layer, z, layer === 2 ? 3 : 4);
        else if (d < rad) ctx.set(x, base + layer, z, AIR);
      }
  }

  // 符文地面（中心图案）
  for (let x = 4; x <= 11; x++)
    for (let z = 4; z <= 11; z++) {
      const d = Math.hypot(x + 0.5 - cx, z + 0.5 - cz);
      ctx.set(x, base + 2, z, d < 1.6 ? 15 : Math.abs(d - 3) < 0.6 ? 18 : 3);
    }

  // 八根石柱（高低错落，顶部水晶）
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2;
    const px = Math.round(cx + Math.cos(a) * 5 - 0.5);
    const pz = Math.round(cz + Math.sin(a) * 5 - 0.5);
    const h = 3 + (i % 3);
    for (let y = 0; y < h; y++) ctx.set(px, base + 3 + y, pz, 4);
    ctx.set(px, base + 3 + h, pz, 15);
    ctx.set(px, base + 4 + h, pz, 18);
  }

  // 中央悬浮水晶阵
  ctx.set(7, base + 4, 7, 15);
  ctx.set(8, base + 5, 8, 18);
  ctx.set(7, base + 6, 8, 15);
  ctx.set(8, base + 4, 7, 18);

  // 四角火盆
  for (const [fx, fz] of [[4, 4], [11, 4], [4, 11], [11, 11]]) {
    ctx.set(fx, base + 3, fz, 4);
    ctx.set(fx, base + 4, fz, 13);
  }

  // 上坛阶梯
  for (let i = 0; i < 3; i++) ctx.set(7, base + i, 13 - i, 4);

  ctx.chest(5, base + 3, 9, 'altar');
  ctx.mark('altar', 7, base + 3, 7);
}

/** 瞭望塔：锥形收分塔身 + 挑台 + 螺旋楼梯 + 旗杆 + 石基 */
export function buildTower(ctx: StructCtx) {
  const base = baseOf(ctx, 3, 3, 12, 12);
  platform(ctx, 3, 3, 12, 12, base, 4);

  // 石基（外扩）
  for (let x = 4; x <= 11; x++)
    for (let z = 4; z <= 11; z++) {
      const edge = x === 4 || x === 11 || z === 4 || z === 11;
      ctx.set(x, base, z, edge ? 4 : 8);
      if (edge) ctx.set(x, base + 1, z, 4);
    }

  // 收分塔身（每 3 层缩一圈）
  for (let y = 2; y < 14; y++) {
    const shrink = Math.floor((y - 2) / 4);
    const x0 = 5 + shrink;
    const x1 = 10 - shrink;
    for (let x = x0; x <= x1; x++)
      for (let z = x0; z <= x1; z++) {
        const edge = x === x0 || x === x1 || z === x0 || z === x1;
        if (!edge) continue;
        // 窗洞
        const isWindow = y % 4 === 0 && ((x === x0 && z === Math.floor((x0 + x1) / 2)) || (z === x0 && x === Math.floor((x0 + x1) / 2)));
        ctx.set(x, base + y, z, isWindow ? AIR : 4);
      }
  }

  // 挑台（每 4 层一圈外沿）
  for (let level = 0; level < 3; level++) {
    const y = base + 5 + level * 4;
    const shrink = Math.floor((5 + level * 4 - 2) / 4);
    const x0 = 4 + shrink;
    const x1 = 11 - shrink;
    for (let x = x0; x <= x1; x++)
      for (let z = x0; z <= x1; z++) {
        const edge = x === x0 || x === x1 || z === x0 || z === x1;
        ctx.set(x, y, z, 8);
        if (edge) ctx.set(x, y + 1, z, 8);
      }
  }

  // 螺旋楼梯
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * Math.PI * 4;
    const px = Math.round(7.5 + Math.cos(a) * 2 - 0.5);
    const pz = Math.round(7.5 + Math.sin(a) * 2 - 0.5);
    ctx.set(px, base + 2 + i, pz, 8);
  }

  // 顶棚 + 旗杆
  for (let x = 5; x <= 10; x++)
    for (let z = 5; z <= 10; z++) ctx.set(x, base + 14, z, 10);
  ctx.set(7, base + 15, 7, 6);
  ctx.set(7, base + 16, 7, 6);
  ctx.set(8, base + 16, 7, 18);
  ctx.set(8, base + 15, 7, 18);
  for (const [lx, lz] of [[5, 5], [10, 5], [5, 10], [10, 10]]) ctx.set(lx, base + 15, lz, 30);

  ctx.chest(7, base + 1, 7, 'tower');
  ctx.mark('tower', 7, base + 2, 7);
}

/** 雪屋：真冰穹顶 + 冰砖内衬 + 烟囱 + 冰窗 + 内部炉火 */
export function buildIgloo(ctx: StructCtx) {
  const base = baseOf(ctx, 2, 2, 13, 13);
  platform(ctx, 2, 2, 13, 13, base, 12);
  const cx = 7.5;
  const cz = 7.5;

  for (let x = 2; x <= 13; x++)
    for (let z = 2; z <= 13; z++)
      for (let y = 0; y <= 6; y++) {
        const d = Math.hypot(x + 0.5 - cx, z + 0.5 - cz, y * 1.15);
        if (d > 3.2 && d < 4.8) ctx.set(x, base + y, z, y > 3 ? 23 : 12);
        else if (y === 0) ctx.set(x, base, z, 12);
      }

  // 门洞 + 门框
  ctx.set(7, base + 1, 3, AIR);
  ctx.set(7, base + 2, 3, AIR);
  ctx.set(6, base + 1, 3, 23);
  ctx.set(8, base + 1, 3, 23);
  ctx.set(7, base + 3, 3, 23);
  // 冰窗
  ctx.set(4, base + 2, 7, 23);
  ctx.set(11, base + 2, 7, 23);
  // 烟囱
  ctx.set(9, base + 5, 9, 12);
  ctx.set(9, base + 6, 9, 12);
  // 内部：炉火 + 床 + 箱
  ctx.set(9, base + 1, 9, 13);
  ctx.set(5, base + 1, 9, 8);
  ctx.set(5, base + 1, 10, 14);
  ctx.chest(10, base + 1, 6, 'igloo');
  ctx.mark('igloo', 7, base + 1, 7);
}

/** 露营地：锥形帐篷 + 石圈篝火 + 原木座椅 + 木桶 + 晾肉架 */
export function buildCamp(ctx: StructCtx) {
  const base = baseOf(ctx, 2, 2, 13, 13);
  platform(ctx, 2, 2, 13, 13, base, 1);

  // 篝火石圈
  for (let a = 0; a < 8; a++) {
    const ang = (a / 8) * Math.PI * 2;
    ctx.set(Math.round(7 + Math.cos(ang) * 2), base, Math.round(7 + Math.sin(ang) * 2), 4);
  }
  ctx.set(7, base, 7, 6);
  ctx.set(7, base + 1, 7, 30);
  ctx.set(6, base, 7, 6);
  ctx.set(8, base, 7, 6);

  // 两顶锥形帐篷
  for (const [tx, tz] of [[4, 4], [11, 10]] as const) {
    for (let layer = 0; layer < 3; layer++) {
      const rad = 2 - layer;
      for (let dx = -rad; dx <= rad; dx++)
        for (let dz = -rad; dz <= rad; dz++) {
          const edge = Math.abs(dx) === rad || Math.abs(dz) === rad;
          if (edge) ctx.set(tx + dx, base + 1 + layer, tz + dz, layer === 2 ? 8 : 14);
          else if (layer === 0) ctx.set(tx + dx, base, tz + dz, 8);
        }
    }
    ctx.set(tx, base + 4, tz, 6);
    // 门帘
    ctx.set(tx, base + 1, tz - 2, AIR);
  }

  // 原木座椅
  for (const [sx, sz] of [[5, 8], [9, 6]] as const) {
    ctx.set(sx, base + 1, sz, 6);
    ctx.set(sx + 1, base + 1, sz, 6);
  }
  // 木桶 + 晾肉架
  ctx.set(12, base + 1, 4, 8);
  ctx.set(12, base + 2, 4, 8);
  ctx.set(3, base + 1, 11, 6);
  ctx.set(3, base + 2, 11, 6);
  ctx.set(4, base + 2, 11, 6);
  ctx.set(3, base + 1, 11, 22);

  ctx.chest(10, base + 1, 12, 'camp');
  ctx.mark('camp', 7, base + 1, 7);
}

/** 废弃矿井：地下坑道 + 木支架 + 矿车轨道 + 塌陷口 + 宝箱 */
export function buildMineshaft(ctx: StructCtx) {
  const base = baseOf(ctx, 1, 1, 14, 14);
  const y = Math.max(6, base - 8);

  // 主坑道（十字交叉）
  for (let i = 1; i <= 14; i++) {
    for (let h = 0; h < 3; h++) {
      ctx.set(i, y + h, 7, AIR);
      ctx.set(i, y + h, 8, AIR);
      ctx.set(7, y + h, i, AIR);
      ctx.set(8, y + h, i, AIR);
    }
  }
  // 木支架（每 3 格一组）
  for (let i = 2; i <= 13; i += 3) {
    ctx.set(i, y, 6, 6);
    ctx.set(i, y + 1, 6, 6);
    ctx.set(i, y + 2, 6, 6);
    ctx.set(i, y, 9, 6);
    ctx.set(i, y + 1, 9, 6);
    ctx.set(i, y + 2, 9, 6);
    ctx.set(i, y + 3, 7, 8);
    ctx.set(i, y + 3, 8, 8);
  }
  // 轨道（用木板条模拟）
  for (let i = 1; i <= 14; i++) {
    ctx.set(i, y, 7, 8);
    ctx.set(i, y, 8, 8);
  }
  // 侧室
  for (let x = 10; x <= 13; x++)
    for (let z = 10; z <= 13; z++)
      for (let h = 0; h < 3; h++) ctx.set(x, y + h, z, AIR);
  ctx.set(11, y, 11, 21);
  ctx.set(12, y + 1, 12, 13);
  // 塌陷口（通往地面）
  for (let h = 0; h < 6; h++) {
    ctx.set(3, y + h, 3, AIR);
    ctx.set(4, y + h, 3, AIR);
  }
  ctx.set(3, y, 3, 4);

  ctx.chest(12, y, 11, 'ruin');
  ctx.mark('ruin', 7, y, 7);
}

/** 树屋：巨树 + 平台 + 梯 + 围栏 + 吊桥 + 灯笼 */
export function buildTreehouse(ctx: StructCtx) {
  const base = baseOf(ctx, 1, 1, 14, 14);
  platform(ctx, 3, 3, 12, 12, base, 2);
  const tx = 7;
  const tz = 7;
  const trunkH = 9;

  // 巨树树干（2x2）
  for (let y = 0; y < trunkH; y++) {
    ctx.set(tx, base + y, tz, 6);
    ctx.set(tx + 1, base + y, tz, 6);
    ctx.set(tx, base + y, tz + 1, 6);
    ctx.set(tx + 1, base + y, tz + 1, 6);
  }
  // 树冠
  for (let dx = -3; dx <= 4; dx++)
    for (let dz = -3; dz <= 4; dz++)
      for (let dy = 0; dy < 3; dy++) {
        const d = Math.hypot(dx - 0.5, dz - 0.5);
        if (d < 3.6 - dy * 0.7) ctx.set(tx + dx, base + trunkH + dy, tz + dz, 7);
      }

  // 平台
  const py = base + 6;
  for (let dx = -3; dx <= 4; dx++)
    for (let dz = -3; dz <= 4; dz++) {
      if (Math.abs(dx) < 2 && Math.abs(dz) < 2) continue;
      ctx.set(tx + dx, py, tz + dz, 8);
    }
  // 围栏
  for (let dx = -3; dx <= 4; dx++)
    for (let dz = -3; dz <= 4; dz++) {
      const edge = Math.abs(dx) === 3 || Math.abs(dx) === 4 || Math.abs(dz) === 3 || Math.abs(dz) === 4;
      if (edge) ctx.set(tx + dx, py + 1, tz + dz, 8);
    }
  // 小屋
  for (let dx = 2; dx <= 4; dx++)
    for (let dz = -3; dz <= -1; dz++) {
      ctx.set(tx + dx, py + 1, tz + dz, 8);
      ctx.set(tx + dx, py + 2, tz + dz, 8);
      ctx.set(tx + dx, py + 3, tz + dz, 10);
    }
  // 梯子
  for (let y = 0; y < 6; y++) ctx.set(tx - 1, base + y, tz - 1, 8);
  // 灯笼
  ctx.set(tx - 3, py + 2, tz - 3, 30);
  ctx.set(tx + 4, py + 2, tz + 4, 30);

  ctx.chest(tx + 3, py + 1, tz - 2, 'camp');
  ctx.mark('camp', tx, py + 1, tz);
}

/** 沼泽小屋：水上高脚屋 + 支柱 + 栈道 + 芦苇 */
export function buildHut(ctx: StructCtx) {
  const base = baseOf(ctx, 2, 2, 13, 13);
  const fy = base + 3;
  platform(ctx, 2, 2, 13, 13, base, 2);

  // 水面
  for (let x = 2; x <= 13; x++)
    for (let z = 2; z <= 13; z++) {
      ctx.set(x, base, z, 11);
      ctx.set(x, base - 1, z, 2);
    }

  // 高脚支柱
  for (const [px, pz] of [[4, 4], [11, 4], [4, 11], [11, 11], [7, 4], [7, 11]] as const) {
    for (let y = base; y < fy; y++) ctx.set(px, y, pz, 6);
  }
  // 地板 + 墙 + 尖顶
  for (let x = 4; x <= 11; x++)
    for (let z = 4; z <= 11; z++) {
      ctx.set(x, fy, z, 8);
      const edge = x === 4 || x === 11 || z === 4 || z === 11;
      if (edge && !(x === 7 && z === 4)) {
        ctx.set(x, fy + 1, z, 8);
        ctx.set(x, fy + 2, z, 8);
      }
    }
  for (let i = 0; i <= 4; i++)
    for (let x = 3 + i; x <= 12 - i; x++) {
      ctx.set(x, fy + 3 + i, 4 + i, 10);
      ctx.set(x, fy + 3 + i, 11 - i, 10);
    }
  // 栈道
  for (let z = 12; z <= 13; z++) ctx.set(7, fy, z, 8);
  // 芦苇
  for (const [rx, rz] of [[3, 8], [12, 6], [5, 13], [10, 2]] as const) {
    ctx.set(rx, base + 1, rz, 26);
    ctx.set(rx, base + 2, rz, 26);
  }
  ctx.set(9, fy + 1, 9, 30);

  ctx.chest(6, fy + 1, 9, 'camp');
  ctx.mark('camp', 7, fy + 1, 7);
}
