import * as THREE from 'three';
import { TILE_NAMES, getBlock } from './blocks';
import { getTool } from './items';

export const TILE_PX = 32;
export const ATLAS_COLS = 10;
export const ATLAS_ROWS = 8;
export const ATLAS_PX = TILE_PX * ATLAS_COLS;

function rand(seed: number) {
  let s = (seed * 2654435761) >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

type Ctx = CanvasRenderingContext2D;

function px(ctx: Ctx, x: number, y: number, w: number, h: number, color: string) {
  ctx.fillStyle = color;
  ctx.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h));
}

function speckle(ctx: Ctx, r: () => number, colors: string[], count: number, size = 2) {
  for (let i = 0; i < count; i++) {
    const c = colors[Math.floor(r() * colors.length)];
    const s = size + Math.floor(r() * 2);
    px(ctx, Math.floor(r() * TILE_PX), Math.floor(r() * TILE_PX), s, s, c);
  }
}

/** soft cartoon rim: light top-left, dark bottom-right */
function rim(ctx: Ctx, light = 'rgba(255,255,255,0.28)', dark = 'rgba(0,0,0,0.18)') {
  px(ctx, 0, 0, TILE_PX, 2, light);
  px(ctx, 0, 0, 2, TILE_PX, light);
  px(ctx, 0, TILE_PX - 2, TILE_PX, 2, dark);
  px(ctx, TILE_PX - 2, 0, 2, TILE_PX, dark);
}

/** 16 色染色玻璃的基础色（跟 Minecraft 染料色一一对应，也是 HD 材质包里
 *  对应文件名 `<color>_stained_glass.png` 的那 16 个颜色名）。 */
export const GLASS_COLORS: Record<string, string> = {
  white: '235,235,235',
  orange: '235,140,50',
  magenta: '210,90,200',
  light_blue: '110,185,230',
  yellow: '235,210,60',
  lime: '140,210,60',
  pink: '235,150,190',
  gray: '95,100,105',
  light_gray: '155,160,165',
  cyan: '50,160,170',
  purple: '130,70,190',
  blue: '55,80,190',
  brown: '110,75,45',
  green: '90,110,40',
  red: '175,50,45',
  black: '25,25,30',
};

function drawStainedGlass(ctx: Ctx, rgb: string) {
  ctx.clearRect(0, 0, TILE_PX, TILE_PX);
  px(ctx, 0, 0, TILE_PX, TILE_PX, `rgba(${rgb},0.55)`);
  ctx.strokeStyle = 'rgba(255,255,255,0.85)';
  ctx.lineWidth = 3;
  ctx.strokeRect(1.5, 1.5, TILE_PX - 3, TILE_PX - 3);
  ctx.strokeStyle = `rgba(${rgb},0.95)`;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(6, 24);
  ctx.lineTo(22, 7);
  ctx.moveTo(15, 26);
  ctx.lineTo(26, 14);
  ctx.stroke();
}

const DRAW: Record<string, (ctx: Ctx, r: () => number) => void> = {
  grass_top(ctx, r) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#6ec949');
    speckle(ctx, r, ['#5cb63c', '#84dc5c', '#4fa634'], 90, 2);
    speckle(ctx, r, ['#9bec74'], 26, 2);
    rim(ctx, 'rgba(255,255,255,0.22)', 'rgba(0,60,0,0.16)');
  },
  grass_side(ctx, r) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#a4723f');
    speckle(ctx, r, ['#8d6035', '#b98a53', '#7b5330'], 70, 2);
    // wavy grass lip
    for (let x = 0; x < TILE_PX; x += 2) {
      const h = 8 + Math.floor(r() * 6);
      px(ctx, x, 0, 2, h, '#6ec949');
      px(ctx, x, h - 2, 2, 2, '#57ae38');
      if (r() > 0.6) px(ctx, x, 0, 2, 3, '#8ee162');
    }
    px(ctx, 0, 0, TILE_PX, 2, 'rgba(255,255,255,0.25)');
    px(ctx, 0, TILE_PX - 2, TILE_PX, 2, 'rgba(0,0,0,0.18)');
  },
  dirt(ctx, r) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#a4723f');
    speckle(ctx, r, ['#8d6035', '#b98a53', '#7b5330', '#c39a66'], 110, 2);
    rim(ctx, 'rgba(255,235,200,0.2)', 'rgba(60,30,0,0.2)');
  },
  stone(ctx, r) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#a8a8b4');
    speckle(ctx, r, ['#9a9aa6', '#b8b8c4', '#8f8f9c'], 80, 3);
    ctx.strokeStyle = 'rgba(90,90,105,0.6)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(4, 10);
    ctx.lineTo(14, 14);
    ctx.lineTo(22, 8);
    ctx.moveTo(8, 24);
    ctx.lineTo(20, 26);
    ctx.stroke();
    rim(ctx, 'rgba(255,255,255,0.3)', 'rgba(40,40,55,0.22)');
  },
  cobble(ctx, r) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#6f6f7c');
    const cells = [
      [1, 1, 13, 12],
      [16, 1, 15, 9],
      [1, 15, 9, 16],
      [12, 12, 11, 10],
      [24, 12, 7, 12],
      [12, 24, 12, 7],
      [1, 24, 9, 7],
    ];
    for (const [x, y, w, h] of cells) {
      const g = 150 + Math.floor(r() * 45);
      px(ctx, x, y, w, h, `rgb(${g},${g},${g + 10})`);
      px(ctx, x, y, w, 2, `rgb(${g + 30},${g + 30},${g + 38})`);
      px(ctx, x, y + h - 2, w, 2, `rgb(${g - 35},${g - 35},${g - 25})`);
    }
  },
  sand(ctx, r) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#f6e3a6');
    speckle(ctx, r, ['#ecd48c', '#fff2c8', '#e2c777'], 90, 2);
    rim(ctx, 'rgba(255,255,255,0.35)', 'rgba(150,110,40,0.18)');
  },
  log_side(ctx, r) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#ab7a45');
    for (let x = 0; x < TILE_PX; x += 4) {
      const c = r() > 0.5 ? '#96683a' : '#bd8d55';
      px(ctx, x, 0, 2 + Math.floor(r() * 2), TILE_PX, c);
    }
    px(ctx, 8, 10, 6, 9, '#835a31');
    px(ctx, 10, 12, 3, 5, '#a67746');
    rim(ctx, 'rgba(255,220,170,0.25)', 'rgba(60,35,0,0.25)');
  },
  log_top(ctx, r) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#8e6236');
    const rings = ['#d8ab72', '#c3945c', '#e0b982', '#b98a53'];
    for (let i = 0; i < 4; i++) {
      const inset = 3 + i * 3;
      px(ctx, inset, inset, TILE_PX - inset * 2, TILE_PX - inset * 2, rings[i % rings.length]);
    }
    px(ctx, 14, 14, 4, 4, '#8e6236');
    speckle(ctx, r, ['rgba(255,255,255,0.10)'], 20, 2);
  },
  leaves(ctx, r) {
    ctx.clearRect(0, 0, TILE_PX, TILE_PX);
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#4fb83a');
    // holes
    for (let i = 0; i < 14; i++) {
      const x = Math.floor(r() * TILE_PX);
      const y = Math.floor(r() * TILE_PX);
      ctx.clearRect(x, y, 2 + Math.floor(r() * 2), 2 + Math.floor(r() * 2));
    }
    speckle(ctx, r, ['#67d64f', '#3f9a2e', '#7ee863'], 80, 3);
    px(ctx, 0, 0, TILE_PX, 2, 'rgba(255,255,255,0.22)');
    px(ctx, 0, TILE_PX - 2, TILE_PX, 2, 'rgba(0,50,0,0.2)');
  },
  planks(ctx, r) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#dba86c');
    for (let row = 0; row < 4; row++) {
      const y = row * 8;
      px(ctx, 0, y, TILE_PX, 1, '#a97c46');
      px(ctx, 0, y + 1, TILE_PX, 2, '#e9bd83');
      px(ctx, 0, y + 7, TILE_PX, 1, '#b98a53');
      const notch = Math.floor(r() * 22) + 4;
      px(ctx, notch, y + 1, 1, 6, '#a97c46');
      for (let i = 0; i < 3; i++) {
        px(ctx, Math.floor(r() * TILE_PX), y + 3 + Math.floor(r() * 3), 5, 1, '#c8965a');
      }
    }
    rim(ctx, 'rgba(255,255,255,0.2)', 'rgba(90,55,10,0.2)');
  },
  glass(ctx) {
    ctx.clearRect(0, 0, TILE_PX, TILE_PX);
    px(ctx, 0, 0, TILE_PX, TILE_PX, 'rgba(178,235,255,0.20)');
    ctx.strokeStyle = 'rgba(255,255,255,0.92)';
    ctx.lineWidth = 3;
    ctx.strokeRect(1.5, 1.5, TILE_PX - 3, TILE_PX - 3);
    ctx.strokeStyle = 'rgba(160,225,255,0.85)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(6, 24);
    ctx.lineTo(22, 7);
    ctx.moveTo(15, 26);
    ctx.lineTo(26, 14);
    ctx.stroke();
  },
  brick(ctx, r) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#efe6d6');
    for (let row = 0; row < 4; row++) {
      const y = row * 8 + 1;
      const off = row % 2 === 0 ? 0 : -8;
      for (let x = off; x < TILE_PX; x += 16) {
        const shade = 190 + Math.floor(r() * 25);
        px(ctx, x + 1, y, 14, 6, `rgb(${shade},${Math.floor(shade * 0.45)},${Math.floor(shade * 0.36)})`);
        px(ctx, x + 1, y, 14, 2, `rgb(${shade + 25},${Math.floor(shade * 0.58)},${Math.floor(shade * 0.48)})`);
      }
    }
  },
  water(ctx, r) {
    ctx.clearRect(0, 0, TILE_PX, TILE_PX);
    px(ctx, 0, 0, TILE_PX, TILE_PX, 'rgba(56,160,232,0.72)');
    for (let i = 0; i < 5; i++) {
      const y = Math.floor(r() * TILE_PX);
      px(ctx, 0, y, TILE_PX, 2, 'rgba(150,225,255,0.45)');
      px(ctx, Math.floor(r() * 16), y + 2, 12, 1, 'rgba(255,255,255,0.35)');
    }
  },
  snow_top(ctx, r) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#f7fbff');
    speckle(ctx, r, ['#e4eefa', '#ffffff', '#d7e6f7'], 60, 3);
    rim(ctx, 'rgba(255,255,255,0.6)', 'rgba(140,170,200,0.25)');
  },
  snow_side(ctx, r) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#a4723f');
    speckle(ctx, r, ['#8d6035', '#b98a53'], 50, 2);
    for (let x = 0; x < TILE_PX; x += 2) {
      const h = 9 + Math.floor(r() * 5);
      px(ctx, x, 0, 2, h, '#f7fbff');
      px(ctx, x, h - 2, 2, 2, '#dfeaf6');
    }
  },
  glow(ctx, r) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#ffc93c');
    const g = ctx.createRadialGradient(16, 16, 2, 16, 16, 18);
    g.addColorStop(0, '#fff8c9');
    g.addColorStop(0.5, '#ffd85e');
    g.addColorStop(1, '#f0a319');
    ctx.fillStyle = g;
    ctx.fillRect(3, 3, 26, 26);
    speckle(ctx, r, ['#fff3ad', '#ef9c12'], 26, 2);
    px(ctx, 0, 0, TILE_PX, 3, '#ffe89a');
    px(ctx, 0, TILE_PX - 3, TILE_PX, 3, '#d8890c');
  },
  candy(ctx) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#ff8fc0');
    ctx.save();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 5;
    ctx.beginPath();
    for (let i = -TILE_PX; i < TILE_PX * 2; i += 12) {
      ctx.moveTo(i, 0);
      ctx.lineTo(i + TILE_PX, TILE_PX);
    }
    ctx.stroke();
    ctx.restore();
    px(ctx, 5, 5, 4, 4, '#fff0f6');
    px(ctx, 22, 18, 3, 3, '#ffd9e9');
    rim(ctx, 'rgba(255,255,255,0.45)', 'rgba(180,40,100,0.25)');
  },
  crystal(ctx) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#4fd2f5');
    const facets: [number, number, number, number, string][] = [
      [2, 2, 14, 14, '#8ce9ff'],
      [16, 4, 13, 12, '#33bce6'],
      [4, 17, 12, 12, '#2aa9d6'],
      [17, 17, 12, 12, '#7fe2fb'],
    ];
    for (const [x, y, w, h, c] of facets) px(ctx, x, y, w, h, c);
    px(ctx, 6, 6, 4, 4, '#ffffff');
    px(ctx, 20, 21, 3, 3, '#ffffff');
    rim(ctx, 'rgba(255,255,255,0.5)', 'rgba(0,60,90,0.3)');
  },
  bedrock(ctx, r) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#4b4b58');
    speckle(ctx, r, ['#3a3a45', '#5f5f6d', '#2e2e38', '#6d6d7c'], 110, 4);
    rim(ctx, 'rgba(255,255,255,0.12)', 'rgba(0,0,0,0.35)');
  },
  lava(ctx, r) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#ef6a13');
    for (let i = 0; i < 10; i++) {
      px(ctx, Math.floor(r() * 28), Math.floor(r() * 28), 5 + Math.floor(r() * 5), 4, '#ffd34d');
    }
    for (let i = 0; i < 8; i++) {
      px(ctx, Math.floor(r() * 28), Math.floor(r() * 28), 4, 3, '#c93a06');
    }
    px(ctx, 0, 0, TILE_PX, 2, '#ffb03a');
  },
  rainbow(ctx) {
    const colors = ['#ff6b6b', '#ffa94d', '#ffe066', '#8ce99a', '#66d9e8', '#b197fc'];
    const h = TILE_PX / colors.length;
    colors.forEach((c, i) => px(ctx, 0, i * h, TILE_PX, h, c));
    px(ctx, 0, 0, TILE_PX, 2, 'rgba(255,255,255,0.55)');
    px(ctx, 3, 3, 4, TILE_PX - 6, 'rgba(255,255,255,0.25)');
  },
  cloud(ctx, r) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#f4f8ff');
    for (let i = 0; i < 8; i++) {
      ctx.fillStyle = i % 2 ? 'rgba(210,226,245,0.9)' : 'rgba(255,255,255,0.95)';
      ctx.beginPath();
      ctx.arc(r() * TILE_PX, r() * TILE_PX, 4 + r() * 5, 0, Math.PI * 2);
      ctx.fill();
    }
    rim(ctx, 'rgba(255,255,255,0.8)', 'rgba(160,185,215,0.35)');
  },
  tnt_side(ctx) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#e04141');
    px(ctx, 0, 10, TILE_PX, 12, '#f7f2ea');
    px(ctx, 0, 10, TILE_PX, 2, '#c9c1b4');
    ctx.fillStyle = '#3a3a45';
    ctx.font = 'bold 10px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('TNT', 16, 20);
    px(ctx, 0, 0, TILE_PX, 3, '#f26b6b');
    px(ctx, 0, TILE_PX - 3, TILE_PX, 3, '#a82626');
  },
  tnt_top(ctx) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#e04141');
    px(ctx, 4, 4, 24, 24, '#c22f2f');
    ctx.fillStyle = '#3a3a45';
    ctx.beginPath();
    ctx.arc(16, 16, 6, 0, Math.PI * 2);
    ctx.fill();
    px(ctx, 15, 2, 2, 8, '#ffd34d');
  },
  gem_ore(ctx, r) {
    DRAW.stone(ctx, r);
    const gems: [number, number, string][] = [
      [7, 8, '#5ce1e6'],
      [19, 6, '#ff8fc0'],
      [12, 19, '#ffe066'],
      [22, 20, '#b197fc'],
    ];
    for (const [x, y, c] of gems) {
      px(ctx, x, y, 6, 6, c);
      px(ctx, x + 1, y + 1, 2, 2, '#ffffff');
      px(ctx, x, y + 5, 6, 1, 'rgba(0,0,0,0.25)');
    }
  },
  ore_iron(ctx) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#7a7a8a');
    speckle(ctx, rand(23), ['#8a8a9a', '#6a6a7a'], 50, 3);
    ctx.fillStyle = '#d4b89a';
    for (let i = 0; i < 7; i++) {
      const x = Math.floor(rand(i * 2)() * 26) + 3;
      const y = Math.floor(rand(i * 2 + 1)() * 26) + 3;
      ctx.fillRect(x, y, 4, 4);
    }
    ctx.fillStyle = '#e8d4b8';
    for (let i = 0; i < 4; i++) {
      const x = Math.floor(rand(i + 50)() * 28) + 2;
      const y = Math.floor(rand(i + 51)() * 28) + 2;
      ctx.fillRect(x, y, 2, 2);
    }
  },
  ore_gold(ctx) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#8a7a5a');
    speckle(ctx, rand(24), ['#9a8a6a', '#7a6a4a'], 50, 3);
    ctx.fillStyle = '#ffd700';
    for (let i = 0; i < 7; i++) {
      const x = Math.floor(rand(i + 20)() * 26) + 3;
      const y = Math.floor(rand(i + 21)() * 26) + 3;
      ctx.fillRect(x, y, 4, 4);
    }
    ctx.fillStyle = '#ffea00';
    for (let i = 0; i < 4; i++) {
      const x = Math.floor(rand(i + 30)() * 28) + 2;
      const y = Math.floor(rand(i + 31)() * 28) + 2;
      ctx.fillRect(x, y, 2, 2);
    }
  },
  ore_coal(ctx) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#4a4a4a');
    speckle(ctx, rand(25), ['#5a5a5a', '#3a3a3a'], 50, 3);
    ctx.fillStyle = '#1a1a1a';
    for (let i = 0; i < 9; i++) {
      const x = Math.floor(rand(i + 40)() * 26) + 3;
      const y = Math.floor(rand(i + 41)() * 26) + 3;
      ctx.fillRect(x, y, 5, 5);
    }
  },
  ore_redstone(ctx) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#6a4a4a');
    speckle(ctx, rand(26), ['#7a5a5a', '#5a3a3a'], 50, 3);
    ctx.fillStyle = '#ff3030';
    for (let i = 0; i < 7; i++) {
      const x = Math.floor(rand(i + 50)() * 26) + 3;
      const y = Math.floor(rand(i + 51)() * 26) + 3;
      ctx.fillRect(x, y, 4, 4);
    }
    ctx.fillStyle = '#ff5050';
    for (let i = 0; i < 4; i++) {
      const x = Math.floor(rand(i + 60)() * 28) + 2;
      const y = Math.floor(rand(i + 61)() * 28) + 2;
      ctx.fillRect(x, y, 2, 2);
    }
  },
  furnace_side(ctx) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#8a8a94');
    speckle(ctx, rand(27), ['#9a9aa4', '#7a7a84'], 40, 3);
    px(ctx, 0, 0, TILE_PX, 2, '#6a6a74');
    px(ctx, 0, TILE_PX - 2, TILE_PX, 2, '#6a6a74');
  },
  furnace_front(ctx) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#8a8a94');
    speckle(ctx, rand(28), ['#9a9aa4', '#7a7a84'], 30, 3);
    px(ctx, 8, 8, 16, 16, '#2a2a34');
    px(ctx, 10, 10, 12, 12, '#4a4a54');
    px(ctx, 12, 12, 8, 8, '#ff8c00');
    px(ctx, 14, 14, 4, 4, '#ffd700');
  },
  furnace_top(ctx) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#6a6a74');
    speckle(ctx, rand(29), ['#7a7a84', '#5a5a64'], 40, 3);
  },
  bookshelf(ctx) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#8b6f47');
    speckle(ctx, rand(30), ['#9b7f57', '#7b5f37'], 30, 3);
    const bookColors = ['#c62828', '#1565c0', '#2e7d32', '#6a1b9a', '#f57f17'];
    for (let row = 0; row < 2; row++) {
      const y = row === 0 ? 4 : 18;
      let x = 2;
      while (x < TILE_PX - 4) {
        const w = 4 + Math.floor(rand(x + row * 10)() * 3);
        const color = bookColors[Math.floor(rand(x + row * 20)() * bookColors.length)];
        ctx.fillStyle = color;
        ctx.fillRect(x, y, w, 10);
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(x, y + 2, w, 1);
        x += w + 1;
      }
    }
  },
  clay(ctx) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#9e9e9e');
    speckle(ctx, rand(31), ['#aeaeae', '#8e8e8e'], 50, 3);
    px(ctx, 0, 0, TILE_PX, 2, '#bebebe');
    px(ctx, 0, TILE_PX - 2, TILE_PX, 2, '#7e7e7e');
  },
  wool_yellow(ctx) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#f1e05b');
    speckle(ctx, rand(32), ['#ffe16b', '#e1d04b'], 50, 3);
    px(ctx, 0, 0, TILE_PX, 2, '#fff17b');
    px(ctx, 0, TILE_PX - 2, TILE_PX, 2, '#d1c03b');
  },
  wool_red(ctx) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#b33a3a');
    speckle(ctx, rand(33), ['#c34a4a', '#a32a2a'], 50, 3);
    px(ctx, 0, 0, TILE_PX, 2, '#d35a5a');
    px(ctx, 0, TILE_PX - 2, TILE_PX, 2, '#931a1a');
  },
  wool_blue(ctx) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#3a5fb3');
    speckle(ctx, rand(34), ['#4a6fc3', '#2a4fa3'], 50, 3);
    px(ctx, 0, 0, TILE_PX, 2, '#5a7fd3');
    px(ctx, 0, TILE_PX - 2, TILE_PX, 2, '#1a3f93');
  },
  wool_green(ctx) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#3a8b3a');
    speckle(ctx, rand(35), ['#4a9b4a', '#2a7b2a'], 50, 3);
    px(ctx, 0, 0, TILE_PX, 2, '#5aab5a');
    px(ctx, 0, TILE_PX - 2, TILE_PX, 2, '#1a6b1a');
  },
  pumpkin_side(ctx) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#f08b2a');
    for (let x = 2; x < TILE_PX; x += 7) px(ctx, x, 0, 2, TILE_PX, '#d9761c');
    px(ctx, 0, 0, TILE_PX, 3, '#ffab55');
    px(ctx, 0, TILE_PX - 3, TILE_PX, 3, '#bd5f11');
    // cute face
    px(ctx, 7, 11, 5, 5, '#5a2d06');
    px(ctx, 20, 11, 5, 5, '#5a2d06');
    px(ctx, 10, 21, 12, 3, '#5a2d06');
    px(ctx, 8, 18, 3, 3, '#5a2d06');
    px(ctx, 21, 18, 3, 3, '#5a2d06');
  },
  pumpkin_top(ctx) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#e07f22');
    for (let x = 2; x < TILE_PX; x += 7) px(ctx, x, 0, 2, TILE_PX, '#c96b16');
    px(ctx, 12, 12, 8, 8, '#7bb23c');
    px(ctx, 14, 8, 4, 6, '#8ec74a');
  },
  ice(ctx, r) {
    ctx.clearRect(0, 0, TILE_PX, TILE_PX);
    px(ctx, 0, 0, TILE_PX, TILE_PX, 'rgba(150,220,255,0.62)');
    for (let i = 0; i < 6; i++) {
      px(ctx, Math.floor(r() * 26), Math.floor(r() * 26), 6, 6, 'rgba(255,255,255,0.35)');
    }
    ctx.strokeStyle = 'rgba(255,255,255,0.6)';
    ctx.lineWidth = 2;
    ctx.strokeRect(1, 1, TILE_PX - 2, TILE_PX - 2);
  },
  chest_side(ctx) {
    // Mini-style candy gift box, not a Minecraft chest!
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#ff6b9d');
    px(ctx, 6, 0, 4, TILE_PX, '#ff8fb3');
    px(ctx, 22, 0, 4, TILE_PX, '#ff8fb3');
    px(ctx, 0, 0, TILE_PX, 3, '#ffd166');
    px(ctx, 0, TILE_PX - 3, TILE_PX, 3, '#e8a33d');
    px(ctx, 12, 12, 8, 10, '#ffd166');
    px(ctx, 14, 15, 4, 6, '#ff9f1c');
    px(ctx, 15, 17, 2, 2, '#fff3ad');
    px(ctx, 4, 22, 2, 2, '#ffffff');
    px(ctx, 26, 8, 2, 2, '#ffffff');
    rim(ctx, 'rgba(255,255,255,0.4)', 'rgba(150,20,70,0.3)');
  },
  chest_top(ctx) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#ff8fb3');
    px(ctx, 14, 0, 4, TILE_PX, '#ff5d8f');
    px(ctx, 0, 14, TILE_PX, 4, '#ff5d8f');
    // big bow
    px(ctx, 6, 5, 8, 8, '#ff5d8f');
    px(ctx, 18, 5, 8, 8, '#ff5d8f');
    px(ctx, 13, 2, 6, 6, '#ffd166');
    px(ctx, 0, 0, TILE_PX, 2, '#ffd166');
    px(ctx, 0, TILE_PX - 2, TILE_PX, 2, '#e0407a');
    px(ctx, 2, 2, 2, 2, '#ffffff');
    px(ctx, 28, 26, 2, 2, '#ffffff');
  },
  cactus_side(ctx, r) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#3f9a2e');
    px(ctx, 2, 0, 8, TILE_PX, '#57b53f');
    px(ctx, 22, 0, 8, TILE_PX, '#57b53f');
    for (let i = 0; i < 8; i++) {
      px(ctx, Math.floor(r() * 30), Math.floor(r() * 30), 2, 2, '#2e7d23');
    }
    ctx.strokeStyle = 'rgba(255,255,255,0.7)';
    ctx.lineWidth = 1;
    for (let i = 0; i < 6; i++) {
      const x = 2 + Math.floor(r() * 28);
      const y = 4 + Math.floor(r() * 26);
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + 2, y - 2);
      ctx.stroke();
    }
    rim(ctx, 'rgba(255,255,255,0.35)', 'rgba(15,60,10,0.35)');
  },
  cactus_top(ctx, r) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#4fb83a');
    speckle(ctx, r, ['#57b53f', '#3f9a2e'], 30, 3);
    px(ctx, 10, 8, 5, 5, '#ff8fb3');
    px(ctx, 12, 10, 2, 2, '#ffe066');
    rim(ctx, 'rgba(255,255,255,0.35)', 'rgba(15,60,10,0.3)');
  },
  torch(ctx) {
    ctx.clearRect(0, 0, TILE_PX, TILE_PX);
    // stick
    px(ctx, 14, 14, 4, 16, '#8e5b2e');
    px(ctx, 15, 14, 2, 16, '#a06a36');
    // flame glow
    const g = ctx.createRadialGradient(16, 11, 1, 16, 11, 13);
    g.addColorStop(0, 'rgba(255,214,102,0.85)');
    g.addColorStop(0.45, 'rgba(255,160,60,0.45)');
    g.addColorStop(1, 'rgba(255,140,40,0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, TILE_PX, TILE_PX);
    // flame
    px(ctx, 13, 4, 6, 10, '#ffd166');
    px(ctx, 15, 1, 3, 5, '#fff3ad');
    px(ctx, 14, 6, 4, 6, '#ff9f1c');
  },
  crafting_side(ctx, r) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#d8a05e');
    speckle(ctx, r, ['#c28a4a', '#e8b97c'], 40, 3);
    px(ctx, 0, 0, TILE_PX, 3, '#8e6236');
    px(ctx, 0, 29, TILE_PX, 3, '#8e6236');
    // tool silhouettes: pickaxe + axe
    ctx.fillStyle = '#7a4b17';
    ctx.fillRect(6, 8, 2, 12);
    ctx.fillRect(3, 5, 7, 3);
    ctx.fillRect(11, 8, 8, 3);
    ctx.fillStyle = '#5b351d';
    ctx.fillRect(20, 10, 2, 10);
    ctx.fillRect(18, 5, 7, 3);
    ctx.fillRect(16, 8, 3, 2);
    rim(ctx, 'rgba(255,240,195,0.3)', 'rgba(70,40,5,0.3)');
  },
  crafting_top(ctx, r) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#d8a05e');
    speckle(ctx, r, ['#c28a4a', '#e8b97c'], 50, 3);
    px(ctx, 0, 0, TILE_PX, 3, '#a06a36');
    px(ctx, 0, 29, TILE_PX, 3, '#a06a36');
    px(ctx, 2, 2, 28, 28, 'rgba(255,255,255,0.08)');
    px(ctx, 8, 8, 16, 16, 'rgba(90,55,15,0.18)');
    px(ctx, 13, 5, 6, 22, '#8e6236');
    px(ctx, 5, 13, 22, 6, '#8e6236');
    rim(ctx, 'rgba(255,240,195,0.35)', 'rgba(70,40,5,0.3)');
  },
  flower_red(ctx) {
    ctx.clearRect(0, 0, TILE_PX, TILE_PX);
    px(ctx, 15, 16, 2, 14, '#3f9a2e');
    px(ctx, 10, 22, 5, 2, '#4fb83a');
    px(ctx, 17, 19, 5, 2, '#4fb83a');
    const petals: [number, number][] = [
      [12, 6],
      [18, 6],
      [12, 12],
      [18, 12],
      [15, 3],
      [9, 9],
      [21, 9],
      [15, 15],
    ];
    for (const [x, y] of petals) px(ctx, x, y, 5, 5, '#ff5d6c');
    px(ctx, 14, 9, 5, 5, '#ffe066');
    px(ctx, 15, 10, 2, 2, '#fff6cf');
  },
  flower_blue(ctx) {
    ctx.clearRect(0, 0, TILE_PX, TILE_PX);
    px(ctx, 15, 16, 2, 14, '#3f9a2e');
    px(ctx, 11, 24, 5, 2, '#4fb83a');
    const petals: [number, number][] = [
      [11, 7],
      [19, 7],
      [11, 13],
      [19, 13],
      [15, 4],
      [15, 16],
    ];
    for (const [x, y] of petals) px(ctx, x, y, 5, 6, '#6aa9ff');
    px(ctx, 14, 10, 5, 5, '#fff0a8');
  },
  tallgrass(ctx, r) {
    ctx.clearRect(0, 0, TILE_PX, TILE_PX);
    for (let i = 0; i < 9; i++) {
      const x = 3 + i * 3;
      const h = 10 + Math.floor(r() * 16);
      const c = ['#5cb63c', '#6ec949', '#4a9c31'][i % 3];
      px(ctx, x, TILE_PX - h, 2, h, c);
      px(ctx, x + (r() > 0.5 ? 1 : -1), TILE_PX - h - 2, 2, 3, c);
    }
  },
  mushroom(ctx) {
    ctx.clearRect(0, 0, TILE_PX, TILE_PX);
    px(ctx, 13, 16, 6, 13, '#f6efe0');
    px(ctx, 8, 8, 16, 9, '#e8503f');
    px(ctx, 10, 5, 12, 4, '#f2604f');
    px(ctx, 11, 9, 4, 4, '#fff2e8');
    px(ctx, 18, 11, 3, 3, '#fff2e8');
    px(ctx, 8, 16, 16, 2, '#c93f31');
  },
  // ---- 下界维度专用贴图 ----
  obsidian(ctx, r) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#150c22');
    speckle(ctx, r, ['#2a1740', '#0d0716', '#3b2159'], 46, 2);
    speckle(ctx, r, ['#6b3fb0'], 6, 1); // 零星的紫色高光结晶感
    rim(ctx, 'rgba(150,100,220,0.22)', 'rgba(0,0,0,0.45)');
  },
  netherrack(ctx, r) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#5b2a26');
    speckle(ctx, r, ['#4a201d', '#6f3630', '#3a1613'], 90, 2);
    speckle(ctx, r, ['#241010'], 20, 3); // 多孔洞穴质感的深色孔洞
    rim(ctx, 'rgba(255,120,80,0.1)', 'rgba(0,0,0,0.28)');
  },
  portal(ctx, r) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#210a3d');
    for (let y = 0; y < TILE_PX; y += 1) {
      const wobble = Math.sin(y * 0.6 + r() * 2) * 3;
      const c = r() > 0.55 ? '#9450f5' : r() > 0.3 ? '#c9a2ff' : '#4c1e8f';
      px(ctx, Math.max(0, wobble), y, TILE_PX - Math.abs(wobble), 1, c);
    }
    speckle(ctx, r, ['#ffffff'], 14, 1);
  },
  // ---- 恶地/悬崖高原（mesa）陶土 ----
  terracotta_red(ctx, r) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#9c4a34');
    speckle(ctx, r, ['#7d3524', '#b9603f', '#6b2c1e'], 70, 2);
    for (let y = 0; y < TILE_PX; y += 5) px(ctx, 0, y, TILE_PX, 1, 'rgba(60,20,12,0.18)'); // 细横纹，暗示水平层理
  },
  terracotta_orange(ctx, r) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#c67a35');
    speckle(ctx, r, ['#a85f24', '#dd934a', '#8f4f1e'], 70, 2);
    for (let y = 0; y < TILE_PX; y += 5) px(ctx, 0, y, TILE_PX, 1, 'rgba(70,35,10,0.16)');
  },
  terracotta_pale(ctx, r) {
    px(ctx, 0, 0, TILE_PX, TILE_PX, '#d9c9a3');
    speckle(ctx, r, ['#c2b088', '#e8ddc0', '#a89670'], 70, 2);
    for (let y = 0; y < TILE_PX; y += 5) px(ctx, 0, y, TILE_PX, 1, 'rgba(120,100,70,0.15)');
  },
  // ---- 16 色染色玻璃（默认程序化版本；开启 HD PBR 材质包后会被替换成真实贴图）----
  glass_white(ctx) { drawStainedGlass(ctx, GLASS_COLORS.white); },
  glass_orange(ctx) { drawStainedGlass(ctx, GLASS_COLORS.orange); },
  glass_magenta(ctx) { drawStainedGlass(ctx, GLASS_COLORS.magenta); },
  glass_light_blue(ctx) { drawStainedGlass(ctx, GLASS_COLORS.light_blue); },
  glass_yellow(ctx) { drawStainedGlass(ctx, GLASS_COLORS.yellow); },
  glass_lime(ctx) { drawStainedGlass(ctx, GLASS_COLORS.lime); },
  glass_pink(ctx) { drawStainedGlass(ctx, GLASS_COLORS.pink); },
  glass_gray(ctx) { drawStainedGlass(ctx, GLASS_COLORS.gray); },
  glass_light_gray(ctx) { drawStainedGlass(ctx, GLASS_COLORS.light_gray); },
  glass_cyan(ctx) { drawStainedGlass(ctx, GLASS_COLORS.cyan); },
  glass_purple(ctx) { drawStainedGlass(ctx, GLASS_COLORS.purple); },
  glass_blue(ctx) { drawStainedGlass(ctx, GLASS_COLORS.blue); },
  glass_brown(ctx) { drawStainedGlass(ctx, GLASS_COLORS.brown); },
  glass_green(ctx) { drawStainedGlass(ctx, GLASS_COLORS.green); },
  glass_red(ctx) { drawStainedGlass(ctx, GLASS_COLORS.red); },
  glass_black(ctx) { drawStainedGlass(ctx, GLASS_COLORS.black); },
};

let cachedTiles: HTMLCanvasElement[] | null = null;
let cachedAtlas: HTMLCanvasElement | null = null;
let cachedProcNormalAtlas: HTMLCanvasElement | null = null;

/** 从贴图自身的亮度变化推一张"假凹凸"法线贴图出来——没有真实高度数据，但对
 *  已经带噪点/颗粒感的程序化贴图（泥土、石头、木纹……）效果很自然：亮的地方
 *  当"凸起"，暗的地方当"凹陷"，用 Sobel 算子求出局部斜率再编码成切线空间法线。
 *  这样默认（没开 HD 材质包）的方块也能有立体的凹凸感，而不是纯平的一张贴图。 */
function deriveNormalFromColor(src: HTMLCanvasElement, strength = 1.6): HTMLCanvasElement {
  const w = src.width;
  const h = src.height;
  const srcCtx = src.getContext('2d')!;
  const srcData = srcCtx.getImageData(0, 0, w, h).data;
  const lum = (x: number, y: number) => {
    const xi = (x + w) % w;
    const yi = (y + h) % h; // 按 tile 自身循环取样，边缘不会有断层
    const i = (yi * w + xi) * 4;
    return (srcData[i] * 0.299 + srcData[i + 1] * 0.587 + srcData[i + 2] * 0.114) / 255;
  };
  const out = document.createElement('canvas');
  out.width = w;
  out.height = h;
  const ctx = out.getContext('2d')!;
  const outImg = ctx.createImageData(w, h);
  const d = outImg.data;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      // Sobel 算子求局部亮度梯度
      const gx =
        -lum(x - 1, y - 1) - 2 * lum(x - 1, y) - lum(x - 1, y + 1) +
        lum(x + 1, y - 1) + 2 * lum(x + 1, y) + lum(x + 1, y + 1);
      const gy =
        -lum(x - 1, y - 1) - 2 * lum(x, y - 1) - lum(x + 1, y - 1) +
        lum(x - 1, y + 1) + 2 * lum(x, y + 1) + lum(x + 1, y + 1);
      let nx = -gx * strength;
      let ny = -gy * strength;
      let nz = 1;
      const len = Math.sqrt(nx * nx + ny * ny + nz * nz);
      nx /= len;
      ny /= len;
      nz /= len;
      const i = (y * w + x) * 4;
      d[i] = (nx * 0.5 + 0.5) * 255;
      d[i + 1] = (ny * 0.5 + 0.5) * 255;
      d[i + 2] = (nz * 0.5 + 0.5) * 255;
      d[i + 3] = 255;
    }
  }
  ctx.putImageData(outImg, 0, 0);
  return out;
}

/** 给整套程序化贴图（不受 HD 材质包开关影响，默认就有）拼一张法线图集，
 *  跟颜色图集用同一套槽位布局，方便直接整体挂给共享材质。 */
export function getProceduralNormalAtlasTexture(): THREE.Texture {
  if (!cachedProcNormalAtlas) {
    const tiles = getTileCanvases();
    const slot = tiles[0]?.width ?? TILE_PX;
    const c = document.createElement('canvas');
    c.width = slot * ATLAS_COLS;
    c.height = slot * ATLAS_ROWS;
    const ctx = c.getContext('2d')!;
    ctx.imageSmoothingEnabled = false;
    ctx.fillStyle = '#8080ff';
    ctx.fillRect(0, 0, c.width, c.height);
    TILE_NAMES.forEach((_name, i) => {
      const tile = tiles[i];
      if (!tile) return;
      const normalTile = deriveNormalFromColor(tile);
      const col = i % ATLAS_COLS;
      const row = Math.floor(i / ATLAS_COLS);
      ctx.drawImage(normalTile, col * slot, row * slot, slot, slot);
    });
    cachedProcNormalAtlas = c;
  }
  const tex = new THREE.CanvasTexture(cachedProcNormalAtlas);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.LinearFilter;
  tex.generateMipmaps = false;
  tex.wrapS = THREE.ClampToEdgeWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  return tex;
}
let hdMode = false;

/** 高清修复材质包：分辨率翻倍 + 细节噪点 + 边缘强化 */
export function setHDTextures(on: boolean) {
  if (hdMode === on) return;
  hdMode = on;
  cachedTiles = null;
  cachedAtlas = null;
  cachedProcNormalAtlas = null;
}

/** 把 32px 图块放大到 64px 并叠加细节，得到“高清修复”观感 */
function upscaleHD(src: HTMLCanvasElement): HTMLCanvasElement {
  const out = document.createElement('canvas');
  out.width = TILE_PX * 2;
  out.height = TILE_PX * 2;
  const ctx = out.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;
  ctx.drawImage(src, 0, 0, out.width, out.height);

  const img = ctx.getImageData(0, 0, out.width, out.height);
  const d = img.data;
  const rnd = rand(src.width * 31 + 7);
  for (let i = 0; i < d.length; i += 4) {
    if (d[i + 3] === 0) continue;
    const n = (rnd() - 0.5) * 26;
    d[i] = Math.max(0, Math.min(255, d[i] + n));
    d[i + 1] = Math.max(0, Math.min(255, d[i + 1] + n));
    d[i + 2] = Math.max(0, Math.min(255, d[i + 2] + n));
  }
  ctx.putImageData(img, 0, 0);

  // 边缘强化：让像素块之间有更明确的接缝与高光
  ctx.globalAlpha = 0.16;
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 1;
  for (let y = 0; y < out.height; y += 8) {
    ctx.beginPath();
    ctx.moveTo(0, y + 0.5);
    ctx.lineTo(out.width, y + 0.5);
    ctx.stroke();
  }
  ctx.strokeStyle = '#000000';
  for (let x = 0; x < out.width; x += 8) {
    ctx.beginPath();
    ctx.moveTo(x + 0.5, 0);
    ctx.lineTo(x + 0.5, out.height);
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
  return out;
}

/* ---------------- HD PBR 材质包（实验性，默认关闭）----------------
 * 用户提供的真实贴图包，覆盖了大部分常见方块（泥土/石头/木板/矿石/羊毛/陶土/
 * 玻璃……共 69 种），含底色 + 法线 + 高光/PBR 贴图，放在 public/hd/core/ 下，
 * 运行时按需异步加载，不影响默认的程序化贴图路径。关掉的时候完全不会发请求
 * 加载这些图，纯程序化版本照常工作。
 *
 * 贴图文件名在拷贝进项目的时候就已经按 TILE_NAMES 里的名字重新命名过了
 * （比如 grass_top.png 对应贴图名 'grass_top'），所以这里不需要再维护一张
 * "游戏内名字 -> 材质包文件名"的映射表，文件名本身就是游戏内的贴图名。 */

interface HDEntry {
  color: HTMLImageElement;
  orm: HTMLCanvasElement | null; // 重新打包过的 three.js 标准 ORM 贴图（G=粗糙度, B=金属度）；没有 spec 贴图的方块是 null
  normal: HTMLImageElement | null; // 没有法线贴图的方块（比如花）是 null
}

/** 材质包里实际提供了对应贴图的方块列表——只有这些名字会去尝试加载真实贴图，
 *  其余方块无论如何都用程序化贴图（不会对不存在的文件发请求）。 */
const HD_COVERED_TILES = new Set([
  'grass_top', 'grass_side', 'dirt', 'stone', 'cobble', 'sand', 'log_side', 'log_top',
  'leaves', 'planks', 'glass', 'brick', 'water', 'snow_top', 'snow_side', 'glow',
  'crystal', 'bedrock', 'lava', 'tnt_side', 'tnt_top', 'gem_ore', 'flower_red',
  'flower_blue', 'tallgrass', 'mushroom', 'pumpkin_side', 'pumpkin_top', 'ice',
  'cactus_side', 'cactus_top', 'torch', 'crafting_side', 'crafting_top', 'ore_iron',
  'ore_gold', 'ore_coal', 'ore_redstone', 'furnace_side', 'furnace_front', 'furnace_top',
  'bookshelf', 'clay', 'wool_yellow', 'wool_red', 'wool_blue', 'wool_green', 'obsidian',
  'netherrack', 'portal', 'terracotta_red', 'terracotta_orange', 'terracotta_pale',
  'glass_white', 'glass_orange', 'glass_magenta', 'glass_light_blue', 'glass_yellow',
  'glass_lime', 'glass_pink', 'glass_gray', 'glass_light_gray', 'glass_cyan',
  'glass_purple', 'glass_blue', 'glass_brown', 'glass_green', 'glass_red', 'glass_black',
]);

let hdImages: Record<string, HDEntry> | null = null;
let hdCoreMode = false;
let hdLoadingPromise: Promise<Record<string, HDEntry>> | null = null;
let cachedNormalAtlas: HTMLCanvasElement | null = null;
let cachedOrmAtlas: HTMLCanvasElement | null = null;

function loadImage(url: string): Promise<HTMLImageElement> {
  const img = new Image();
  img.src = url;
  return img.decode().then(() => img);
}

/** 可选贴图（法线/高光）单独加载，失败/不存在就返回 null，不影响其它贴图。 */
async function loadImageOptional(url: string): Promise<HTMLImageElement | null> {
  try {
    return await loadImage(url);
  } catch {
    return null;
  }
}

/** 这个材质包用的是 LabPBR 那套 spec 贴图约定：R=光滑度(smoothness)，G=金属度。
 *  three.js 的 roughnessMap/metalnessMap 是按标准 glTF ORM 贴图的通道来读的
 *  （G=粗糙度，B=金属度），两者对不上，所以要重新打包一遍通道，不能直接拿来用。 */
function repackORM(specImg: HTMLImageElement): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = specImg.width;
  c.height = specImg.height;
  const ctx = c.getContext('2d')!;
  ctx.drawImage(specImg, 0, 0);
  const imgData = ctx.getImageData(0, 0, c.width, c.height);
  const d = imgData.data;
  for (let i = 0; i < d.length; i += 4) {
    const smoothness = d[i];
    const metalness = d[i + 1];
    d[i] = 255; // R 通道（AO）不用，留白
    d[i + 1] = 255 - smoothness; // G：粗糙度 = 1 - 光滑度
    d[i + 2] = metalness; // B：金属度
    d[i + 3] = 255;
  }
  ctx.putImageData(imgData, 0, 0);
  return c;
}

/** 开关 HD PBR 材质包。第一次开启时会异步加载 public/hd/core/ 下的贴图
 *  （69 种方块，每种最多 3 张图），加载失败会静默回退、返回 false，不会让
 *  游戏崩掉。加载过的贴图会缓存住，后面再切换开关不会重复发请求。 */
export async function setHDGlassTextures(on: boolean): Promise<boolean> {
  if (!on) {
    if (hdCoreMode) {
      hdCoreMode = false;
      cachedTiles = null;
      cachedAtlas = null;
      cachedNormalAtlas = null;
      cachedOrmAtlas = null;
      cachedProcNormalAtlas = null;
    }
    return true;
  }
  if (!hdImages) {
    if (!hdLoadingPromise) {
      hdLoadingPromise = (async () => {
        const entries: Record<string, HDEntry> = {};
        for (const name of HD_COVERED_TILES) {
          const [colorImg, normalImg, specImg] = await Promise.all([
            loadImage(`/hd/core/${name}.png`),
            loadImageOptional(`/hd/core/${name}_n.png`),
            loadImageOptional(`/hd/core/${name}_s.png`),
          ]);
          entries[name] = { color: colorImg, normal: normalImg, orm: specImg ? repackORM(specImg) : null };
        }
        return entries;
      })();
    }
    try {
      hdImages = await hdLoadingPromise;
    } catch (err) {
      console.warn('HD PBR 材质包加载失败，已回退到程序化贴图', err);
      hdLoadingPromise = null;
      return false;
    }
  }
  hdCoreMode = true;
  cachedTiles = null;
  cachedAtlas = null;
  cachedNormalAtlas = null;
  cachedOrmAtlas = null;
  cachedProcNormalAtlas = null;
  return true;
}

export function isHDGlassEnabled(): boolean {
  return hdCoreMode;
}

export function getTileCanvases(): HTMLCanvasElement[] {
  if (cachedTiles) return cachedTiles;
  cachedTiles = TILE_NAMES.map((name, i) => {
    if (hdCoreMode && hdImages?.[name]) {
      const src = hdImages[name].color;
      const c = document.createElement('canvas');
      c.width = src.width;
      c.height = src.height;
      const ctx = c.getContext('2d')!;
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(src, 0, 0);
      return c;
    }
    const c = document.createElement('canvas');
    c.width = TILE_PX;
    c.height = TILE_PX;
    const ctx = c.getContext('2d')!;
    ctx.imageSmoothingEnabled = false;
    const fn = DRAW[name];
    if (fn) fn(ctx, rand(i + 7));
    else px(ctx, 0, 0, TILE_PX, TILE_PX, '#ff00ff');
    return hdMode ? upscaleHD(c) : c;
  });
  return cachedTiles;
}

/** 跟颜色图集用同一套槽位布局，但只有材质包真正覆盖到的格子是真贴图，其它格子
 *  一律填"中性"值（法线贴图是平的正上方向，ORM 贴图是不粗不金属）——
 *  这样这张图集可以直接整体挂在共享材质的 normalMap/roughnessMap/metalnessMap
 *  上，不会影响到同一份材质里没接上材质包的其它方块的观感。 */
function buildAuxAtlas(kind: 'normal' | 'orm'): HTMLCanvasElement | null {
  if (!hdCoreMode || !hdImages) return null;
  const tiles = getTileCanvases();
  const slot = tiles[0]?.width ?? TILE_PX;
  const c = document.createElement('canvas');
  c.width = slot * ATLAS_COLS;
  c.height = slot * ATLAS_ROWS;
  const ctx = c.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;
  ctx.fillStyle = kind === 'normal' ? '#8080ff' : '#ffc800'; // 中性法线 / 中性 ORM（粗糙度约0.78，金属度0）
  ctx.fillRect(0, 0, c.width, c.height);
  TILE_NAMES.forEach((name, i) => {
    const entry = hdImages![name];
    if (!entry) return;
    const src = kind === 'normal' ? entry.normal : entry.orm;
    if (!src) return; // 这个方块没有对应的法线/高光贴图，保留中性值
    const col = i % ATLAS_COLS;
    const row = Math.floor(i / ATLAS_COLS);
    ctx.drawImage(src, col * slot, row * slot, slot, slot);
  });
  return c;
}

export function getGlassNormalAtlasTexture(): THREE.Texture | null {
  if (!hdCoreMode) return null;
  if (!cachedNormalAtlas) cachedNormalAtlas = buildAuxAtlas('normal');
  if (!cachedNormalAtlas) return null;
  const tex = new THREE.CanvasTexture(cachedNormalAtlas);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.LinearFilter;
  tex.generateMipmaps = false;
  tex.wrapS = THREE.ClampToEdgeWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  return tex;
}

export function getGlassOrmAtlasTexture(): THREE.Texture | null {
  if (!hdCoreMode) return null;
  if (!cachedOrmAtlas) cachedOrmAtlas = buildAuxAtlas('orm');
  if (!cachedOrmAtlas) return null;
  const tex = new THREE.CanvasTexture(cachedOrmAtlas);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.LinearFilter;
  tex.generateMipmaps = false;
  tex.wrapS = THREE.ClampToEdgeWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  return tex;
}

export function getAtlasCanvas(): HTMLCanvasElement {
  if (cachedAtlas) return cachedAtlas;
  const tiles = getTileCanvases();
  // 高清材质包下图块是 64px，图集槽位必须跟着放大，否则会互相覆盖
  const slot = tiles[0]?.width ?? TILE_PX;
  const c = document.createElement('canvas');
  c.width = slot * ATLAS_COLS;
  c.height = slot * ATLAS_ROWS;
  const ctx = c.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;
  tiles.forEach((tile, i) => {
    const col = i % ATLAS_COLS;
    const row = Math.floor(i / ATLAS_COLS);
    ctx.drawImage(tile, col * slot, row * slot, slot, slot);
  });
  cachedAtlas = c;
  return c;
}

export function createAtlasTexture(): THREE.Texture {
  const tex = new THREE.CanvasTexture(getAtlasCanvas());
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.LinearFilter;
  tex.generateMipmaps = false;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.ClampToEdgeWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  return tex;
}

const EPS = 0.35 / ATLAS_PX;

/** returns [u0, v0, u1, v1] for a tile index */
export function tileUV(index: number): [number, number, number, number] {
  const col = index % ATLAS_COLS;
  const row = Math.floor(index / ATLAS_COLS);
  const u0 = col / ATLAS_COLS + EPS;
  const u1 = (col + 1) / ATLAS_COLS - EPS;
  const v1 = 1 - row / ATLAS_ROWS - EPS;
  const v0 = 1 - (row + 1) / ATLAS_ROWS + EPS;
  return [u0, v0, u1, v1];
}

const iconCache = new Map<number, string>();
const toolIconCache = new Map<number, string>();

const TOOL_COLORS: Record<string, { main: string; dark: string; light: string }> = {
  wood: { main: '#c9975e', dark: '#8e5b2e', light: '#e2b57e' },
  stone: { main: '#a8a8b4', dark: '#6f6f7c', light: '#c9c9d6' },
  crystal: { main: '#5ce1e6', dark: '#2a8f9e', light: '#aef3ff' },
};

/** 像素风工具图标（镐/斧/铲/剑） */
export function toolIcon(toolId: number, size = 64): string {
  const key = toolId * 1000 + size;
  const cached = toolIconCache.get(key);
  if (cached) return cached;
  const tool = getTool(toolId);
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;
  if (!tool) {
    const url = canvas.toDataURL();
    toolIconCache.set(key, url);
    return url;
  }
  // draw on a 16x16 pixel grid then scale up
  const g = document.createElement('canvas');
  g.width = g.height = 16;
  const gc = g.getContext('2d')!;
  const c = TOOL_COLORS[tool.material] ?? TOOL_COLORS.stone;
  const p = (x: number, y: number, w = 1, h = 1, color: string) => {
    gc.fillStyle = color;
    gc.fillRect(x, y, w, h);
  };
  const D = c.dark;
  const M = c.main;
  const L = c.light;
  if (tool.type === 'pickaxe') {
    // handle
    p(7, 4, 2, 12, D);
    p(8, 4, 1, 12, M);
    // head
    p(3, 2, 4, 2, M);
    p(2, 4, 3, 2, L);
    p(4, 1, 3, 1, L);
    p(3, 4, 2, 2, D);
    p(9, 2, 4, 2, M);
    p(11, 4, 3, 2, L);
  } else if (tool.type === 'axe') {
    p(7, 4, 2, 12, D);
    p(8, 4, 1, 12, M);
    p(2, 3, 6, 3, M);
    p(2, 2, 5, 1, L);
    p(6, 6, 3, 2, D);
    p(1, 4, 2, 1, L);
    p(2, 6, 3, 1, D);
  } else if (tool.type === 'shovel') {
    p(7, 5, 2, 11, D);
    p(8, 5, 1, 11, M);
    p(3, 1, 6, 2, M);
    p(2, 3, 8, 3, L);
    p(3, 6, 6, 2, D);
    p(4, 2, 4, 1, L);
  } else if (tool.type === 'gun') {
    // 枪械：枪管 + 握把 + 枪机
    const metal = tool.material === 'crystal' ? '#5ce1e6' : tool.material === 'stone' ? '#a8a8b4' : '#6f6f7c';
    const metalL = tool.material === 'crystal' ? '#aef3ff' : tool.material === 'stone' ? '#c9c9d6' : '#a8a8b4';
    p(2, 6, 12, 3, metal);
    p(2, 6, 12, 1, metalL);
    p(12, 5, 2, 5, '#4b4b58');
    p(4, 4, 5, 2, metal);
    p(5, 9, 3, 5, '#8e5b2e');
    p(5, 9, 1, 5, '#a06a36');
    p(7, 3, 2, 1, '#ffd166');
  } else {
    // sword
    p(7, 1, 2, 10, M);
    p(7, 1, 1, 10, L);
    p(6, 3, 1, 4, L);
    p(8, 2, 1, 5, D);
    p(5, 11, 6, 2, D);
    p(6, 11, 4, 1, M);
    p(7, 13, 2, 3, D);
    p(8, 13, 1, 3, M);
  }
  ctx.drawImage(g, 0, 0, size, size);
  const url = canvas.toDataURL();
  toolIconCache.set(key, url);
  return url;
}

/** 木棍等物品图标 */
export function itemIcon(itemId: number, size = 64): string {
  const key0 = itemId * 1000 + size;
  if (itemId === 202 || itemId === 203 || itemId === 204 || itemId === 205 || itemId === 206) {
    const cached0 = toolIconCache.get(key0);
    if (cached0) return cached0;
    const g = document.createElement('canvas');
    g.width = g.height = 16;
    const gc = g.getContext('2d')!;
    const p = (x: number, y: number, w: number, h: number, color: string) => {
      gc.fillStyle = color;
      gc.fillRect(x, y, w, h);
    };
    if (itemId === 202) {
      // 枪管
      p(3, 7, 10, 3, '#6f6f7c');
      p(3, 7, 10, 1, '#a8a8b4');
      p(12, 6, 2, 5, '#4b4b58');
    } else if (itemId === 203) {
      // 击发器
      p(5, 5, 6, 6, '#c9a227');
      p(6, 6, 4, 4, '#ffd166');
      p(7, 11, 2, 3, '#8e5b2e');
    } else {
      // 弹药
      const col = itemId === 204 ? '#c9975e' : itemId === 205 ? '#cfd8dc' : '#5ce1e6';
      const dark = itemId === 204 ? '#8e5b2e' : itemId === 205 ? '#8a8f98' : '#2a8f9e';
      p(6, 4, 4, 5, col);
      p(6, 4, 4, 1, '#ffffff');
      p(5, 9, 6, 4, dark);
      p(7, 13, 2, 1, '#ffd166');
    }
    const canvas = document.createElement('canvas');
    canvas.width = canvas.height = size;
    const ctx = canvas.getContext('2d')!;
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(g, 0, 0, size, size);
    const url = canvas.toDataURL();
    toolIconCache.set(key0, url);
    return url;
  }
  if (itemId === 201) {
    const key = 201 * 1000 + size;
    const cached = toolIconCache.get(key);
    if (cached) return cached;
    const g = document.createElement('canvas');
    g.width = g.height = 16;
    const gc = g.getContext('2d')!;
    gc.fillStyle = '#c9975e';
    gc.fillRect(7, 2, 3, 12);
    gc.fillStyle = '#8e5b2e';
    gc.fillRect(8, 2, 1, 12);
    gc.fillStyle = '#e2b57e';
    gc.fillRect(7, 2, 1, 12);
    const canvas = document.createElement('canvas');
    canvas.width = canvas.height = size;
    const ctx = canvas.getContext('2d')!;
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(g, 0, 0, size, size);
    const url = canvas.toDataURL();
    toolIconCache.set(key, url);
    return url;
  }
  return toolIcon(itemId, size);
}

/** Isometric cube icon for the UI, drawn from the block's own tiles. */
export function blockIcon(blockId: number, size = 64): string {
  const key = blockId * 1000 + size;
  const cached = iconCache.get(key);
  if (cached) return cached;
  const tiles = getTileCanvases();
  const def = getBlock(blockId);
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;

  if (def.render === 'cross') {
    ctx.drawImage(tiles[def.tiles[0]], size * 0.06, size * 0.06, size * 0.88, size * 0.88);
    const url = canvas.toDataURL();
    iconCache.set(key, url);
    return url;
  }

  const S = TILE_PX;
  const w = size * 0.92;
  const ox = (size - w) / 2;
  const oy = size * 0.05;
  const top = tiles[def.tiles[2]];
  const side = tiles[def.tiles[0]];

  const face = (
    tile: HTMLCanvasElement,
    p0: [number, number],
    u: [number, number],
    v: [number, number],
    shade: string,
  ) => {
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(ox + p0[0] * w, oy + p0[1] * w);
    ctx.lineTo(ox + (p0[0] + u[0]) * w, oy + (p0[1] + u[1]) * w);
    ctx.lineTo(ox + (p0[0] + u[0] + v[0]) * w, oy + (p0[1] + u[1] + v[1]) * w);
    ctx.lineTo(ox + (p0[0] + v[0]) * w, oy + (p0[1] + v[1]) * w);
    ctx.closePath();
    ctx.clip();
    ctx.transform(
      (u[0] * w) / S,
      (u[1] * w) / S,
      (v[0] * w) / S,
      (v[1] * w) / S,
      ox + p0[0] * w,
      oy + p0[1] * w,
    );
    ctx.drawImage(tile, 0, 0);
    ctx.restore();
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(ox + p0[0] * w, oy + p0[1] * w);
    ctx.lineTo(ox + (p0[0] + u[0]) * w, oy + (p0[1] + u[1]) * w);
    ctx.lineTo(ox + (p0[0] + u[0] + v[0]) * w, oy + (p0[1] + u[1] + v[1]) * w);
    ctx.lineTo(ox + (p0[0] + v[0]) * w, oy + (p0[1] + v[1]) * w);
    ctx.closePath();
    ctx.fillStyle = shade;
    ctx.fill();
    ctx.restore();
  };

  // top face
  face(top, [0, 0.25], [0.5, -0.25], [0.5, 0.25], 'rgba(255,255,255,0.08)');
  // left face
  face(side, [0, 0.25], [0.5, 0.25], [0, 0.5], 'rgba(0,0,0,0.16)');
  // right face
  face(side, [0.5, 0.5], [0.5, -0.25], [0, 0.5], 'rgba(0,0,0,0.32)');

  const url = canvas.toDataURL();
  iconCache.set(key, url);
  return url;
}

/* ---------------- 方块破坏裂纹 ---------------- */

let crackTextures: THREE.Texture[] | null = null;

/** 8 级破坏裂纹贴图（透明底 + 深色裂缝），随挖掘进度逐级加深 */
export function createCrackTextures(): THREE.Texture[] {
  if (crackTextures) return crackTextures;
  const stages = 8;
  crackTextures = [];
  for (let s = 0; s < stages; s++) {
    const c = document.createElement('canvas');
    c.width = c.height = TILE_PX;
    const ctx = c.getContext('2d')!;
    ctx.clearRect(0, 0, TILE_PX, TILE_PX);
    const r = rand(s * 977 + 13);
    const branches = 2 + s * 2;
    ctx.lineCap = 'round';
    for (let b = 0; b < branches; b++) {
      let x = TILE_PX * (0.25 + r() * 0.5);
      let y = TILE_PX * (0.25 + r() * 0.5);
      let ang = r() * Math.PI * 2;
      const segs = 2 + s;
      for (let i = 0; i < segs; i++) {
        const len = 3 + r() * (4 + s * 1.2);
        const nx = x + Math.cos(ang) * len;
        const ny = y + Math.sin(ang) * len;
        ctx.strokeStyle = `rgba(12,12,16,${0.5 + s * 0.05})`;
        ctx.lineWidth = Math.max(1, 2.6 - s * 0.16);
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(nx, ny);
        ctx.stroke();
        // 高光边，让裂缝有厚度
        ctx.strokeStyle = `rgba(255,255,255,${0.16 + s * 0.02})`;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(x + 1, y + 1);
        ctx.lineTo(nx + 1, ny + 1);
        ctx.stroke();
        x = nx;
        y = ny;
        ang += (r() - 0.5) * 1.5;
      }
    }
    const tex = new THREE.CanvasTexture(c);
    tex.magFilter = THREE.NearestFilter;
    tex.minFilter = THREE.LinearFilter;
    tex.colorSpace = THREE.SRGBColorSpace;
    crackTextures.push(tex);
  }
  return crackTextures;
}

/** soft cloud sprite texture for the sky layer.
 *
 *  之前的版本有两个真问题：
 *  1）"发霉"——用一堆半透明的软圆随意叠加，透明度会不均匀地累积，密的地方糊成一
 *     团、疏的地方斑斑点点，看起来像霉斑而不是云。这版先用完全不透明的圆拼出一个
 *     连续、扎实的云团轮廓（不透明就不会有那种斑驳感），再整体高斯模糊出柔和边缘，
 *     最后用 source-atop 只在云团范围内叠一层底部阴影——阴影绝不会画到云团外面去。
 *  2）"到处被截断"——纹理是平铺的，但画云团的时候完全没考虑贴图边界，贴着边缘的
 *     云团会被画布硬生生切掉一半，平铺之后每块贴图的接缝处都能看见这种断层。这版
 *     每个云团在紧贴四条边/四个角的时候，会在对边/对角再画一份完全一样的拷贝
 *     （经典的"可平铺纹理"套接技巧）——平铺之后，图块 A 右边缘的半个云团正好接上
 *     图块 B 左边缘的另一半，天衣无缝，不会再有断层。
 *
 *  seed 可传不同值，多层云用不同纹理，不会看起来像同一张图叠了两次。
 */
export function createCloudTexture(seed = 99): THREE.Texture {
  const size = 768;
  const c = document.createElement('canvas');
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d')!;
  const r = rand(seed);
  ctx.clearRect(0, 0, size, size);

  const drawPuffySilhouette = (cx: number, cy: number, rad: number, lobeSeed: () => number) => {
    ctx.fillStyle = '#ffffff';
    const lobes = 7 + Math.floor(lobeSeed() * 5);
    for (let i = 0; i < lobes; i++) {
      const ang = (i / lobes) * Math.PI * 2 + lobeSeed() * 0.4;
      const dist = rad * (0.25 + lobeSeed() * 0.32);
      const lx = cx + Math.cos(ang) * dist;
      const ly = cy + Math.sin(ang) * dist * 0.55; // 压扁一点，云底部比顶部平
      const lr = rad * (0.42 + lobeSeed() * 0.3);
      ctx.beginPath();
      ctx.arc(lx, ly, lr, 0, Math.PI * 2);
      ctx.fill();
    }
    const bumps = 4 + Math.floor(lobeSeed() * 4);
    for (let i = 0; i < bumps; i++) {
      const ang = lobeSeed() * Math.PI * 2;
      const dist = rad * lobeSeed() * 0.35;
      const lx = cx + Math.cos(ang) * dist;
      const ly = cy - rad * 0.22 + Math.sin(ang) * dist * 0.4;
      const lr = rad * (0.22 + lobeSeed() * 0.22);
      ctx.beginPath();
      ctx.arc(lx, ly, lr, 0, Math.PI * 2);
      ctx.fill();
    }
  };

  const clusterCount = 11 + Math.floor(r() * 6);
  for (let k = 0; k < clusterCount; k++) {
    const cx = r() * size;
    const cy = r() * size;
    const rad = 60 + r() * 80;
    // 每个云团用固定的一串随机数生成瓣状轮廓，这样"本体"和"套接的边缘拷贝"
    // 长得一模一样（同一颗云，只是画在了两个位置）——注意每次画拷贝前都要用
    // 同一个种子重新生成一个随机数发生器，不能复用同一个发生器继续往下取数，
    // 不然每份拷贝形状都不一样，接缝处就对不上了。
    const lobeSeedValue = Math.floor(r() * 1e9);
    const offsets: [number, number][] = [[0, 0]];
    if (cx - rad < 0) offsets.push([size, 0]);
    if (cx + rad > size) offsets.push([-size, 0]);
    if (cy - rad < 0) offsets.push([0, size]);
    if (cy + rad > size) offsets.push([0, -size]);
    if (cx - rad < 0 && cy - rad < 0) offsets.push([size, size]);
    if (cx + rad > size && cy - rad < 0) offsets.push([-size, size]);
    if (cx - rad < 0 && cy + rad > size) offsets.push([size, -size]);
    if (cx + rad > size && cy + rad > size) offsets.push([-size, -size]);
    for (const [ox, oy] of offsets) {
      drawPuffySilhouette(cx + ox, cy + oy, rad, rand(lobeSeedValue));
    }
  }

  // 整体做一次柔和模糊：不透明的硬边界变成自然的羽化边缘，而不是锯齿分明的圆。
  // 因为边缘的云团已经在对边套接过拷贝，模糊也会正确地跨越接缝、两边对得上。
  ctx.filter = 'blur(6px)';
  ctx.drawImage(c, 0, 0);
  ctx.filter = 'none';

  // 底部阴影：source-atop 保证这层只会画在"已经有云"的地方，绝不会在云团外面
  // 留下多余的色块——这也是之前"发霉"感的另一个来源（阴影层跟主体没对齐）。
  ctx.globalCompositeOperation = 'source-atop';
  const shade = ctx.createLinearGradient(0, 0, 0, size);
  shade.addColorStop(0, 'rgba(255,255,255,0)');
  shade.addColorStop(0.5, 'rgba(255,255,255,0)');
  shade.addColorStop(1, 'rgba(160,175,200,0.4)');
  ctx.fillStyle = shade;
  ctx.fillRect(0, 0, size, size);
  ctx.globalCompositeOperation = 'source-over';

  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(2, 2);
  return tex;
}
