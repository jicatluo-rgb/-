/** 重新设计的枪械模型 - 更精细的第一人称模型 */

import * as THREE from 'three';

/** 手枪模型 */
export function createPistolModel(): THREE.Group {
  const group = new THREE.Group();
  const metalColor = 0x3a3a3a;
  const gripColor = 0x2a2a2a;
  const accentColor = 0x4a4a4a;

  // 枪管
  const barrel = new THREE.Mesh(
    new THREE.BoxGeometry(0.05, 0.05, 0.4),
    new THREE.MeshLambertMaterial({ color: metalColor })
  );
  barrel.position.set(0, 0, -0.2);
  group.add(barrel);

  // 枪口
  const muzzle = new THREE.Mesh(
    new THREE.CylinderGeometry(0.03, 0.035, 0.05, 8),
    new THREE.MeshLambertMaterial({ color: metalColor })
  );
  muzzle.rotation.x = Math.PI / 2;
  muzzle.position.set(0, 0, -0.42);
  group.add(muzzle);

  // 套筒
  const slide = new THREE.Mesh(
    new THREE.BoxGeometry(0.06, 0.08, 0.35),
    new THREE.MeshLambertMaterial({ color: accentColor })
  );
  slide.position.set(0, 0.03, -0.15);
  group.add(slide);

  // 握把
  const grip = new THREE.Mesh(
    new THREE.BoxGeometry(0.05, 0.15, 0.08),
    new THREE.MeshLambertMaterial({ color: gripColor })
  );
  grip.position.set(0, -0.1, 0.05);
  grip.rotation.x = -0.2;
  group.add(grip);

  // 扳机
  const trigger = new THREE.Mesh(
    new THREE.BoxGeometry(0.02, 0.06, 0.03),
    new THREE.MeshLambertMaterial({ color: metalColor })
  );
  trigger.position.set(0, -0.05, -0.02);
  group.add(trigger);

  // 扳机护圈
  const triggerGuard = new THREE.Mesh(
    new THREE.TorusGeometry(0.04, 0.015, 4, 8, Math.PI),
    new THREE.MeshLambertMaterial({ color: metalColor })
  );
  triggerGuard.rotation.y = Math.PI / 2;
  triggerGuard.position.set(0, -0.05, -0.02);
  group.add(triggerGuard);

  group.traverse((obj) => {
    if ((obj as THREE.Mesh).isMesh) {
      obj.castShadow = true;
    }
  });

  return group;
}

/** 步枪模型 */
export function createRifleModel(): THREE.Group {
  const group = new THREE.Group();
  const metalColor = 0x2a2a2a;
  const woodColor = 0x6b4326;
  const accentColor = 0x3a3a3a;

  // 长枪管
  const barrel = new THREE.Mesh(
    new THREE.BoxGeometry(0.04, 0.04, 0.8),
    new THREE.MeshLambertMaterial({ color: metalColor })
  );
  barrel.position.set(0, 0, -0.4);
  group.add(barrel);

  // 枪口
  const muzzle = new THREE.Mesh(
    new THREE.CylinderGeometry(0.025, 0.03, 0.08, 8),
    new THREE.MeshLambertMaterial({ color: metalColor })
  );
  muzzle.rotation.x = Math.PI / 2;
  muzzle.position.set(0, 0, -0.82);
  group.add(muzzle);

  // 机匣
  const receiver = new THREE.Mesh(
    new THREE.BoxGeometry(0.06, 0.1, 0.3),
    new THREE.MeshLambertMaterial({ color: accentColor })
  );
  receiver.position.set(0, 0.02, -0.1);
  group.add(receiver);

  // 枪托（木质）
  const stock = new THREE.Mesh(
    new THREE.BoxGeometry(0.06, 0.12, 0.35),
    new THREE.MeshLambertMaterial({ color: woodColor })
  );
  stock.position.set(0, 0, 0.25);
  group.add(stock);

  // 握把
  const grip = new THREE.Mesh(
    new THREE.BoxGeometry(0.05, 0.18, 0.08),
    new THREE.MeshLambertMaterial({ color: woodColor })
  );
  grip.position.set(0, -0.12, 0.05);
  grip.rotation.x = -0.2;
  group.add(grip);

  // 扳机
  const trigger = new THREE.Mesh(
    new THREE.BoxGeometry(0.02, 0.08, 0.03),
    new THREE.MeshLambertMaterial({ color: metalColor })
  );
  trigger.position.set(0, -0.08, -0.02);
  group.add(trigger);

  // 扳机护圈
  const triggerGuard = new THREE.Mesh(
    new THREE.TorusGeometry(0.05, 0.02, 4, 8, Math.PI),
    new THREE.MeshLambertMaterial({ color: metalColor })
  );
  triggerGuard.rotation.y = Math.PI / 2;
  triggerGuard.position.set(0, -0.08, -0.02);
  group.add(triggerGuard);

  // 瞄准镜基座
  const scopeBase = new THREE.Mesh(
    new THREE.BoxGeometry(0.03, 0.03, 0.15),
    new THREE.MeshLambertMaterial({ color: metalColor })
  );
  scopeBase.position.set(0, 0.07, -0.1);
  group.add(scopeBase);

  // 瞄准镜
  const scope = new THREE.Mesh(
    new THREE.CylinderGeometry(0.025, 0.025, 0.2, 8),
    new THREE.MeshLambertMaterial({ color: metalColor })
  );
  scope.rotation.x = Math.PI / 2;
  scope.position.set(0, 0.09, -0.1);
  group.add(scope);

  group.traverse((obj) => {
    if ((obj as THREE.Mesh).isMesh) {
      obj.castShadow = true;
    }
  });

  return group;
}

/** 霰弹枪模型 */
export function createShotgunModel(): THREE.Group {
  const group = new THREE.Group();
  const metalColor = 0x3a3a3a;
  const woodColor = 0x5d3a1a;
  const accentColor = 0x4a4a4a;

  // 双管枪管
  const barrel1 = new THREE.Mesh(
    new THREE.CylinderGeometry(0.025, 0.03, 0.6, 8),
    new THREE.MeshLambertMaterial({ color: metalColor })
  );
  barrel1.rotation.x = Math.PI / 2;
  barrel1.position.set(-0.03, 0, -0.3);
  group.add(barrel1);

  const barrel2 = new THREE.Mesh(
    new THREE.CylinderGeometry(0.025, 0.03, 0.6, 8),
    new THREE.MeshLambertMaterial({ color: metalColor })
  );
  barrel2.rotation.x = Math.PI / 2;
  barrel2.position.set(0.03, 0, -0.3);
  group.add(barrel2);

  // 机匣
  const receiver = new THREE.Mesh(
    new THREE.BoxGeometry(0.08, 0.12, 0.25),
    new THREE.MeshLambertMaterial({ color: accentColor })
  );
  receiver.position.set(0, 0.02, -0.05);
  group.add(receiver);

  // 枪托（木质）
  const stock = new THREE.Mesh(
    new THREE.BoxGeometry(0.07, 0.14, 0.4),
    new THREE.MeshLambertMaterial({ color: woodColor })
  );
  stock.position.set(0, 0, 0.28);
  group.add(stock);

  // 握把
  const grip = new THREE.Mesh(
    new THREE.BoxGeometry(0.06, 0.2, 0.1),
    new THREE.MeshLambertMaterial({ color: woodColor })
  );
  grip.position.set(0, -0.14, 0.05);
  grip.rotation.x = -0.25;
  group.add(grip);

  // 扳机
  const trigger = new THREE.Mesh(
    new THREE.BoxGeometry(0.02, 0.1, 0.03),
    new THREE.MeshLambertMaterial({ color: metalColor })
  );
  trigger.position.set(0, -0.1, -0.02);
  group.add(trigger);

  group.traverse((obj) => {
    if ((obj as THREE.Mesh).isMesh) {
      obj.castShadow = true;
    }
  });

  return group;
}

/** 狙击枪模型 */
export function createSniperModel(): THREE.Group {
  const group = new THREE.Group();
  const metalColor = 0x2a2a2a;
  const camoColor = 0x4a5d3a;
  const accentColor = 0x3a3a3a;

  // 长枪管
  const barrel = new THREE.Mesh(
    new THREE.CylinderGeometry(0.02, 0.025, 1.0, 8),
    new THREE.MeshLambertMaterial({ color: metalColor })
  );
  barrel.rotation.x = Math.PI / 2;
  barrel.position.set(0, 0, -0.5);
  group.add(barrel);

  // 消音器
  const suppressor = new THREE.Mesh(
    new THREE.CylinderGeometry(0.035, 0.04, 0.15, 8),
    new THREE.MeshLambertMaterial({ color: metalColor })
  );
  suppressor.rotation.x = Math.PI / 2;
  suppressor.position.set(0, 0, -1.05);
  group.add(suppressor);

  // 机匣
  const receiver = new THREE.Mesh(
    new THREE.BoxGeometry(0.07, 0.12, 0.35),
    new THREE.MeshLambertMaterial({ color: accentColor })
  );
  receiver.position.set(0, 0.02, -0.1);
  group.add(receiver);

  // 枪托（迷彩）
  const stock = new THREE.Mesh(
    new THREE.BoxGeometry(0.07, 0.14, 0.45),
    new THREE.MeshLambertMaterial({ color: camoColor })
  );
  stock.position.set(0, 0, 0.32);
  group.add(stock);

  // 握把
  const grip = new THREE.Mesh(
    new THREE.BoxGeometry(0.06, 0.22, 0.1),
    new THREE.MeshLambertMaterial({ color: camoColor })
  );
  grip.position.set(0, -0.16, 0.05);
  grip.rotation.x = -0.3;
  group.add(grip);

  // 大型瞄准镜
  const scopeMount = new THREE.Mesh(
    new THREE.BoxGeometry(0.04, 0.04, 0.2),
    new THREE.MeshLambertMaterial({ color: metalColor })
  );
  scopeMount.position.set(0, 0.09, -0.1);
  group.add(scopeMount);

  const scope = new THREE.Mesh(
    new THREE.CylinderGeometry(0.035, 0.035, 0.3, 8),
    new THREE.MeshLambertMaterial({ color: metalColor })
  );
  scope.rotation.x = Math.PI / 2;
  scope.position.set(0, 0.12, -0.1);
  group.add(scope);

  // 瞄准镜前镜头
  const scopeFront = new THREE.Mesh(
    new THREE.CylinderGeometry(0.04, 0.035, 0.05, 8),
    new THREE.MeshLambertMaterial({ color: metalColor })
  );
  scopeFront.rotation.x = Math.PI / 2;
  scopeFront.position.set(0, 0.12, -0.28);
  group.add(scopeFront);

  // 两脚架
  const bipod1 = new THREE.Mesh(
    new THREE.CylinderGeometry(0.015, 0.015, 0.2, 6),
    new THREE.MeshLambertMaterial({ color: metalColor })
  );
  bipod1.position.set(-0.04, -0.1, -0.35);
  bipod1.rotation.z = 0.3;
  group.add(bipod1);

  const bipod2 = new THREE.Mesh(
    new THREE.CylinderGeometry(0.015, 0.015, 0.2, 6),
    new THREE.MeshLambertMaterial({ color: metalColor })
  );
  bipod2.position.set(0.04, -0.1, -0.35);
  bipod2.rotation.z = -0.3;
  group.add(bipod2);

  group.traverse((obj) => {
    if ((obj as THREE.Mesh).isMesh) {
      obj.castShadow = true;
    }
  });

  return group;
}
