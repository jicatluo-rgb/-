import * as THREE from 'three';
import { getBlock } from './blocks';
import { World, type MobLike } from './world';
import { sfx } from './audio';
import type { BiomeType } from './biome';

export type MobBehavior = 'wander' | 'hop' | 'fly' | 'chase' | 'flee' | 'explode';

export type ModelKind =
  | 'naochi'
  | 'mage'
  | 'quadruped'
  | 'bird'
  | 'humanoid'
  | 'creeper'
  | 'ender'
  | 'skeleton'
  | 'spider'
  | 'slime'
  | 'golem'
  | 'snowman'
  | 'rabbit'
  | 'bat'
  | 'dragon'
  | 'demon'
  | 'mimic';

export interface MobDef {
  id: number;
  name: string;
  behavior: MobBehavior;
  friendly: boolean;
  maxHp: number;
  scale: number;
  colors: { body: number; head?: number; acc?: number };
  legs: number;
  model: ModelKind;
  dropId: number;
  favFood?: number;
  boss?: boolean;
  biomes?: BiomeType[];
  undead?: boolean;
  /** 需要该模组才会出现 */
  requiresMod?: string;
  /** 移动速度倍率 */
  speedMul?: number;
  /** 攻击力 */
  attack?: number;
}

export const MOB_DEFS: MobDef[] = [
  { id: 1, name: '闹吃', behavior: 'hop', friendly: true, maxHp: 12, scale: 1.05, colors: { body: 0xffd166, head: 0xffd166, acc: 0xff5468 }, legs: 2, model: 'naochi', dropId: 14, favFood: 14 },
  { id: 2, name: '蛊真兴', behavior: 'chase', friendly: false, maxHp: 90, scale: 1.5, colors: { body: 0x4a148c, head: 0xb388ff, acc: 0xe040fb }, legs: 2, model: 'mage', dropId: 15, boss: true, attack: 6 },
  { id: 3, name: '粉萌小猪', behavior: 'wander', friendly: true, maxHp: 8, scale: 0.85, colors: { body: 0xffb7c5, head: 0xffccd5, acc: 0xff8da1 }, legs: 4, model: 'quadruped', dropId: 22, favFood: 22 },
  { id: 4, name: '蓬蓬咩咩羊', behavior: 'wander', friendly: true, maxHp: 8, scale: 0.9, colors: { body: 0xf7f7f7, head: 0xffebd6, acc: 0xbdbdbd }, legs: 4, model: 'quadruped', dropId: 27, favFood: 26 },
  { id: 5, name: '哞哞大奶牛', behavior: 'wander', friendly: true, maxHp: 14, scale: 1.15, colors: { body: 0x5d4037, head: 0xf5f5f5, acc: 0x3e2723 }, legs: 4, model: 'quadruped', dropId: 8, favFood: 26 },
  { id: 6, name: '大眼尖叫鸡', behavior: 'hop', friendly: true, maxHp: 4, scale: 0.62, colors: { body: 0xfff2a1, head: 0xfff2a1, acc: 0xff5d6c }, legs: 2, model: 'bird', dropId: 24, favFood: 24 },
  { id: 7, name: '哈士奇二哈', behavior: 'chase', friendly: true, maxHp: 12, scale: 0.85, colors: { body: 0x78909c, head: 0xf5f5f5, acc: 0x263238 }, legs: 4, model: 'quadruped', dropId: 6, favFood: 8, speedMul: 1.25 },
  { id: 8, name: '淘气小黄猫', behavior: 'wander', friendly: true, maxHp: 6, scale: 0.68, colors: { body: 0xffb74d, head: 0xffcc80, acc: 0xe65100 }, legs: 4, model: 'quadruped', dropId: 1, favFood: 11, speedMul: 1.2 },
  { id: 9, name: '绿皮僵尸', behavior: 'chase', friendly: false, maxHp: 20, scale: 1.0, colors: { body: 0x4caf50, head: 0x388e3c, acc: 0x2e7d32 }, legs: 2, model: 'humanoid', dropId: 3, undead: true, attack: 3 },
  { id: 10, name: '暴躁苦力怕', behavior: 'explode', friendly: false, maxHp: 16, scale: 1.0, colors: { body: 0x81c784, head: 0x4caf50, acc: 0x2e7d32 }, legs: 4, model: 'creeper', dropId: 20, undead: true },
  { id: 11, name: '末影黑影', behavior: 'chase', friendly: false, maxHp: 35, scale: 1.45, colors: { body: 0x16161d, head: 0x0d0d12, acc: 0xd500f9 }, legs: 2, model: 'ender', dropId: 15, undead: true, attack: 5, speedMul: 1.2 },
  { id: 12, name: '白骨骷髅', behavior: 'chase', friendly: false, maxHp: 16, scale: 1.0, colors: { body: 0xe8e4d8, head: 0xf2efe6, acc: 0x9e9a8c }, legs: 2, model: 'skeleton', dropId: 3, undead: true, attack: 4 },
  { id: 13, name: '巨型红眼蛛', behavior: 'chase', friendly: false, maxHp: 14, scale: 1.05, colors: { body: 0x3e2723, head: 0x1a0c00, acc: 0xd50000 }, legs: 8, model: 'spider', dropId: 9, undead: true, attack: 3, speedMul: 1.3 },
  { id: 14, name: '弹跳史莱姆', behavior: 'hop', friendly: true, maxHp: 6, scale: 0.75, colors: { body: 0x4db6ac, head: 0x80cbc4, acc: 0x00796b }, legs: 0, model: 'slime', dropId: 15 },
  { id: 15, name: '铁憨憨傀儡', behavior: 'wander', friendly: true, maxHp: 80, scale: 1.45, colors: { body: 0xcfd8dc, head: 0xb0bec5, acc: 0x455a64 }, legs: 2, model: 'golem', dropId: 4, attack: 8 },
  { id: 16, name: '雪地小雪人', behavior: 'wander', friendly: true, maxHp: 4, scale: 0.8, colors: { body: 0xffffff, head: 0xff9100, acc: 0x212121 }, legs: 0, model: 'snowman', dropId: 12, biomes: ['snow'] },
  { id: 17, name: '彩虹独角兽', behavior: 'hop', friendly: true, maxHp: 24, scale: 1.15, colors: { body: 0xffffff, head: 0xf3e5f5, acc: 0xff4081 }, legs: 4, model: 'quadruped', dropId: 18, favFood: 18, speedMul: 1.3 },
  { id: 18, name: '红翼小恶魔', behavior: 'fly', friendly: false, maxHp: 16, scale: 0.85, colors: { body: 0xd50000, head: 0xb71c1c, acc: 0x3e2723 }, legs: 2, model: 'bat', dropId: 17, undead: true, attack: 3 },
  { id: 19, name: '森林小萌狐', behavior: 'wander', friendly: true, maxHp: 8, scale: 0.78, colors: { body: 0xff6d00, head: 0xff9e40, acc: 0xffffff }, legs: 4, model: 'quadruped', dropId: 22, favFood: 22, speedMul: 1.2 },
  { id: 20, name: '长耳大眼兔', behavior: 'hop', friendly: true, maxHp: 4, scale: 0.55, colors: { body: 0xffebd6, head: 0xffffff, acc: 0xff4081 }, legs: 2, model: 'rabbit', dropId: 25, favFood: 25 },
  { id: 21, name: '幽灵小飞龙', behavior: 'fly', friendly: false, maxHp: 40, scale: 1.25, colors: { body: 0x00bcd4, head: 0xe0f7fa, acc: 0x006064 }, legs: 2, model: 'dragon', dropId: 21, attack: 5 },
  { id: 22, name: '熔岩魔王', behavior: 'chase', friendly: false, maxHp: 140, scale: 1.85, colors: { body: 0x7a2d0a, head: 0xff6a00, acc: 0xffd166 }, legs: 2, model: 'demon', dropId: 18, boss: true, attack: 9 },
  { id: 23, name: '遗迹守护者', behavior: 'chase', friendly: false, maxHp: 110, scale: 1.65, colors: { body: 0x8a8f98, head: 0x5d6a75, acc: 0x00e5ff }, legs: 2, model: 'golem', dropId: 21, boss: true, attack: 8 },
  { id: 24, name: '冰雪女王', behavior: 'chase', friendly: false, maxHp: 120, scale: 1.55, colors: { body: 0x90caf9, head: 0xe3f2fd, acc: 0xffffff }, legs: 2, model: 'mage', dropId: 23, boss: true, biomes: ['snow'], attack: 7 },
  { id: 25, name: '沙漠木乃伊', behavior: 'chase', friendly: false, maxHp: 18, scale: 1.0, colors: { body: 0xe6d3b3, head: 0xd4bf9a, acc: 0x8d7a5c }, legs: 2, model: 'humanoid', dropId: 5, biomes: ['desert'], undead: true, attack: 3 },

  /* ---- 未知生物模组 ---- */
  { id: 30, name: '影袭者', behavior: 'chase', friendly: false, maxHp: 28, scale: 1.3, colors: { body: 0x0a0a12, head: 0x05050a, acc: 0x00e5ff }, legs: 2, model: 'ender', dropId: 15, undead: true, requiresMod: 'unknown', attack: 6, speedMul: 1.35 },
  { id: 31, name: '拟态宝箱怪', behavior: 'chase', friendly: false, maxHp: 34, scale: 1.0, colors: { body: 0x9b5b2b, head: 0xffd166, acc: 0x5b351d }, legs: 4, model: 'mimic', dropId: 21, requiresMod: 'unknown', attack: 7 },
  { id: 32, name: '虚空爬行者', behavior: 'chase', friendly: false, maxHp: 26, scale: 1.15, colors: { body: 0x1a1030, head: 0x2d1b4e, acc: 0xb388ff }, legs: 8, model: 'spider', dropId: 15, requiresMod: 'unknown', attack: 5, speedMul: 1.25 },

  /* ---- 小心雨模组 ---- */
  { id: 33, name: '雨夜怨灵', behavior: 'chase', friendly: false, maxHp: 30, scale: 1.35, colors: { body: 0x37474f, head: 0x546e7a, acc: 0x80deea }, legs: 2, model: 'ender', dropId: 23, undead: true, requiresMod: 'rainhorror', attack: 5, speedMul: 1.3 },
  { id: 34, name: '湿骨行尸', behavior: 'chase', friendly: false, maxHp: 24, scale: 1.05, colors: { body: 0x607d8b, head: 0x90a4ae, acc: 0x37474f }, legs: 2, model: 'skeleton', dropId: 3, undead: true, requiresMod: 'rainhorror', attack: 4 },

  /* ---- 敲门人模组 ---- */
  { id: 35, name: '敲门人', behavior: 'chase', friendly: false, maxHp: 40, scale: 1.7, colors: { body: 0x0d0d0d, head: 0x1a1a1a, acc: 0xff1744 }, legs: 2, model: 'humanoid', dropId: 15, undead: true, requiresMod: 'knocker', attack: 8, speedMul: 1.15 },

  /* ---- 群系专属生物：森林 ---- */
  { id: 40, name: '梅花小鹿', behavior: 'flee', friendly: true, maxHp: 8, scale: 0.95, colors: { body: 0xa0724d, head: 0xc79764, acc: 0xfff3e0 }, legs: 4, model: 'quadruped', dropId: 6, biomes: ['forest'], speedMul: 1.15 },
  { id: 41, name: '林间浣熊', behavior: 'wander', friendly: true, maxHp: 6, scale: 0.62, colors: { body: 0x78716c, head: 0x9c9691, acc: 0x1c1917 }, legs: 4, model: 'quadruped', dropId: 27, biomes: ['forest'] },
  { id: 42, name: '啄木鸟', behavior: 'hop', friendly: true, maxHp: 4, scale: 0.5, colors: { body: 0x6d4c2f, head: 0xd32f2f, acc: 0xfff3e0 }, legs: 2, model: 'bird', dropId: 24, biomes: ['forest'] },
  { id: 43, name: '猫头鹰哨兵', behavior: 'wander', friendly: true, maxHp: 6, scale: 0.7, colors: { body: 0x8d6e63, head: 0xd7ccc8, acc: 0x3e2723 }, legs: 2, model: 'bird', dropId: 24, biomes: ['forest'] },
  { id: 44, name: '绿林盗贼', behavior: 'chase', friendly: false, maxHp: 22, scale: 1.0, colors: { body: 0x33691e, head: 0x558b2f, acc: 0x3e2723 }, legs: 2, model: 'humanoid', dropId: 8, biomes: ['forest'], attack: 4 },
  { id: 45, name: '苔藓史莱姆', behavior: 'hop', friendly: true, maxHp: 6, scale: 0.7, colors: { body: 0x558b2f, head: 0x7cb342, acc: 0x33691e }, legs: 0, model: 'slime', dropId: 27, biomes: ['forest'] },

  /* ---- 群系专属生物：平原 ---- */
  { id: 46, name: '稻草人卫兵', behavior: 'wander', friendly: true, maxHp: 14, scale: 1.05, colors: { body: 0xd7ba6f, head: 0xffca28, acc: 0x6d4c2f }, legs: 2, model: 'humanoid', dropId: 6, biomes: ['plains'] },
  { id: 47, name: '毛毛羊驼', behavior: 'wander', friendly: true, maxHp: 10, scale: 1.1, colors: { body: 0xefebe9, head: 0xd7ccc8, acc: 0x8d6e63 }, legs: 4, model: 'quadruped', dropId: 26, biomes: ['plains'] },
  { id: 48, name: '平原猎鹰', behavior: 'fly', friendly: false, maxHp: 10, scale: 0.8, colors: { body: 0x795548, head: 0xd7ccc8, acc: 0x3e2723 }, legs: 2, model: 'bat', dropId: 24, biomes: ['plains'], attack: 2 },

  /* ---- 群系专属生物：沼泽 ---- */
  { id: 49, name: '沼泽鳄鱼', behavior: 'chase', friendly: false, maxHp: 26, scale: 1.2, colors: { body: 0x33512e, head: 0x1b2e18, acc: 0x9ccc65 }, legs: 4, model: 'quadruped', dropId: 4, biomes: ['swamp'], attack: 6 },
  { id: 50, name: '毒雾史莱姆', behavior: 'hop', friendly: false, maxHp: 14, scale: 0.85, colors: { body: 0x6a1b9a, head: 0x9c27b0, acc: 0x4a148c }, legs: 0, model: 'slime', dropId: 27, biomes: ['swamp'], attack: 3 },
  { id: 51, name: '沼泽巫婆', behavior: 'chase', friendly: false, maxHp: 24, scale: 1.05, colors: { body: 0x37474f, head: 0x546e7a, acc: 0x76ff03 }, legs: 2, model: 'humanoid', dropId: 27, biomes: ['swamp'], attack: 5 },
  { id: 52, name: '萤火精灵', behavior: 'fly', friendly: true, maxHp: 4, scale: 0.4, colors: { body: 0xfff59d, head: 0xffee58, acc: 0xffee58 }, legs: 2, model: 'bat', dropId: 13, biomes: ['swamp'] },
  { id: 53, name: '沼泽巨蛙', behavior: 'hop', friendly: false, maxHp: 16, scale: 0.95, colors: { body: 0x558b2f, head: 0x9ccc65, acc: 0x33691e }, legs: 4, model: 'quadruped', dropId: 27, biomes: ['swamp'], attack: 3 },

  /* ---- 群系专属生物：海洋 ---- */
  { id: 54, name: '珊瑚海龟', behavior: 'wander', friendly: true, maxHp: 12, scale: 0.9, colors: { body: 0x2e7d32, head: 0xd4bf9a, acc: 0xff8a65 }, legs: 4, model: 'quadruped', dropId: 9, biomes: ['ocean'] },
  { id: 55, name: '水母精灵', behavior: 'hop', friendly: true, maxHp: 6, scale: 0.75, colors: { body: 0xb39ddb, head: 0xe1bee7, acc: 0x7e57c2 }, legs: 0, model: 'slime', dropId: 9, biomes: ['ocean'] },
  { id: 56, name: '深海鮟鱇怪', behavior: 'chase', friendly: false, maxHp: 24, scale: 1.1, colors: { body: 0x0d1b2a, head: 0x1b263b, acc: 0xffee58 }, legs: 2, model: 'ender', dropId: 15, biomes: ['ocean'], attack: 5 },
  { id: 57, name: '巨蟹战士', behavior: 'chase', friendly: false, maxHp: 20, scale: 0.95, colors: { body: 0xd84315, head: 0xff5722, acc: 0xbf360c }, legs: 2, model: 'golem', dropId: 4, biomes: ['ocean'], attack: 5 },

  /* ---- 群系专属生物：雪原（在已有雪人/冰雪女王之外补充） ---- */
  { id: 58, name: '雪原孤狼', behavior: 'chase', friendly: false, maxHp: 18, scale: 1.0, colors: { body: 0xeceff1, head: 0xffffff, acc: 0x607d8b }, legs: 4, model: 'quadruped', dropId: 23, biomes: ['snow'], attack: 4, speedMul: 1.2 },
  { id: 59, name: '冰晶蝙蝠', behavior: 'fly', friendly: false, maxHp: 10, scale: 0.7, colors: { body: 0xb3e5fc, head: 0xe1f5fe, acc: 0x4fc3f7 }, legs: 2, model: 'bat', dropId: 23, biomes: ['snow'], attack: 2 },
  { id: 60, name: '企鹅宝宝', behavior: 'hop', friendly: true, maxHp: 4, scale: 0.55, colors: { body: 0x212121, head: 0xffffff, acc: 0xff9100 }, legs: 2, model: 'bird', dropId: 23, biomes: ['snow'] },
  { id: 61, name: '冰川巨魔', behavior: 'chase', friendly: false, maxHp: 60, scale: 1.5, colors: { body: 0x81d4fa, head: 0xb3e5fc, acc: 0x0277bd }, legs: 2, model: 'golem', dropId: 23, biomes: ['snow'], attack: 7 },

  /* ---- 群系专属生物：沙漠（在已有木乃伊之外补充） ---- */
  { id: 62, name: '沙漠蝎子', behavior: 'chase', friendly: false, maxHp: 14, scale: 0.9, colors: { body: 0xd7a465, head: 0xbf7e3f, acc: 0x5d4037 }, legs: 8, model: 'spider', dropId: 5, biomes: ['desert'], attack: 4, speedMul: 1.2 },
  { id: 63, name: '沙丘骆驼', behavior: 'wander', friendly: true, maxHp: 14, scale: 1.2, colors: { body: 0xd7ba6f, head: 0xe8d5a3, acc: 0x8d6e4a }, legs: 4, model: 'quadruped', dropId: 5, biomes: ['desert'] },
  { id: 64, name: '沙丘幽魂', behavior: 'chase', friendly: false, maxHp: 22, scale: 1.3, colors: { body: 0xe6d3b3, head: 0xf5ead0, acc: 0xbfa76f }, legs: 2, model: 'ender', dropId: 5, biomes: ['desert'], undead: true, attack: 5 },
];

/* ------------------------------------------------------------------ */

interface Limb {
  upper: THREE.Group;
  lower: THREE.Mesh;
  phase: number;
  len: number;
}

export class MobEntity {
  id: number;
  def: MobDef;
  pos = new THREE.Vector3();
  prevPos = new THREE.Vector3();
  vel = new THREE.Vector3();
  yaw = 0;
  hp: number;
  maxHp: number;
  onGround = false;
  tamed = false;
  scale: number;
  behavior: MobBehavior;
  wanderTimer = 0;
  targetPos = new THREE.Vector3();
  jumpCooldown = 0;
  damageFlash = 0;
  explodeTimer = 0;
  attackCooldown = 0;
  specialCooldown = 2.5;
  /** 攻击动作计时（0~1） */
  attackAnim = 0;

  group = new THREE.Group();
  wings: THREE.Object3D[] = [];
  private limbs: Limb[] = [];
  private headPivot!: THREE.Object3D;
  private bodyPivot!: THREE.Object3D;
  private tailPivot: THREE.Object3D | null = null;
  private ears: THREE.Object3D[] = [];
  private extras: { obj: THREE.Object3D; kind: string }[] = [];
  private mats: THREE.Material[] = [];
  private geos: THREE.BufferGeometry[] = [];
  private baseColors: THREE.Color[] = [];
  private walkPhase = 0;
  private breath = Math.random() * Math.PI * 2;
  private blinkT = 2 + Math.random() * 3;
  private eyelids: THREE.Object3D[] = [];

  constructor(def: MobDef, x: number, y: number, z: number) {
    this.id = Math.floor(Math.random() * 999999);
    this.def = def;
    this.pos.set(x, y, z);
    this.prevPos.copy(this.pos);
    this.hp = def.maxHp;
    this.maxHp = def.maxHp;
    this.behavior = def.behavior;
    this.scale = def.scale;
    this.build();
    this.group.position.copy(this.pos);
    this.group.scale.setScalar(this.scale);
    // 生物投射柔和阴影，落地感更强
    this.group.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) {
        o.castShadow = true;
        o.receiveShadow = true;
      }
    });
  }

  /* ================= 建模工具 ================= */

  private mat(color: number, opts: Partial<THREE.MeshLambertMaterialParameters> = {}) {
    const m = new THREE.MeshLambertMaterial({ color, ...opts });
    this.mats.push(m);
    this.baseColors.push(new THREE.Color(color));
    return m;
  }

  private geo(g: THREE.BufferGeometry) {
    this.geos.push(g);
    return g;
  }

  private box(
    w: number,
    h: number,
    d: number,
    color: number,
    x: number,
    y: number,
    z: number,
    parent: THREE.Object3D = this.group,
    opts: Partial<THREE.MeshLambertMaterialParameters> = {},
  ) {
    const mesh = new THREE.Mesh(this.geo(new THREE.BoxGeometry(w, h, d)), this.mat(color, opts));
    mesh.position.set(x, y, z);
    parent.add(mesh);
    return mesh;
  }

  /** 胶囊体：让有机生物看起来圆润而不是方块 */
  private capsule(
    r: number,
    len: number,
    color: number,
    x: number,
    y: number,
    z: number,
    parent: THREE.Object3D = this.group,
    rotZ = 0,
  ) {
    const g = this.geo(new THREE.CapsuleGeometry(r, len, 6, 12));
    const mesh = new THREE.Mesh(g, this.mat(color));
    mesh.position.set(x, y, z);
    mesh.rotation.z = rotZ;
    parent.add(mesh);
    return mesh;
  }

  private ball(
    r: number,
    color: number,
    x: number,
    y: number,
    z: number,
    parent: THREE.Object3D = this.group,
    basic = false,
    seg = 10,
  ) {
    const m = basic ? new THREE.MeshBasicMaterial({ color }) : this.mat(color);
    if (basic) {
      this.mats.push(m);
      this.baseColors.push(new THREE.Color(color));
    }
    const mesh = new THREE.Mesh(this.geo(new THREE.SphereGeometry(r, seg, Math.max(6, seg - 2))), m);
    mesh.position.set(x, y, z);
    parent.add(mesh);
    return mesh;
  }

  /** 卡通大眼睛：白底 + 瞳孔 + 高光 + 可眨眼皮 */
  private eye(size: number, x: number, y: number, z: number, parent: THREE.Object3D, hostile = false) {
    const white = this.ball(size, 0xffffff, x, y, z, parent, true);
    white.scale.set(1, 1.2, 0.45);
    const pupil = this.ball(size * 0.55, hostile ? 0xff1a1a : 0x2b2b35, x, y - size * 0.1, z - size * 0.4, parent, true);
    pupil.scale.set(1, 1.25, 0.5);
    const glint = this.ball(size * 0.22, 0xffffff, x - size * 0.25, y + size * 0.3, z - size * 0.55, parent, true);
    glint.scale.set(1, 1, 0.4);
    // 眼皮（用于眨眼）
    const lid = this.box(size * 2.1, size * 0.9, size * 0.5, this.def.colors.head ?? this.def.colors.body, x, y + size * 0.95, z - size * 0.1, parent);
    lid.scale.y = 0.01;
    this.eyelids.push(lid);
  }

  /** 双段肢体：返回可用于步态动画的关节 */
  private limb(
    len1: number,
    len2: number,
    thick: number,
    color: number,
    x: number,
    y: number,
    z: number,
    phase: number,
    parent: THREE.Object3D = this.group,
  ): Limb {
    const upper = new THREE.Group();
    upper.position.set(x, y, z);
    parent.add(upper);
    this.box(thick, len1, thick, color, 0, -len1 / 2, 0, upper);
    this.ball(thick * 0.52, color, 0, -len1, 0, upper);
    const lower = this.box(thick * 0.86, len2, thick * 0.86, color, 0, -len1 - len2 / 2, 0, upper);
    // 把下半段的枢轴移到膝盖：用嵌套 group 实现
    lower.geometry.translate(0, len2 / 2, 0);
    lower.position.set(0, -len1, 0);
    return { upper, lower, phase, len: len1 + len2 };
  }

  /** 四足/人形腿组 */
  private legSet(
    count: number,
    len1: number,
    len2: number,
    thick: number,
    color: number,
    hipY: number,
    spreadX: number,
    spreadZ: number,
    diagonal = false,
  ) {
    const spots: [number, number, number][] = [];
    if (count === 2) spots.push([-spreadX, 0, 0.9], [spreadX, 0, 1.9]);
    else if (count === 4)
      spots.push(
        [-spreadX, -spreadZ, diagonal ? 0 : 0],
        [spreadX, -spreadZ, diagonal ? Math.PI : 0],
        [-spreadX, spreadZ, diagonal ? Math.PI : 0.6],
        [spreadX, spreadZ, diagonal ? 0 : 0.6 + Math.PI],
      );
    for (const [lx, lz, ph] of spots) {
      this.limbs.push(this.limb(len1, len2, thick, color, lx, hipY, lz, ph));
    }
  }

  private armSet(len1: number, len2: number, thick: number, color: number, shoulderY: number, spreadX: number) {
    for (const s of [-1, 1]) {
      this.limbs.push(this.limb(len1, len2, thick, color, s * spreadX, shoulderY, 0, s > 0 ? Math.PI : 0));
    }
  }

  /* ================= 各物种建模 ================= */

  private build() {
    const c = this.def.colors;
    const bodyC = c.body;
    const headC = c.head ?? c.body;
    const accC = c.acc ?? c.body;
    const hostile = !this.def.friendly;

    switch (this.def.model) {
      /* ---------- 四足哺乳类 ---------- */
      case 'quadruped': {
        const id = this.def.id;
        this.bodyPivot = new THREE.Group();
        this.bodyPivot.position.y = 0.62;
        this.group.add(this.bodyPivot);
        const fluffy = id === 4;

        // 躯干：胶囊主体（沿 Z 轴，即前后方向）+ 肩部方块，圆润不方块
        const bodyMain = this.capsule(0.21, 0.44, bodyC, 0, 0, 0.06, this.bodyPivot);
        // 默认 Y 轴胶囊，绕 X 轴旋转 π/2 让它沿 Z 方向（身体长轴）
        bodyMain.rotation.x = Math.PI / 2;
        // 前肩补形，让脖子和躯干过渡自然
        this.box(0.38, 0.28, 0.26, bodyC, 0, 0.04, -0.22, this.bodyPivot);
        // 后胯补形
        this.box(0.36, 0.24, 0.22, bodyC, 0, 0.02, 0.26, this.bodyPivot);
        if (fluffy) {
          for (const [ox, oy, oz] of [
            [-0.22, 0.16, -0.16],
            [0.22, 0.16, -0.16],
            [-0.22, 0.16, 0.22],
            [0.22, 0.16, 0.22],
            [0, 0.24, 0.04],
          ])
            this.ball(0.17, bodyC, ox, oy, oz, this.bodyPivot);
        }
        if (id === 5) {
          this.box(0.46, 0.18, 0.24, 0xf5f5f5, 0, 0.1, -0.14, this.bodyPivot);
          this.box(0.3, 0.14, 0.18, 0xf5f5f5, -0.1, -0.08, 0.3, this.bodyPivot);
        }

        // 脖子 + 头
        const neck = new THREE.Group();
        neck.position.set(0, 0.12, -0.34);
        neck.rotation.x = -0.35;
        this.bodyPivot.add(neck);
        this.box(0.24, 0.26, 0.2, headC, 0, 0.1, 0, neck);
        const head = new THREE.Group();
        head.position.set(0, 0.26, -0.06);
        neck.add(head);
        this.headPivot = head;
        this.box(0.34, 0.3, 0.32, headC, 0, 0, 0, head);
        this.box(0.24, 0.17, 0.16, id === 3 || id === 5 ? accC : headC, 0, -0.06, -0.2, head);
        if (id === 3 || id === 5) {
          this.ball(0.028, 0x5a2d06, -0.06, -0.06, -0.28, head, true);
          this.ball(0.028, 0x5a2d06, 0.06, -0.06, -0.28, head, true);
        }
        this.eye(0.07, -0.1, 0.05, -0.16, head);
        this.eye(0.07, 0.1, 0.05, -0.16, head);

        // 耳朵（物种差异）
        if (id === 7 || id === 8 || id === 19) {
          for (const s of [-1, 1]) {
            const ear = new THREE.Group();
            ear.position.set(s * 0.12, 0.16, 0.02);
            head.add(ear);
            const e = this.box(0.09, 0.2, 0.06, accC, 0, 0.09, 0, ear);
            e.rotation.z = s * 0.3;
            this.box(0.05, 0.13, 0.03, 0xffb7c5, 0, 0.09, -0.03, ear);
            this.ears.push(ear);
          }
        } else if (id === 4) {
          for (const s of [-1, 1]) {
            const ear = new THREE.Group();
            ear.position.set(s * 0.16, 0.12, 0.02);
            head.add(ear);
            this.box(0.07, 0.13, 0.14, headC, 0, 0.04, 0, ear);
            this.ears.push(ear);
          }
        } else if (id === 5) {
          for (const s of [-1, 1]) {
            const ear = new THREE.Group();
            ear.position.set(s * 0.18, 0.08, 0.02);
            head.add(ear);
            const e = this.box(0.12, 0.07, 0.1, headC, s * 0.05, 0, 0, ear);
            e.rotation.z = s * 0.5;
            this.box(0.07, 0.14, 0.07, 0xf5f5f5, s * 0.02, 0.14, 0, ear);
            this.ears.push(ear);
          }
        } else {
          for (const s of [-1, 1]) {
            const ear = new THREE.Group();
            ear.position.set(s * 0.15, 0.14, 0.02);
            head.add(ear);
            this.box(0.07, 0.1, 0.14, headC, 0, 0.03, 0, ear);
            this.ears.push(ear);
          }
        }

        // 独角兽角 + 鬃毛
        if (id === 17) {
          const horn = this.box(0.08, 0.34, 0.08, 0xffd166, 0, 0.26, -0.08, head);
          horn.rotation.x = -0.35;
          const mane = ['#ff6b6b', '#ffd166', '#8ce99a', '#66d9e8', '#b197fc'];
          mane.forEach((col, i) => this.box(0.09, 0.16, 0.1, Number(`0x${col.slice(1)}`), 0, 0.2 - i * 0.03, -0.2 + i * 0.16, this.bodyPivot));
        }

        // 尾巴
        const tail = new THREE.Group();
        tail.position.set(0, 0.06, 0.48);
        this.bodyPivot.add(tail);
        this.tailPivot = tail;
        if (id === 7 || id === 8) {
          const t = this.box(0.1, 0.3, 0.1, accC, 0, 0.12, 0.04, tail);
          t.rotation.x = 0.5;
        } else if (id === 19) {
          this.box(0.16, 0.16, 0.3, bodyC, 0, 0.02, 0.12, tail);
          this.box(0.18, 0.18, 0.1, 0xffffff, 0, 0.02, 0.28, tail);
        } else if (id === 17) {
          ['#ff6b6b', '#ffd166', '#66d9e8'].forEach((col, i) =>
            this.box(0.06, 0.06, 0.16, Number(`0x${col.slice(1)}`), (i - 1) * 0.08, -0.02, 0.12, tail),
          );
        } else if (id === 3) {
          const t = this.box(0.06, 0.06, 0.16, accC, 0, 0.02, 0.06, tail);
          t.rotation.x = -0.8;
        } else {
          this.box(0.07, 0.07, 0.2, accC, 0, 0, 0.08, tail);
        }

        this.legSet(4, 0.2, 0.18, 0.11, accC, 0.44, 0.17, 0.2, true);
        // 蹄子：贴在腿末端的深色小节，站姿更扎实
        const hoofColor = id === 17 ? 0xf3e5f5 : 0x4e342e;
        const shinLen = 0.18; // 与 legSet 的 len2 一致
        for (const limb of this.limbs) {
          this.box(0.135, 0.09, 0.16, hoofColor, 0, -shinLen + 0.03, 0, limb.lower);
        }
        // 鼻孔
        if (id === 3 || id === 5) {
          this.ball(0.025, 0x5a2d06, -0.05, -0.06, -0.3, this.headPivot, true);
          this.ball(0.025, 0x5a2d06, 0.05, -0.06, -0.3, this.headPivot, true);
        }
        break;
      }

      /* ---------- 闹吃 ---------- */
      case 'naochi': {
        this.bodyPivot = new THREE.Group();
        this.bodyPivot.position.y = 0.5;
        this.group.add(this.bodyPivot);
        const b = this.box(0.66, 0.6, 0.56, bodyC, 0, 0.12, 0, this.bodyPivot);
        b.scale.set(1, 1, 1);
        this.ball(0.3, bodyC, 0, 0.12, 0, this.bodyPivot);
        this.box(0.5, 0.14, 0.44, 0xffe9b0, 0, -0.08, -0.02, this.bodyPivot);

        const head = new THREE.Group();
        head.position.y = 0.72;
        this.group.add(head);
        this.headPivot = head;
        this.box(0.56, 0.48, 0.5, headC, 0, 0, 0, head);
        // 大嘴（会张合）
        const jaw = new THREE.Group();
        jaw.position.set(0, -0.1, -0.24);
        head.add(jaw);
        this.box(0.38, 0.06, 0.1, 0x5a2d06, 0, 0, 0, jaw);
        this.extras.push({ obj: jaw, kind: 'jaw' });
        for (let i = 0; i < 4; i++) this.box(0.05, 0.06, 0.04, 0xffffff, -0.12 + i * 0.08, -0.04, -0.02, jaw);
        this.eye(0.095, -0.14, 0.1, -0.26, head);
        this.eye(0.095, 0.14, 0.1, -0.26, head);
        for (const s of [-1, 1]) this.box(0.07, 0.14, 0.07, accC, s * 0.18, 0.28, 0, head);
        this.ball(0.05, 0xff5468, -0.2, 0.02, -0.27, head, true);
        this.ball(0.05, 0xff5468, 0.2, 0.02, -0.27, head, true);

        this.tailPivot = new THREE.Group();
        this.tailPivot.position.set(0, 0.16, 0.3);
        this.bodyPivot.add(this.tailPivot);
        this.box(0.09, 0.09, 0.2, accC, 0, 0, 0.08, this.tailPivot);
        this.ball(0.08, accC, 0, 0, 0.2, this.tailPivot);

        this.legSet(2, 0.2, 0.16, 0.14, accC, 0.36, 0.2, 0, false);
        break;
      }

      /* ---------- 鸡 ---------- */
      case 'bird': {
        this.bodyPivot = new THREE.Group();
        this.bodyPivot.position.y = 0.5;
        this.group.add(this.bodyPivot);
        this.box(0.36, 0.38, 0.4, bodyC, 0, 0, 0.02, this.bodyPivot);
        this.box(0.3, 0.16, 0.2, 0xffffff, 0, 0.06, 0.14, this.bodyPivot);

        const head = new THREE.Group();
        head.position.set(0, 0.3, -0.12);
        this.bodyPivot.add(head);
        this.headPivot = head;
        this.box(0.26, 0.26, 0.24, headC, 0, 0, 0, head);
        const beak = this.box(0.11, 0.09, 0.16, 0xff9f1c, 0, -0.04, -0.18, head);
        beak.rotation.x = -0.1;
        this.extras.push({ obj: beak, kind: 'beak' });
        this.box(0.07, 0.13, 0.14, 0xff5d6c, 0, 0.19, 0, head);
        this.ball(0.045, 0xff5d6c, 0, 0.15, -0.07, head);
        this.box(0.06, 0.09, 0.06, 0xff5d6c, 0, -0.14, -0.06, head);
        this.eye(0.085, -0.09, 0.05, -0.13, head);
        this.eye(0.085, 0.09, 0.05, -0.13, head);

        for (const s of [-1, 1]) {
          const wing = new THREE.Group();
          wing.position.set(s * 0.2, 0.08, 0.02);
          this.bodyPivot.add(wing);
          this.box(0.06, 0.26, 0.3, bodyC, 0, -0.1, 0, wing);
          this.box(0.05, 0.18, 0.2, 0xffe082, 0, -0.2, 0.04, wing);
          this.wings.push(wing);
        }
        const tail = new THREE.Group();
        tail.position.set(0, 0.12, 0.24);
        this.bodyPivot.add(tail);
        this.tailPivot = tail;
        this.box(0.09, 0.22, 0.1, bodyC, 0, 0.06, 0.02, tail).rotation.x = 0.5;

        this.legSet(2, 0.14, 0.14, 0.06, 0xff9f1c, 0.32, 0.1, 0, false);
        break;
      }

      /* ---------- 兔子 ---------- */
      case 'rabbit': {
        this.bodyPivot = new THREE.Group();
        this.bodyPivot.position.y = 0.36;
        this.group.add(this.bodyPivot);
        this.box(0.34, 0.34, 0.42, bodyC, 0, 0, 0.04, this.bodyPivot);
        this.ball(0.19, bodyC, 0, 0, 0.06, this.bodyPivot);

        const head = new THREE.Group();
        head.position.set(0, 0.16, -0.2);
        this.bodyPivot.add(head);
        this.headPivot = head;
        this.box(0.3, 0.28, 0.28, headC, 0, 0, 0, head);
        this.ball(0.04, accC, 0, -0.04, -0.16, head, true);
        this.box(0.16, 0.08, 0.1, headC, 0, -0.1, -0.1, head);
        for (const s of [-1, 1]) this.box(0.05, 0.14, 0.04, 0xffffff, s * 0.05, -0.12, -0.14, head);
        this.eye(0.085, -0.09, 0.04, -0.15, head);
        this.eye(0.085, 0.09, 0.04, -0.15, head);
        for (const s of [-1, 1]) {
          const ear = new THREE.Group();
          ear.position.set(s * 0.09, 0.16, 0.02);
          head.add(ear);
          this.box(0.09, 0.36, 0.07, headC, 0, 0.17, 0, ear);
          this.box(0.05, 0.28, 0.03, accC, 0, 0.17, -0.03, ear);
          ear.rotation.z = s * 0.12;
          this.ears.push(ear);
        }
        this.ball(0.1, 0xffffff, 0, 0.02, 0.28, this.bodyPivot);
        // 强壮后腿
        for (const s of [-1, 1]) {
          const leg = this.limb(0.14, 0.16, 0.12, headC, s * 0.17, 0.26, 0.16, s > 0 ? 0 : Math.PI);
          leg.upper.rotation.x = -0.5;
        }
        this.legSet(2, 0.1, 0.12, 0.08, headC, 0.24, 0.12, -0.12, false);
        break;
      }

      /* ---------- 人形（僵尸/木乃伊/敲门人） ---------- */
      case 'humanoid': {
        const knocker = this.def.id === 35;
        this.bodyPivot = new THREE.Group();
        this.bodyPivot.position.y = 0.78;
        this.group.add(this.bodyPivot);
        this.box(0.42, 0.54, 0.26, bodyC, 0, 0.26, 0, this.bodyPivot);
        this.box(0.44, 0.16, 0.28, accC, 0, 0.04, 0, this.bodyPivot);
        if (knocker) {
          // 长风衣
          this.box(0.5, 0.5, 0.32, 0x141414, 0, 0.06, 0, this.bodyPivot);
          this.box(0.52, 0.1, 0.34, accC, 0, 0.3, 0, this.bodyPivot);
        }

        const head = new THREE.Group();
        head.position.y = 0.78;
        this.group.add(head);
        this.headPivot = head;
        this.box(0.42, 0.42, 0.4, headC, 0, 0, 0, head);
        if (knocker) {
          this.box(0.46, 0.14, 0.44, 0x0a0a0a, 0, 0.2, 0, head);
          this.box(0.5, 0.05, 0.5, 0x0a0a0a, 0, 0.13, 0, head);
          this.ball(0.05, accC, -0.11, 0.02, -0.21, head, true);
          this.ball(0.05, accC, 0.11, 0.02, -0.21, head, true);
        } else {
          this.box(0.44, 0.1, 0.42, accC, 0, 0.17, 0, head);
          this.eye(0.075, -0.1, 0.01, -0.2, head, true);
          this.eye(0.075, 0.1, 0.01, -0.2, head, true);
          this.box(0.2, 0.05, 0.05, 0x2b2b35, 0, -0.13, -0.2, head);
          if (this.def.id === 25) {
            // 木乃伊绷带
            for (let i = 0; i < 3; i++) this.box(0.44, 0.05, 0.42, 0xf5ead6, 0, -0.1 + i * 0.14, 0, head);
          }
        }

        // 前伸手臂（僵尸经典姿势）
        this.armSet(0.26, 0.24, 0.13, bodyC, 0.5, 0.29);
        this.limbs.forEach((l) => {
          l.upper.rotation.x = -1.35;
        });
        this.legSet(2, 0.34, 0.3, 0.15, accC, 0.78, 0.13, 0, false);
        break;
      }

      /* ---------- 骷髅 ---------- */
      case 'skeleton': {
        const bone = bodyC;
        const dark = 0x1c1c22;
        this.bodyPivot = new THREE.Group();
        this.bodyPivot.position.y = 0.72;
        this.group.add(this.bodyPivot);
        this.box(0.09, 0.46, 0.09, bone, 0, 0.26, 0, this.bodyPivot);
        for (let i = 0; i < 3; i++) {
          const y = 0.42 - i * 0.15;
          this.box(0.4, 0.045, 0.05, bone, 0, y, -0.02, this.bodyPivot);
          this.box(0.05, 0.045, 0.18, bone, -0.19, y - 0.03, 0.02, this.bodyPivot);
          this.box(0.05, 0.045, 0.18, bone, 0.19, y - 0.03, 0.02, this.bodyPivot);
        }
        this.box(0.28, 0.09, 0.16, bone, 0, 0.02, 0, this.bodyPivot);
        this.box(0.42, 0.05, 0.06, bone, 0, 0.5, 0, this.bodyPivot);

        const head = new THREE.Group();
        head.position.y = 0.8;
        this.group.add(head);
        this.headPivot = head;
        this.box(0.4, 0.32, 0.38, headC, 0, 0.04, 0, head);
        this.box(0.12, 0.13, 0.09, dark, -0.1, 0.06, -0.18, head);
        this.box(0.12, 0.13, 0.09, dark, 0.1, 0.06, -0.18, head);
        this.ball(0.032, hostile ? 0xff3b30 : 0xffe082, -0.1, 0.06, -0.22, head, true);
        this.ball(0.032, hostile ? 0xff3b30 : 0xffe082, 0.1, 0.06, -0.22, head, true);
        this.box(0.05, 0.07, 0.07, dark, 0, -0.04, -0.19, head);
        this.box(0.28, 0.09, 0.26, bone, 0, -0.15, -0.02, head);
        for (let i = 0; i < 4; i++) this.box(0.045, 0.055, 0.035, dark, -0.1 + i * 0.07, -0.1, -0.16, head);

        this.armSet(0.24, 0.22, 0.07, bone, 0.48, 0.26);
        this.limbs.forEach((l) => (l.upper.rotation.x = -1.05));
        // 弓
        const bow = new THREE.Mesh(
          this.geo(new THREE.TorusGeometry(0.28, 0.022, 4, 14, Math.PI)),
          this.mat(0x6b4326),
        );
        bow.position.set(-0.4, 0.92, -0.22);
        bow.rotation.y = Math.PI / 2;
        this.group.add(bow);
        this.extras.push({ obj: bow, kind: 'bow' });
        this.legSet(2, 0.3, 0.28, 0.08, bone, 0.72, 0.11, 0, false);
        break;
      }

      /* ---------- 蜘蛛 ---------- */
      case 'spider': {
        this.bodyPivot = new THREE.Group();
        this.bodyPivot.position.y = 0.5;
        this.group.add(this.bodyPivot);
        this.box(0.58, 0.3, 0.46, bodyC, 0, 0, -0.14, this.bodyPivot);
        this.ball(0.32, bodyC, 0, 0.02, 0.34, this.bodyPivot);
        this.ball(0.09, accC, -0.13, 0.24, 0.28, this.bodyPivot);
        this.ball(0.09, accC, 0.13, 0.24, 0.28, this.bodyPivot);
        this.ball(0.07, accC, 0, 0.28, 0.42, this.bodyPivot);

        const head = new THREE.Group();
        head.position.set(0, -0.02, -0.42);
        this.bodyPivot.add(head);
        this.headPivot = head;
        this.box(0.42, 0.28, 0.28, headC, 0, 0, 0, head);
        this.eye(0.07, -0.1, 0.06, -0.15, head, true);
        this.eye(0.07, 0.1, 0.06, -0.15, head, true);
        for (const [ex, ey, ez] of [
          [-0.16, 0.1, -0.11],
          [0.16, 0.1, -0.11],
          [-0.05, 0.13, -0.14],
          [0.05, 0.13, -0.14],
          [-0.12, -0.02, -0.14],
          [0.12, -0.02, -0.14],
        ])
          this.ball(0.03, accC, ex, ey, ez, head, true);
        for (const s of [-1, 1]) {
          const fang = this.box(0.055, 0.13, 0.055, 0xf5f5f5, s * 0.09, -0.15, -0.1, head);
          fang.rotation.x = 0.3;
        }

        // 8 条两节腿，波浪步态
        for (const s of [-1, 1]) {
          for (let i = 0; i < 4; i++) {
            const zPos = -0.3 + i * 0.24;
            const leg = this.limb(0.34, 0.4, 0.075, accC, s * 0.26, 0.06, zPos, i * (Math.PI / 2) + (s > 0 ? 0 : Math.PI));
            leg.upper.rotation.z = s * 0.9;
            leg.upper.rotation.y = s * (0.3 + i * 0.08);
          }
        }
        break;
      }

      /* ---------- 苦力怕 ---------- */
      case 'creeper': {
        this.bodyPivot = new THREE.Group();
        this.bodyPivot.position.y = 0.6;
        this.group.add(this.bodyPivot);
        this.box(0.4, 0.62, 0.28, bodyC, 0, 0.24, 0, this.bodyPivot);
        for (const [ox, oy, oz] of [
          [-0.14, 0.38, -0.15],
          [0.12, 0.14, 0.15],
          [0, 0.46, 0.15],
        ])
          this.box(0.11, 0.11, 0.03, accC, ox, oy, oz, this.bodyPivot);

        const head = new THREE.Group();
        head.position.y = 0.86;
        this.group.add(head);
        this.headPivot = head;
        this.box(0.44, 0.42, 0.42, headC, 0, 0, 0, head);
        this.box(0.11, 0.13, 0.05, 0x1a1a1a, -0.11, 0.07, -0.22, head);
        this.box(0.11, 0.13, 0.05, 0x1a1a1a, 0.11, 0.07, -0.22, head);
        this.box(0.09, 0.15, 0.05, 0x1a1a1a, 0, -0.07, -0.22, head);
        this.box(0.17, 0.07, 0.05, 0x1a1a1a, 0, -0.17, -0.22, head);
        for (const [lx, lz] of [
          [-0.14, -0.14],
          [0.14, -0.14],
          [-0.14, 0.14],
          [0.14, 0.14],
        ])
          this.limbs.push(this.limb(0.18, 0.16, 0.16, accC, lx, 0.6, lz, lx > 0 ? 0 : Math.PI));
        break;
      }

      /* ---------- 末影 / 影袭者 / 怨灵 ---------- */
      case 'ender': {
        this.bodyPivot = new THREE.Group();
        this.bodyPivot.position.y = 0.9;
        this.group.add(this.bodyPivot);
        this.box(0.28, 0.72, 0.2, bodyC, 0, 0.4, 0, this.bodyPivot);
        this.box(0.32, 0.14, 0.24, accC, 0, 0.72, 0, this.bodyPivot, { transparent: true, opacity: 0.85 });

        const head = new THREE.Group();
        head.position.y = 1.1;
        this.group.add(head);
        this.headPivot = head;
        this.box(0.4, 0.38, 0.38, headC, 0, 0, 0, head);
        this.ball(0.065, accC, -0.1, 0.02, -0.2, head, true);
        this.ball(0.065, accC, 0.1, 0.02, -0.2, head, true);
        this.ball(0.028, 0xffffff, -0.12, 0.06, -0.24, head, true);
        this.ball(0.028, 0xffffff, 0.08, 0.06, -0.24, head, true);

        this.armSet(0.42, 0.4, 0.09, bodyC, 0.76, 0.22);
        this.legSet(2, 0.42, 0.4, 0.1, bodyC, 0.9, 0.11, 0, false);
        const ring = new THREE.Mesh(
          this.geo(new THREE.TorusGeometry(0.42, 0.022, 5, 20)),
          new THREE.MeshBasicMaterial({ color: accC, transparent: true, opacity: 0.65 }),
        );
        this.mats.push(ring.material as THREE.Material);
        this.baseColors.push(new THREE.Color(accC));
        ring.rotation.x = Math.PI / 2;
        ring.position.y = 1.32;
        this.group.add(ring);
        this.extras.push({ obj: ring, kind: 'ring' });
        break;
      }

      /* ---------- 史莱姆 ---------- */
      case 'slime': {
        this.bodyPivot = new THREE.Group();
        this.bodyPivot.position.y = 0.34;
        this.group.add(this.bodyPivot);
        // 半透明胶质球体（Phong 高光让它看起来是黏液而不是塑料块）
        const gelMat = new THREE.MeshPhongMaterial({
          color: bodyC,
          transparent: true,
          opacity: 0.72,
          shininess: 90,
          specular: new THREE.Color(0xbff5ef),
        });
        this.mats.push(gelMat);
        this.baseColors.push(new THREE.Color(bodyC));
        const gelGeo = this.geo(new THREE.SphereGeometry(0.34, 16, 12));
        const gel = new THREE.Mesh(gelGeo, gelMat);
        this.bodyPivot.add(gel);
        const coreMat = new THREE.MeshLambertMaterial({ color: headC, transparent: true, opacity: 0.95 });
        this.mats.push(coreMat);
        this.baseColors.push(new THREE.Color(headC));
        const core = new THREE.Mesh(this.geo(new THREE.SphereGeometry(0.19, 12, 9)), coreMat);
        core.position.y = -0.02;
        this.bodyPivot.add(core);
        this.eye(0.085, -0.11, 0.08, -0.32, this.bodyPivot);
        this.eye(0.085, 0.11, 0.08, -0.32, this.bodyPivot);
        this.ball(0.05, accC, 0, -0.16, 0, this.bodyPivot, true);
        break;
      }

      /* ---------- 傀儡 / 守护者 ---------- */
      case 'golem': {
        const guard = this.def.id === 23;
        this.bodyPivot = new THREE.Group();
        this.bodyPivot.position.y = 0.7;
        this.group.add(this.bodyPivot);
        this.box(0.74, 0.66, 0.46, bodyC, 0, 0.44, 0, this.bodyPivot);
        this.box(0.8, 0.14, 0.5, accC, 0, 0.12, 0, this.bodyPivot);
        if (guard) {
          this.box(0.2, 0.5, 0.1, accC, 0, 0.5, -0.26, this.bodyPivot, { transparent: true, opacity: 0.8 });
          this.box(0.5, 0.12, 0.1, accC, 0, 0.62, -0.26, this.bodyPivot, { transparent: true, opacity: 0.8 });
        }

        const head = new THREE.Group();
        head.position.y = 1.06;
        this.group.add(head);
        this.headPivot = head;
        this.box(0.48, 0.42, 0.44, headC, 0, 0, 0, head);
        this.box(0.52, 0.11, 0.48, accC, 0, 0.19, 0, head);
        this.ball(0.065, guard ? accC : 0xffd166, -0.12, 0.02, -0.23, head, true);
        this.ball(0.065, guard ? accC : 0xffd166, 0.12, 0.02, -0.23, head, true);
        this.box(0.18, 0.06, 0.05, 0x2b2b35, 0, -0.13, -0.23, head);
        this.box(0.11, 0.2, 0.14, 0xff9f1c, 0, -0.02, -0.26, head);

        this.armSet(0.36, 0.34, 0.2, bodyC, 0.78, 0.5);
        this.legSet(2, 0.32, 0.3, 0.2, accC, 0.7, 0.2, 0, false);
        if (guard) {
          const ring = new THREE.Mesh(
            this.geo(new THREE.TorusGeometry(0.7, 0.03, 5, 22)),
            new THREE.MeshBasicMaterial({ color: accC, transparent: true, opacity: 0.7 }),
          );
          this.mats.push(ring.material as THREE.Material);
          this.baseColors.push(new THREE.Color(accC));
          ring.rotation.x = Math.PI / 2;
          ring.position.y = 1.5;
          this.group.add(ring);
          this.extras.push({ obj: ring, kind: 'ring' });
        }
        break;
      }

      /* ---------- 雪人 ---------- */
      case 'snowman': {
        this.bodyPivot = new THREE.Group();
        this.group.add(this.bodyPivot);
        this.ball(0.32, bodyC, 0, 0.32, 0, this.bodyPivot);
        this.ball(0.24, bodyC, 0, 0.74, 0, this.bodyPivot);
        const head = new THREE.Group();
        head.position.y = 1.04;
        this.group.add(head);
        this.headPivot = head;
        this.ball(0.2, 0xf7fbff, 0, 0, 0, head);
        this.box(0.28, 0.24, 0.28, headC, 0, 0.24, 0, head);
        this.box(0.3, 0.05, 0.3, 0x7bb23c, 0, 0.37, 0, head);
        this.box(0.07, 0.07, 0.05, 0x5a2d06, -0.07, 0.26, -0.15, head);
        this.box(0.07, 0.07, 0.05, 0x5a2d06, 0.07, 0.26, -0.15, head);
        this.box(0.12, 0.04, 0.05, 0x5a2d06, 0, 0.17, -0.15, head);
        for (const s of [-1, 1]) {
          const arm = new THREE.Group();
          arm.position.set(s * 0.24, 0.74, 0);
          this.group.add(arm);
          this.box(0.05, 0.05, 0.36, 0x6b4326, s * 0.16, 0, 0, arm);
          this.box(0.04, 0.04, 0.12, 0x6b4326, s * 0.28, 0.06, 0.06, arm);
          this.wings.push(arm);
        }
        break;
      }

      /* ---------- 蝙蝠 / 小恶魔 ---------- */
      case 'bat': {
        this.bodyPivot = new THREE.Group();
        this.bodyPivot.position.y = 0.72;
        this.group.add(this.bodyPivot);
        this.box(0.32, 0.4, 0.26, bodyC, 0, 0, 0, this.bodyPivot);
        const head = new THREE.Group();
        head.position.y = 0.32;
        this.bodyPivot.add(head);
        this.headPivot = head;
        this.box(0.3, 0.26, 0.26, headC, 0, 0, 0, head);
        for (const s of [-1, 1]) {
          const ear = new THREE.Group();
          ear.position.set(s * 0.1, 0.16, 0);
          head.add(ear);
          this.box(0.07, 0.2, 0.05, headC, 0, 0.08, 0, ear).rotation.z = s * 0.3;
          this.ears.push(ear);
        }
        for (const s of [-1, 1]) this.box(0.05, 0.12, 0.05, accC, s * 0.05, 0.18, -0.05, head);
        this.eye(0.06, -0.08, 0.02, -0.14, head, true);
        this.eye(0.06, 0.08, 0.02, -0.14, head, true);
        for (const s of [-1, 1]) this.box(0.035, 0.07, 0.035, 0xffffff, s * 0.045, -0.14, -0.12, head);

        for (const s of [-1, 1]) {
          const wing = new THREE.Group();
          wing.position.set(s * 0.16, 0.14, 0);
          this.bodyPivot.add(wing);
          this.box(0.44, 0.05, 0.32, accC, s * 0.24, 0, 0, wing);
          this.box(0.3, 0.04, 0.2, bodyC, s * 0.38, -0.05, 0.06, wing);
          this.wings.push(wing);
        }
        this.legSet(2, 0.2, 0.18, 0.09, accC, 0.56, 0.12, 0, false);
        break;
      }

      /* ---------- 飞龙 ---------- */
      case 'dragon': {
        this.bodyPivot = new THREE.Group();
        this.bodyPivot.position.y = 0.72;
        this.group.add(this.bodyPivot);
        this.box(0.44, 0.38, 0.76, bodyC, 0, 0, 0.06, this.bodyPivot);
        this.box(0.36, 0.2, 0.3, accC, 0, 0.16, -0.06, this.bodyPivot);

        const neck = new THREE.Group();
        neck.position.set(0, 0.12, -0.4);
        neck.rotation.x = -0.3;
        this.bodyPivot.add(neck);
        this.box(0.2, 0.2, 0.3, bodyC, 0, 0.06, -0.08, neck);
        const head = new THREE.Group();
        head.position.set(0, 0.16, -0.22);
        neck.add(head);
        this.headPivot = head;
        this.box(0.32, 0.28, 0.4, headC, 0, 0, 0, head);
        this.box(0.22, 0.14, 0.18, headC, 0, -0.07, -0.26, head);
        for (const s of [-1, 1]) {
          const horn = this.box(0.06, 0.18, 0.06, accC, s * 0.11, 0.2, 0.04, head);
          horn.rotation.z = s * -0.3;
        }
        this.eye(0.06, -0.09, 0.05, -0.18, head, hostile);
        this.eye(0.06, 0.09, 0.05, -0.18, head, hostile);

        for (const s of [-1, 1]) {
          const wing = new THREE.Group();
          wing.position.set(s * 0.22, 0.2, 0.06);
          this.bodyPivot.add(wing);
          this.box(0.62, 0.06, 0.46, accC, s * 0.34, 0.04, 0, wing);
          this.box(0.38, 0.05, 0.28, bodyC, s * 0.56, -0.04, 0.1, wing);
          this.wings.push(wing);
        }
        this.tailPivot = new THREE.Group();
        this.tailPivot.position.set(0, 0, 0.44);
        this.bodyPivot.add(this.tailPivot);
        for (let i = 0; i < 3; i++) {
          const t = this.box(0.15 - i * 0.035, 0.15 - i * 0.035, 0.26, bodyC, 0, -i * 0.04, 0.14 + i * 0.24, this.tailPivot);
          t.rotation.x = i * 0.12;
        }
        this.legSet(2, 0.22, 0.2, 0.12, accC, 0.54, 0.18, 0.14, false);
        break;
      }

      /* ---------- 恶魔 Boss ---------- */
      case 'demon': {
        this.bodyPivot = new THREE.Group();
        this.bodyPivot.position.y = 0.86;
        this.group.add(this.bodyPivot);
        this.box(0.66, 0.78, 0.44, bodyC, 0, 0.5, 0, this.bodyPivot);
        this.box(0.74, 0.2, 0.5, accC, 0, 0.86, 0, this.bodyPivot);
        for (const [ox, oy, oz] of [
          [-0.2, 0.62, -0.23],
          [0.18, 0.34, -0.23],
          [0, 0.2, -0.23],
        ])
          this.box(0.15, 0.05, 0.03, accC, ox, oy, oz, this.bodyPivot, { emissive: 0xff6a00, emissiveIntensity: 0.7 } as never);

        const head = new THREE.Group();
        head.position.y = 1.34;
        this.group.add(head);
        this.headPivot = head;
        this.box(0.52, 0.46, 0.46, headC, 0, 0, 0, head);
        this.box(0.54, 0.12, 0.48, bodyC, 0, 0.22, 0, head);
        for (const s of [-1, 1]) {
          const horn = this.box(0.11, 0.4, 0.11, accC, s * 0.22, 0.32, 0, head);
          horn.rotation.z = s * -0.4;
          this.box(0.08, 0.18, 0.08, 0xfff3ad, s * 0.32, 0.5, 0, head);
        }
        this.eye(0.09, -0.13, 0.02, -0.24, head, true);
        this.eye(0.09, 0.13, 0.02, -0.24, head, true);
        for (const s of [-1, 1]) {
          const fang = this.box(0.06, 0.15, 0.06, 0xffffff, s * 0.11, -0.22, -0.18, head);
          fang.rotation.x = 0.2;
        }
        // 皇冠
        this.box(0.4, 0.14, 0.4, 0xffd166, 0, 0.32, 0, head);
        for (const sx of [-1, 0, 1]) this.box(0.06, 0.14, 0.06, 0xfff3ad, sx * 0.13, 0.44, 0, head);
        this.ball(0.045, 0xff5d6c, 0, 0.34, -0.2, head, true);

        for (const s of [-1, 1]) {
          const wing = new THREE.Group();
          wing.position.set(s * 0.36, 0.86, 0.14);
          this.bodyPivot.add(wing);
          this.box(0.84, 0.07, 0.6, accC, s * 0.46, 0.08, 0, wing);
          this.box(0.52, 0.06, 0.38, bodyC, s * 0.72, -0.04, 0.12, wing);
          this.wings.push(wing);
        }
        this.armSet(0.32, 0.3, 0.18, bodyC, 0.9, 0.46);
        this.legSet(2, 0.38, 0.34, 0.19, bodyC, 0.86, 0.2, 0, false);
        const ring = new THREE.Mesh(
          this.geo(new THREE.TorusGeometry(0.78, 0.035, 5, 24)),
          new THREE.MeshBasicMaterial({ color: 0xff6a00, transparent: true, opacity: 0.8 }),
        );
        this.mats.push(ring.material as THREE.Material);
        this.baseColors.push(new THREE.Color(0xff6a00));
        ring.rotation.x = Math.PI / 2;
        ring.position.y = 1.72;
        this.group.add(ring);
        this.extras.push({ obj: ring, kind: 'ring' });
        break;
      }

      /* ---------- 法师 Boss ---------- */
      case 'mage': {
        const queen = this.def.id === 24;
        this.bodyPivot = new THREE.Group();
        this.bodyPivot.position.y = 0.6;
        this.group.add(this.bodyPivot);
        this.box(0.42, 0.48, 0.3, bodyC, 0, 0.42, 0, this.bodyPivot);
        this.box(0.58, 0.4, 0.42, bodyC, 0, 0.12, 0, this.bodyPivot);
        this.box(0.64, 0.09, 0.46, accC, 0, -0.06, 0, this.bodyPivot);
        this.box(0.46, 0.08, 0.34, accC, 0, 0.36, 0, this.bodyPivot);

        const head = new THREE.Group();
        head.position.y = 0.96;
        this.group.add(head);
        this.headPivot = head;
        this.box(0.36, 0.36, 0.34, headC, 0, 0, 0, head);
        this.box(0.48, 0.26, 0.46, bodyC, 0, 0.14, 0.03, head);
        this.box(0.46, 0.42, 0.12, bodyC, 0, 0, 0.18, head);
        this.eye(0.07, -0.09, 0.02, -0.18, head, hostile);
        this.eye(0.07, 0.09, 0.02, -0.18, head, hostile);
        if (queen) {
          this.box(0.34, 0.12, 0.34, 0xffd166, 0, 0.26, 0, head);
          for (const sx of [-1, 0, 1]) this.box(0.05, 0.12, 0.05, 0xfff3ad, sx * 0.11, 0.36, 0, head);
          for (const s of [-1, 1]) {
            const wing = new THREE.Group();
            wing.position.set(s * 0.3, 0.5, 0.1);
            this.bodyPivot.add(wing);
            this.box(0.5, 0.05, 0.36, accC, s * 0.28, 0.04, 0, wing, { transparent: true, opacity: 0.7 });
            this.wings.push(wing);
          }
        }

        const staff = new THREE.Group();
        staff.position.set(0.4, 0.36, 0.1);
        this.group.add(staff);
        this.box(0.06, 0.92, 0.06, 0x6b4326, 0, 0.2, 0, staff);
        this.ball(0.11, accC, 0, 0.7, 0, staff, true);
        this.ball(0.05, 0xffffff, 0.03, 0.74, -0.03, staff, true);
        this.extras.push({ obj: staff, kind: 'staff' });

        this.armSet(0.26, 0.24, 0.12, bodyC, 0.62, 0.3);
        this.legSet(2, 0.22, 0.2, 0.13, bodyC, 0.6, 0.14, 0, false);
        const ring = new THREE.Mesh(
          this.geo(new THREE.TorusGeometry(0.46, 0.026, 5, 22)),
          new THREE.MeshBasicMaterial({ color: accC, transparent: true, opacity: 0.75 }),
        );
        this.mats.push(ring.material as THREE.Material);
        this.baseColors.push(new THREE.Color(accC));
        ring.rotation.x = Math.PI / 2;
        ring.position.y = 1.34;
        this.group.add(ring);
        this.extras.push({ obj: ring, kind: 'ring' });
        break;
      }

      /* ---------- 拟态宝箱怪 ---------- */
      case 'mimic': {
        this.bodyPivot = new THREE.Group();
        this.bodyPivot.position.y = 0.4;
        this.group.add(this.bodyPivot);
        this.box(0.72, 0.42, 0.56, bodyC, 0, 0, 0, this.bodyPivot);
        const lid = new THREE.Group();
        lid.position.set(0, 0.21, -0.28);
        this.bodyPivot.add(lid);
        this.box(0.72, 0.24, 0.56, 0xb06a30, 0, 0.12, 0.28, lid);
        this.extras.push({ obj: lid, kind: 'jaw' });
        this.box(0.74, 0.06, 0.58, accC, 0, 0.02, 0, this.bodyPivot);
        this.box(0.12, 0.2, 0.1, 0xffd166, 0, 0.02, -0.3, this.bodyPivot);
        // 牙齿
        for (let i = 0; i < 6; i++) this.box(0.07, 0.12, 0.06, 0xffffff, -0.28 + i * 0.11, 0.16, -0.28, this.bodyPivot);
        this.eye(0.07, -0.16, 0.12, -0.29, this.bodyPivot, true);
        this.eye(0.07, 0.16, 0.12, -0.29, this.bodyPivot, true);
        // 小短腿
        for (const [lx, lz] of [
          [-0.24, -0.18],
          [0.24, -0.18],
          [-0.24, 0.18],
          [0.24, 0.18],
        ])
          this.limbs.push(this.limb(0.1, 0.1, 0.1, accC, lx, 0.2, lz, lx > 0 ? 0 : Math.PI));
        break;
      }
    }
  }

  /* ================= 动画 ================= */

  /** 每渲染帧调用：位置插值 + 步态 + 呼吸 + 头部追踪 */
  animate(dt: number, alpha: number, playerPos: THREE.Vector3, moving: boolean) {
    this.group.position.lerpVectors(this.prevPos, this.pos, alpha);

    // 平滑转身
    let dy = this.yaw - this.group.rotation.y;
    while (dy > Math.PI) dy -= Math.PI * 2;
    while (dy < -Math.PI) dy += Math.PI * 2;
    this.group.rotation.y += dy * Math.min(1, dt * 12);

    const speed = Math.hypot(this.vel.x, this.vel.z);
    const gait = this.def.model === 'spider' ? 9 : this.def.model === 'golem' ? 4.5 : 7;
    if (speed > 0.25) this.walkPhase += dt * (gait + speed * 0.9);
    else this.walkPhase += dt * 0.6;

    this.breath += dt * 2.2;
    this.blinkT -= dt;
    if (this.blinkT <= 0) this.blinkT = 2.4 + Math.random() * 3.2;
    const blinking = this.blinkT < 0.12;
    for (const lid of this.eyelids) lid.scale.y = blinking ? 1 : 0.01;

    const amp = Math.min(1, speed / 2.2);
    const swing = Math.sin(this.walkPhase);
    const swing2 = Math.sin(this.walkPhase * 2);

    // 四肢步态（双段关节：大腿摆动 + 小腿膝弯）
    this.limbs.forEach((limb, i) => {
      const isLeg = i >= this.limbs.length - this.def.legs;
      const ph = limb.phase;
      const s = Math.sin(this.walkPhase + ph);
      const c2 = Math.cos(this.walkPhase + ph);
      if (this.def.model === 'spider') {
        limb.upper.rotation.x = s * 0.42 * amp;
        limb.lower.rotation.x = -0.35 - Math.max(0, c2) * 0.5 * amp;
      } else if (isLeg) {
        limb.upper.rotation.x = s * 0.72 * amp;
        limb.lower.rotation.x = -Math.max(0, -c2) * 0.85 * amp - 0.04;
      } else {
        // 手臂：僵尸/骷髅保持前伸，其余自然摆动
        const base = this.def.model === 'humanoid' || this.def.model === 'skeleton' ? -1.15 : 0;
        const atk = this.attackAnim > 0 ? -Math.sin(this.attackAnim * Math.PI) * 1.5 : 0;
        limb.upper.rotation.x = base + (i % 2 === 0 ? -s : s) * 0.55 * amp + atk;
        limb.lower.rotation.x = -0.18 - Math.max(0, i % 2 === 0 ? c2 : -c2) * 0.4 * amp;
      }
    });

    // 躯干起伏与倾斜
    if (this.bodyPivot) {
      const bob = this.def.model === 'quadruped' || this.def.model === 'dragon' ? swing2 * 0.035 * amp : swing2 * 0.03 * amp;
      const breathe = Math.sin(this.breath) * 0.012;
      this.bodyPivot.position.y = (this.bodyPivot.userData.baseY ?? (this.bodyPivot.userData.baseY = this.bodyPivot.position.y)) + bob + breathe;
      this.bodyPivot.rotation.z = swing * 0.05 * amp;
      this.bodyPivot.rotation.x = Math.min(0.22, speed * 0.045) + breathe * 0.4;
      const sc = 1 + breathe * 0.5;
      this.bodyPivot.scale.set(1 + breathe * 0.3, sc, 1 + breathe * 0.3);
    }

    // 头部：看玩家 + 走路点头
    if (this.headPivot) {
      const toPlayer = Math.atan2(
        playerPos.x - this.pos.x,
        playerPos.z - this.pos.z,
      );
      let hd = toPlayer - this.yaw;
      while (hd > Math.PI) hd -= Math.PI * 2;
      while (hd < -Math.PI) hd += Math.PI * 2;
      const look = THREE.MathUtils.clamp(hd, -0.7, 0.7);
      const dist = this.pos.distanceTo(playerPos);
      const lookAmt = dist < 14 ? 0.75 : 0.2;
      this.headPivot.rotation.y = look * lookAmt;
      this.headPivot.rotation.x = swing2 * 0.05 * amp + Math.sin(this.breath * 0.7) * 0.02;
    }

    // 尾巴摇摆
    if (this.tailPivot) {
      this.tailPivot.rotation.y = Math.sin(this.walkPhase * 0.8) * (0.25 + amp * 0.4);
      this.tailPivot.rotation.x = Math.sin(this.walkPhase * 0.5) * 0.12;
    }

    // 耳朵抽动
    this.ears.forEach((ear, i) => {
      ear.rotation.x = Math.sin(this.breath * 1.4 + i) * 0.12;
      ear.rotation.z += Math.sin(this.breath * 0.9 + i * 1.7) * 0.002;
    });

    // 翅膀扇动
    if (this.wings.length) {
      const flying = this.def.behavior === 'fly' || !this.onGround;
      const rate = flying ? 11 : 3;
      const f = Math.sin(this.walkPhase * (rate / 7)) * (flying ? 0.75 : 0.18);
      this.wings.forEach((w, i) => {
        w.rotation.z = i % 2 === 0 ? f : -f;
        w.rotation.x = Math.sin(this.walkPhase * (rate / 7) + 0.4) * 0.12;
      });
    }

    // 特殊部件
    for (const ex of this.extras) {
      if (ex.kind === 'ring') {
        ex.obj.rotation.z += dt * 1.6;
        ex.obj.position.y += Math.sin(this.breath * 1.2) * 0.0015;
      } else if (ex.kind === 'jaw') {
        const open = this.attackAnim > 0 ? Math.sin(this.attackAnim * Math.PI) * 0.7 : Math.max(0, Math.sin(this.breath * 0.8)) * 0.08;
        ex.obj.rotation.x = -open;
      } else if (ex.kind === 'beak') {
        ex.obj.rotation.x = -0.1 - Math.max(0, Math.sin(this.breath * 1.6)) * 0.25;
      } else if (ex.kind === 'bow') {
        ex.obj.rotation.z = this.attackAnim > 0 ? -0.5 : 0;
      } else if (ex.kind === 'staff') {
        ex.obj.rotation.z = Math.sin(this.breath * 0.9) * 0.06;
      }
    }

    // 跳跃挤压拉伸 / 落地缓冲
    let sy = 1;
    let sx = 1;
    if (!this.onGround) {
      const s = THREE.MathUtils.clamp(this.vel.y * 0.035, -0.18, 0.22);
      sy = 1 + s;
      sx = 1 - s * 0.5;
    }
    if (this.def.model === 'creeper' && this.explodeTimer > 0.2) {
      const swell = 1 + Math.min(0.35, this.explodeTimer * 0.18);
      sx *= swell;
      sy *= swell;
    }
    this.group.scale.set(this.scale * sx, this.scale * sy, this.scale * sx);
    if (moving && speed < 0.2) this.group.position.y += Math.sin(this.breath) * 0.012;
  }

  /* ================= 运行时 ================= */

  damage(amount: number, forceDir: THREE.Vector3) {
    if (this.hp <= 0) return;
    this.hp = Math.max(0, this.hp - amount);
    this.damageFlash = 0.3;
    this.attackAnim = 0.001;
    this.vel.addScaledVector(forceDir, 4.6);
    this.vel.y += 2.2;
    sfx.hurt();
    if (this.hp <= 0) sfx.break_();
  }

  applyFlash() {
    if (this.damageFlash <= 0) return;
    this.damageFlash -= 1 / 60;
    const on = Math.floor(this.damageFlash * 16) % 2 === 0;
    this.mats.forEach((m, i) => {
      const col = (m as THREE.MeshLambertMaterial).color;
      if (!col) return;
      col.set(on ? 0xff4d4d : this.baseColors[i] ?? 0xffffff);
    });
    if (this.damageFlash <= 0) this.mats.forEach((m, i) => (m as THREE.MeshLambertMaterial).color?.set(this.baseColors[i] ?? 0xffffff));
  }

  tick(dt: number, world: World, playerPos: THREE.Vector3) {
    this.prevPos.copy(this.pos);
    this.applyFlash();
    if (this.attackAnim > 0) this.attackAnim = Math.min(1, this.attackAnim + dt * 3.2);
    if (this.attackAnim >= 1) this.attackAnim = 0;

    if (this.def.model !== 'slime') this.vel.y -= 22 * dt;
    else this.vel.y -= 15 * dt;
    if (this.vel.y < -40) this.vel.y = -40;

    const distToPlayer = this.pos.distanceTo(playerPos);
    let speed = (this.def.friendly ? 1.7 : 3.3) * (this.def.speedMul ?? 1);
    if (this.def.boss) speed *= 1.05;
    if (this.tamed) speed = Math.max(speed, 3.2);

    this.wanderTimer -= dt;
    this.jumpCooldown = Math.max(0, this.jumpCooldown - dt);
    this.attackCooldown = Math.max(0, this.attackCooldown - dt);
    this.specialCooldown = Math.max(0, this.specialCooldown - dt);

    let moveX = 0;
    let moveZ = 0;

    const actWander = () => {
      if (this.wanderTimer <= 0) {
        this.wanderTimer = 2.6 + Math.random() * 4.5;
        this.targetPos.set(
          this.pos.x + (Math.random() - 0.5) * 18,
          this.pos.y,
          this.pos.z + (Math.random() - 0.5) * 18,
        );
      }
      const dx = this.targetPos.x - this.pos.x;
      const dz = this.targetPos.z - this.pos.z;
      const d = Math.hypot(dx, dz);
      if (d > 1.2) {
        moveX = dx / d;
        moveZ = dz / d;
      }
    };

    const chase = () => {
      const dx = playerPos.x - this.pos.x;
      const dz = playerPos.z - this.pos.z;
      const d = Math.hypot(dx, dz) || 1;
      moveX = dx / d;
      moveZ = dz / d;
      this.yaw = Math.atan2(-dx, -dz);
    };

    const tamedFight = () => {
      let nearest: MobLike | null = null;
      let nd = 11;
      for (const other of world.mobList ?? []) {
        if ((other as unknown) === (this as unknown) || other.tamed || other.def.friendly) continue;
        const d = other.pos.distanceTo(this.pos);
        if (d < nd) {
          nd = d;
          nearest = other;
        }
      }
      if (nearest) {
        const dx = nearest.pos.x - this.pos.x;
        const dz = nearest.pos.z - this.pos.z;
        const d = Math.hypot(dx, dz) || 1;
        moveX = dx / d;
        moveZ = dz / d;
        this.yaw = Math.atan2(-dx, -dz);
        if (nd < 1.7 && this.attackCooldown <= 0) {
          this.attackCooldown = 0.9;
          this.attackAnim = 0.001;
          nearest.damage(this.def.attack ?? 4, new THREE.Vector3(moveX, 0.3, moveZ));
        }
        return true;
      }
      return false;
    };

    if (this.tamed) {
      if (!tamedFight()) {
        if (distToPlayer > 3.4) chase();
        else actWander();
      }
    } else if (this.behavior === 'chase' && distToPlayer < (this.def.boss ? 28 : 17) && !this.def.friendly) {
      chase();
      if (distToPlayer < 1.8 && this.attackCooldown <= 0) {
        this.attackCooldown = 1.0;
        this.attackAnim = 0.001;
      }
    } else if (this.behavior === 'explode' && distToPlayer < 13 && !this.def.friendly) {
      chase();
      this.explodeTimer = distToPlayer < 2.6 ? this.explodeTimer + dt : Math.max(0, this.explodeTimer - dt * 2);
    } else if (this.behavior === 'fly') {
      if (this.wanderTimer <= 0) {
        this.wanderTimer = 2 + Math.random() * 3.5;
        this.targetPos.set(
          this.pos.x + (Math.random() - 0.5) * 22,
          Math.max(16, this.pos.y + (Math.random() - 0.5) * 7),
          this.pos.z + (Math.random() - 0.5) * 22,
        );
      }
      if (!this.def.friendly && distToPlayer < 15) this.targetPos.copy(playerPos).add(new THREE.Vector3(0, 1.3, 0));
      const dx = this.targetPos.x - this.pos.x;
      const dy = this.targetPos.y - this.pos.y;
      const dz = this.targetPos.z - this.pos.z;
      const d = Math.hypot(dx, dz);
      if (d > 1) {
        moveX = dx / d;
        moveZ = dz / d;
        this.yaw = Math.atan2(-dx, -dz);
        this.vel.y += (dy - this.vel.y) * 4 * dt;
      }
      this.vel.y = Math.max(-4.5, Math.min(5, this.vel.y));
    } else {
      actWander();
    }

    if (moveX !== 0 || moveZ !== 0) {
      this.vel.x = moveX * speed;
      this.vel.z = moveZ * speed;
      if (this.behavior !== 'chase' && this.behavior !== 'explode') this.yaw = Math.atan2(-moveX, -moveZ);
    } else {
      this.vel.x *= 1 - Math.min(1, dt * 8);
      this.vel.z *= 1 - Math.min(1, dt * 8);
    }

    if (this.behavior === 'hop' && this.onGround && this.jumpCooldown <= 0) {
      this.vel.y = this.def.model === 'slime' ? 6.6 : 5.4;
      this.jumpCooldown = 0.85 + Math.random() * 0.8;
    }

    if ((this.vel.x !== 0 || this.vel.z !== 0) && this.def.model !== 'slime') {
      const nextX = this.pos.x + Math.sign(this.vel.x) * 0.45;
      const nextZ = this.pos.z + Math.sign(this.vel.z) * 0.45;
      const frontBlock = world.getBlock(Math.floor(nextX), Math.floor(this.pos.y + 0.1), Math.floor(nextZ));
      const headBlock = world.getBlock(Math.floor(nextX), Math.floor(this.pos.y + 1.2), Math.floor(nextZ));
      if (getBlock(frontBlock).solid && !getBlock(headBlock).solid && this.onGround && this.jumpCooldown <= 0) {
        this.vel.y = 6.4;
        this.onGround = false;
        this.jumpCooldown = 0.75;
      }
    }

    this.onGround = false;
    this.moveAxis('x', this.vel.x * dt, world);
    this.moveAxis('z', this.vel.z * dt, world);
    this.moveAxis('y', this.vel.y * dt, world);
  }

  private collides(px: number, py: number, pz: number, world: World) {
    const half = 0.28 * this.scale;
    const minX = Math.floor(px - half);
    const maxX = Math.floor(px + half);
    const minY = Math.floor(py);
    const maxY = Math.floor(py + 1.2 * this.scale);
    const minZ = Math.floor(pz - half);
    const maxZ = Math.floor(pz + half);
    for (let x = minX; x <= maxX; x++)
      for (let y = minY; y <= maxY; y++)
        for (let z = minZ; z <= maxZ; z++) if (getBlock(world.getBlock(x, y, z)).solid) return true;
    return false;
  }

  private moveAxis(axis: 'x' | 'y' | 'z', amount: number, world: World) {
    if (amount === 0) return;
    const steps = Math.ceil(Math.abs(amount) / 0.15);
    const inc = amount / steps;
    for (let i = 0; i < steps; i++) {
      const prev = this.pos[axis];
      this.pos[axis] += inc;
      if (this.collides(this.pos.x, this.pos.y, this.pos.z, world)) {
        this.pos[axis] = prev;
        if (axis === 'y' && this.vel.y < 0) {
          this.onGround = true;
          this.vel.y = 0;
        } else this.vel[axis] = 0;
        return;
      }
    }
  }

  dispose() {
    this.geos.forEach((g) => g.dispose());
    this.mats.forEach((m) => m.dispose());
    this.geos = [];
    this.mats = [];
  }
}
