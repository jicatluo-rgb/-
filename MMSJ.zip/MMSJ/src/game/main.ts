/** 主游戏文件 - 集成所有系统 */

import * as THREE from 'three';
import { GameOptimizations } from './game_optimizations';
import { GraphicsOptionsUI } from './graphics_ui';

export class MainGame {
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private renderer: THREE.WebGLRenderer;
  private clock: THREE.Clock;
  private optimizations: GameOptimizations;
  private graphicsUI: GraphicsOptionsUI | null = null;
  
  // 玩家控制
  private keys: Set<string> = new Set();
  private playerVelocity: THREE.Vector3 = new THREE.Vector3();
  private playerRotation: THREE.Euler = new THREE.Euler();
  
  constructor() {
    // 初始化Three.js
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x87ceeb);
    this.scene.fog = new THREE.Fog(0x87ceeb, 50, 200);
    
    this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    this.camera.position.set(0, 5, 10);
    
    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    document.body.appendChild(this.renderer.domElement);
    
    this.clock = new THREE.Clock();
    
    // 初始化优化系统
    this.optimizations = new GameOptimizations(this.scene, this.camera, this.renderer);
    
    // 初始化UI
    this.initUI();
    
    // 初始化控制
    this.initControls();
    
    // 开始游戏循环
    this.animate();
  }
  
  private initUI() {
    // 创建UI容器
    const uiContainer = document.createElement('div');
    uiContainer.id = 'ui-container';
    document.body.appendChild(uiContainer);
    
    // 创建画质选项按钮
    const graphicsBtn = document.createElement('button');
    graphicsBtn.textContent = '画质设置';
    graphicsBtn.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 12px 24px;
      background: #ffd166;
      color: #14141e;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-size: 14px;
      font-weight: bold;
      z-index: 999;
    `;
    graphicsBtn.addEventListener('click', () => {
      if (this.graphicsUI) {
        this.graphicsUI.toggle();
      }
    });
    document.body.appendChild(graphicsBtn);
    
    // 创建画质选项UI
    this.graphicsUI = new GraphicsOptionsUI(uiContainer, this.optimizations.getGraphicsManager());
  }
  
  private initControls() {
    // 键盘控制
    document.addEventListener('keydown', (e) => {
      this.keys.add(e.code);
      
      // ESC键切换画质菜单
      if (e.code === 'Escape' && this.graphicsUI) {
        this.graphicsUI.toggle();
      }
    });
    
    document.addEventListener('keyup', (e) => {
      this.keys.delete(e.code);
    });
    
    // 鼠标控制
    document.addEventListener('mousemove', (e) => {
      if (document.pointerLockElement === this.renderer.domElement) {
        this.playerRotation.y -= e.movementX * 0.002;
        this.playerRotation.x -= e.movementY * 0.002;
        this.playerRotation.x = Math.max(-Math.PI / 2, Math.min(Math.PI / 2, this.playerRotation.x));
      }
    });
    
    this.renderer.domElement.addEventListener('click', () => {
      this.renderer.domElement.requestPointerLock();
    });
    
    // 窗口大小调整
    window.addEventListener('resize', () => {
      this.camera.aspect = window.innerWidth / window.innerHeight;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(window.innerWidth, window.innerHeight);
    });
  }
  
  private updatePlayer(deltaTime: number) {
    // 玩家移动
    const speed = 10;
    const direction = new THREE.Vector3();
    
    if (this.keys.has('KeyW')) direction.z -= 1;
    if (this.keys.has('KeyS')) direction.z += 1;
    if (this.keys.has('KeyA')) direction.x -= 1;
    if (this.keys.has('KeyD')) direction.x += 1;
    
    direction.normalize();
    direction.multiplyScalar(speed * deltaTime);
    
    // 应用旋转
    direction.applyEuler(new THREE.Euler(0, this.playerRotation.y, 0));
    
    this.playerVelocity.x = direction.x;
    this.playerVelocity.z = direction.z;
    
    // 应用重力
    this.playerVelocity.y -= 20 * deltaTime;
    
    // 更新位置
    this.camera.position.x += this.playerVelocity.x;
    this.camera.position.y += this.playerVelocity.y;
    this.camera.position.z += this.playerVelocity.z;
    
    // 地面碰撞
    if (this.camera.position.y < 2) {
      this.camera.position.y = 2;
      this.playerVelocity.y = 0;
    }
    
    // 更新相机旋转
    this.camera.rotation.copy(this.playerRotation);
  }
  
  private animate() {
    requestAnimationFrame(() => this.animate());
    
    const deltaTime = this.clock.getDelta();
    
    // 更新玩家
    this.updatePlayer(deltaTime);
    
    // 更新所有系统
    this.optimizations.update(deltaTime);
    
    // 渲染
    this.renderer.render(this.scene, this.camera);
  }
}

// 启动游戏
window.addEventListener('DOMContentLoaded', () => {
  new MainGame();
});
