import * as THREE from 'three';
import { getBlock } from './blocks';
import { getTool, STICK_ID } from './items';
import { tileUV } from './textures';

/** 掉在地上的物品实体（我的世界式掉落物） */
export interface ItemDrop {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  id: number;
  count: number;
  age: number;
  frozen: number; // 0.5s 内不可拾取
}

export function createDropMesh(id: number, atlas: THREE.Texture | null): THREE.Mesh {
  // 工具 / 木棍 → 细长条
  if (getTool(id) || id === STICK_ID) {
    const mat = new THREE.MeshLambertMaterial({
      color: getTool(id)?.material === 'crystal' ? 0x5ce1e6 : id === STICK_ID ? 0xc9975e : 0xa8a8b4,
    });
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.42, 0.16), mat);
    mesh.castShadow = true;
    return mesh;
  }
  const def = getBlock(id);
  const geo = new THREE.BoxGeometry(0.28, 0.28, 0.28);
  const uv = geo.getAttribute('uv') as THREE.BufferAttribute;
  for (let f = 0; f < 6; f++) {
    const [u0, v0, u1, v1] = tileUV(def.tiles[f]);
    const o = f * 4;
    uv.setXY(o, u0, v1);
    uv.setXY(o + 1, u1, v1);
    uv.setXY(o + 2, u0, v0);
    uv.setXY(o + 3, u1, v0);
  }
  uv.needsUpdate = true;
  const mat = new THREE.MeshLambertMaterial({
    map: atlas,
    transparent: def.pass !== 'opaque',
    alphaTest: def.pass === 'cutout' ? 0.5 : 0,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.castShadow = true;
  return mesh;
}
