/** 扩展遗迹系统 - 15+群系特定遗迹 */

export interface StructureDef {
  id: string;
  name: string;
  biome: string;
  rarity: number; // 0-1, 越低越稀有
  size: 'small' | 'medium' | 'large' | 'huge';
  loot: number[]; // 战利品ID列表
  description: string;
  hasMobSpawner?: boolean;
  hasChest?: boolean;
  hasPortal?: boolean;
}

export const NEW_STRUCTURES: StructureDef[] = [
  // 平原遗迹
  { 
    id: 'village_plains', 
    name: '平原村庄', 
    biome: 'plains', 
    rarity: 0.15, 
    size: 'large', 
    loot: [221, 222, 230, 236, 237, 238, 250], 
    description: '大型村庄，有村民和农田',
    hasMobSpawner: false,
    hasChest: true,
  },
  { 
    id: 'mineshaft', 
    name: '废弃矿井', 
    biome: 'plains', 
    rarity: 0.08, 
    size: 'large', 
    loot: [200, 201, 210, 230, 232, 233, 234, 239], 
    description: '地下矿井，有铁轨和箱子',
    hasMobSpawner: true,
    hasChest: true,
  },
  { 
    id: 'stronghold', 
    name: '要塞', 
    biome: 'plains', 
    rarity: 0.03, 
    size: 'huge', 
    loot: [201, 211, 232, 250, 252, 254], 
    description: '地下要塞，有末地传送门',
    hasMobSpawner: true,
    hasChest: true,
    hasPortal: true,
  },
  { 
    id: 'dungeon', 
    name: '地牢', 
    biome: 'plains', 
    rarity: 0.12, 
    size: 'small', 
    loot: [200, 210, 220, 221, 222, 234], 
    description: '小型地牢，有刷怪笼',
    hasMobSpawner: true,
    hasChest: true,
  },
  
  // 森林遗迹
  { 
    id: 'treehouse', 
    name: '树屋', 
    biome: 'forest', 
    rarity: 0.1, 
    size: 'medium', 
    loot: [202, 212, 220, 237, 238, 240], 
    description: '建在树上的小屋',
    hasChest: true,
  },
  { 
    id: 'witch_hut', 
    name: '女巫小屋', 
    biome: 'forest', 
    rarity: 0.05, 
    size: 'small', 
    loot: [224, 225, 227, 242], 
    description: '女巫的住所',
    hasMobSpawner: true,
    hasChest: true,
  },
  { 
    id: 'jungle_temple', 
    name: '丛林神庙', 
    biome: 'forest', 
    rarity: 0.04, 
    size: 'large', 
    loot: [201, 211, 232, 250, 251, 252], 
    description: '隐藏的丛林神庙，有陷阱',
    hasMobSpawner: true,
    hasChest: true,
  },
  
  // 沙漠遗迹
  { 
    id: 'desert_temple', 
    name: '沙漠神殿', 
    biome: 'desert', 
    rarity: 0.06, 
    size: 'large', 
    loot: [201, 231, 232, 250, 251, 252, 255], 
    description: '金字塔，有TNT陷阱',
    hasMobSpawner: true,
    hasChest: true,
  },
  { 
    id: 'desert_village', 
    name: '沙漠村庄', 
    biome: 'desert', 
    rarity: 0.1, 
    size: 'medium', 
    loot: [203, 221, 231, 236, 255], 
    description: '沙漠中的村庄',
    hasChest: true,
  },
  { 
    id: 'pyramid', 
    name: '金字塔', 
    biome: 'desert', 
    rarity: 0.03, 
    size: 'huge', 
    loot: [201, 231, 232, 250, 251, 252, 255], 
    description: '古老金字塔，有诅咒',
    hasMobSpawner: true,
    hasChest: true,
  },
  
  // 海洋遗迹
  { 
    id: 'ocean_monument', 
    name: '海底神殿', 
    biome: 'ocean', 
    rarity: 0.04, 
    size: 'large', 
    loot: [201, 213, 228, 232, 250, 251, 252], 
    description: '海底神殿，有守卫者',
    hasMobSpawner: true,
    hasChest: true,
  },
  { 
    id: 'shipwreck', 
    name: '沉船', 
    biome: 'ocean', 
    rarity: 0.08, 
    size: 'medium', 
    loot: [201, 204, 228, 231, 250, 252], 
    description: '沉没的船只',
    hasChest: true,
  },
  { 
    id: 'underwater_ruins', 
    name: '水下废墟', 
    biome: 'ocean', 
    rarity: 0.06, 
    size: 'medium', 
    loot: [201, 213, 228, 232], 
    description: '水下古代遗迹',
    hasMobSpawner: true,
    hasChest: true,
  },
  
  // 沼泽遗迹
  { 
    id: 'swamp_hut', 
    name: '沼泽小屋', 
    biome: 'swamp', 
    rarity: 0.07, 
    size: 'small', 
    loot: [224, 227, 235, 242], 
    description: '沼泽中的小屋',
    hasMobSpawner: true,
    hasChest: true,
  },
  { 
    id: 'mansion', 
    name: '林地府邸', 
    biome: 'swamp', 
    rarity: 0.02, 
    size: 'huge', 
    loot: [201, 211, 224, 225, 227, 232, 250, 251, 252], 
    description: '大型府邸，有卫道士',
    hasMobSpawner: true,
    hasChest: true,
  },
  
  // 雪原遗迹
  { 
    id: 'igloo', 
    name: '雪屋', 
    biome: 'snow', 
    rarity: 0.08, 
    size: 'small', 
    loot: [201, 220, 221, 222, 250, 251], 
    description: '雪地上的小屋',
    hasChest: true,
  },
  { 
    id: 'snow_village', 
    name: '雪原村庄', 
    biome: 'snow', 
    rarity: 0.06, 
    size: 'medium', 
    loot: [201, 220, 221, 222, 241, 250], 
    description: '雪原上的村庄',
    hasChest: true,
  },
  { 
    id: 'frozen_castle', 
    name: '冰封城堡', 
    biome: 'snow', 
    rarity: 0.02, 
    size: 'huge', 
    loot: [201, 211, 232, 241, 250, 251, 252], 
    description: '冰封的古代城堡',
    hasMobSpawner: true,
    hasChest: true,
  },
  
  // 下界遗迹
  { 
    id: 'nether_fortress', 
    name: '下界要塞', 
    biome: 'nether', 
    rarity: 0.05, 
    size: 'large', 
    loot: [201, 214, 225, 231, 234, 250, 251, 255], 
    description: '下界要塞，有烈焰人',
    hasMobSpawner: true,
    hasChest: true,
  },
  { 
    id: 'bastion', 
    name: '堡垒遗迹', 
    biome: 'nether', 
    rarity: 0.04, 
    size: 'large', 
    loot: [201, 214, 225, 231, 234, 250, 255], 
    description: '猪灵的堡垒',
    hasMobSpawner: true,
    hasChest: true,
  },
  
  // 末地遗迹
  { 
    id: 'end_city', 
    name: '末地城', 
    biome: 'end', 
    rarity: 0.03, 
    size: 'large', 
    loot: [201, 211, 232, 253, 254], 
    description: '末地城市，有潜影贝',
    hasMobSpawner: true,
    hasChest: true,
  },
  { 
    id: 'end_ship', 
    name: '末地船', 
    biome: 'end', 
    rarity: 0.02, 
    size: 'medium', 
    loot: [201, 211, 232, 253, 254], 
    description: '末地飞船，有鞘翅',
    hasMobSpawner: true,
    hasChest: true,
  },
];

// 群系遗迹映射
export const BIOME_STRUCTURES: Record<string, string[]> = {
  plains: ['village_plains', 'mineshaft', 'stronghold', 'dungeon'],
  forest: ['treehouse', 'witch_hut', 'jungle_temple'],
  desert: ['desert_temple', 'desert_village', 'pyramid'],
  ocean: ['ocean_monument', 'shipwreck', 'underwater_ruins'],
  swamp: ['swamp_hut', 'mansion'],
  snow: ['igloo', 'snow_village', 'frozen_castle'],
  nether: ['nether_fortress', 'bastion'],
  end: ['end_city', 'end_ship'],
};
