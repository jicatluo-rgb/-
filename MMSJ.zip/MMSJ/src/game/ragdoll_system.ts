/** 修复的布娃娃系统 - 更真实的物理 */

import * as THREE from 'three';

export interface RagdollPart {
  mesh: THREE.Mesh;
  velocity: THREE.Vector3;
  angularVelocity: THREE.Vector3;
  mass: number;
  life: number;
  maxLife: number;
}

export interface Ragdoll {
  parts: RagdollPart[];
  life: number;
  maxLife: number;
  group: THREE.Group;
}

/** 创建布娃娃系统 */
export class RagdollSystem {
  private ragdolls: Ragdoll[] = [];
  private scene: THREE.Scene;
  private gravity: number = -25;
  private friction: number = 0.85;
  private angularDamping: number = 0.92;
  private bounceRestitution: number = 0.4;

  constructor(scene: THREE.Scene) {
    this.scene = scene;
  }

  /** 创建布娃娃（从生物模型） */
  createRagdoll(model: THREE.Group, position: THREE.Vector3, impulse: THREE.Vector3): Ragdoll {
    const ragdollGroup = new THREE.Group();
    ragdollGroup.position.copy(position);
    this.scene.add(ragdollGroup);

    const parts: RagdollPart[] = [];

    // 遍历模型的所有子对象，创建布娃娃部件
    model.traverse((obj) => {
      if ((obj as THREE.Mesh).isMesh) {
        const mesh = obj as THREE.Mesh;
        
        // 克隆网格
        const partMesh = new THREE.Mesh(
          mesh.geometry.clone(),
          (mesh.material as THREE.Material).clone()
        );
        
        // 设置世界位置
        const worldPos = new THREE.Vector3();
        mesh.getWorldPosition(worldPos);
        partMesh.position.copy(worldPos).sub(position);
        
        // 设置旋转
        const worldQuat = new THREE.Quaternion();
        mesh.getWorldQuaternion(worldQuat);
        partMesh.quaternion.copy(worldQuat);
        
        partMesh.castShadow = true;
        partMesh.receiveShadow = true;
        
        ragdollGroup.add(partMesh);

        // 创建布娃娃部件
        const part: RagdollPart = {
          mesh: partMesh,
          velocity: new THREE.Vector3(
            impulse.x * (0.8 + Math.random() * 0.4),
            impulse.y * (0.8 + Math.random() * 0.4),
            impulse.z * (0.8 + Math.random() * 0.4)
          ),
          angularVelocity: new THREE.Vector3(
            (Math.random() - 0.5) * 15,
            (Math.random() - 0.5) * 15,
            (Math.random() - 0.5) * 15
          ),
          mass: 1.0,
          life: 5.0,
          maxLife: 5.0,
        };
        
        parts.push(part);
      }
    });

    const ragdoll: Ragdoll = {
      parts,
      life: 5.0,
      maxLife: 5.0,
      group: ragdollGroup,
    };

    this.ragdolls.push(ragdoll);
    return ragdoll;
  }

  /** 更新所有布娃娃 */
  update(deltaTime: number) {
    for (let i = this.ragdolls.length - 1; i >= 0; i--) {
      const ragdoll = this.ragdolls[i];
      
      ragdoll.life -= deltaTime;
      
      // 更新每个部件
      for (const part of ragdoll.parts) {
        // 应用重力
        part.velocity.y += this.gravity * deltaTime;
        
        // 更新位置
        part.mesh.position.add(part.velocity.clone().multiplyScalar(deltaTime));
        
        // 更新旋转
        part.mesh.rotation.x += part.angularVelocity.x * deltaTime;
        part.mesh.rotation.y += part.angularVelocity.y * deltaTime;
        part.mesh.rotation.z += part.angularVelocity.z * deltaTime;
        
        // 应用角阻尼
        part.angularVelocity.multiplyScalar(this.angularDamping);
        
        // 地面碰撞检测
        if (part.mesh.position.y < 0.1) {
          part.mesh.position.y = 0.1;
          
          // 反弹
          if (part.velocity.y < 0) {
            part.velocity.y = -part.velocity.y * this.bounceRestitution;
            part.velocity.x *= this.friction;
            part.velocity.z *= this.friction;
            part.angularVelocity.multiplyScalar(this.friction);
          }
        }
        
        // 生命周期淡出
        if (part.life < 1.0) {
          const alpha = part.life;
          (part.mesh.material as THREE.MeshLambertMaterial).transparent = true;
          (part.mesh.material as THREE.MeshLambertMaterial).opacity = alpha;
        }
        
        part.life -= deltaTime;
      }
      
      // 移除死亡的布娃娃
      if (ragdoll.life <= 0) {
        this.removeRagdoll(ragdoll);
        this.ragdolls.splice(i, 1);
      }
    }
  }

  /** 移除布娃娃 */
  private removeRagdoll(ragdoll: Ragdoll) {
    this.scene.remove(ragdoll.group);
    
    for (const part of ragdoll.parts) {
      part.mesh.geometry.dispose();
      (part.mesh.material as THREE.Material).dispose();
    }
  }

  /** 清理所有布娃娃 */
  dispose() {
    for (const ragdoll of this.ragdolls) {
      this.removeRagdoll(ragdoll);
    }
    this.ragdolls = [];
  }

  /** 获取布娃娃数量 */
  getRagdollCount(): number {
    return this.ragdolls.length;
  }
}

/** 创建爆炸布娃娃（TNT爆炸效果） */
export function createExplosionRagdoll(
  system: RagdollSystem,
  position: THREE.Vector3,
  radius: number = 5
): void {
  // 创建多个碎片
  const fragmentCount = 20;
  
  for (let i = 0; i < fragmentCount; i++) {
    const fragment = new THREE.Mesh(
      new THREE.BoxGeometry(0.2, 0.2, 0.2),
      new THREE.MeshLambertMaterial({ color: 0xff6600 })
    );
    
    const angle = (i / fragmentCount) * Math.PI * 2;
    const force = radius * 2;
    
    const ragdoll = system.createRagdoll(
      new THREE.Group().add(fragment),
      position,
      new THREE.Vector3(
        Math.cos(angle) * force * (0.5 + Math.random() * 0.5),
        force * (0.8 + Math.random() * 0.4),
        Math.sin(angle) * force * (0.5 + Math.random() * 0.5)
      )
    );
    
    // 设置更短的生命周期
    ragdoll.life = 3.0;
    ragdoll.maxLife = 3.0;
  }
}
