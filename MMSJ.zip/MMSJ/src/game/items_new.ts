/** 扩展道具系统 - 15+新道具 */

export interface ItemDef {
  id: number;
  name: string;
  type: 'tool' | 'weapon' | 'consumable' | 'material' | 'ammo' | 'special';
  stackable: boolean;
  maxStack: number;
  description?: string;
  biome?: string; // 群系特定
}

export const NEW_ITEMS: ItemDef[] = [
  // 工具类
  { id: 200, name: '铁镐', type: 'tool', stackable: false, maxStack: 1, description: '挖掘石头和矿石', biome: 'plains' },
  { id: 201, name: '钻石镐', type: 'tool', stackable: false, maxStack: 1, description: '最耐用的镐子', biome: 'plains' },
  { id: 202, name: '铁斧', type: 'tool', stackable: false, maxStack: 1, description: '砍伐树木', biome: 'forest' },
  { id: 203, name: '铁铲', type: 'tool', stackable: false, maxStack: 1, description: '挖掘泥土和沙子', biome: 'desert' },
  { id: 204, name: '钓鱼竿', type: 'tool', stackable: false, maxStack: 1, description: '在水边钓鱼', biome: 'ocean' },
  
  // 武器类
  { id: 210, name: '铁剑', type: 'weapon', stackable: false, maxStack: 1, description: '近战武器', biome: 'plains' },
  { id: 211, name: '钻石剑', type: 'weapon', stackable: false, maxStack: 1, description: '强大的近战武器', biome: 'plains' },
  { id: 212, name: '弓', type: 'weapon', stackable: false, maxStack: 1, description: '远程武器', biome: 'forest' },
  { id: 213, name: '三叉戟', type: 'weapon', stackable: false, maxStack: 1, description: '可投掷的武器', biome: 'ocean' },
  { id: 214, name: '火焰弓', type: 'weapon', stackable: false, maxStack: 1, description: '发射火焰箭', biome: 'nether' },
  
  // 消耗品
  { id: 220, name: '苹果', type: 'consumable', stackable: true, maxStack: 64, description: '恢复2点饥饿值', biome: 'forest' },
  { id: 221, name: '面包', type: 'consumable', stackable: true, maxStack: 64, description: '恢复5点饥饿值', biome: 'plains' },
  { id: 222, name: '牛排', type: 'consumable', stackable: true, maxStack: 64, description: '恢复8点饥饿值', biome: 'plains' },
  { id: 223, name: '金苹果', type: 'consumable', stackable: true, maxStack: 64, description: '恢复生命并提供抗性', biome: 'plains' },
  { id: 224, name: '治疗药水', type: 'consumable', stackable: true, maxStack: 16, description: '瞬间恢复生命', biome: 'swamp' },
  { id: 225, name: '力量药水', type: 'consumable', stackable: true, maxStack: 16, description: '增加攻击力', biome: 'nether' },
  { id: 226, name: '迅捷药水', type: 'consumable', stackable: true, maxStack: 16, description: '增加移动速度', biome: 'plains' },
  { id: 227, name: '抗火药水', type: 'consumable', stackable: true, maxStack: 16, description: '抵抗火焰伤害', biome: 'nether' },
  { id: 228, name: '水下呼吸药水', type: 'consumable', stackable: true, maxStack: 16, description: '水下呼吸', biome: 'ocean' },
  
  // 材料类
  { id: 230, name: '铁锭', type: 'material', stackable: true, maxStack: 64, description: '制作铁制工具', biome: 'plains' },
  { id: 231, name: '金锭', type: 'material', stackable: true, maxStack: 64, description: '制作金制工具', biome: 'desert' },
  { id: 232, name: '钻石', type: 'material', stackable: true, maxStack: 64, description: '最珍贵的材料', biome: 'plains' },
  { id: 233, name: '红石粉', type: 'material', stackable: true, maxStack: 64, description: '制作红石电路', biome: 'plains' },
  { id: 234, name: '火药', type: 'material', stackable: true, maxStack: 64, description: '制作TNT', biome: 'plains' },
  { id: 235, name: '粘液球', type: 'material', stackable: true, maxStack: 64, description: '制作粘性活塞', biome: 'swamp' },
  { id: 236, name: '皮革', type: 'material', stackable: true, maxStack: 64, description: '制作皮革装备', biome: 'plains' },
  { id: 237, name: '线', type: 'material', stackable: true, maxStack: 64, description: '制作弓和钓鱼竿', biome: 'plains' },
  { id: 238, name: '羽毛', type: 'material', stackable: true, maxStack: 64, description: '制作箭', biome: 'plains' },
  { id: 239, name: '燧石', type: 'material', stackable: true, maxStack: 64, description: '制作打火石', biome: 'plains' },
  
  // 弹药类
  { id: 240, name: '箭', type: 'ammo', stackable: true, maxStack: 64, description: '弓的弹药', biome: 'plains' },
  { id: 241, name: '火焰箭', type: 'ammo', stackable: true, maxStack: 64, description: '造成火焰伤害', biome: 'nether' },
  { id: 242, name: '药水箭', type: 'ammo', stackable: true, maxStack: 64, description: '带有药水效果', biome: 'swamp' },
  
  // 特殊物品
  { id: 250, name: '指南针', type: 'special', stackable: false, maxStack: 1, description: '指向出生点', biome: 'plains' },
  { id: 251, name: '时钟', type: 'special', stackable: false, maxStack: 1, description: '显示时间', biome: 'plains' },
  { id: 252, name: '地图', type: 'special', stackable: false, maxStack: 1, description: '显示周围地形', biome: 'plains' },
  { id: 253, name: '鞘翅', type: 'special', stackable: false, maxStack: 1, description: '滑翔飞行', biome: 'end' },
  { id: 254, name: '末影珍珠', type: 'special', stackable: true, maxStack: 16, description: '传送', biome: 'end' },
  { id: 255, name: '火焰弹', type: 'special', stackable: true, maxStack: 64, description: '发射火焰', biome: 'nether' },
];

// 群系特定道具映射
export const BIOME_ITEMS: Record<string, number[]> = {
  plains: [200, 201, 210, 211, 220, 221, 222, 223, 224, 225, 226, 230, 232, 233, 234, 236, 237, 238, 239, 240, 250, 251, 252],
  forest: [202, 212, 220, 237, 238, 240],
  desert: [203, 231, 255],
  ocean: [204, 213, 228],
  swamp: [224, 227, 235, 242],
  nether: [214, 225, 241, 255],
  end: [253, 254],
};
