/** 扩展生物系统 - 25+群系特定生物 */

export interface MobDefNew {
  id: number;
  name: string;
  type: 'passive' | 'neutral' | 'hostile' | 'boss';
  biome: string;
  health: number;
  damage: number;
  speed: number;
  drops: number[]; // 掉落物品ID
  behavior: 'wander' | 'chase' | 'flee' | 'guard' | 'fly';
  spawnRate: number; // 0-1
  description?: string;
}

export const NEW_MOBS: MobDefNew[] = [
  // 平原群系生物
  { id: 300, name: '牛', type: 'passive', biome: 'plains', health: 10, damage: 0, speed: 1.2, drops: [236], behavior: 'wander', spawnRate: 0.3, description: '提供皮革和牛肉' },
  { id: 301, name: '猪', type: 'passive', biome: 'plains', health: 10, damage: 0, speed: 1.0, drops: [222], behavior: 'wander', spawnRate: 0.3, description: '提供猪肉' },
  { id: 302, name: '羊', type: 'passive', biome: 'plains', health: 8, damage: 0, speed: 1.1, drops: [236], behavior: 'wander', spawnRate: 0.3, description: '提供羊毛' },
  { id: 303, name: '鸡', type: 'passive', biome: 'plains', health: 4, damage: 0, speed: 1.3, drops: [238], behavior: 'wander', spawnRate: 0.4, description: '提供羽毛和鸡蛋' },
  { id: 304, name: '马', type: 'passive', biome: 'plains', health: 20, damage: 0, speed: 2.5, drops: [236], behavior: 'wander', spawnRate: 0.15, description: '可以骑乘' },
  { id: 305, name: '村民', type: 'passive', biome: 'plains', health: 20, damage: 0, speed: 1.0, drops: [], behavior: 'wander', spawnRate: 0.2, description: '可以交易' },
  { id: 306, name: '僵尸', type: 'hostile', biome: 'plains', health: 20, damage: 3, speed: 1.0, drops: [220], behavior: 'chase', spawnRate: 0.3, description: '夜晚出现' },
  { id: 307, name: '骷髅', type: 'hostile', biome: 'plains', health: 20, damage: 4, speed: 1.2, drops: [240], behavior: 'chase', spawnRate: 0.25, description: '远程攻击' },
  { id: 308, name: '苦力怕', type: 'hostile', biome: 'plains', health: 20, damage: 10, speed: 1.0, drops: [234], behavior: 'chase', spawnRate: 0.2, description: '会爆炸' },
  { id: 309, name: '蜘蛛', type: 'neutral', biome: 'plains', health: 16, damage: 2, speed: 1.5, drops: [237], behavior: 'chase', spawnRate: 0.2, description: '夜晚攻击' },
  
  // 森林群系生物
  { id: 310, name: '狼', type: 'neutral', biome: 'forest', health: 16, damage: 4, speed: 2.0, drops: [236], behavior: 'chase', spawnRate: 0.15, description: '可以驯服' },
  { id: 311, name: '狐狸', type: 'passive', biome: 'forest', health: 10, damage: 0, speed: 1.8, drops: [236], behavior: 'flee', spawnRate: 0.2, description: '偷取物品' },
  { id: 312, name: '兔子', type: 'passive', biome: 'forest', health: 3, damage: 0, speed: 2.0, drops: [236], behavior: 'flee', spawnRate: 0.3, description: '快速逃跑' },
  { id: 313, name: '豹猫', type: 'neutral', biome: 'forest', health: 10, damage: 3, speed: 2.2, drops: [236], behavior: 'chase', spawnRate: 0.1, description: '可以驯服' },
  { id: 314, name: '鹦鹉', type: 'passive', biome: 'forest', health: 6, damage: 0, speed: 1.5, drops: [238], behavior: 'fly', spawnRate: 0.2, description: '可以驯服' },
  { id: 315, name: '熊', type: 'neutral', biome: 'forest', health: 30, damage: 6, speed: 1.5, drops: [236], behavior: 'guard', spawnRate: 0.08, description: '保护幼崽' },
  
  // 沙漠群系生物
  { id: 320, name: '骆驼', type: 'passive', biome: 'desert', health: 20, damage: 0, speed: 1.8, drops: [236], behavior: 'wander', spawnRate: 0.15, description: '可以骑乘' },
  { id: 321, name: '蝎子', type: 'hostile', biome: 'desert', health: 12, damage: 5, speed: 1.5, drops: [237], behavior: 'chase', spawnRate: 0.2, description: '有毒' },
  { id: 322, name: '沙漠僵尸', type: 'hostile', biome: 'desert', health: 20, damage: 3, speed: 1.0, drops: [231], behavior: 'chase', spawnRate: 0.3, description: '夜晚出现' },
  { id: 323, name: '骷髅马', type: 'hostile', biome: 'desert', health: 15, damage: 4, speed: 2.5, drops: [238], behavior: 'chase', spawnRate: 0.1, description: '快速攻击' },
  
  // 海洋群系生物
  { id: 330, name: '海豚', type: 'passive', biome: 'ocean', health: 10, damage: 0, speed: 2.5, drops: [], behavior: 'wander', spawnRate: 0.2, description: '友好' },
  { id: 331, name: '海龟', type: 'passive', biome: 'ocean', health: 20, damage: 0, speed: 0.8, drops: [236], behavior: 'wander', spawnRate: 0.15, description: '产卵' },
  { id: 332, name: '溺尸', type: 'hostile', biome: 'ocean', health: 20, damage: 4, speed: 1.0, drops: [231], behavior: 'chase', spawnRate: 0.25, description: '水下攻击' },
  { id: 333, name: '守卫者', type: 'hostile', biome: 'ocean', health: 30, damage: 6, speed: 1.2, drops: [232], behavior: 'guard', spawnRate: 0.1, description: '守护海底神殿' },
  { id: 334, name: '鲨鱼', type: 'hostile', biome: 'ocean', health: 25, damage: 8, speed: 2.0, drops: [236], behavior: 'chase', spawnRate: 0.15, description: '快速攻击' },
  
  // 沼泽群系生物
  { id: 340, name: '青蛙', type: 'passive', biome: 'swamp', health: 6, damage: 0, speed: 1.5, drops: [], behavior: 'wander', spawnRate: 0.3, description: '吃虫子' },
  { id: 341, name: '史莱姆', type: 'hostile', biome: 'swamp', health: 16, damage: 3, speed: 1.0, drops: [235], behavior: 'chase', spawnRate: 0.25, description: '分裂' },
  { id: 342, name: '女巫', type: 'hostile', biome: 'swamp', health: 26, damage: 5, speed: 1.2, drops: [224, 227], behavior: 'chase', spawnRate: 0.15, description: '投掷药水' },
  { id: 343, name: '沼泽僵尸', type: 'hostile', biome: 'swamp', health: 20, damage: 3, speed: 0.9, drops: [235], behavior: 'chase', spawnRate: 0.3, description: '缓慢但强壮' },
  
  // 雪原群系生物
  { id: 350, name: '北极熊', type: 'neutral', biome: 'snow', health: 30, damage: 6, speed: 1.5, drops: [236], behavior: 'guard', spawnRate: 0.1, description: '保护幼崽' },
  { id: 351, name: '雪傀儡', type: 'passive', biome: 'snow', health: 4, damage: 0, speed: 1.0, drops: [], behavior: 'guard', spawnRate: 0.15, description: '投掷雪球' },
  { id: 352, name: '流浪者', type: 'hostile', biome: 'snow', health: 20, damage: 4, speed: 1.0, drops: [241], behavior: 'chase', spawnRate: 0.2, description: '发射缓慢箭' },
  { id: 353, name: '雪怪', type: 'hostile', biome: 'snow', health: 40, damage: 8, speed: 1.2, drops: [236], behavior: 'chase', spawnRate: 0.08, description: 'Boss级生物' },
  
  // 下界群系生物
  { id: 360, name: '僵尸猪灵', type: 'neutral', biome: 'nether', health: 20, damage: 5, speed: 1.5, drops: [231], behavior: 'guard', spawnRate: 0.3, description: '攻击时群起' },
  { id: 361, name: '烈焰人', type: 'hostile', biome: 'nether', health: 20, damage: 6, speed: 1.2, drops: [234], behavior: 'fly', spawnRate: 0.2, description: '发射火球' },
  { id: 362, name: '恶魂', type: 'hostile', biome: 'nether', health: 10, damage: 10, speed: 1.0, drops: [234], behavior: 'fly', spawnRate: 0.15, description: '远程爆炸' },
  { id: 363, name: '岩浆怪', type: 'hostile', biome: 'nether', health: 16, damage: 4, speed: 1.0, drops: [235], behavior: 'chase', spawnRate: 0.2, description: '跳跃攻击' },
  
  // 末地群系生物
  { id: 370, name: '末影人', type: 'neutral', biome: 'end', health: 40, damage: 7, speed: 2.0, drops: [254], behavior: 'chase', spawnRate: 0.2, description: '瞬移' },
  { id: 371, name: '末影龙', type: 'boss', biome: 'end', health: 200, damage: 15, speed: 1.5, drops: [253], behavior: 'fly', spawnRate: 0.01, description: '最终Boss' },
  { id: 372, name: '潜影贝', type: 'hostile', biome: 'end', health: 30, damage: 5, speed: 0.5, drops: [254], behavior: 'guard', spawnRate: 0.15, description: '发射导弹' },
];

// 群系生物映射
export const BIOME_MOBS: Record<string, number[]> = {
  plains: [300, 301, 302, 303, 304, 305, 306, 307, 308, 309],
  forest: [310, 311, 312, 313, 314, 315],
  desert: [320, 321, 322, 323],
  ocean: [330, 331, 332, 333, 334],
  swamp: [340, 341, 342, 343],
  snow: [350, 351, 352, 353],
  nether: [360, 361, 362, 363],
  end: [370, 371, 372],
};
