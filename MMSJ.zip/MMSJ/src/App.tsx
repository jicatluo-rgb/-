import { useCallback, useEffect, useRef, useState } from 'react';
import StartScreen, { type StartConfig } from './ui/StartScreen';
import Hud from './ui/Hud';
import Inventory from './ui/Inventory';
import ChestUI from './ui/ChestUI';
import CraftTable from './ui/CraftTable';
import PauseMenu, { type Settings } from './ui/PauseMenu';
import TouchControls from './ui/TouchControls';
import { Game, type HudState, type Mode, type SaveData } from './game/engine';
import type { ItemStack } from './game/items';
import { sfx } from './game/audio';
import { MWButton, Panel } from './ui/kit';
import { exportSingleHTML } from './utils/exportHtml';

const DEFAULT_STATE: HudState = {
  fps: 0,
  x: 0,
  y: 0,
  z: 0,
  mode: 'creative',
  health: 20,
  hunger: 20,
  air: 1,
  timeOfDay: 0.28,
  biome: 'plains',
  chunks: 0,
  flying: true,
  inWater: false,
  breakProgress: 0,
  targetName: null,
  loading: 0,
  dead: false,
  mobCount: 0,
  hostileCount: 0,
  bossName: null,
  bossHealth: 0,
  bossMaxHealth: 0,
  quests: [],
  wave: 0,
  waveMode: false,
  activeMods: [],
  raining: false,
  ammo: 0,
  stamina: 10,
  thirst: 10,
  temp: 5,
  day: 1,
  fear: 0,
  glitch: 0,
};

const TIPS = [
  '双击空格可以开启飞行，像小鸟一样俯瞰世界～',
  '按住左键可以持续挖掘方块，生存模式下石头更难挖哦！',
  '按 E 打开背包，把喜欢的方块放进快捷栏。',
  '试试用彩虹块和糖果块盖一座梦幻城堡吧！',
  '夜晚会有点黑，记得带上荧光石照明～',
  '中键（滚轮点击）可以快速拾取你看到的方块。',
  '世界里会生成村庄、遗迹和祭坛，右键战利品箱可以打开。',
  '按 E 打开合成工坊，利用采集到的材料制作稀有方块。',
  '蛊真兴只会在夜晚的祭坛附近现身，击败它可获得秘境水晶。',
  '用镐挖石头、用斧砍树、用铲铲土，对应工具事半功倍！',
  '按 Q 打开冒险目标，完成目标会获得奖励。',
  '火把能照亮黑夜，遇到怪物记得用剑反击！',
];

const SAVE_KEY = 'mini-block-world-save-v1';

/** 读取已启用的玩法模组 */
function loadActiveMods(): string[] {
  try {
    const raw = JSON.parse(localStorage.getItem('msw-mods-on') ?? '[]') as unknown;
    return Array.isArray(raw) ? raw.filter((x): x is string => typeof x === 'string') : [];
  } catch {
    return [];
  }
}

function loadSave(): SaveData | null {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    return raw ? (JSON.parse(raw) as SaveData) : null;
  } catch {
    return null;
  }
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [saved, setSaved] = useState<SaveData | null>(() => loadSave());
  const [pendingSave, setPendingSave] = useState<SaveData | null>(null);
  const [screen, setScreen] = useState<'menu' | 'game'>('menu');
  const [config, setConfig] = useState<StartConfig | null>(null);
  const [state, setState] = useState<HudState>(DEFAULT_STATE);
  const [inv, setInv] = useState<(ItemStack | null)[]>(Array.from({ length: 36 }, () => null));
  const [selected, setSelected] = useState(0);
  const [chestSlots, setChestSlots] = useState<(ItemStack | null)[] | null>(null);
  const [craft2, setCraft2] = useState<(ItemStack | null)[]>(Array.from({ length: 4 }, () => null));
  const [craft2Result, setCraft2Result] = useState<ItemStack | null>(null);
  const [craft3, setCraft3] = useState<(ItemStack | null)[]>(Array.from({ length: 9 }, () => null));
  const [craft3Result, setCraft3Result] = useState<ItemStack | null>(null);
  const [overlay, setOverlay] = useState<null | 'inventory' | 'pause' | 'chest' | 'craft'>(null);
  const [showQuests, setShowQuests] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [locked, setLocked] = useState(false);
  const [ready, setReady] = useState(false);
  const [tip] = useState(() => TIPS[Math.floor(Math.random() * TIPS.length)]);
  const [isTouch] = useState(
    () => typeof window !== 'undefined' && ('ontouchstart' in window || navigator.maxTouchPoints > 0),
  );
  const [settings, setSettings] = useState<Settings>({
    renderDistance: 6,
    sensitivity: 1,
    volume: 0.5,
    dayNight: true,
    timeOfDay: 0.28,
    bloom: false,
    ssr: false,
    ssao: false,
    godray: false,
    dof: false,
    motionBlur: false,
    hdPBR: false,
  });
  const toastTimer = useRef<number | null>(null);

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(null), 1900);
  }, []);

  /* ---------------- boot game ---------------- */
  useEffect(() => {
    if (screen !== 'game' || !config || !canvasRef.current) return;
    sfx.volume = settings.volume;
    const game = new Game(canvasRef.current, {
      seed: config.seed,
      worldType: config.worldType,
      mode: config.mode,
      renderDistance: config.renderDistance,
      save: pendingSave,
      waveGame: config.waveGame,
      mods: config.mods,
      onState: setState,
      onInventory: (slots, sel) => {
        setInv(slots);
        setSelected(sel);
      },
      onChest: (slots) => {
        setChestSlots(slots);
        setOverlay('chest');
      },
      onGrid2: (grid, result) => {
        setCraft2(grid);
        setCraft2Result(result);
      },
      onCraftTable: (grid, result) => {
        setCraft3(grid);
        setCraft3Result(result);
        setOverlay('craft');
      },
      onLockChange: setLocked,
      onToast: showToast,
    });
    gameRef.current = game;
    setInv([...game.inventory]);
    setSettings((s) => ({ ...s, renderDistance: config.renderDistance }));
    return () => {
      game.dispose();
      gameRef.current = null;
      setReady(false);
      setState(DEFAULT_STATE);
    };
  }, [screen, config, showToast]);

  useEffect(() => {
    if (state.loading >= 0.999 && !ready) {
      setReady(true);
      showToast('🌟 欢迎来到我的秘密世界！好玩才是硬道理！');
    }
  }, [state.loading, ready, showToast]);

  /* ---------------- settings sync ---------------- */
  useEffect(() => {
    const g = gameRef.current;
    if (!g) return;
    g.setRenderDistance(settings.renderDistance);
    g.sensitivity = 0.0022 * settings.sensitivity;
    g.setDayNight(settings.dayNight);
    sfx.volume = settings.volume;
    if (!settings.dayNight) g.setTimeOfDay(settings.timeOfDay);
    g.setBloom(settings.bloom);
    g.setSSR(settings.ssr);
    g.setSSAO(settings.ssao);
    g.setGodray(settings.godray);
    g.setDOF(settings.dof);
    g.setMotionBlur(settings.motionBlur);
    g.setHDPBR(settings.hdPBR);
  }, [settings]);

  /* ---------------- pause handling ---------------- */
  useEffect(() => {
    const g = gameRef.current;
    if (!g) return;
    g.setPaused(overlay !== null);
    if (overlay !== null) g.exitLock();
  }, [overlay]);

  /* ---------------- hotkeys ---------------- */
  useEffect(() => {
    if (screen !== 'game') return;
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA')) {
        if (e.code === 'Escape') (t as HTMLInputElement).blur();
        return;
      }
      if (e.code === 'KeyQ') {
        e.preventDefault();
        setShowQuests((v) => !v);
      } else if (e.code === 'KeyE') {
        e.preventDefault();
        setOverlay((o) => (o === 'inventory' ? null : 'inventory'));
      } else if (e.code === 'Escape') {
        setOverlay((o) => (o ? null : 'pause'));
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [screen]);

  const resume = useCallback(() => {
    gameRef.current?.closeCraft2();
    gameRef.current?.closeCraftTable();
    setChestSlots(null);
    setOverlay(null);
    if (!isTouch) setTimeout(() => gameRef.current?.requestLock(), 60);
  }, [isTouch]);

  const persist = useCallback(() => {
    const g = gameRef.current;
    if (!g) return;
    const doSave = () => {
      try {
        const data = g.serialize();
        localStorage.setItem(SAVE_KEY, JSON.stringify(data));
        setSaved(data);
      } catch {
        /* storage may be full or unavailable */
      }
    };
    // Run serialization when the browser is idle so autosave never causes a hitch.
    const w = window as unknown as { requestIdleCallback?: (cb: () => void, opts?: { timeout: number }) => void };
    if (typeof w.requestIdleCallback === 'function') {
      w.requestIdleCallback(doSave, { timeout: 2500 });
    } else {
      setTimeout(doSave, 350);
    }
  }, []);

  // autosave every 25 seconds
  useEffect(() => {
    if (screen !== 'game' || !ready) return;
    const id = window.setInterval(persist, 25000);
    return () => window.clearInterval(id);
  }, [screen, ready, persist]);

  const handleExportHTML = useCallback(async () => {
    const copied = await exportSingleHTML();
    showToast(copied ? '✅ 单HTML已复制到剪贴板并下载！可离线运行' : '📦 单HTML已下载！可离线运行');
  }, [showToast]);

  const quit = useCallback(() => {
    persist();
    showToast('💾 世界已保存');
    setOverlay(null);
    setScreen('menu');
    setConfig(null);
    setPendingSave(null);
  }, [persist, showToast]);

  if (screen === 'menu') {
    return (
      <div className="fixed inset-0">
        <StartScreen
          saved={saved}
          onExportHTML={() => void handleExportHTML()}
          onStart={(c) => {
            sfx.resume();
            setPendingSave(null);
            setConfig(c);
            setSettings((s) => ({ ...s, renderDistance: c.renderDistance }));
            setScreen('game');
          }}
          onContinue={() => {
            if (!saved) return;
            sfx.resume();
            setPendingSave(saved);
            setConfig({
              mode: saved.mode,
              worldType: saved.worldType,
              seed: saved.seed,
              renderDistance: settings.renderDistance,
              mods: loadActiveMods(),
            });
            setScreen('game');
          }}
          onDeleteSave={() => {
            localStorage.removeItem(SAVE_KEY);
            setSaved(null);
          }}
        />
      </div>
    );
  }

  return (
    <div className="fixed inset-0 overflow-hidden bg-[#8fd3ff]">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 h-full w-full touch-none"
        onClick={() => {
          if (!isTouch && !overlay) gameRef.current?.requestLock();
        }}
      />

      {/* underwater tint */}
      {state.inWater && <div className="pointer-events-none absolute inset-0 bg-[#2f8fd0]/35 mix-blend-multiply" />}
      {/* low health vignette */}
      {state.mode === 'survival' && state.health <= 6 && !state.dead && (
        <div
          className="pointer-events-none absolute inset-0 animate-pulse"
          style={{ boxShadow: 'inset 0 0 140px rgba(220,30,40,0.75)' }}
        />
      )}

      <Hud
        state={state}
        hotbar={inv.slice(0, 9)}
        selected={selected}
        onSelect={(i) => gameRef.current?.setSelected(i)}
        onOpenInventory={() => setOverlay('inventory')}
        onOpenMenu={() => setOverlay('pause')}
        onToggleFly={() => gameRef.current?.toggleFly()}
        onCycleCamera={() => gameRef.current?.cycleCamera()}
        toast={toast}
        locked={locked || isTouch || overlay !== null}
        isTouch={isTouch}
        showQuests={showQuests}
        onToggleQuests={() => setShowQuests((v) => !v)}
      />

      {isTouch && !overlay && (
        <TouchControls
          onMove={(x, z) => gameRef.current?.setTouchMove(x, z)}
          onLook={(dx, dy) => gameRef.current?.touchLook(dx, dy)}
          onJump={() => gameRef.current?.triggerJump()}
          onPlace={() => gameRef.current?.triggerPlace()}
          onBreak={(d) => gameRef.current?.setBreaking(d)}
          onToggleFly={() => gameRef.current?.toggleFly()}
          flying={state.flying}
          creative={state.mode === 'creative'}
        />
      )}

      {overlay === 'inventory' && (
        <Inventory
          inv={inv}
          selected={selected}
          mode={state.mode}
          craft2={craft2}
          craft2Result={craft2Result}
          onAssign={(id) => gameRef.current?.selectOrSetBlock(id)}
          onMove={(fz, fi, tz, ti) => gameRef.current?.moveSlot(fz as 'inv' | 'craft2', fi, tz as 'inv' | 'craft2', ti)}
          onQuickMove={(z, i) => gameRef.current?.quickMove(z as 'inv' | 'craft2', i)}
          onTakeResult={() => gameRef.current?.takeCraftResult('craft2')}
          onLoadRecipe={(recipeId) => gameRef.current?.loadRecipeToGrid(recipeId, 'craft2')}
          onClose={resume}
        />
      )}

      {overlay === 'craft' && (
        <CraftTable
          craft3={craft3}
          craft3Result={craft3Result}
          inv={inv}
          selected={selected}
          mode={state.mode}
          onMove={(fz, fi, tz, ti) => gameRef.current?.moveSlot(fz as 'inv' | 'craft', fi, tz as 'inv' | 'craft', ti)}
          onQuickMove={(z, i) => gameRef.current?.quickMove(z as 'inv' | 'craft', i)}
          onTakeResult={() => gameRef.current?.takeCraftResult('craft')}
          onLoadRecipe={(recipeId) => gameRef.current?.loadRecipeToGrid(recipeId, 'craft')}
          onClose={() => {
            gameRef.current?.closeCraftTable();
            resume();
          }}
        />
      )}

      {overlay === 'chest' && chestSlots && (
        <ChestUI
          chestSlots={chestSlots}
          inv={inv}
          selected={selected}
          mode={state.mode}
          onMove={(fz, fi, tz, ti) =>
            gameRef.current?.moveSlot(fz as 'inv' | 'chest', fi, tz as 'inv' | 'chest', ti)
          }
          onQuickMove={(z, i) => gameRef.current?.quickMove(z as 'inv' | 'chest', i)}
          onTakeAll={() => gameRef.current?.takeAllChest()}
          onClose={() => {
            gameRef.current?.closeChest();
            resume();
          }}
        />
      )}

      {overlay === 'pause' && (
        <PauseMenu
          settings={settings}
          mode={state.mode}
          onChange={(s) => setSettings((prev) => ({ ...prev, ...s }))}
          onResume={resume}
          onClose={resume}
          onSetMode={(m: Mode) => gameRef.current?.setMode(m)}
          onTeleport={() => {
            gameRef.current?.respawn();
            resume();
          }}
          onSave={() => {
            persist();
            showToast('💾 世界已保存');
          }}
          onExportHTML={() => void handleExportHTML()}
          onQuit={quit}
        />
      )}

      {/* death screen */}
      {state.dead && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-red-900/45 backdrop-blur-sm">
          <Panel title="你倒下了" className="w-full max-w-sm text-center">
            <div className="space-y-3 pt-2">
              <div className="text-5xl">💀</div>
              <p className="text-sm font-bold text-[#a5713f]">别灰心，方块世界永远欢迎你回来！</p>
              <MWButton
                className="w-full py-3 text-lg"
                onClick={() => {
                  gameRef.current?.respawn();
                  if (!isTouch) setTimeout(() => gameRef.current?.requestLock(), 60);
                }}
              >
                🌱 重新出生
              </MWButton>
              <MWButton variant="gray" className="w-full" onClick={quit}>
                🏠 返回主菜单
              </MWButton>
            </div>
          </Panel>
        </div>
      )}

      {/* loading */}
      {!ready && (
        <div className="absolute inset-0 z-40 flex flex-col items-center justify-center gap-6 bg-gradient-to-b from-[#6ec6ff] to-[#d8f3c8]">
          <div className="animate-[floaty_2.6s_ease-in-out_infinite] text-6xl">🧱</div>
          <div
            className="text-3xl font-black text-white"
            style={{ textShadow: '0 4px 0 #3ba13a, 0 8px 18px rgba(0,0,0,0.3)' }}
          >
            正在生成秘密世界…
          </div>
          <div className="h-6 w-72 overflow-hidden rounded-full border-[4px] border-white bg-white/40 shadow-inner">
            <div
              className="h-full rounded-full bg-gradient-to-r from-[#ffd166] to-[#ff9f1c] transition-all duration-200"
              style={{ width: `${Math.round(state.loading * 100)}%` }}
            />
          </div>
          <div className="max-w-md rounded-2xl border-4 border-white/70 bg-white/40 px-5 py-2 text-center text-sm font-bold text-[#3b4a2f]">
            💡 {tip}
          </div>
        </div>
      )}
    </div>
  );
}
