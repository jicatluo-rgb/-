/** 复制当前页面（已打包为单文件 HTML）到剪贴板，并同时下载一份 offline.html */
export async function exportSingleHTML(): Promise<boolean> {
  const html = document.documentElement.outerHTML;
  let copied = false;

  // 1) Clipboard API
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(html);
      copied = true;
    }
  } catch {
    copied = false;
  }

  // 2) Fallback: hidden textarea + execCommand
  if (!copied) {
    try {
      const ta = document.createElement('textarea');
      ta.value = html;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      copied = document.execCommand('copy');
      ta.remove();
    } catch {
      copied = false;
    }
  }

  // Always also download a copy so the player has the file even if clipboard is blocked.
  try {
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = '我的秘密世界_offline.html';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  } catch {
    /* ignore download errors */
  }

  return copied;
}
